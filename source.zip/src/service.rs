//! Shared product controls. Both the native app and the headless CLI use this
//! service; neither owns a second implementation of account state.
use crate::core::{
    account_router::{AccountRouter, ACCOUNT_SLOTS},
    catalog::ModelCatalog,
    chat_completions,
    config::Config,
    limits::LimitsCache,
};
use crate::login::lib::LoginMethod;
use crate::settings::Settings;
use crate::{app_router, AppState};
use anyhow::{anyhow, bail, Context, Result};
use axum::{
    extract::State,
    http::{HeaderMap, StatusCode},
    routing::post,
    Json, Router,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    collections::VecDeque,
    fs,
    path::{Path, PathBuf},
    sync::Arc,
};
use tokio::sync::Mutex;

#[derive(Clone, Serialize, Deserialize)]
struct ControlAddress {
    port: u16,
    token: String,
}
struct Running {
    shutdown: tokio::sync::oneshot::Sender<()>,
    task: tokio::task::JoinHandle<()>,
    address: ControlAddress,
    config: Arc<Config>,
}
#[derive(Default, Clone, Serialize)]
struct LoginState {
    pending: bool,
    slot: Option<String>,
    error: Option<String>,
    method: Option<LoginMethod>,
    id: Option<String>,
}

pub struct Relay {
    state: AppState,
    running: Mutex<Option<Running>>,
    login_task: Mutex<Option<tokio::task::JoinHandle<()>>>,
    login_state: Arc<Mutex<LoginState>>,
    events: Arc<Mutex<VecDeque<Value>>>,
    settings: Mutex<Settings>,
    _lock: fs::File,
}

fn descriptor(root: &Path) -> PathBuf {
    root.join("control.json")
}
fn private_json(path: &Path, value: &impl Serialize) -> Result<()> {
    let mut file = tempfile::NamedTempFile::new_in(path.parent().context("missing parent")?)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        file.as_file()
            .set_permissions(fs::Permissions::from_mode(0o600))?;
    }
    serde_json::to_writer_pretty(file.as_file_mut(), value)?;
    file.as_file_mut().sync_all()?;
    file.persist(path).map_err(|e| e.error)?;
    Ok(())
}

impl Relay {
    pub async fn new() -> Result<Arc<Self>> {
        let config = Arc::new(Config::load()?);
        fs::create_dir_all(&config.codex_home)
            .context("Relay data directory is not writable; set RELAY_AUTH_DIR")?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(&config.codex_home, fs::Permissions::from_mode(0o700))?;
        }
        let lock = fs::OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(config.codex_home.join("runtime.lock"))?;
        lock.try_lock().context("This relay installation is already open; use its window or the headless control commands")?;
        let api_key = crate::local_key::load(
            &config.codex_home,
            std::env::var("RELAY_API_KEY").ok().as_deref(),
        )?;
        let settings = Settings::load(&config.codex_home)?;
        settings.effective_port()?;
        let accounts = AccountRouter::open(&config.codex_home).await?;
        let client = reqwest::Client::builder()
            .tcp_keepalive(std::time::Duration::from_secs(30))
            .build()?;
        chat_completions::resolve_codex_cli_version(&client).await;
        Ok(Arc::new(Self {
            state: AppState {
                api_key: Some(Arc::from(api_key)),
                config,
                accounts,
                client,
                limits: LimitsCache::default(),
                catalog: ModelCatalog::from_env(),
            },
            running: Mutex::new(None),
            login_task: Mutex::new(None),
            login_state: Arc::new(Mutex::new(LoginState::default())),
            events: Arc::new(Mutex::new(VecDeque::new())),
            settings: Mutex::new(settings),
            _lock: lock,
        }))
    }

    async fn event(&self, message: impl Into<String>) {
        let mut events = self.events.lock().await;
        events.push_front(json!({"time": chrono::Local::now().format("%H:%M:%S").to_string(), "message": message.into()}));
        events.truncate(100);
    }

    pub fn start(self: &Arc<Self>) -> futures_util::future::BoxFuture<'_, Result<()>> {
        Box::pin(async move {
            let mut running = self.running.lock().await;
            if running
                .as_ref()
                .is_some_and(|server| !server.task.is_finished())
            {
                return Ok(());
            }
            *running = None;
            let settings = self.settings.lock().await.clone();
            let port = settings.effective_port()?;
            let listener = tokio::net::TcpListener::bind((std::net::Ipv4Addr::LOCALHOST,port)).await
            .with_context(|| format!("Port {port} is already in use or unavailable. Stop its owner or choose another port."))?;
            let port = listener.local_addr()?.port();
            let address = ControlAddress {
                port,
                token: uuid::Uuid::new_v4().to_string(),
            };
            let control = Router::new()
                .route("/_relay/control", post(control_handler))
                .layer(axum::extract::DefaultBodyLimit::max(32768))
                .with_state((self.clone(), address.token.clone()));
            let config = Arc::new(settings.config(&self.state.config));
            let mut state = self.state.clone();
            state.config = config.clone();
            let app = app_router(state).merge(control);
            private_json(&descriptor(&self.state.config.codex_home), &address)?;
            let (shutdown, receive) = tokio::sync::oneshot::channel();
            let task = tokio::spawn(async move {
                let _ = axum::serve(listener, app)
                    .with_graceful_shutdown(async {
                        let _ = receive.await;
                    })
                    .await;
            });
            *running = Some(Running {
                shutdown,
                task,
                address,
                config,
            });
            self.event(format!("API started on 127.0.0.1:{port}")).await;
            Ok(())
        })
    }

    pub async fn stop(&self) -> Result<()> {
        let mut running = self.running.lock().await;
        if let Some(mut server) = running.take() {
            let _ = server.shutdown.send(());
            if tokio::time::timeout(std::time::Duration::from_secs(3), &mut server.task)
                .await
                .is_err()
            {
                server.task.abort();
            }
            if let Ok(bytes) = fs::read(descriptor(&self.state.config.codex_home)) {
                if serde_json::from_slice::<ControlAddress>(&bytes)
                    .is_ok_and(|a| a.token == server.address.token)
                {
                    let _ = fs::remove_file(descriptor(&self.state.config.codex_home));
                }
            }
            self.event("API stopped").await;
        }
        Ok(())
    }

    pub async fn status(&self) -> Result<Value> {
        let active = self.state.accounts.active_slot().await;
        let mut accounts = vec![];
        for slot in ACCOUNT_SLOTS {
            let file = self.state.accounts.auth_home(slot)?.join("auth.json");
            let auth = crate::login::lib::try_read_auth_json(&file);
            let (email, plan, error) = match auth {
                Ok(auth) => match auth.tokens {
                    Some(tokens) => (
                        tokens.id_token.email.clone(),
                        tokens.id_token.get_chatgpt_plan_type(),
                        None,
                    ),
                    None => (None, None, Some("Subscription credentials required")),
                },
                Err(_) if file.exists() => (
                    None,
                    None,
                    Some("Credentials cannot be read; sign in again"),
                ),
                Err(_) => (None, None, None),
            };
            accounts.push(json!({"slot":slot,"configured":file.is_file(),"active":slot==active && file.is_file(),
                "email":email,"plan":plan,"error":error}));
        }
        let login = self.login_state.lock().await.clone();
        let settings = self.settings.lock().await.clone();
        let desired_port = settings.effective_port()?;
        let desired_config = settings.config(&self.state.config);
        let (running, port, restart_required) = {
            let server = self.running.lock().await;
            match server.as_ref().filter(|r| !r.task.is_finished()) {
                Some(r) => (
                    true,
                    r.address.port,
                    r.address.port != desired_port || *r.config != desired_config,
                ),
                None => (false, desired_port, false),
            }
        };
        let overrides: Vec<&str> = [
            "RELAY_PORT",
            "RELAY_DEFAULT_MODEL",
            "RELAY_REASONING_EFFORT",
            "RELAY_INSTRUCTIONS",
            "RELAY_PARALLEL_TOOL_CALLS",
            "RELAY_API_KEY",
        ]
        .into_iter()
        .filter(|name| std::env::var_os(name).is_some())
        .collect();
        Ok(
            json!({"product":"Praxis Relay","version":env!("CARGO_PKG_VERSION"),"running":running,
            "port":port,"base_url":format!("http://127.0.0.1:{port}/v1"),
            "api_key":self.state.api_key.as_deref(),"auth_directory":self.state.config.codex_home,
            "protocol_version":chat_completions::codex_cli_version(),"accounts":accounts,
            "settings":settings,"restart_required":restart_required,"environment_overrides":overrides,
            "instructions_file":crate::core::config::custom_instructions().map(|_| crate::core::config::instructions_file_path()),
            "login":login,"login_url":if login.pending { crate::login::lib::login_url() } else { None },
            "device_code":if login.pending && login.method == Some(LoginMethod::DeviceCode) { crate::login::lib::device_code_prompt() } else { None },
            "events":self.events.lock().await.clone()}),
        )
    }

    pub async fn preferences(&self) -> Settings {
        self.settings.lock().await.clone()
    }

    pub async fn configure(&self, patch: Value) -> Result<Value> {
        {
            let mut settings = self.settings.lock().await;
            let next = settings.patched(patch)?;
            private_json(&self.state.config.codex_home.join("settings.json"), &next)?;
            *settings = next;
        }
        self.status().await
    }

    pub async fn startup_error(&self, error: String) {
        self.event(format!("API startup failed: {error}")).await;
    }

    pub async fn begin_login(self: &Arc<Self>, slot: &str) -> Result<()> {
        self.begin_login_with_method(slot, LoginMethod::Browser)
            .await
    }

    async fn begin_login_with_method(
        self: &Arc<Self>,
        slot: &str,
        method: LoginMethod,
    ) -> Result<()> {
        self.state.accounts.auth_home(slot)?;
        let mut task = self.login_task.lock().await;
        if task.as_ref().is_some_and(|t| !t.is_finished()) {
            bail!("A login is already in progress; finish or cancel it first");
        }
        crate::login::lib::clear_login_url();
        let id = uuid::Uuid::new_v4().to_string();
        *self.login_state.lock().await = LoginState {
            pending: true,
            slot: Some(slot.to_string()),
            error: None,
            method: Some(method),
            id: Some(id.clone()),
        };
        self.event(format!(
            "Signing in to {slot} using {}",
            if method == LoginMethod::DeviceCode {
                "device code"
            } else {
                "browser"
            }
        ))
        .await;
        let relay = self.clone();
        let slot = slot.to_string();
        *task = Some(tokio::spawn(async move {
            let result = tokio::time::timeout(
                std::time::Duration::from_secs(if method == LoginMethod::DeviceCode {
                    960
                } else {
                    300
                }),
                relay.state.login_account_with_method(&slot, method),
            )
            .await;
            let error = match result {
                Ok(Ok(())) => None,
                Ok(Err(e)) => Some(format!("{e:#}")),
                Err(_) => Some("Login timed out; start sign-in again".into()),
            };
            relay.state.limits.invalidate(&slot).await;
            relay
                .event(if error.is_none() {
                    format!("Signed in to {slot}")
                } else {
                    format!("Sign-in failed for {slot}")
                })
                .await;
            *relay.login_state.lock().await = LoginState {
                pending: false,
                slot: Some(slot),
                error,
                method: Some(method),
                id: Some(id),
            };
            crate::login::lib::clear_login_url();
        }));
        Ok(())
    }

    pub async fn cancel_login(&self) {
        if let Some(task) = self.login_task.lock().await.take() {
            task.abort();
            let _ = task.await;
        }
        *self.login_state.lock().await = LoginState::default();
        crate::login::lib::clear_login_url();
    }

    async fn cancel_login_if_id(&self, id: &str) {
        let mut task = self.login_task.lock().await;
        if self.login_state.lock().await.id.as_deref() != Some(id) {
            return;
        }
        if let Some(task) = task.take() {
            task.abort();
            let _ = task.await;
        }
        *self.login_state.lock().await = LoginState::default();
        crate::login::lib::clear_login_url();
    }

    /// Small command vocabulary is shared by Tauri IPC and authenticated local
    /// headless control. Subscription tokens never cross this boundary.
    pub async fn command(
        self: &Arc<Self>,
        op: &str,
        slot: Option<&str>,
        port: Option<u16>,
    ) -> Result<Value> {
        let wanted = || slot.ok_or_else(|| anyhow!("Choose primary or secondary"));
        match op {
            "status" => return self.status().await,
            "start" => self.start().await?,
            "stop" => self.stop().await?,
            "login" => self.begin_login(wanted()?).await?,
            "login_device" => {
                self.begin_login_with_method(wanted()?, LoginMethod::DeviceCode)
                    .await?
            }
            "cancel_login" => self.cancel_login().await,
            "cancel_login_id" => self.cancel_login_if_id(wanted()?).await,
            "open_login" => {
                let url = crate::login::lib::login_url().context("No login is in progress")?;
                if !url.starts_with("https://auth.openai.com/") {
                    bail!("Unexpected login address");
                }
                #[cfg(windows)]
                {
                    use std::os::windows::process::CommandExt;
                    std::process::Command::new("rundll32.exe")
                        .args(["url.dll,FileProtocolHandler", &url])
                        .creation_flags(0x08000000)
                        .spawn()?;
                }
                #[cfg(target_os = "macos")]
                {
                    std::process::Command::new("open").arg(&url).spawn()?;
                }
                #[cfg(all(unix, not(target_os = "macos")))]
                {
                    std::process::Command::new("xdg-open").arg(&url).spawn()?;
                }
            }
            "logout" => {
                self.cancel_login().await;
                let slots = if slot == Some("all") {
                    ACCOUNT_SLOTS.to_vec()
                } else {
                    vec![wanted()?]
                };
                for slot in slots {
                    self.state.logout_account(slot).await?;
                    self.state.limits.invalidate(slot).await;
                    self.event(format!("Signed out of {slot}")).await;
                }
            }
            "switch" => {
                let slot = wanted()?;
                self.state.switch_account(slot).await?;
                self.event(format!("Active subscription: {slot}")).await;
            }
            "limits" => {
                let slot = wanted()?;
                let account = self.state.accounts.lease_slot(slot).await?;
                return self.state.limits.get_for_account(&account).await;
            }
            "port" => {
                if self.running.lock().await.is_some() {
                    bail!("Stop the API before changing its port");
                }
                let port = port.filter(|p| *p > 0).context("Port must be 1..65535")?;
                return self.configure(json!({"port":port})).await;
            }
            "models" => {
                let snapshot = self
                    .state
                    .catalog
                    .snapshot(&self.state.accounts, &self.state.client)
                    .await;
                return Ok(
                    json!({"source":snapshot.source.as_str(),"models":snapshot.listed_slugs(),
                        "data":crate::core::catalog::model_list_from(&snapshot).data}),
                );
            }
            _ => bail!("Unknown command: {op}"),
        }
        self.status().await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn device_login_uses_the_shared_slot_install_and_clears_public_instructions() {
        use crate::core::catalog::test_support::staged_login;
        let root = tempfile::tempdir().unwrap();
        let relay = isolated(root.path(), 0).await;
        relay
            .state
            .accounts
            .stage_next_login(staged_login("secondary", "device-account"));
        relay
            .command("login_device", Some("secondary"), None)
            .await
            .unwrap();
        let task = relay.login_task.lock().await.take().unwrap();
        task.await.unwrap();
        let status = relay.status().await.unwrap();
        assert_eq!(status["login"]["method"], "device_code");
        assert_eq!(status["login"]["pending"], false);
        assert!(status["login"]["error"].is_null());
        assert!(status["device_code"].is_null());
        assert!(status["login_url"].is_null());
        let auth = crate::login::lib::try_read_auth_json(
            &root.path().join("accounts/secondary/auth.json"),
        )
        .unwrap();
        assert_eq!(
            auth.tokens.unwrap().account_id.as_deref(),
            Some("device-account")
        );
    }

    #[tokio::test]
    async fn stale_cli_cancellation_cannot_cancel_a_new_signin() {
        use crate::core::catalog::test_support::{staged_login, write_account};
        let root = tempfile::tempdir().unwrap();
        write_account(root.path(), "primary", "original-account");
        let relay = isolated(root.path(), 0).await;
        let lease = relay.state.accounts.hold_refresh_for_test("primary").await;
        relay
            .state
            .accounts
            .stage_next_login(staged_login("primary", "replacement-account"));
        relay
            .begin_login_with_method("primary", LoginMethod::DeviceCode)
            .await
            .unwrap();
        let id = relay.login_state.lock().await.id.clone().unwrap();
        tokio::task::yield_now().await;
        relay.cancel_login_if_id("stale-id").await;
        assert!(relay.login_state.lock().await.pending);
        relay.cancel_login_if_id(&id).await;
        assert!(!relay.login_state.lock().await.pending);
        let auth =
            crate::login::lib::try_read_auth_json(&root.path().join("accounts/primary/auth.json"))
                .unwrap();
        assert_eq!(
            auth.tokens.unwrap().account_id.as_deref(),
            Some("original-account")
        );
        drop(lease);
    }

    async fn isolated(root: &Path, port: u16) -> Arc<Relay> {
        isolated_with_catalog(root, port, ModelCatalog::from_env()).await
    }

    async fn isolated_with_catalog(root: &Path, port: u16, catalog: ModelCatalog) -> Arc<Relay> {
        let config = Arc::new(Config {
            codex_home: root.to_path_buf(),
            chatgpt_base_url: "https://invalid.example".into(),
            model: "test".into(),
            user_instructions: None,
            reasoning_effort: None,
            instructions_mode: None,
            parallel_tool_calls: true,
        });
        let lock = fs::File::create(root.join("lock")).unwrap();
        Arc::new(Relay {
            state: AppState {
                api_key: Some(Arc::from("test-relay-client-key")),
                config,
                accounts: AccountRouter::open(root).await.unwrap(),
                client: reqwest::Client::new(),
                limits: LimitsCache::default(),
                catalog,
            },
            running: Mutex::new(None),
            login_task: Mutex::new(None),
            login_state: Arc::new(Mutex::new(LoginState::default())),
            events: Arc::new(Mutex::new(VecDeque::new())),
            settings: Mutex::new(Settings {
                port,
                ..Settings::default()
            }),
            _lock: lock,
        })
    }

    #[tokio::test]
    async fn settings_persist_without_mutating_running_config_or_credentials() {
        let root = tempfile::tempdir().unwrap();
        let relay = isolated(root.path(), 0).await;
        relay.start().await.unwrap();
        let port = relay.status().await.unwrap()["port"].as_u64().unwrap() as u16;
        let result = relay.configure(json!({"port":port,"defaults":{"model":"configured-model","reasoning":"high","instructions_mode":"minimal","instructions":"Owner instructions"},"labels":{"primary":"Work"}})).await.unwrap();
        assert_eq!(result["restart_required"], true);
        assert_ne!(
            relay.running.lock().await.as_ref().unwrap().config.model,
            "configured-model"
        );
        let persisted = fs::read(root.path().join("settings.json")).unwrap();
        assert!(relay.configure(json!({"port":0})).await.is_err());
        assert_eq!(
            fs::read(root.path().join("settings.json")).unwrap(),
            persisted
        );
        relay.stop().await.unwrap();
        relay.start().await.unwrap();
        assert_eq!(relay.status().await.unwrap()["restart_required"], false);
        {
            let running = relay.running.lock().await;
            let config = &running.as_ref().unwrap().config;
            assert_eq!(config.model, "configured-model");
            assert_eq!(config.reasoning_effort.as_deref(), Some("high"));
            assert!(config.minimal_instructions());
            assert!(config
                .user_instructions
                .as_deref()
                .unwrap()
                .contains("Owner instructions"));
        }
        let value = relay
            .configure(json!({"appearance":{"theme":"dark"}}))
            .await
            .unwrap();
        assert_eq!(value["restart_required"], false);
        let saved = Settings::load(root.path()).unwrap();
        assert_eq!(saved.labels.primary, "Work");
        assert_eq!(saved.defaults.model, "configured-model");
        relay.stop().await.unwrap();
        assert!(!root.path().join("auth.json").exists());
    }

    #[tokio::test]
    async fn model_and_image_requests_require_the_installation_key() {
        let root = tempfile::tempdir().unwrap();
        let relay = isolated(root.path(), 0).await;
        relay.start().await.unwrap();
        let address: ControlAddress =
            serde_json::from_slice(&fs::read(descriptor(root.path())).unwrap()).unwrap();
        let base = format!("http://127.0.0.1:{}", address.port);
        let client = reqwest::Client::new();
        for route in [
            "/v1/chat/completions",
            "/v1/images/generations",
            "/v1/images/edits",
        ] {
            for key in [None, Some("relay"), Some("wrong-key")] {
                let mut request = client.post(format!("{base}{route}")).json(&json!({}));
                if let Some(key) = key {
                    request = request.bearer_auth(key);
                }
                assert_eq!(request.send().await.unwrap().status(), 401, "{route}");
            }
        }
        let image_catalog = format!("{base}/v1/images/models");
        assert_eq!(
            client.get(&image_catalog).send().await.unwrap().status(),
            401
        );
        assert_eq!(
            client
                .get(&image_catalog)
                .bearer_auth("test-relay-client-key")
                .send()
                .await
                .unwrap()
                .status(),
            200
        );
        relay.stop().await.unwrap();
    }

    #[tokio::test]
    async fn headless_controls_require_local_secret_and_reject_browser_origins() {
        let root = tempfile::tempdir().unwrap();
        let relay = isolated(root.path(), 0).await;
        relay.start().await.unwrap();
        let address: ControlAddress =
            serde_json::from_slice(&fs::read(descriptor(root.path())).unwrap()).unwrap();
        let url = format!("http://127.0.0.1:{}/_relay/control", address.port);
        let client = reqwest::Client::new();
        let body = json!({"op":"status","slot":null,"port":null});
        assert_eq!(
            client.post(&url).json(&body).send().await.unwrap().status(),
            403
        );
        assert_eq!(
            client
                .post(&url)
                .header("x-relay-control", "wrong")
                .json(&body)
                .send()
                .await
                .unwrap()
                .status(),
            403
        );
        assert_eq!(
            client
                .post(&url)
                .header("x-relay-control", &address.token)
                .header("origin", "https://untrusted.example")
                .json(&body)
                .send()
                .await
                .unwrap()
                .status(),
            403
        );
        let response = client
            .post(&url)
            .header("x-relay-control", &address.token)
            .json(&body)
            .send()
            .await
            .unwrap();
        assert_eq!(response.status(), 200);
        let value: Value = response.json().await.unwrap();
        assert_eq!(value["running"], true);
        assert!(value["accounts"]
            .as_array()
            .unwrap()
            .iter()
            .all(|a| a["configured"] == false));
        assert!(value.get("tokens").is_none());
        relay.stop().await.unwrap();
        assert!(!descriptor(root.path()).exists());
        assert!(
            tokio::net::TcpListener::bind((std::net::Ipv4Addr::LOCALHOST, address.port))
                .await
                .is_ok()
        );
    }

    #[tokio::test]
    async fn the_switch_control_refreshes_a_catalog_fetched_through_the_other_slot() {
        use crate::core::catalog::test_support::{model_for, write_account, CatalogFixture};
        let backend = CatalogFixture::start().await;
        let root = tempfile::tempdir().unwrap();
        write_account(root.path(), "primary", "acct-primary");
        write_account(root.path(), "secondary", "acct-secondary");
        let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;

        let before = relay.command("models", None, None).await.unwrap();
        assert_eq!(before["source"], "live");
        assert_eq!(before["models"], json!([model_for("acct-primary")]));

        relay
            .command("switch", Some("secondary"), None)
            .await
            .unwrap();
        let after = relay.command("models", None, None).await.unwrap();
        assert_eq!(after["source"], "live");
        assert_eq!(after["models"], json!([model_for("acct-secondary")]));
        assert_eq!(relay.state.catalog.status().await["slot"], "secondary");
        assert_eq!(backend.hits("acct-primary"), 1);
        assert_eq!(backend.hits("acct-secondary"), 1);
    }

    async fn get_json(app: &Router, uri: &str) -> Value {
        use tower::ServiceExt;
        let request = axum::http::Request::builder()
            .uri(uri)
            .body(axum::body::Body::empty())
            .unwrap();
        let response = app.clone().oneshot(request).await.unwrap();
        assert_eq!(response.status(), StatusCode::OK, "{uri}");
        let bytes = axum::body::to_bytes(response.into_body(), 1024 * 1024)
            .await
            .unwrap();
        serde_json::from_slice(&bytes).unwrap()
    }

    #[tokio::test]
    async fn the_logout_control_drops_the_signed_out_slot_catalog_from_health_and_models() {
        use crate::core::catalog::test_support::{model_for, write_account, CatalogFixture};
        let backend = CatalogFixture::start().await;
        let root = tempfile::tempdir().unwrap();
        write_account(root.path(), "primary", "acct-primary");
        write_account(root.path(), "secondary", "acct-secondary");
        let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;
        let app = app_router(relay.state.clone());
        let models = get_json(&app, "/v1/models").await;
        assert_eq!(
            models["relay_catalog"],
            json!({"source": "live", "slot": "primary"})
        );

        relay
            .command("logout", Some("primary"), None)
            .await
            .unwrap();
        // The router moved to the remaining slot by itself, and `/health`,
        // which never fetches, no longer names the signed-out slot's answer.
        let health = get_json(&app, "/health").await;
        assert_eq!(health["account_router"]["active_slot"], "secondary");
        assert_eq!(health["model_catalog"]["source"], "fallback");
        assert!(health["model_catalog"]["slot"].is_null());

        // The very next read, well inside the TTL, is the secondary's answer.
        let models = get_json(&app, "/v1/models").await;
        assert_eq!(
            models["relay_catalog"],
            json!({"source": "live", "slot": "secondary"})
        );
        assert_eq!(models["data"].as_array().unwrap().len(), 1);
        assert_eq!(models["data"][0]["id"], model_for("acct-secondary"));
        let health = get_json(&app, "/health").await;
        assert_eq!(health["model_catalog"]["source"], "live");
        assert_eq!(health["model_catalog"]["slot"], "secondary");
        assert_eq!(backend.hits("acct-primary"), 1);
        assert_eq!(backend.hits("acct-secondary"), 1);
    }

    /// The shared `login` control, run to its end; how it ended.
    async fn finish_login(relay: &Arc<Relay>, slot: &str) -> LoginState {
        relay.command("login", Some(slot), None).await.unwrap();
        let task = relay
            .login_task
            .lock()
            .await
            .take()
            .expect("a sign-in task");
        task.await.unwrap();
        let login = relay.login_state.lock().await.clone();
        assert!(!login.pending);
        login
    }

    /// A sign-in through the shared `login` control, start to finish; the
    /// router's staged-login seam stands in for the browser.
    async fn sign_in(relay: &Arc<Relay>, slot: &str, account_id: &str) {
        use crate::core::catalog::test_support::staged_login;
        relay
            .state
            .accounts
            .stage_next_login(staged_login(slot, account_id));
        assert_eq!(finish_login(relay, slot).await.error, None);
    }

    /// A directory where `path` names a file: removing or replacing it fails.
    fn occupy(path: &Path) {
        let _ = fs::remove_file(path);
        fs::create_dir_all(path.join("occupied")).unwrap();
    }

    #[tokio::test]
    async fn the_login_control_refreshes_the_catalog_after_a_cold_start_and_a_replacement() {
        use crate::core::catalog::test_support::{model_for, CatalogFixture};
        let backend = CatalogFixture::start().await;
        let root = tempfile::tempdir().unwrap();
        let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;
        // A first run: nobody to ask, and the failed attempt arms the cooldown.
        let cold = relay.command("models", None, None).await.unwrap();
        assert_eq!(cold["source"], "fallback");
        assert!(relay.state.catalog.status().await["last_error"].is_string());

        sign_in(&relay, "primary", "acct-first").await;
        let first = relay.command("models", None, None).await.unwrap();
        assert_eq!(first["source"], "live");
        assert_eq!(first["models"], json!([model_for("acct-first")]));

        // The same slot signed in again, as another account, inside the TTL.
        sign_in(&relay, "primary", "acct-second").await;
        let status = relay.state.catalog.status().await;
        assert_eq!(status["source"], "fallback", "{status}");
        assert!(status["slot"].is_null());
        let second = relay.command("models", None, None).await.unwrap();
        assert_eq!(second["source"], "live");
        assert_eq!(second["models"], json!([model_for("acct-second")]));
        assert_eq!(relay.state.catalog.status().await["slot"], "primary");
        assert_eq!(backend.hits("acct-first"), 1);
        assert_eq!(backend.hits("acct-second"), 1);
    }

    /// A sign-out that removes primary's credentials and only then fails --
    /// its legacy cleanup or its state write refused -- has still removed
    /// them: `/health` stops naming the answer they fetched, and the next
    /// read, well inside the TTL, asks again rather than serving it.
    #[tokio::test]
    async fn a_logout_that_fails_after_removing_credentials_still_retires_their_catalog() {
        use crate::core::catalog::test_support::{model_for, write_account, CatalogFixture};
        for blocked in ["auth.json", "router-state.json"] {
            let backend = CatalogFixture::start().await;
            let root = tempfile::tempdir().unwrap();
            write_account(root.path(), "primary", "acct-primary");
            write_account(root.path(), "secondary", "acct-secondary");
            let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;
            let app = app_router(relay.state.clone());
            let models = get_json(&app, "/v1/models").await;
            assert_eq!(
                models["relay_catalog"],
                json!({"source": "live", "slot": "primary"})
            );

            // The legacy auth.json the cleanup removes, or the state file the
            // router writes, cannot be: both steps come after primary's own
            // auth.json is gone.
            let blocker = root.path().join(blocked);
            occupy(&blocker);
            let error = relay
                .command("logout", Some("primary"), None)
                .await
                .unwrap_err();
            assert!(
                !root.path().join("accounts/primary/auth.json").exists(),
                "{blocked}: {error:#}"
            );
            let health = get_json(&app, "/health").await;
            assert_eq!(
                health["account_router"]["active_slot"], "primary",
                "the router never got to move"
            );
            assert_eq!(
                health["model_catalog"]["source"], "fallback",
                "{blocked}: {error:#}"
            );
            assert!(health["model_catalog"]["slot"].is_null());

            // Unblocked, the next read asks the slot that still has an account.
            fs::remove_dir_all(&blocker).unwrap();
            let models = get_json(&app, "/v1/models").await;
            assert_eq!(
                models["relay_catalog"],
                json!({"source": "live", "slot": "secondary"}),
                "{blocked}"
            );
            assert_eq!(models["data"][0]["id"], model_for("acct-secondary"));
            assert_eq!(backend.hits("acct-primary"), 1);
            assert_eq!(backend.hits("acct-secondary"), 1);
        }
    }

    /// The sign-in side. A sign-in whose OAuth fails has touched no
    /// credential, so the answer the slot's account fetched stays live and
    /// costs nothing. A replacement whose state write fails after the install
    /// has swapped the account all the same: the old account's answer is
    /// retired at once, and the next read asks the new one.
    #[tokio::test]
    async fn a_failed_sign_in_retires_the_catalog_only_once_it_replaced_the_account() {
        use crate::core::catalog::test_support::{model_for, staged_login, CatalogFixture};
        let backend = CatalogFixture::start().await;
        let root = tempfile::tempdir().unwrap();
        let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;
        sign_in(&relay, "primary", "acct-first").await;
        let first = relay.command("models", None, None).await.unwrap();
        assert_eq!(first["source"], "live");
        assert_eq!(first["models"], json!([model_for("acct-first")]));

        relay
            .state
            .accounts
            .fail_next_login(std::io::Error::other("the browser was closed"));
        let login = finish_login(&relay, "primary").await;
        assert!(
            login
                .error
                .as_deref()
                .is_some_and(|error| error.contains("browser was closed")),
            "{:?}",
            login.error
        );
        let status = relay.state.catalog.status().await;
        assert_eq!(status["source"], "live", "{status}");
        assert_eq!(status["slot"], "primary");
        let kept = relay.command("models", None, None).await.unwrap();
        assert_eq!(kept["models"], json!([model_for("acct-first")]));
        assert_eq!(backend.hits("acct-first"), 1, "nothing was due");

        occupy(&root.path().join("router-state.json"));
        relay
            .state
            .accounts
            .stage_next_login(staged_login("primary", "acct-second"));
        let login = finish_login(&relay, "primary").await;
        assert!(
            login
                .error
                .as_deref()
                .is_some_and(|error| error.contains("account router state")),
            "{:?}",
            login.error
        );
        let status = relay.state.catalog.status().await;
        assert_eq!(status["source"], "fallback", "{status}");
        assert!(status["slot"].is_null());
        let second = relay.command("models", None, None).await.unwrap();
        assert_eq!(second["source"], "live");
        assert_eq!(second["models"], json!([model_for("acct-second")]));
        assert_eq!(relay.state.catalog.status().await["slot"], "primary");
        assert_eq!(backend.hits("acct-first"), 1);
        assert_eq!(backend.hits("acct-second"), 1);
    }

    /// A replacement sign-in has installed its credentials and waits for the
    /// router state, which a quota failover holds at its commit (the router's
    /// commit gate pins that instant), when the user cancels. The sign-in
    /// never finishes, yet the slot already holds the new account: the answer
    /// the old one fetched must retire all the same, so neither `/health` nor
    /// `/v1/models` goes on presenting it as the slot's list.
    #[tokio::test]
    async fn a_sign_in_cancelled_after_installing_credentials_still_retires_the_old_catalog() {
        use crate::core::account_router::TestCommitGate;
        use crate::core::catalog::test_support::{
            model_for, staged_login, write_account, CatalogFixture,
        };
        let backend = CatalogFixture::start().await;
        let root = tempfile::tempdir().unwrap();
        write_account(root.path(), "primary", "acct-primary");
        write_account(root.path(), "secondary", "acct-secondary");
        let relay = isolated_with_catalog(root.path(), 0, backend.catalog()).await;
        let app = app_router(relay.state.clone());
        let models = get_json(&app, "/v1/models").await;
        assert_eq!(
            models["relay_catalog"],
            json!({"source": "live", "slot": "primary"})
        );
        assert_eq!(models["data"][0]["id"], model_for("acct-primary"));

        // A quota failover reaches its commit and holds the router state there.
        let accounts = relay.state.accounts.clone();
        let exhausted = accounts.lease_active().await.unwrap();
        let (gate, commit_reached, release_commit) = TestCommitGate::new();
        accounts.gate_next_commit(gate);
        let failover = std::thread::spawn(move || {
            tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap()
                .block_on(accounts.switch_after_quota(
                    &exhausted,
                    crate::core::account_router::QuotaReset::default(),
                ))
                .map(|standby| standby.slot)
        });
        commit_reached
            .recv_timeout(std::time::Duration::from_secs(5))
            .expect("the failover must reach its commit and hold the router state");

        // The sign-in installs the replacement credentials, then waits for
        // that state. `begin_login` and `cancel_login` are called directly:
        // `command` would also read the router state for its status reply.
        relay
            .state
            .accounts
            .stage_next_login(staged_login("primary", "acct-replacement"));
        relay.begin_login("primary").await.unwrap();
        let auth_file = root.path().join("accounts/primary/auth.json");
        let installed = || {
            crate::login::lib::try_read_auth_json(&auth_file)
                .ok()
                .and_then(|auth| auth.tokens)
                .and_then(|tokens| tokens.account_id)
        };
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            while installed().as_deref() != Some("acct-replacement") {
                tokio::task::yield_now().await;
            }
        })
        .await
        .expect("the sign-in must install the replacement credentials");
        assert!(relay.login_state.lock().await.pending);

        relay.cancel_login().await;
        // Cut off past the install: the slot keeps the new credentials, and
        // the sign-in task never got to report an outcome of its own.
        assert_eq!(installed().as_deref(), Some("acct-replacement"));
        let login = relay.login_state.lock().await.clone();
        assert!(!login.pending);
        assert_eq!(login.slot, None);
        assert_eq!(login.error, None);
        let events = relay.events.lock().await.clone();
        assert!(
            events.iter().all(|event| {
                let message = event["message"].as_str().unwrap_or_default();
                !message.starts_with("Signed in") && !message.starts_with("Sign-in failed")
            }),
            "{events:?}"
        );
        // The old account's answer is gone already, before anything is read.
        let status = relay.state.catalog.status().await;
        assert_eq!(status["source"], "fallback", "{status}");
        assert!(status["slot"].is_null(), "{status}");

        release_commit.send(()).unwrap();
        assert_eq!(failover.join().unwrap().unwrap(), "secondary");
        let health = get_json(&app, "/health").await;
        assert_eq!(health["account_router"]["active_slot"], "secondary");
        assert_eq!(health["model_catalog"]["source"], "fallback");
        assert!(health["model_catalog"]["slot"].is_null());
        // The next read asks at once, through the slot the failover moved to.
        let models = get_json(&app, "/v1/models").await;
        assert_eq!(
            models["relay_catalog"],
            json!({"source": "live", "slot": "secondary"})
        );
        assert_eq!(models["data"].as_array().unwrap().len(), 1);
        assert_eq!(models["data"][0]["id"], model_for("acct-secondary"));

        // Back on primary, its list is the replacement account's.
        relay
            .command("switch", Some("primary"), None)
            .await
            .unwrap();
        let models = get_json(&app, "/v1/models").await;
        assert_eq!(
            models["relay_catalog"],
            json!({"source": "live", "slot": "primary"})
        );
        assert_eq!(models["data"].as_array().unwrap().len(), 1);
        assert_eq!(models["data"][0]["id"], model_for("acct-replacement"));
        let health = get_json(&app, "/health").await;
        assert_eq!(health["model_catalog"]["source"], "live");
        assert_eq!(health["model_catalog"]["slot"], "primary");
        assert_eq!(backend.hits("acct-primary"), 1);
        assert_eq!(backend.hits("acct-secondary"), 1);
        assert_eq!(backend.hits("acct-replacement"), 1);
    }

    #[tokio::test]
    async fn occupied_port_is_an_actionable_error_and_does_not_claim_running() {
        let root = tempfile::tempdir().unwrap();
        let busy = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let relay = isolated(root.path(), busy.local_addr().unwrap().port()).await;
        let error = relay.start().await.unwrap_err().to_string();
        assert!(error.contains("already in use"));
        assert_eq!(relay.status().await.unwrap()["running"], false);
        assert!(!descriptor(root.path()).exists());
    }
}

#[derive(Deserialize, Serialize)]
struct Command {
    op: String,
    slot: Option<String>,
    port: Option<u16>,
    settings: Option<Value>,
}
async fn control_handler(
    State((relay, token)): State<(Arc<Relay>, String)>,
    headers: HeaderMap,
    Json(command): Json<Command>,
) -> (StatusCode, Json<Value>) {
    if headers.contains_key("origin")
        || headers.get("x-relay-control").and_then(|v| v.to_str().ok()) != Some(&token)
    {
        return (
            StatusCode::FORBIDDEN,
            Json(json!({"error":"Local control authorization required"})),
        );
    }
    if command.op == "stop" {
        tokio::spawn(async move {
            tokio::time::sleep(std::time::Duration::from_millis(50)).await;
            let _ = relay.stop().await;
        });
        return (StatusCode::OK, Json(json!({"stopping":true})));
    }
    let result = if command.op == "configure" {
        relay
            .configure(command.settings.unwrap_or(Value::Null))
            .await
    } else {
        relay
            .command(&command.op, command.slot.as_deref(), command.port)
            .await
    };
    match result {
        Ok(value) => (StatusCode::OK, Json(value)),
        Err(e) => (
            StatusCode::CONFLICT,
            Json(json!({"error":format!("{e:#}")})),
        ),
    }
}

async fn control_request(
    address: &ControlAddress,
    op: &str,
    slot: Option<String>,
    settings: Option<Value>,
) -> Result<Value> {
    let response = reqwest::Client::new()
        .post(format!("http://127.0.0.1:{}/_relay/control", address.port))
        .header("x-relay-control", &address.token)
        .json(&Command {
            op: op.into(),
            slot,
            port: None,
            settings,
        })
        .timeout(std::time::Duration::from_secs(30))
        .send()
        .await?;
    let status = response.status();
    let value: Value = response.json().await?;
    if !status.is_success() {
        bail!(
            "{}",
            value["error"].as_str().unwrap_or("Control command failed")
        );
    }
    Ok(value)
}

async fn wait_device_login<F, Fut, C, CFut>(
    mut value: Value,
    mut status: F,
    cancel: C,
) -> Result<()>
where
    F: FnMut() -> Fut,
    Fut: std::future::Future<Output = Result<Value>>,
    C: FnOnce() -> CFut,
    CFut: std::future::Future<Output = Result<Value>>,
{
    let id = value["login"]["id"]
        .as_str()
        .context("Login did not start")?
        .to_owned();
    let mut shown = false;
    loop {
        if value["login"]["id"].as_str() != Some(&id) {
            bail!("This sign-in was cancelled or replaced");
        }
        if !value["login"]["pending"].as_bool().unwrap_or(false) {
            if let Some(error) = value["login"]["error"].as_str() {
                bail!("{error}");
            }
            return Ok(());
        }
        if !shown {
            if let (Some(url), Some(code)) = (
                value["device_code"]["verification_url"].as_str(),
                value["device_code"]["user_code"].as_str(),
            ) {
                eprintln!("Open {url} on any device and enter this one-time code:\n\n  {code}\n\nThe code expires in 15 minutes. Waiting for confirmation; Ctrl+C cancels.");
                shown = true;
            }
        }
        tokio::select! {
            result = tokio::signal::ctrl_c() => {
                result?;
                let _ = cancel().await;
                bail!("Device-code sign-in cancelled");
            }
            _ = tokio::time::sleep(std::time::Duration::from_millis(250)) => {}
        }
        value = status().await?;
    }
}

pub async fn cli() -> Result<()> {
    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "praxis_relay=info".into()),
        )
        .with_writer(std::io::stderr)
        .try_init();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut action = args.first().map(String::as_str).unwrap_or("serve");
    if action == "login" {
        for arg in args.iter().skip(1) {
            if !matches!(arg.as_str(), "primary" | "secondary" | "--device-auth") {
                bail!("Use login [primary|secondary] [--device-auth]");
            }
        }
        if args.iter().any(|arg| arg == "--device-auth") {
            action = "login_device";
        }
    }
    if matches!(action, "version" | "--version" | "-V") {
        println!(
            "Praxis Relay {} (independent relay; Codex-compatible upstream protocol)",
            env!("CARGO_PKG_VERSION")
        );
        return Ok(());
    }
    if matches!(action, "help" | "--help" | "-h") {
        println!("Praxis Relay {}\nHeadless: serve [--headless]\nControls: status | login [primary|secondary] [--device-auth] | cancel_login | logout primary|secondary|all | switch primary|secondary | limits primary|secondary | models | stop\nSettings: configure <patch.json> (works offline and against a running process)\nConfig: RELAY_AUTH_DIR, RELAY_PORT, RELAY_API_KEY, RELAY_PYTHON, RELAY_CODEX_VERSION\nNative desktop: praxis-relay-desktop",env!("CARGO_PKG_VERSION"));
        return Ok(());
    }
    if !matches!(
        action,
        "serve"
            | "server"
            | "run"
            | "--headless"
            | "status"
            | "login"
            | "login_device"
            | "cancel_login"
            | "logout"
            | "switch"
            | "limits"
            | "stop"
            | "configure"
            | "models"
    ) {
        bail!("Unknown command {action}; use --help");
    }
    let serve = matches!(action, "serve" | "server" | "run" | "--headless");
    let settings = if action == "configure" {
        Some(serde_json::from_str::<Value>(&fs::read_to_string(
            args.get(1).context("Use configure <patch.json>")?,
        )?)?)
    } else {
        None
    };
    let slot = args
        .iter()
        .skip(1)
        .find(|a| !a.starts_with('-'))
        .cloned()
        .or_else(|| matches!(action, "login" | "login_device").then(|| "primary".into()));
    if !serve {
        let root = crate::core::config::auth_root()?;
        if let Ok(bytes) = fs::read(descriptor(&root)) {
            let address: ControlAddress = serde_json::from_slice(&bytes)?;
            let value = control_request(&address, action, slot.clone(), settings).await?;
            if action == "login_device" {
                let id = value["login"]["id"]
                    .as_str()
                    .context("Login did not start")?
                    .to_owned();
                wait_device_login(
                    value,
                    || control_request(&address, "status", None, None),
                    || control_request(&address, "cancel_login_id", Some(id.clone()), None),
                )
                .await?;
                println!("Signed in to {}", slot.as_deref().unwrap_or("primary"));
            } else {
                println!("{}", serde_json::to_string_pretty(&value)?);
            }
            return Ok(());
        }
    }
    let relay = Relay::new().await?;
    if serve {
        relay.start().await?;
        println!("Praxis Relay {} · {}\nFully headless. Use a second terminal for controls; Ctrl+C stops this process.",env!("CARGO_PKG_VERSION"),relay.status().await?["base_url"].as_str().unwrap_or(""));
        tokio::select! {
            _=shutdown_signal()=>{},
            _=async { while relay.running.lock().await.is_some() { tokio::time::sleep(std::time::Duration::from_millis(250)).await; } }=>{}
        }
        relay.cancel_login().await;
        relay.stop().await?;
    } else {
        let value = if action == "configure" {
            relay.configure(settings.unwrap()).await?
        } else {
            relay.command(action, slot.as_deref(), None).await?
        };
        if action == "login_device" {
            let id = value["login"]["id"]
                .as_str()
                .context("Login did not start")?
                .to_owned();
            wait_device_login(
                value,
                || relay.status(),
                || async {
                    relay.cancel_login_if_id(&id).await;
                    Ok(Value::Null)
                },
            )
            .await?;
            println!("Signed in to {}", slot.as_deref().unwrap_or("primary"));
        } else if action == "login" {
            while relay.login_state.lock().await.pending {
                tokio::time::sleep(std::time::Duration::from_millis(100)).await;
            }
            let login = relay.login_state.lock().await.clone();
            if let Some(error) = login.error {
                bail!("{error}");
            }
            println!("Signed in to {}", slot.as_deref().unwrap_or("primary"));
        } else {
            println!("{}", serde_json::to_string_pretty(&value)?);
        }
    }
    Ok(())
}

async fn shutdown_signal() {
    #[cfg(unix)]
    {
        if let Ok(mut term) =
            tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
        {
            tokio::select! { _=tokio::signal::ctrl_c()=>{}, _=term.recv()=>{} }
            return;
        }
    }
    let _ = tokio::signal::ctrl_c().await;
}

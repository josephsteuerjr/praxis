"""Refresh an exact qualified Mac donor, then admit the actual resulting ZIP."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, sys

P=argparse.ArgumentParser()
P.add_argument('--target',choices=('macos','macos-intel'),required=True)
P.add_argument('--donors',type=Path,required=True)
P.add_argument('--finish',action='store_true')
a=P.parse_args()
ROOT=Path(__file__).resolve().parent.parent
E=ROOT/'equipment';S=ROOT/'source';O=ROOT/'evidence';O.mkdir(exist_ok=True)
W=ROOT/'work';W.mkdir(exist_ok=True)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(name,args,timeout=2700):
    with (O/(name+'.log')).open('wb') as f:
        r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    assert r.returncode==0,'Read '+name+'.log'
note=json.loads((E/'DONORS.json').read_bytes())[a.target]
arch='x86_64' if a.target=='macos-intel' else 'arm64'
assert sys.platform=='darwin' and platform.machine()==arch
matches=[p for p in a.donors.rglob('*.zip') if p.stat().st_size==note['size'] and sha(p)==note['sha256']]
assert len(matches)==1,matches
donor=matches[0]
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.path[:0]=[str(S/'desk'),str(S/'desk/installer')]
from build_python_macos_rc import unpack
if not a.finish:
    unpack(donor,W/'donor')
    python=W/'donor/Helene/runtime/bin/python3'
    os.execv(str(python),[str(python),'-B',__file__,'--target',a.target,'--donors',str(a.donors.resolve()),'--finish'])
proof=json.loads((E/'SOURCE-FROZEN.json').read_bytes())
for name,row in proof['files'].items():assert sha(S/name)==row['sha256'],name
skip=O/'command-skips.json'
run('skip-collection',[sys.executable,'-I','-S','-B',E/'source_declared_skips.py','--core',S/'helene/core','--out',skip],60)
run('package',[sys.executable,'-B',E/'build_portable.py','--source',S,'--donor',donor,'--sha',note['sha256'],
    '--out',O/'package','--frontends',E/'FRONTENDS.json','--platform','macos','--macos-arch',arch,'--version','2.7.1','--extra-skip-map',skip])
archive=O/'package'/('Helene-2.7.1-macos-'+arch+'.zip')
unpack(archive,W/'installed');program=W/'installed/Helene'
run('codesign',['codesign','--verify','--deep','--strict',program/'Helene.app'],60)
run('wrapper-help',[program/'Helene.app/Contents/MacOS/Helene','--help'],60)
run('native-suite',[program/'runtime/bin/python3','-B',E/'posix_native_suite.py','--program',program,
    '--source',S,'--equipment',E,'--out',O/'native','--version','2.7.1'])
result={'passed':True,'platform':a.target,'architecture':arch,'host':platform.mac_ver()[0],
    'source_commit':proof['commit'],'source_tree_sha256':proof['source_tree_sha256'],
    'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,
    'runtime_donor_sha256':note['sha256'],'native':json.loads((O/'native/native-final.json').read_bytes()),
    'native_launcher_rebuilt':True,'runtime_and_body_reused':True,'notarized':False,'owner_installation_changed':False}
(O/'COMPLETE.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='native'}))

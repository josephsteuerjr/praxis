"""Bind literal skip declarations in changed tests without importing test code."""
from pathlib import Path
import ast,hashlib,json

def collect(source):
    source=Path(source);modules=json.loads(Path(__file__).with_name('HANDOFF-TESTS.json').read_bytes())['modules']
    result={};inputs={}
    def reasons(decorators):
        found=[]
        for item in decorators:
            if not isinstance(item,ast.Call):continue
            name=item.func.attr if isinstance(item.func,ast.Attribute) else item.func.id if isinstance(item.func,ast.Name) else ''
            if name not in ('skip','skipIf','skipUnless'):continue
            reason=item.args[-1] if item.args else None
            if isinstance(reason,ast.Constant) and isinstance(reason.value,str):found.append(reason.value)
        return found
    for module in modules:
        path=source/'desk/tests'/(module+'.py');raw=path.read_bytes();tree=ast.parse(raw)
        for cls in tree.body:
            if not isinstance(cls,ast.ClassDef):continue
            for method in cls.body:
                if not isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)) or not method.name.startswith('test'):continue
                declared=reasons(cls.decorator_list)+reasons(method.decorator_list)
                if declared:
                    assert len(set(declared))==1,(module,cls.name,method.name,declared)
                    result['desk::'+module+'.'+cls.name+'.'+method.name]=declared[0]
                    inputs[path.relative_to(source).as_posix()]=hashlib.sha256(raw).hexdigest()
    return {'source_files':inputs,'allowed':result,'scope':'Exact literal decorators only; execution still determines applicability. No failures converted to skips.'}

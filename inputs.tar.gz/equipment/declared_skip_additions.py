"""Bind literal skip declarations in changed tests without importing test code."""
from pathlib import Path
import ast,hashlib,json,os,sys

def collect(source):
    source=Path(source);modules=json.loads(Path(__file__).with_name('HANDOFF-TESTS.json').read_bytes())['modules']
    result={};inputs={}
    def reasons(decorators):
        found=[]
        for item in decorators:
            if not isinstance(item,ast.Call):continue
            name=item.func.attr if isinstance(item.func,ast.Attribute) else item.func.id if isinstance(item.func,ast.Name) else ''
            if name not in ('skip','skipIf','skipUnless'):continue
            reason=item.args[-1] if item.args else None
            if isinstance(reason,ast.Constant) and isinstance(reason.value,str):found.append(reason.value)
        return found
    for module in modules:
        path=source/'desk/tests'/(module+'.py');raw=path.read_bytes();tree=ast.parse(raw)
        for cls in tree.body:
            if not isinstance(cls,ast.ClassDef):continue
            for method in cls.body:
                if not isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)) or not method.name.startswith('test'):continue
                declared=reasons(cls.decorator_list)+reasons(method.decorator_list)
                if declared:
                    if len(set(declared))>1:
                        if (module,cls.name,method.name)==('t_relay_device_1311','ServerBoundary','test_real_desk_peer_can_login_agent_cannot_read_socket_or_auth'):
                            assert declared==['Linux peer credentials','Root permission fixture']
                            declared=declared[1:] if sys.platform.startswith('linux') else declared[:1]
                        else:
                        # The only nested declaration skips the entire POSIX
                        # server class on Windows. Git remains required on
                        # POSIX: a missing-git method skip must fail admission.
                            assert (module,cls.name,method.name)==('t_server_return_1211','ServerSnapshot','test_round_trip_returns_fresh_life_code_projects_and_git')
                            assert declared==['server helper uses flock, like install.sh','git is required for the worktree fixture']
                            declared=declared[:1]
                    assert len(set(declared))==1,(module,cls.name,method.name,declared)
                    result['desk/tests/'+module+'.py::'+module+'.'+cls.name+'.'+method.name]=declared[0]
                    inputs[path.relative_to(source).as_posix()]=hashlib.sha256(raw).hexdigest()
    if os.name=='nt':
        # These nine real link-migration tests must create their input symlink.
        # Ordinary Windows tokens without Developer Mode cannot create it.
        # Bind only the literal helper skip and its actual callers; do not
        # waive any observed application failure or any other test outcome.
        rel='desk/tests/t_first_start_links_3110.py';raw=(source/rel).read_bytes();tree=ast.parse(raw)
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DataLinks')
        methods={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)}
        skips=[n for n in ast.walk(methods['link']) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='skipTest']
        assert len(skips)==1 and isinstance(skips[0].args[0],ast.Constant)
        reason=skips[0].args[0].value
        assert reason=='Fixture creation requires Windows symlink privilege; migration itself does not'
        def calls(node,name):return any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='self' and n.func.attr==name for n in ast.walk(node))
        assert calls(methods['cached'],'link')
        linked=[n for n,m in methods.items() if n.startswith('test_') and (calls(m,'link') or calls(m,'cached'))]
        assert len(linked)==9
        for name in linked:result[rel+'::t_first_start_links_3110.DataLinks.'+name]=reason
        inputs[rel]=hashlib.sha256(raw).hexdigest()
    return {'source_files':inputs,'allowed':result,'scope':'Literal decorators and nine source-bound Windows symlink fixture guards; execution determines applicability. No application failures converted to skips.'}

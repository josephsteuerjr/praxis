"""Collect only the new command contract's source-declared native OS skips."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import unittest

MODULE = 'test_command_admission_0611'
FORMAT = 'helene-command-source-skips.v1'


def collect(core):
    core = Path(core).resolve()
    source = core/(MODULE+'.py')
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    saved = {name:sys.modules.get(name) for name in ('command_process', MODULE)}
    bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        for name in ('command_process', MODULE):
            spec = importlib.util.spec_from_file_location(name, core/(name+'.py'))
            assert spec is not None and spec.loader is not None
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
        def cases(suite):
            for item in suite:
                if isinstance(item, unittest.TestSuite):
                    yield from cases(item)
                else:
                    yield item
        rows = []
        for case in cases(unittest.defaultTestLoader.loadTestsFromModule(module)):
            method = getattr(case, case._testMethodName)
            owner = type(case) if getattr(type(case), '__unittest_skip__', False) else method
            skipped = bool(getattr(owner, '__unittest_skip__', False))
            reason = getattr(owner, '__unittest_skip_why__', None) if skipped else None
            assert case.id().startswith(MODULE+'.') and (not skipped or isinstance(reason,str) and reason)
            rows.append({'id':case.id(), 'skipped':skipped, 'reason':reason})
        assert rows and any(not row['skipped'] for row in rows)
    finally:
        sys.dont_write_bytecode = bytecode
        for name, previous in saved.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    return {'format':FORMAT, 'module':MODULE, 'source_sha256':before,
            'platform':sys.platform, 'collection_only':True, 'cases':rows,
            'allowed_test_skips':{sys.platform:{'core::'+row['id']:row['reason']
                for row in rows if row['skipped']}}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--core', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result = collect(args.core)
    assert not args.out.exists()
    args.out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'platform':result['platform'], 'source_sha256':result['source_sha256'],
        'collected':len(result['cases']), 'os_skips':len(result['allowed_test_skips'][sys.platform]),
        'tests_executed':0}), flush=True)


if __name__ == '__main__':
    main()

"""Observe the packaged production entry in a disposable native POSIX window.

Only remote service responses are synthetic. No model/vendor/network or owner
profile is used. Native webview, bridge, Controller and startup are production.
"""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import hashlib,json,os,runpy,subprocess,sys,threading,time,traceback
ROOT=Path(sys.argv[1]).resolve();OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
assert OUT!=ROOT and not OUT.is_relative_to(ROOT)
sys.path.insert(0,str(ROOT/'app'))
from localharness import posix_first_start as first
DATA=ROOT.parent/'synthetic-native-profile';DATA.mkdir(exist_ok=True)
identity=DATA/'memory/.control/profile-identity.json';identity.parent.mkdir(parents=True,exist_ok=True)
identity.write_text(json.dumps({'agent_name':'Native release fixture'}))
first.prepare(ROOT,places=first.Places(DATA))
REQUESTS=[];WRITES=[]
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_GET(self):
        path=self.path.split('?')[0];REQUESTS.append(path)
        if path=='/api/home':value={'tree':'/synthetic-remote-profile'}
        elif path=='/api/speech/status':value={'ok':True,'selection':{'provider':'fish','enabled':True,'revision':'synthetic','reference_id':'fixture','model':'drama-3'},'fish':{'configured':True,'authenticated':True,'api_credit_raw':'15'}}
        elif path.startswith('/api/speech/fish/catalog/'):value={'ok':True,'page':1,'has_more':False,'voices':[{'id':'fixture','name':'Синтетический голос для приёмки'}]}
        elif path=='/api/containers':value={'available':True,'containers':[],'allowed':[]}
        elif path=='/api/logs':value=[]
        elif path=='/api/supervisor':value={'kind':'synthetic','alive':True,'beat_age':0,'started_utc':'2026-01-01T00:00:00Z','in_container':False,'children':[],'targets':[],'receipt':None,'pending':None,'control':{'available':False,'why':'Synthetic read-only fixture'}}
        elif path=='/api/autonomy':value={'available':False,'why':'Synthetic read-only fixture'}
        elif path=='/api/frame-stats':value={'days':7,'summary':{'calls':0,'runs':0,'cache_ratio':None,
            'cached_tokens':0,'input_tokens':0,'output_tokens':0,'cuts':0},'by':{}}
        elif path=='/api/spend':value={'days':7,'summary':{'calls':0,'runs':0,'input_tokens':0,
            'cached_tokens':0,'fresh_tokens':0,'output_tokens':0,'total_tokens':0,'cache_ratio':None,
            'seconds':0,'errors':0,'kinds':{},'models':{},'bound_calls':0,'unbound_calls':0,'fields_in_log':{}},
            'by_chat':[],'by_person':[],'by_run':[],'by_kind':[],'unbound':[]}
        elif path=='/api/brain':value={'ok':True,'roles':{'voice':{'framework':'codex','model':'fixture-fast','reasoning_effort':'high','service_tier':'priority'}},'frameworks':{'codex':{'base_url':'http://127.0.0.1:5011'},'anthropic':{'base_url':'https://api.anthropic.invalid'}},'service_tiers':{'voice':{'codex':True,'available':True,'requested':'priority','actual':'default'}}}
        elif path=='/api/brain-models':value={'ok':True,'by_framework':{'codex':{'ok':True,'codex':True,'models':['fixture-fast','fixture-standard'],'model_details':[{'id':'fixture-fast','reasoning_efforts':['high','ultra'],'service_tiers':[{'id':'priority','name':'Fast'}]},{'id':'fixture-standard','reasoning_efforts':['medium'],'service_tiers':[],'additional_speed_tiers':[]}]},'anthropic':{'ok':True,'codex':False,'models':['claude-test'],'model_details':[]}}}
        elif path=='/api/state':value={'agent':'Native release fixture','level':'ok','phrase':'Синтетический стенд','runner':{'alive':False,'busy':False,'ever':True},'brain':{'configured':True,'model':'fixture'},'telegram':{'enabled':False}}
        elif path=='/api/agent-config':value={'ok':True,'config':{'agent':{'name':'Native release fixture'},'model':{'provider':'api','model':'fixture'},'telegram':{}},'mtime_ns':'1','editable':[]}
        elif path=='/api/forge/tasks':value={'active':[],'recent':[]}
        elif path=='/api/phone/activity':value={'reviewers':[],'recent_reviewers':[]}
        elif path=='/api/agenda':value={'active':[],'total':0}
        elif path=='/api/computer/remote/state':value={'devices':[]}
        elif path in ('/api/runs','/api/chats','/api/shadow','/api/md-tree'):value=[]
        elif path=='/api/events':value={'events':[]}
        else:value={}
        raw=json.dumps(value,ensure_ascii=False).encode();self.send_response(200)
        for k,v in {'Content-Type':'application/json; charset=utf-8','Content-Length':str(len(raw)),'Access-Control-Allow-Origin':self.headers.get('Origin','null'),'Cache-Control':'no-store'}.items():self.send_header(k,v)
        self.end_headers();self.wfile.write(raw)
    def do_POST(self):
        WRITES.append(self.path);self.send_response(403);self.end_headers()
    def do_OPTIONS(self):
        self.send_response(204);self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Allow-Headers','authorization, content-type');self.send_header('Access-Control-Allow-Methods','GET, OPTIONS');self.end_headers()
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
config=json.loads((ROOT/'helene.json').read_text());config.update(mode='remote',base=f'http://127.0.0.1:{server.server_port}',key='',setup_complete=True,tree=str(DATA))
config.update(relay={'enabled':False},computer={'enabled':False},voice={'enabled':False},telegram={})
(ROOT/'helene.json').write_text(json.dumps(config));(DATA/'memory/.state').mkdir(exist_ok=True)
(DATA/'memory/.state/helene-profile.json').write_text(json.dumps(config))
import webview
original_create=webview.create_window;result={'native':sys.platform,'program':str(ROOT),'synthetic_remote':True,'scenes':[],'success':False}
failed=[]
def capture(window,name):
    if sys.platform=='darwin':subprocess.run(['screencapture','-x','-t','png',str(OUT/(name+'.png'))],check=True)
    else:
        # X11 root capture runs outside the Qt event loop.
        subprocess.run(['import','-window','root',str(OUT/(name+'.png'))],check=True)
    result['scenes'].append({'name':name,'sha256':hashlib.sha256((OUT/(name+'.png')).read_bytes()).hexdigest(),'visually_inspected':False})
def drive(window):
    try:
        end=time.monotonic()+70
        while time.monotonic()<end:
            if window.evaluate_js("!!document.querySelector('[data-page=now]')"):break
            time.sleep(.2)
        else:raise TimeoutError('Production Now did not mount')
        time.sleep(1);capture(window,'native-now')
        window.evaluate_js("window.dispatchEvent(new CustomEvent('frame-go',{detail:'settings'}))")
        while time.monotonic()<end:
            if window.evaluate_js("!!document.querySelector('[data-speech-preview]')"):break
            time.sleep(.2)
        else:raise TimeoutError('Production remote Fish controls did not mount')
        window.evaluate_js("document.querySelector('[data-server-speech-card]').scrollIntoView({block:'start'})")
        time.sleep(.5);capture(window,'native-fish')
        window.evaluate_js("document.querySelector('[data-server-speech-card] .server-speech-voices').scrollIntoView({block:'start'})")
        time.sleep(.3);capture(window,'native-fish-voices')
        window.evaluate_js("Array.from(document.querySelectorAll('.rail-item')).find(node=>node.textContent.includes('Система')).click()")
        while time.monotonic()<end:
            if window.evaluate_js("!!document.querySelector('[data-brain-form=voice] [data-f=service_tier] option[value=priority]')"):break
            time.sleep(.2)
        else:raise TimeoutError('Production Fast role controls did not mount')
        assert window.evaluate_js("document.querySelectorAll('[data-brain-form=voice] [data-f=reasoning_effort] option[value=none]').length===0")
        assert window.evaluate_js("document.querySelectorAll('[data-brain-form=voice] [data-f=reasoning_effort] option[value=ultra]').length===1")
        window.evaluate_js("document.querySelector('[data-brain-form=voice]').scrollIntoView({block:'start'})")
        time.sleep(.4);capture(window,'native-fast-controls')
        window.evaluate_js("(()=>{const input=document.querySelector('[data-brain-form=voice] [data-f=model]');input.value='fixture-standard';input.dispatchEvent(new Event('input',{bubbles:true}));})()")
        assert window.evaluate_js("document.querySelectorAll('[data-brain-form=voice] [data-f=service_tier] option[value=priority]').length===0")
        assert window.evaluate_js("document.querySelectorAll('[data-brain-form=voice] [data-f=reasoning_effort] option[value=high]').length===0")
        time.sleep(.3);capture(window,'native-fast-standard-model')
        result['fast_controls']={'codex_advertised_only':True,'ultra_advertised':True,'none_absent':True,'known_standard_hides_fast':True}
        assert not WRITES,'Native inspection wrote to remote service' 
        result['success']=True
    except BaseException:
        failed.append(traceback.format_exc());result['error']=failed[-1]
        try:
            capture(window,'native-failure')
            result['speech_note']=window.evaluate_js("document.querySelector('[data-server-speech-card]')?.textContent||''")
        except BaseException:pass
    finally:
        (OUT/'native-gui.json').write_text(json.dumps(result,indent=2))
        try:window.evaluate_js("window.__HELENE__.win('exit')")
        except BaseException:window.destroy()
def create(*args,**kwargs):
    window=original_create(*args,**kwargs)
    window.events.loaded+=lambda:threading.Thread(target=drive,args=(window,),daemon=True).start()
    return window
webview.create_window=create
sys.argv=[str(ROOT/'app/python_app.py'),'--root',str(ROOT)]
try:
    try:runpy.run_path(str(ROOT/'app/python_app.py'),run_name='__main__')
    except SystemExit as exc:
        if exc.code not in (None,0):raise
finally:
    server.shutdown();result['remote_writes']=WRITES;result['remote_reads']=sorted(set(REQUESTS))
    (OUT/'native-gui.json').write_text(json.dumps(result,indent=2))
assert result['success'] and not failed,result
print(json.dumps({'native_gui':True,'platform':sys.platform,'scenes':len(result['scenes']),'remote_writes':len(WRITES)}),flush=True)

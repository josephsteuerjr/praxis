"""Task-only exact source refresh with streamed retained-tool verification."""
from pathlib import Path
import argparse,hashlib,json,sys,zipfile,tarfile


def admitted_bootstrap(source,binary,receipt):
    """Only a fresh qualified build may override a donor's Windows entry."""
    assert bool(binary)==bool(receipt),'Windows bootstrap and its build receipt must be supplied together'
    if binary is None:return None
    proof=json.loads(receipt.read_bytes())
    assert proof['format']=='helene-windows-launcher-build.v1' and proof['passed'] is True
    assert proof['build_entry']=='desk/installer/windows_archive_entry.py::launcher'
    assert proof['tests']['passed'] is True and proof['tests']['actual_embedded_python'] is True
    assert proof['tests']['runtime_executor_lock_matched'] is True
    assert proof['tests']['cases']>0 and proof['tests']['executed']==proof['tests']['cases'] and not proof['tests']['skipped']
    for name,row in proof['source_files'].items():
        assert name.startswith('desk/') and not Path(name).is_absolute() and '..' not in Path(name).parts
        raw=(source/name).read_bytes()
        assert len(raw)==row['size'] and hashlib.sha256(raw).hexdigest()==row['sha256'],name
    required={'desk/installer/windows_launcher.rs','desk/installer/windows_archive_entry.py','desk/shell/icons/icon.ico',
              'desk/tests/t_bootstrap_ready_3010.py','desk/localharness/bootstrap_ready.py'}
    assert set(proof['source_files'])==required
    assert binary.resolve()==Path(proof['binary']['path']).resolve() and binary.stat().st_size==proof['binary']['size']
    assert hashlib.sha256(binary.read_bytes()).hexdigest()==proof['binary']['sha256']
    bound=binary.with_name(binary.stem+'-bootstrap.json')
    assert bound.resolve()==Path(proof['bootstrap_receipt']['path']).resolve()
    assert hashlib.sha256(bound.read_bytes()).hexdigest()==proof['bootstrap_receipt']['sha256']
    assert hashlib.sha256(Path(proof['tests']['log']).read_bytes()).hexdigest()==proof['tests']['log_sha256']
    import subprocess
    assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==proof['source_commit']
    return binary


def retained_wheelhouses(package,prior,destination,bundle):
    """Retain the exact published offline closure from each qualified donor."""
    result={}
    for platform,declared in prior.get('dependencies',{}).items():
        assert platform in prior['executor_locks'] and declared.get('packages') and declared.get('files')
        prefix='Helene/verification/dependencies/'+platform+'/'
        assert {name[len(prefix):] for name in package.namelist() if name.startswith(prefix) and not name.endswith('/')}==set(declared['files'])
        target=destination/platform
        target.mkdir(parents=True)
        for name,row in declared['files'].items():
            assert Path(name).name==name and row['mode']=='100644'
            item=package.getinfo(prefix+name)
            assert item.file_size==row['size'] and item.file_size<=256*1024*1024
            assert item.external_attr>>16==0o100644
            path=target/name
            measured=hashlib.sha256()
            with package.open(item) as incoming,path.open('xb') as output:
                while data:=incoming.read(1024*1024):measured.update(data);output.write(data)
            assert measured.hexdigest()==row['sha256'],name
            path.chmod(0o644)
        assert bundle.inventory(target)==declared['files']
        (target/'wheels.json').write_text(json.dumps({'packages':declared['packages']}),encoding='utf8')
        result[platform]=target
    return result


def main():
    p=argparse.ArgumentParser()
    for n in ('source','donor','out','frontends'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--sha',required=True);p.add_argument('--platform',required=True)
    p.add_argument('--macos-arch',choices=('arm64','x86_64'),default='arm64')
    p.add_argument('--version',default='2.5.1')
    p.add_argument('--extra-skip-map',type=Path)
    p.add_argument('--verification-wheelhouse',type=Path)
    p.add_argument('--windows-bootstrap',type=Path)
    p.add_argument('--windows-bootstrap-receipt',type=Path)
    a=p.parse_args()
    source=a.source.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    if a.platform!='windows':assert a.windows_bootstrap is None and a.windows_bootstrap_receipt is None
    bootstrap=admitted_bootstrap(source,a.windows_bootstrap,a.windows_bootstrap_receipt)
    sys.path[:0]=[str(source/'desk'),str(source/'desk/installer')]
    from localharness import source_verification_bundle as bundle
    import portable_refresh as refresh
    from portable_zip import PREFIX,Entry,encoded,mode,relative,sha
    assert bundle.digest(a.donor)==a.sha,'Pinned donor changed'
    native={'windows':'win32','macos':'darwin','debian':'linux','fedora':'linux'}[a.platform]
    retained=out/'retained-inputs';retained.mkdir()
    with zipfile.ZipFile(a.donor) as z:
        prior=json.loads(z.read(PREFIX+'verification/manifest.json'))
        if a.platform=='macos':
            metadata=json.loads(z.read(PREFIX+'python-app.json'))
            assert metadata.get('target')=='macos-'+a.macos_arch,metadata.get('target')
        wheelhouses=retained_wheelhouses(z,prior,out/'retained-dependencies',bundle)
        rows=prior.get('retained_evidence',{}).get('files',{})
        if 'retained_evidence' in prior:assert rows and 'bindings.json' in rows,'Incomplete retained evidence declaration'
        for name,row in sorted(rows.items()):
            relative(name);info=z.getinfo(PREFIX+'verification/evidence-inputs/'+name)
            assert info.file_size==row['size'] and info.file_size<=512*1024*1024,name
            target=retained/name;target.parent.mkdir(parents=True,exist_ok=True)
            h=hashlib.sha256()
            with z.open(info) as incoming,target.open('xb') as output:
                while chunk:=incoming.read(1024*1024):h.update(chunk);output.write(chunk)
            assert h.hexdigest()==row['sha256'],name
            if sys.platform!='win32':target.chmod(int(row['mode'][-3:],8))
    assert bundle.inventory(retained)==rows,'Retained source/evidence inventory changed'
    allowed={platform:dict(cases) for platform,cases in prior.get('allowed_test_skips',{}).items()}
    from source_declared_shortcuts import collect as collect_shortcuts
    shortcut_skips=collect_shortcuts(source)
    if shortcut_skips:
        assert shortcut_skips['platform']==native,'Native shortcut declarations require the matching assembly host'
        selected=allowed.setdefault(native,{})
        for key,reason in shortcut_skips['allowed_test_skips'][native].items():
            assert key not in selected or selected[key]==reason
            selected[key]=reason
    from source_declared_idle_skips import collect as collect_idle_skips
    idle_skips=collect_idle_skips(source)
    assert idle_skips and idle_skips['platform']==native
    for key,reason in idle_skips['allowed_test_skips'][native].items():
        assert key not in allowed.setdefault(native,{}) or allowed[native][key]==reason
        allowed[native][key]=reason
    from declared_skip_additions import collect as collect_declared
    declarations=collect_declared(source)
    for platform in allowed:
        for key,reason in declarations['allowed'].items():
            assert key not in allowed[platform] or allowed[platform][key]==reason
            allowed[platform][key]=reason
    extra=None
    if a.extra_skip_map:
        from source_declared_skips import collect
        extra=json.loads(a.extra_skip_map.read_text(encoding='utf8'))
        assert extra==collect(source/'helene/core'),'Skip declaration differs from actual source collection'
        assert extra['platform']==native,'Skip declaration belongs to another native OS'
        additions=extra['allowed_test_skips'][native]
        selected=allowed.setdefault(native,{})
        assert all(key.startswith('core::test_command_admission_0611.') and
                   (key not in selected or selected[key]==reason) for key,reason in additions.items())
        selected.update(additions)
    verification=out/'verification'
    if a.verification_wheelhouse:
        explicit=a.verification_wheelhouse.resolve()
        if native in wheelhouses:
            assert json.loads((explicit/'wheels.json').read_bytes())['packages']==prior['dependencies'][native]['packages']
        wheelhouses[native]=explicit
    record=bundle.build(source,verification,a.version,prior['executor_locks'],
        wheelhouses=wheelhouses,
        allowed_skips=allowed,native=prior.get('native_lanes',[]),
        rebuild=prior.get('build_lanes',[]),scripts=prior.get('script_contracts',{}),retained_inputs=retained if rows else None)
    manifest=json.loads((verification/'manifest.json').read_bytes())
    assert manifest['files'][idle_skips['source']]['sha256']==idle_skips['source_sha256']
    manifest['source_declared_changed_test_skips']=declarations
    manifest['source_declared_idle_skips']=idle_skips
    if shortcut_skips:
        assert manifest['files'][shortcut_skips['source']]['sha256']==shortcut_skips['source_sha256']
        manifest['source_declared_shortcut_skips']=shortcut_skips
    if extra:
        assert manifest['files']['live/test_command_admission_0611.py']['sha256']==extra['source_sha256']
        manifest['source_declared_command_skips']=extra
    if 'bundled_executors' in prior:manifest['bundled_executors']=prior['bundled_executors']
    cache_entries={}
    with tarfile.open(Path(__file__).with_name('npm-cache.tar.gz')) as z:
        for item in z:
            relative(item.name)
            assert item.isfile() and item.name.startswith('cache/_cacache/') and item.size<16*1024*1024
            cache_entries[item.name]=Entry(z.extractfile(item).read(),'100644')
    row=manifest['bundled_executors'][native]
    for name,entry in cache_entries.items():row['files'][name]={'sha256':sha(entry.data),'size':len(entry.data),'mode':0o644}

    (verification/'manifest.json').write_bytes(encoded(manifest));record['sha256']=bundle.digest(verification/'manifest.json')
    (out/'verification.json').write_bytes(encoded(record))
    def retained_tools(package,entries,platform,root=None):
        assert platform==a.platform and root is None
        manifest=json.loads(entries['manifest.json'].data);row=manifest.get('bundled_executors',{}).get(native)
        if row is None:return None
        expected={'node':'bin/node.exe','npm':'npm/bin/npm-cli.js'} if native=='win32' else {'node':'bin/node','npm':'bin/npm'}
        assert row['root']=='verification-tools' and row['tools']==expected and row['npm_cache']=='cache'
        prefix=PREFIX+'verification-tools/';files=row['files']
        assert set(files)==({n[len(prefix):] for n in package.names() if n.startswith(prefix) and not n.endswith('/')}|set(cache_entries))
        for tool,name in expected.items():assert manifest['executor_locks'][native]['tools'][tool]=={'sha256':files[name]['sha256']}
        assert any(n.startswith('cache/_cacache/') for n in files)
        for name,r in files.items():
            if name in cache_entries:
                entry=cache_entries[name];assert sha(entry.data)==r['sha256'] and len(entry.data)==r['size'];package.put(prefix+name,entry);continue
            relative(name);info=package.infos[prefix+name]
            assert info.file_size==r['size'] and int(mode(info)[-3:],8)==r['mode'],name
            h=hashlib.sha256()
            with package.reader.open(info) as f:
                while chunk:=f.read(1024*1024):h.update(chunk)
            assert h.hexdigest()==r['sha256'],name
        return sha(encoded(row))
    refresh._verification_tools=retained_tools
    print(json.dumps({'phase':'verification-bound','manifest_sha256':record['sha256']}),flush=True)
    plan,replacements,removed=refresh.plan(a.donor,source,a.version,a.platform,expected_sha256=a.sha,
        frontend_receipt=a.frontends,verification_bundle=verification,verification_sha256=record['sha256'],
        windows_bootstrap=bootstrap)
    (out/'plan.json').write_bytes(encoded(plan))
    names={'windows':f'Helene-{a.version}.zip','macos':f'Helene-{a.version}-macos-{a.macos_arch}.zip',
           'debian':f'Helene-{a.version}-linux-x86_64.zip','fedora':f'Helene-{a.version}-fedora-x86_64.zip'}
    archive=out/names[a.platform]
    print(json.dumps({'phase':'assembly','replacements':len(replacements),'archive':archive.name}),flush=True)
    result=refresh.build(a.donor,archive,plan,replacements,removed,expected_plan=plan['sha256'])
    result.update(path=str(archive),bytes=archive.stat().st_size,version=a.version,
                  platform=a.platform,full_suite_executed=False,native_gui_qualified=False)
    (out/'artifacts.json').write_text(json.dumps({a.platform:result},indent=2),encoding='utf8')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()

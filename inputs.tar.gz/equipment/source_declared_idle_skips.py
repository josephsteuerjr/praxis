"""Collect only declared unittest class/method skips without running fixtures."""
from pathlib import Path
import ast,hashlib,json,os,sys,types,unittest

MODULE='t_idle_cpu_0711'
SOURCE='desk/tests/'+MODULE+'.py'


def collect(source):
    path=Path(source)/SOURCE
    if not path.is_file():return None
    raw=path.read_bytes();tree=ast.parse(raw)
    classes=[node for node in tree.body if isinstance(node,ast.ClassDef)]
    assert classes and all(len(node.bases)==1 and ast.unparse(node.bases[0])=='unittest.TestCase' for node in classes)
    # Only the actual TestCase declarations are evaluated. Method bodies,
    # setUp/tearDown and application imports are never executed during collection.
    for node in classes:
        assert all(isinstance(item,ast.FunctionDef) or isinstance(item,ast.Expr) and isinstance(item.value,ast.Constant) for item in node.body)
        for method in (item for item in node.body if isinstance(item,ast.FunctionDef)):
            assert method.name!='__init__' and not method.args.defaults and not method.args.kw_defaults
    module=types.ModuleType(MODULE)
    module.__dict__.update(unittest=unittest,os=os)
    exec(compile(ast.fix_missing_locations(ast.Module(body=classes,type_ignores=[])),str(path),'exec'),module.__dict__)
    def cases(suite):
        for item in suite:
            if isinstance(item,unittest.TestSuite):yield from cases(item)
            else:yield item
    rows=[]
    for case in cases(unittest.defaultTestLoader.loadTestsFromModule(module)):
        method=getattr(case,case._testMethodName)
        owner=type(case) if getattr(type(case),'__unittest_skip__',False) else method
        skipped=bool(getattr(owner,'__unittest_skip__',False))
        reason=getattr(owner,'__unittest_skip_why__',None) if skipped else None
        assert case.id().startswith(MODULE+'.') and (not skipped or isinstance(reason,str) and reason)
        rows.append({'id':case.id(),'skipped':skipped,'reason':reason})
    assert rows and any(not row['skipped'] for row in rows)
    assert path.read_bytes()==raw
    return {'format':'helene-idle-source-skips.v1','module':MODULE,'source':SOURCE,
        'source_sha256':hashlib.sha256(raw).hexdigest(),'platform':sys.platform,'collection_only':True,
        'test_bodies_executed':0,'cases':rows,'allowed_test_skips':{sys.platform:{SOURCE+'::'+row['id']:row['reason'] for row in rows if row['skipped']}}}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();value=collect(args.source);assert value is not None and not args.out.exists()
    args.out.write_text(json.dumps(value,indent=2),encoding='utf8')
    print(json.dumps({'platform':value['platform'],'source_sha256':value['source_sha256'],'collected':len(value['cases']),'skipped':sum(row['skipped'] for row in value['cases']),'test_bodies_executed':0}))

// Стенды по ревью 25.09 (A4/A7/A12): окно и оболочка держат слово исходником.
import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { strict as assert } from "node:assert";

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, "..", "src");
const desk = join(here, "..", "..");
const win = join(desk, "ui-kit", "window");
const code = (text) => text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/.*$/gm, "$1");
const read = (...p) => code(readFileSync(join(...p), "utf8"));

// Legacy argument naming remains camelCase. Owner28Oct removed the obsolete
// incompatible-extension update action entirely, rather than keeping a bypass.
const frame = read(win, "views", "settings-frame.ts");
assert.doesNotMatch(frame, /forceExtensions|forceToggle|не пройдут проверку/);
assert.ok(!/force_extensions:/.test(frame), "в вызовах shell() snake_case-ключ force_extensions");
for (const m of frame.matchAll(/shell(?:<[^>]*>)?\("(\w+)",\s*\{([^}]*)\}/g)) {
  const keys = [...m[2].matchAll(/(\w+)\s*:/g)].map((k) => k[1]);
  for (const k of keys) assert.ok(!k.includes("_"), `snake_case-ключ ${k} в shell("${m[1]}")`);
}

// A7 F2: расписка «Сохранено» отличает блоки, которые движок читает только на старте.
assert.match(frame, /blocksNeedingRestart\(before, out\)/, "расписка не сверяет блоки перезапуска по состоянию до записи");
assert.match(frame, /restartBtn\.hidden = !\(modeNote \|\| restartNote \|\| cfg\.needs_local_setup\)/, "перезапуск нужен при смене блоков и первом запуске");
assert.match(frame, /\["telegram", "Telegram"\]/);
assert.match(frame, /\["sandbox", "ограда"\]/);

// A7 F10: дубля строки forceToggle.hidden больше нет.
assert.ok(!/forceToggle\.hidden = true;\s*\n\s*forceToggle\.hidden = true;/.test(frame), "forceToggle.hidden = true дублируется подряд");

// A7 F5/F6/F7: запасной провайдер — одно значение в двух полях, отказ без модели, чистка при смене протокола.
const agent = read(src, "settings-agent.ts");
assert.match(agent, /setField\(spareModelOther, v\)/, "поле «Запасная модель» не отражается во втором");
assert.match(agent, /setField\(spareModelSame, v\)/, "поле «Модель запасного» не отражается в первом");
assert.match(agent, /Запасному провайдеру нужно имя модели/, "«другой провайдер» без модели сохраняется молча");
assert.match(agent, /out\.model\.fallback_framework = spareFramework/, "запасной теряет собственный протокол");
assert.ok(!/spare === "other" && frameworkOf\(provider\) !== before/.test(agent), "смена основного стирает независимый запасной адрес");

// A7 F8/F9: stop is scoped to the foreground run; receipts use request identity.
const talk = read(win, "views", "talk.ts");
assert.match(talk, /"\/api\/interrupt", \{ scope: target\.run_id \}/);
assert.ok(!/scope: "all"/.test(talk), "foreground stop must not pause all autonomy");
assert.match(talk, /"\/api\/supervisor"/);
assert.match(talk, /interruptReceiptMatches\(requestId, receipt\)/);
assert.ok(!existsSync(join(here, "interrupt-browser.html")));
console.log("review-2509: OK");

# -*- coding: utf-8 -*-
"""Hélène — труба окна: читает дерево агента и отдаёт его окну. Референс — Claude Code.

Отдельный демон по форме Атланты: свой процесс, свой порт, дерево агента
смонтировано только на чтение. Пишет ровно в три места, и все три — её:
memory/.control/desk_inbox/ (сообщения владельца из окна и с телефона),
memory/.state/devices.json (спаренные телефоны) и маркдауны разрешённых групп
через /api/md.

Кто пускается (порядок проверок в auth_middleware):
  1. Host      — только IP-литерал, localhost, *.ts.net/*.local или HELENE_HOSTS;
  2. Origin    — пусто (не браузер), оболочка, свой же origin или HELENE_ORIGINS;
  3. ключ      — HELENE_TOKEN, ключ спаренного устройства, либо петля без токена;
  4. область   — ключ устройства ходит только по списку _DEVICE_PATHS.
Открыты до ключа ровно /m/* и /pair/redeem: телефон приходит по QR за ключом,
которого у него ещё нет.

Запуск:
  HELENE_TREE=/data HELENE_TOKEN=... python deskapp.py [port]
Ручки среды: HELENE_HOST, HELENE_PORT, HELENE_HOSTS, HELENE_ORIGINS, HELENE_CONFIG.
"""
from __future__ import annotations

import asyncio
import base64
import dataclasses
import hashlib
import hmac
import datetime as dt
import json
import logging
import math
import os
import re
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import quote
from typing import Any, Awaitable, Callable

from aiohttp import web
from aiohttp.abc import AbstractAccessLogger

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from deskd import agentcfg
from deskd import artifacts
from deskd import control
from deskd import connection_checks
from deskd import readers
from deskd import forge_reader, forge_control
from deskd import rooms
from deskd import usage

# Голос читается ТЕМ ЖЕ модулем, которым его поднимает раннер
# (`localharness/voice.py`): вторая правда о том, скачана ли модель, разъехалась
# бы с первой молча — как разъехались бы два списка моделей. Модуль на стдлибе,
# канал от него не тяжелеет; раскладка `app/deskapp.py` + `app/localharness/`
# одна и в репозитории, и в поставке.
sys.path.insert(0, str(Path(__file__).resolve().parent / "localharness"))
try:
    import voice  # noqa: E402 — путь добавлен строкой выше
except ImportError:
    # Серверный пакет раннера не несёт вовсе (`deskpkg.PARTS`: localharness только у
    # настольных изданий) — и голоса у него нет по построению: агент живёт на
    # сервере, расшифровывает там же. Падать на импорте здесь значило бы уронить
    # весь канал ради ручки, которой у него не должно быть.
    voice = None
try:
    # Сторож родителя (POSIX): умерла оболочка — канал уходит вслед, а не держит
    # порт сиротой. Тот же модуль, что у движка, и по той же причине: две копии
    # одного сторожа разошлись бы. У Пульта модуля нет — и сторож ему не нужен.
    import boot as _boot  # noqa: E402 — путь добавлен выше
except ImportError:
    _boot = None

try:
    import phone_access
except ImportError:
    phone_access = None
_PHONE_ACCESS = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("frame.desk")

# UI окна — сборка Vite (app/dist); в экспортной поставке build_dist.py кладёт
# её в app/static. Старой папки static больше нет.
_HERE = Path(__file__).resolve().parent
STATIC = next((d for d in (_HERE / "static", _HERE / "app" / "dist", _HERE.parent / "app" / "dist")
               if (d / "index.html").is_file()), _HERE / "static")
TOKEN = (os.environ.get("HELENE_TOKEN") or os.environ.get("PRAXIS_DESK_TOKEN") or "").strip()
from deskd import remote_computer as _remote_computer
COOKIE = "desk_key"
_SSE_CLIENTS: set[asyncio.Queue] = set()
_WATCH_INTERVAL = 1.5

# ------------------------------------------------- кто вообще может стучаться
# ГЛАВНЫЙ ЗАМОК ЭТОГО ФАЙЛА, и раньше его не было.
#
# Труба верит петле без токена (HELENE_TOKEN не выставляет никто), а на все
# ответы вешала `Access-Control-Allow-Origin: *`. Значит ЛЮБАЯ страница в
# браузере владельца могла: прочитать memory/llm.json с ключом модели и всю
# переписку; выписать себе постоянный ключ устройства через /pair/new+/redeem;
# переписать soul/SOUL.md; и отправить POST /api/say с адресом комнаты —
# агент написал бы в рабочий чат Telegram ИМЕНЕМ ВЛАДЕЛЬЦА и продолжил бы
# отвечать на уточняющие вопросы.
#
# Замок из двух проверок, обе до всего остального:
#   Origin — браузер обязан его слать на всех не-GET/HEAD запросах и на
#            рукопожатии WebSocket (в no-cors тоже: там он либо чужой, либо
#            "null"), а читать ответ на GET страница может только в режиме
#            cors, который Origin тоже шлёт. Чужой Origin -> 403 и никакого
#            ACAO в ответе.
#   Host   — против перепривязки DNS: страница на evil.example, чей домен
#            указывает на 127.0.0.1, для браузера same-origin и Origin не
#            шлёт вовсе. Имя хоста должно быть IP-литералом или localhost.
#
# Токен это НЕ заменяет: полноценный замок — секрет от оболочки в HELENE_TOKEN
# от оболочки (shell/src/main.rs: spawn_child его НЕ ставит, поэтому TOKEN в
# продукте всегда пуст). Но Origin+Host закрывают весь браузерный класс, а его
# закрыть было нечем.

_SHELL_ORIGINS = {
    "http://tauri.localhost",      # Tauri 2 на Windows (WebView2), вшитая статика
    "https://tauri.localhost",
    "tauri://localhost",           # Tauri 2 на macOS/Linux
    # Свой протокол оболочки (0.3.0): окно читает app/static с диска и ходит
    # с origin helene.localhost — без этой строки труба отвечала 403 на всё,
    # и окно честно писало «Нет связи с харнессом» (найдено живьём 06.09).
    "http://helene.localhost",
    "https://helene.localhost",
    "helene://localhost",
    "http://localhost:5174",       # vite dev нашего же app/ (strictPort)
    "http://127.0.0.1:5174",
}
# Хосты оболочки: origin с таким именем пускается при любой схеме и порте.
_SHELL_HOSTNAMES = {"tauri.localhost", "helene.localhost"}
# Схемы оболочки. На macOS окно приходит не по http, а своим протоколом:
# `helene://localhost` (страница окна) и `tauri://localhost` (Tauri 2 без
# своего протокола). Origin с такой схемой и хостом без точки — внутренний
# хост оболочки: из веба на него не попасть, браузер такого Origin не соберёт.
_SHELL_SCHEMES = {"helene", "tauri"}
_ALLOWED_ORIGINS = _SHELL_ORIGINS | {
    o.strip().rstrip("/") for o in
    (os.environ.get("HELENE_ORIGINS") or "").split(",") if o.strip()
}
# Имена хостов сверх IP-литералов и localhost: Tailscale MagicDNS, mDNS и то,
# что владелец объявил сам (за Caddy на сервере — свой домен).
_ALLOWED_HOSTS = {h.strip().lower() for h in
                  (os.environ.get("HELENE_HOSTS") or "").split(",") if h.strip()}
_ALLOWED_HOST_SUFFIXES = (".ts.net", ".local")

# Пускается ДО ключа: телефон приходит по QR ровно за тем ключом, которого у
# него ещё нет. Без этого списка спаривание физически невозможно — телефон
# получал 403 на самой первой странице, и в Wi-Fi, и через Tailscale.
_OPEN_PATHS = {"/m", "/m/", "/m/manifest.webmanifest", "/pair/redeem", "/tg/", "/tg/config.js", "/api/phone/probe",
               # Раннер спрашивает «эта записка твоя?» (deskd/inbox_seal.py) — ключа у него
               # нет и быть не должно; маршрут только с петли и отвечает да/нет.
               "/api/inbox/claim",
               # Опознание порта БЕЗ ключа: окно обязано узнать держателя порта
               # ДО того, как предъявит ему ключ дерева (deskd/control.py::who).
               # Секретов в ответе нет — имя продукта, корень установки и pid.
               "/api/who",
               "/m/icon-192.png", "/m/icon-512.png", "/m/apple-touch-icon.png",
               # service worker регистрируется до ключа, как и сама /m/;
               # вход мини-аппа Telegram — по подписи initData, ключа ещё нет.
               "/m/sw.js", "/pair/telegram",
               # config.js читает САМА СТРАНИЦА первым тегом — до того, как у
               # неё появился ключ. Имён агента и продукта там ровно столько
               # же, сколько в манифесте PWA, который открыт по той же причине.
               "/config.js", "/m/config.js"}

# Область ключа устройства (телефона, мини-аппа). Всё остальное — только окну:
# ключ устройства уезжает в чужие руки легче всех (Wi-Fi, лог, чужая камера
# над плечом), а /api/anatomy отдаёт OPENAI_API_KEY и /api/md переписывает
# конституцию. Телефон в новом виде (КОНТРАКТ-B→A §4) показывает те же
# комнаты и «Действия», что окно: прогоны, ходы комнаты, пульс — читать
# можно, править конституцию, режим и анатомию — нет.
# /tunnel и /events пускаем: внутри канала область проверяется ещё раз, по
# каждому маршруту (_tunnel_dispatch), иначе телефон обошёл бы разбор прав.
# ⚠ Управление (контейнеры, журналы, мозг) телефону ОТКРЫТО намеренно: пара —
# это его собственное окно, он выдаёт её сам и отзывает одной кнопкой. Смысл кнопки
# «перезапустить» в том, чтобы она была под рукой, когда до компьютера не
# дойти; закрытая от телефона, она бесполезна ровно в этом случае. Что можно
# трогать — решает служба на сервере закрытым списком, а не эта строка.
_DEVICE_PATHS = {"/api/state", "/api/chats", "/api/say", "/api/health", "/api/media", "/api/artifact", "/api/forge",
                 "/api/phone/settings", "/api/phone/settings/receipt",
                 "/api/phone/subscription",
                 "/api/phone/activity", "/api/phone/forge/tasks", "/api/phone/forge/events",
                 "/api/phone/forge/payload",
                 "/api/rooms", "/api/runs", "/api/pulse", "/api/usage", "/api/allowances", "/tunnel", "/events",
                 "/api/containers", "/api/containers/restart", "/api/brain", "/api/brain-models",
                 "/api/interrupt", "/api/interrupt-step", "/api/panic", "/api/autonomy", "/api/voice/attachment"}
_DEVICE_PREFIXES = ("/api/chat/", "/api/rooms/", "/api/chat-turns/", "/api/run/",
                    "/api/container-log/")


def _hostname(raw: str) -> str:
    raw = str(raw or "").strip()
    if raw.startswith("["):                      # [::1]:8094
        return raw[1:raw.find("]")] if "]" in raw else raw[1:]
    return raw.rsplit(":", 1)[0] if ":" in raw else raw


# Хост из `phone.external` (внешний адрес канала, 06.10). Кэш по отпечатку
# файла — ПАРЕ (mtime_ns, size), как у соседнего кэша устройств: на файловых
# системах с грубым mtime (сетевые диски) одна только метка времени могла не
# заметить подмену адреса. Host-гейт спрашивается на КАЖДОМ запросе, и читать
# helene.json с диска ради него было бы лишним. Пусто — адреса нет.
_EXTERNAL_HOST_CACHE: dict = {"stamp": None, "host": ""}


def _phone_external_host() -> str:
    cfg_path = readers.config_path()
    if cfg_path is None:
        return ""
    try:
        st = cfg_path.stat()
        stamp = (st.st_mtime_ns, st.st_size)
    except OSError:
        return ""
    if _EXTERNAL_HOST_CACHE["stamp"] == stamp:
        return str(_EXTERNAL_HOST_CACHE["host"] or "")
    raw = readers._load_json(cfg_path)
    url = str(((raw.get("phone") or {}) if isinstance(raw, dict) else {}).get("external") or "").strip()
    host = ""
    if url:
        # Схема — только http/https: фронт строит QR по тем же правилам, и
        # ftp://host в гейте открыл бы имя, на котором QR-ссылка битая.
        m = re.match(r"^https?://([^/:?#]+)", url, re.I)
        candidate = (m.group(1) if m else ("" if "://" in url else url.split("/")[0])).split(":")[0]
        candidate = _hostname(candidate).strip().lower()
        # Внешний адрес — имя с точкой (FQDN). IP пускается гейтом и без этой
        # ручки, однобуквенные огрызки схемы («http://» без хоста) и wildcard
        # в разрешённые не тащим — только точное имя.
        if candidate and "*" not in candidate and "." in candidate:
            host = candidate
    _EXTERNAL_HOST_CACHE["stamp"] = stamp
    _EXTERNAL_HOST_CACHE["host"] = host
    return host


def _host_ok(request: web.Request) -> bool:
    raw = request.headers.get("Host") or ""
    if not raw:
        return True                              # HTTP/1.0 без Host — не браузер
    name = _hostname(raw).lower()
    if name in ("localhost", "") or name in _ALLOWED_HOSTS:
        return True
    if name.endswith(_ALLOWED_HOST_SUFFIXES):
        return True
    # Внешний адрес канала (`phone.external`, 06.10): телефон приходит по нему
    # через сервер с белым IP ровно за тем ключом, которого у него ещё нет.
    if name and name == _phone_external_host():
        return True
    if _PHONE_ACCESS is not None and name and name == _PHONE_ACCESS.host():
        return True
    if request.path == '/api/phone/probe':
        from localharness.server_probe import permitted
        if permitted(readers.tree(),request,name):return True
    try:
        import ipaddress
        ipaddress.ip_address(name)
        return True                              # телефон приходит по IP
    except ValueError:
        return False


def _origin_ok(request: web.Request) -> tuple[bool, str]:
    """(пустить, какой Origin эхом). Пустой Origin — не браузер, пускаем."""
    origin = (request.headers.get("Origin") or "").strip().rstrip("/")
    if not origin:
        return True, ""
    if origin in _ALLOWED_ORIGINS:
        return True, origin
    # Reopened disposable windows register an exact origin with the persistent
    # session host. No wildcard loopback CORS and no channel/agent restart.
    from localharness.session_host import configured_origin
    if configured_origin(os.environ.get('HELENE_CONFIG'), origin):
        return True, origin
    # tauri.localhost — внутренний хост оболочки, из веба на него не попасть.
    # По имени, а не по точной строке: Tauri может отдавать окно и по http, и
    # по https (useHttpsScheme), а неверная строка означала бы пустое окно.
    if _hostname(origin.split("//", 1)[-1]).lower() in _SHELL_HOSTNAMES:
        return True, origin
    # Своя схема оболочки (macOS: `helene://localhost`, `tauri://localhost`) с
    # хостом без точки — окно, не веб: чужой странице такую схему не собрать.
    scheme, sep, rest = origin.partition("://")
    if sep and scheme.lower() in _SHELL_SCHEMES and "." not in _hostname(rest):
        return True, origin
    # свой же origin: страница /m/ телефона стучится туда, откуда загрузилась.
    # Сравниваем host:port, а не схему: за Caddy наружу https, внутрь http.
    host = (request.headers.get("Host") or "").strip()
    if host and origin.split("//", 1)[-1] == host:
        return True, origin
    return False, origin


def _cors(origin: str) -> dict:
    """CORS ровно для одного разрешённого origin. Было `*` на всех ответах."""
    if not origin:
        return {"Vary": "Origin"}
    return {"Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Vary": "Origin"}


# ------------------------------------------------------------- телефон
# Спаривание по QR: окно просит одноразовую пару (с петли), телефон открывает
# ссылку /m/?pair=<токен> и меняет токен на свой ключ устройства. Токен живёт
# десять минут и годится ТРИЖДЫ (06.10, слово владельца: двух не хватало,
# когда телефон по умолчанию открывает Firefox — браузер и «Установить
# приложение» успевают съесть оба захода ещё до значка на «Домой»). Ключи
# устройств лежат хэшами в memory/.state/devices.json.

_PAIRS: dict[str, dict] = {}
_PAIR_TTL = 600
_PAIR_USES = 3
_PAIR_CACHE = {'path': None, 'stamp': None}


def _pairs_path():
    return _devices_path().with_name('phone-pairs.json')


def _pairs():
    """Pending enrollment is data, not a channel process's memory."""
    path = _pairs_path()
    if _PAIR_CACHE['path'] != str(path):
        _PAIRS.clear(); _PAIR_CACHE.update(path=str(path), stamp=None)
    try:
        info = path.stat(); stamp = (info.st_mtime_ns, info.st_size)
    except FileNotFoundError:
        if _PAIR_CACHE['stamp'] is not None:
            _PAIRS.clear();_PAIR_CACHE['stamp']=None
        return _PAIRS
    if _PAIRS and stamp == _PAIR_CACHE['stamp']: return _PAIRS
    value = json.loads(path.read_text(encoding='utf8'))
    if value.get('format') != 'helene-phone-pairs.v1' or not isinstance(value.get('pairs'), dict):
        raise ValueError('Не удалось прочитать сохранённые коды подключения телефона')
    rows = value['pairs']
    if any(not isinstance(row, dict) or type(row.get('expires')) not in (int, float)
           or not math.isfinite(row['expires']) or type(row.get('uses')) is not int or row['uses']<0
           or ('key' in row and not isinstance(row['key'],str)) for row in rows.values()):
        raise ValueError('Повреждён сохранённый код подключения телефона')
    _PAIRS.clear(); _PAIRS.update(rows); _PAIR_CACHE['stamp'] = stamp
    return _PAIRS


def _save_pairs():
    from localharness.package_notice import write
    path = _pairs_path()
    write(path, {'format': 'helene-phone-pairs.v1', 'pairs': _PAIRS})
    info = path.stat(); _PAIR_CACHE.update(path=str(path), stamp=(info.st_mtime_ns, info.st_size))


def _devices_path() -> Path:
    """Где лежат ключи спаренных телефонов.

    По умолчанию — в состоянии агента (`memory/.state/devices.json`): на
    Windows канал и дерево живут вместе, и файл там с самого начала.

    ⚠ На сервере это НЕ РАБОТАЛО и работать не могло: канал смотрит в чужое
    дерево, смонтированное только на чтение, и запись ключа падала
    `OSError: Read-only file system` — телефон получал 503 «устройство не
    записалось», а владелец видел это как «телефон не подключается» (найдено
    живьём 09.09). Ключи устройств — данные КАНАЛА, а не агента: чужое дерево
    им не место. Своя папка задаётся `HELENE_DESK_STATE` (сервер монтирует её
    на запись, см. server/desk-recipe/docker-compose.yml).
    """
    own = (os.environ.get("HELENE_DESK_STATE") or "").strip()
    if own:
        return Path(own) / "devices.json"
    return readers.tree() / "memory" / ".state" / "devices.json"


_DEVICES_CACHE: dict = {"path": None, "stamp": None, "rows": []}
_DEVICES_LOCK = threading.Lock()


def _devices() -> list[dict]:
    """Список устройств с кэшем по mtime: файл читался с диска синхронно в
    event loop и ДВАЖДЫ за каждый запрос (из _role и из переустановки cookie),
    а телефон опрашивает трубу раз в 6-8 секунд."""
    path = _devices_path()
    try:
        stat = path.stat()
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        _DEVICES_CACHE.update(path=str(path.resolve()),stamp=None,rows=[])
        return []
    identity=str(path.resolve())
    if _DEVICES_CACHE.get('path') == identity and _DEVICES_CACHE["stamp"] == stamp:
        return _DEVICES_CACHE["rows"]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        rows = [d for d in data.get("devices", []) if isinstance(d, dict)]
    except (OSError, ValueError):
        rows = []
    _DEVICES_CACHE["rows"] = rows
    _DEVICES_CACHE["stamp"] = stamp
    _DEVICES_CACHE["path"] = identity
    return rows


def _save_devices(rows: list[dict]) -> None:
    path = _devices_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(".tmp-" + path.name)
    tmp.write_text(json.dumps({"devices": rows}, ensure_ascii=False, indent=1),
                   encoding="utf-8", newline="\n")
    os.replace(tmp, path)
    _DEVICES_CACHE["stamp"] = None      # перечитать на следующем обращении


def _key_hash(key: str) -> str:
    import hashlib
    return hashlib.sha256(str(key or "").encode("utf-8")).hexdigest()


_DEVICE_SEEN: dict[str, float] = {}


def _device_ok(supplied: str) -> bool:
    if not supplied:
        return False
    h = _key_hash(supplied)
    for row in _devices():
        if secrets.compare_digest(h, str(row.get("hash") or "")):
            _DEVICE_SEEN[h] = time.time()   # сторож сольёт на диск не чаще раза в 5 мин
            return True
    return False


def _flush_device_seen() -> None:
    """«Последний раз выходил на связь» в списке устройств. Пишется редко: без
    этого владелец не мог отличить свой телефон от угнанного ключа — в карточке
    были только имя из User-Agent и дата."""
    if not _DEVICE_SEEN:
        return
    seen = dict(_DEVICE_SEEN)
    with _DEVICES_LOCK:
        rows = list(_devices())
        changed = False
        for row in rows:
            stamp = seen.get(str(row.get("hash") or ""))
            if stamp:
                row["last_seen"] = dt.datetime.fromtimestamp(
                    stamp, dt.timezone.utc).isoformat(timespec="seconds")
                changed = True
        if changed:
            try:
                _save_devices(rows)
            except OSError:
                log.debug("last_seen не записался", exc_info=True)


def _is_loopback(request: web.Request) -> bool:
    peer = request.transport.get_extra_info("peername") if request.transport else None
    host = str(peer[0]) if peer else ""
    return host in ("127.0.0.1", "::1", "::ffff:127.0.0.1")


def _role(request: web.Request) -> str:
    """"owner" — окно/эта машина, "device" — спаренный телефон, "" — никто."""
    bearer = request.headers.get("Authorization", "")
    supplied = (bearer[7:] if bearer.startswith("Bearer ") else "") or request.query.get("key") or request.cookies.get(COOKIE) or ""
    remote = getattr(request, 'app', {}).get('_remote_computer')
    if remote is not None and bearer.startswith('Bearer '):
        if request.path.startswith(_remote_computer.PREFIX + '/connect/'):
            device = request.path.rsplit('/', 1)[-1]
            if remote.authenticate(device, supplied):
                return 'computer-desktop'
        if _is_loopback(request) and remote.controller(supplied):
            return 'computer-controller'
    if TOKEN and supplied:
        try:
            if secrets.compare_digest(supplied, TOKEN):
                return "owner"
        except TypeError:
            # compare_digest на не-ASCII строке бросает TypeError мимо всех
            # except'ов middleware: `?key=привет` при заданном токене отдавал
            # 500 на ЛЮБОМ маршруте. Не наш ключ — это «не наш ключ», а не
            # авария трубы.
            pass
    if _device_ok(supplied):
        digest = _key_hash(supplied)
        # Only a fresh, signed owner Telegram enrollment grants the full program.
        # QR devices and pre-upgrade sessions retain their existing scope.
        if any(row.get('scope') == 'program' and row.get('pair') == 'tg:' + _tg_owner_id()
               and secrets.compare_digest(digest, str(row.get('hash') or '')) for row in _devices()):
            return 'owner'
        return "device"
    if not TOKEN and _is_loopback(request) and os.environ.get("HELENE_LOOPBACK_OWNER") == "1":
        # ⚠ 1.2.5 (отчёт Йоны 29.09): «петля без токена = владелец» отдавала роль владельца
        # любому процессу этой машины — и shell самого агента, и тому, что за прокси приходит
        # с 127.0.0.1. В продукте ключ ставят всегда (оболочка, служба, надзор сервера);
        # без ключа — только явная ручка для разработки.
        return "owner"
    return ""


def _scope_ok(role: str, path: str) -> bool:
    if role == "owner":
        return True
    if role == 'computer-desktop':
        return bool(re.fullmatch(re.escape(_remote_computer.PREFIX) + r'/connect/[a-f0-9]{32}', path))
    if role == 'computer-controller':
        return path == _remote_computer.PREFIX + '/controller/state' or path.startswith(_remote_computer.PREFIX + '/bridge/')
    if role != "device":
        return False
    return path in _DEVICE_PATHS or path.startswith(_DEVICE_PREFIXES)


def _open_path(path: str) -> bool:
    return path in _OPEN_PATHS or path == '/tg/icon-192.png' or path.startswith(("/m/assets/", "/tg/assets/"))


@web.middleware
async def auth_middleware(request: web.Request, handler):
    if not _host_ok(request):
        log.warning("отказ по Host: %r", request.headers.get("Host"))
        return web.Response(status=403, text="чужой адрес")
    origin_ok, origin = _origin_ok(request)
    if not origin_ok:
        log.warning("отказ по Origin: %r -> %s", origin, request.path)
        return web.Response(status=403, text="чужая страница")
    cors = _cors(origin)
    if request.method == "OPTIONS":  # CORS preflight нативной оболочки — без ключа
        return web.Response(status=204, headers=cors)
    role = "owner" if _open_path(request.path) else _role(request)
    if not role:
        return web.Response(status=403, text="нет ключа", headers=cors)
    if not _open_path(request.path) and not _scope_ok(role, request.path):
        return web.Response(status=403, headers=cors,
                            text="телефону сюда нельзя — это делают из окна")
    try:
        response = await handler(request)
    except web.HTTPException as exc:
        # Раньше CORS дописывался ТОЛЬКО к успешному ответу: 400/409/404
        # уезжали голыми, браузер отбрасывал их по CORS, и вместо внятного
        # «руннер не поднят — запусти локальный харнесс и повтори» владелец
        # видел «Не ушло: Failed to fetch».
        exc.headers.update(cors)
        return exc
    response.headers.update(cors)
    supplied = request.query.get("key") or ""
    if supplied and ((TOKEN and supplied == TOKEN) or _device_ok(supplied)):
        response.set_cookie(COOKIE, supplied, max_age=365 * 24 * 3600,
                            httponly=True, samesite="Lax")
    return response


# ------------------------------------------------------- разбор параметров

def _int_arg(query, name: str, default: int, lo: int, hi: int) -> int:
    """Целое из query с честным 400 вместо 500 и с потолком СНИЗУ тоже.

    Было `min(200, int(...))`: `?limit=abc` роняло ручку в 500 с трассировкой в
    лог, а `?n=-1` обходило объявленный потолок (`lines[-n:]` при n=-1 отдаёт
    весь буфер) и вывозило до 4 МБ переписки одним запросом.
    """
    raw = query.get(name)
    if raw in (None, ""):
        return default
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(text=f"{name}: нужно целое число, а не {raw!r}")
    return max(lo, min(hi, value))


async def _json_body(request: web.Request):
    """Тело POST с честным 400. Кривое тело давало 500 и трассировку в лог."""
    try:
        return await request.json()
    except (ValueError, UnicodeDecodeError):
        raise web.HTTPBadRequest(text="ожидается JSON")


def _new_pair() -> dict:
    with _DEVICES_LOCK:
        now = time.time()
        pairs = _pairs()
        before = dict(pairs)
        for token, row in list(pairs.items()):
            if row["expires"] < now or row["uses"] <= 0:
                pairs.pop(token, None)
        token = secrets.token_urlsafe(24)
        pairs[token] = {"expires": now + _PAIR_TTL, "uses": _PAIR_USES}
        try: _save_pairs()
        except Exception:
            _PAIRS.clear(); _PAIRS.update(before); raise
    return {"token": token, "path": "/m/?pair=" + token,
            "expires_in": _PAIR_TTL, "uses": _PAIR_USES}


def _revoke_device(wanted: str) -> dict:
    """Отвязать устройство. Снимается ВСЯ пара, а не одна её половина: один QR
    рождал две строки (второй обмен для значка на «Домой» на iPhone), владелец
    видел два одинаковых «iPhone · 03.09.2026», жал «Отвязать» на одной — и
    телефон продолжал работать по второму ключу. Это дыра в отзыве."""
    with _DEVICES_LOCK:
        rows = _devices()
        pairs = {str(d.get("pair") or "") for d in rows
                 if str(d.get("id")) == str(wanted or "") and d.get("pair")}
        left = [d for d in rows
                if str(d.get("id")) != str(wanted or "")
                and not (d.get("pair") and str(d.get("pair")) in pairs)]
        _save_devices(left)
    return {"left": len(left)}


def _device_rows() -> list[dict]:
    return [{k: d.get(k) for k in ("id", "name", "created", "addr", "last_seen")}
            for d in _devices()]


def _redeem(token: str, ua: str, addr: str) -> dict:
    """Обмен токена пары на ключ устройства.

    Тот же токен -> ТОТ ЖЕ ключ и та же строка: два обмена (Safari и значок на
    «Домой») — это одно устройство в двух хранилищах, а не два устройства.
    Списание использования — ПОСЛЕ успешной записи: раньше `uses -= 1` стоял до
    неё, и при занятом файле или дереве только на чтение использование сгорало,
    ключ не сохранялся, а владелец видел «Код устарел» без объяснения.
    """
    with _DEVICES_LOCK:
        row = _pairs().get(token)
        if row is None:
            raise web.HTTPForbidden(
                text=json.dumps({'code': 'pair_unknown', 'error': 'Код не найден: ссылка могла истечь или канал перезапустился. Покажи QR заново.'}, ensure_ascii=False),
                content_type='application/json')
        if row["expires"] < time.time() or row["uses"] <= 0:
            raise web.HTTPForbidden(
                text=json.dumps({'code': 'pair_expired', 'error': 'Код устарел или уже использован — покажи QR заново.'}, ensure_ascii=False),
                content_type='application/json')
        if row.get("key"):
            if not _device_ok(row['key']):
                raise web.HTTPForbidden(text=json.dumps({'code':'pair_expired','error':'Устройство отвязано. Покажи новый QR.'}),content_type='application/json')
            row["uses"] -= 1
            try: _save_pairs()
            except Exception:
                row['uses'] += 1; raise
            return {"key": row["key"], "uses_left": row["uses"]}
        key = "dk-" + secrets.token_urlsafe(30)
        kind = ("iPhone" if "iPhone" in ua else "iPad" if "iPad" in ua
                else "Android" if "Android" in ua else "телефон")
        rows = list(_devices())
        rows.append({"id": secrets.token_hex(6), "pair": _key_hash(token)[:16],
                     "name": kind, "hash": _key_hash(key), "addr": addr,
                     "created": dt.datetime.now(dt.timezone.utc)
                     .isoformat(timespec="seconds"),
                     "last_seen": dt.datetime.now(dt.timezone.utc)
                     .isoformat(timespec="seconds")})
        try:
            _save_devices(rows)
        except OSError as exc:
            log.warning("устройство не записалось (%s)", _devices_path(), exc_info=True)
            # Причину называем прямо: на сервере дерево смонтировано на чтение,
            # и «проверь, что папка данных доступна» отправляло владельца
            # проверять не то. Своя папка канала — HELENE_DESK_STATE.
            why = ("дерево смонтировано только на чтение"
                   if getattr(exc, "errno", None) == 30 else str(exc)[:120])
            raise web.HTTPServiceUnavailable(
                text=f"не смог записать ключ устройства в {_devices_path()}: {why}. "
                     "Канал пишет ключи телефонов туда, куда указывает HELENE_DESK_STATE — "
                     "на сервере это отдельная папка на запись (server/desk-recipe).")
        row["key"] = key
        row["uses"] -= 1
        try: _save_pairs()
        except Exception:
            row.pop('key',None); row['uses'] += 1
            _save_devices(rows[:-1])
            raise
        return {"key": key, "uses_left": row["uses"]}


async def api_pair_redeem(request):
    """Телефон меняет токен на ключ устройства. Токен годится трижды (iPhone
    и браузер по умолчанию; 06.10 — слово владельца про Firefox)."""
    token = str(request.query.get("token") or "")
    peer = request.transport.get_extra_info("peername") if request.transport else None
    supplied = request.headers.get('Authorization','')
    device = supplied[7:] if supplied.startswith('Bearer dk-') else ''
    if not token and device and await asyncio.to_thread(_device_ok,device):
        # Reestablish this already-authorized device's cookie after importing
        # an installed PWA fragment. No enrollment or new device is created.
        got = {'key':device,'uses_left':None}
    else:
        got = await asyncio.to_thread(
            _redeem, token, str(request.headers.get("User-Agent") or ""),
            str(peer[0]) if peer else "")
    response = _json({"key": got["key"], "agent": _agent_name(),
                      "uses_left": got["uses_left"]})
    response.headers['Cache-Control']='no-store'
    response.set_cookie(COOKIE, got["key"], max_age=365 * 24 * 3600,
                        httponly=True, samesite="Lax",secure=request.scheme=='https' or request.headers.get('X-Forwarded-Proto')=='https')
    return response


# ------------------------------------------------------------- PWA /m/
_HERE_DIR = Path(__file__).resolve().parent
# Телефон: в поставке рядом лежит готовая `app/mobile` (её кладёт build_dist), в
# репозитории — `mobile/dist` от Vite. ⚠ Порядок: сборка ПЕРВОЙ. У `mobile/` в
# репозитории тоже есть index.html — но это вход Vite со ссылкой на /src/main.ts,
# и на нём /m/ открывалась пустой страницей (третий кандидат, `../mobile/dist`,
# не существует ни в одной раскладке — он и не срабатывал никогда).
MOBILE = next((d for d in (_HERE_DIR / "mobile" / "dist", _HERE_DIR / "mobile",
                           _HERE_DIR.parent / "mobile" / "dist")
               if (d / "index.html").is_file()), _HERE_DIR / "mobile")


async def mobile_index(request):
    """Страница телефона и мини-аппа. `no-store`: WebView Telegram и PWA на
    экране «Домой» живут неделями, и HTTP-кэш не должен подменять сетевой
    ответ старым index.html — офлайн-копией управляет только service worker,
    который знает штамп своей сборки (приём из hardbot, слово владельца 07.09;
    сама страница сверяет свою сборку с серверной — ui-kit/version.ts)."""
    if not (MOBILE / "index.html").is_file():
        raise web.HTTPNotFound(text="мобильная страница не собрана")
    return web.FileResponse(MOBILE / "index.html", headers={
        "Cache-Control": "no-store, max-age=0", "Pragma": "no-cache"})


async def mobile_sw(request):
    """Service worker телефона (`/m/sw.js`, КОНТРАКТ-B→A §5): лежит в корне
    области `/m/`, отдаётся с `no-cache`, чтобы новая сборка SW подхватывалась
    браузером при следующем открытии."""
    if not (MOBILE / "sw.js").is_file():
        raise web.HTTPNotFound(text="service worker не собран")
    return web.FileResponse(MOBILE / "sw.js", headers={
        "Cache-Control": "no-cache", "Content-Type": "text/javascript; charset=utf-8"})


def _agent_name() -> str:
    """Имя агента для телефона и мини-аппа (КОНТРАКТ-B→A §9): снимок анатомии
    → `agent.name` из helene.json → `HELENE_AGENT_NAME` (сервер без конфига
    продукта) → «Агент». У дерева без снимка Hélène (Praxis) первого
    источника нет — телефон получал «Агент»."""
    anatomy = readers.anatomy() or {}
    return str(anatomy.get("agent_name") or readers.product_config().get("agent_name")
               or os.environ.get("HELENE_AGENT_NAME") or "").strip() or "Агент"


# ---------------------------------------------------- вход мини-аппа Telegram

def _tg_tokens() -> list[str]:
    """Токены ботов, из которых открывается мини-апп: `telegram.bot_token`
    конфига и `HELENE_TG_BOT_TOKENS` (список через запятую — у Праксис два
    бота открывают один мини-апп). В чужой `.env` не лазим."""
    tokens: list[str] = []
    cfg_path = readers.config_path()
    if cfg_path is not None:
        raw = readers._load_json(cfg_path)
        token = str((raw.get("telegram") or {}).get("bot_token") or "").strip()
        if token:
            tokens.append(token)
    for token in (os.environ.get("HELENE_TG_BOT_TOKENS") or "").split(","):
        if token.strip() and token.strip() not in tokens:
            tokens.append(token.strip())
    return tokens


def _tg_owner_id() -> str:
    cfg_path = readers.config_path()
    owner = ""
    if cfg_path is not None:
        raw = readers._load_json(cfg_path)
        owner = str((raw.get("telegram") or {}).get("owner_id") or "").strip()
    if owner in ("", "0"):
        owner = str(os.environ.get("HELENE_TG_OWNER_ID") or "").strip()
    return "" if owner == "0" else owner


def _telegram_init_user(init_data: str, tokens: list[str], *, max_age: float = 7 * 86400,
                        now: float | None = None) -> dict:
    """Пользователь из `Telegram.WebApp.initData` — по подписи, иначе ValueError словами.

    Алгоритм Telegram Web Apps: `secret = HMAC_SHA256("WebAppData", bot_token)`,
    `hash == HMAC_SHA256(secret, data_check_string)`, где строка — пары
    `key=value` (без `hash`) через `\\n` в порядке ключей. Подпись сверяется с
    каждым токеном по очереди; `auth_date` не старше `max_age`.
    """
    from urllib.parse import parse_qsl
    data = dict(parse_qsl(str(init_data or ""), keep_blank_values=True))
    given = str(data.pop("hash", "") or "")
    if not given or not data:
        raise ValueError("нет подписи Telegram")
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    for token in tokens:
        secret = hmac.new(b"WebAppData", str(token).encode("utf-8"), hashlib.sha256).digest()
        calc = hmac.new(secret, check.encode("utf-8"), hashlib.sha256).hexdigest()
        if hmac.compare_digest(calc, given.lower()):
            break
    else:
        raise ValueError("подпись Telegram не сошлась")
    try:
        auth_date = int(data.get("auth_date") or 0)
    except (TypeError, ValueError):
        auth_date = 0
    if (now if now is not None else time.time()) - auth_date > max_age:
        raise ValueError("вход устарел — открой мини-апп заново")
    try:
        user = json.loads(data.get("user") or "{}")
    except ValueError:
        user = {}
    if not isinstance(user, dict) or not user.get("id"):
        raise ValueError("в подписи нет пользователя")
    return user


def _tg_login(user: dict, addr: str) -> dict:
    """Ключ устройства для мини-аппа — той же природы, что у QR (`_redeem`).
    Одно устройство на одного пользователя Telegram: прежняя строка того же
    `pair` заменяется, иначе каждое открытие мини-аппа плодило бы строку в
    списке устройств владельца."""
    key = "dk-" + secrets.token_urlsafe(30)
    pair = "tg:" + str(user.get("id"))
    name = "Telegram · " + (str(user.get("first_name") or user.get("username") or "").strip()
                            or str(user.get("id")))
    stamp = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    with _DEVICES_LOCK:
        rows = [d for d in _devices() if str(d.get("pair") or "") != pair]
        rows.append({"id": secrets.token_hex(6), "pair": pair, "name": name, "scope": "program",
                     "hash": _key_hash(key), "addr": addr, "created": stamp,
                     "last_seen": stamp})
        _save_devices(rows)
    return {"key": key, "name": name}


async def api_pair_telegram(request):
    """`POST /pair/telegram {initData}` → `{key, agent}` (КОНТРАКТ-B→A §6).
    Только владельцу (`telegram.owner_id` или `HELENE_TG_OWNER_ID`); чужому —
    403 словами. Открыт до ключа: ключа у мини-аппа ещё нет."""
    payload = await _json_body(request) or {}
    tokens = _tg_tokens()
    if not tokens:
        raise web.HTTPServiceUnavailable(
            text="у канала нет токена бота — вход из Telegram не настроен")
    try:
        user = _telegram_init_user(str(payload.get("initData") or ""), tokens)
    except ValueError as exc:
        raise web.HTTPForbidden(text=str(exc))
    owner = _tg_owner_id()
    if not owner or str(user.get("id")) != owner:
        raise web.HTTPForbidden(text="этот мини-апп открыт только владельцу агента")
    peer = request.transport.get_extra_info("peername") if request.transport else None
    got = await asyncio.to_thread(_tg_login, user, str(peer[0]) if peer else "")
    response = _json({"key": got["key"], "agent": _agent_name(), "device": got["name"]})
    response.headers['Cache-Control'] = 'no-store'
    response.set_cookie(COOKIE, got["key"], max_age=365 * 24 * 3600,
                        httponly=True, samesite="Lax",
                        secure=request.scheme=='https' or request.headers.get('X-Forwarded-Proto')=='https')
    if _PHONE_ACCESS is not None:
        _PHONE_ACCESS.authorized()
    return response


async def mobile_manifest(request):
    """Retired standalone install endpoint; never export a device in a URL."""
    return web.json_response({'code': 'miniapp_only', 'message': 'Открой меню своего Telegram-бота или отправь /app.'},
                             status=410, headers={'Cache-Control': 'no-store'})


class SafeAccessLogger(AbstractAccessLogger):
    """Access-log БЕЗ строки запроса с query.

    Формат aiohttp по умолчанию — `%r`, то есть «GET /api/health?key=dk-… HTTP/1.1».
    Телефон шлёт свой постоянный ключ в query каждые 6-8 секунд, а /pair/redeem
    несёт токен пары; оболочка заворачивает вывод ребёнка в <дерево>/deskapp.log,
    и этот же файл кнопка «Собрать логи для поддержки» кладёт в zip, который
    владелец отправляет постороннему. helene.json в архив осознанно НЕ берут
    (там ключ модели) — а лог с тысячами копий ключа устройства брали.
    Подменить атом %r нельзя: compile_format берёт методы из БАЗОВОГО класса,
    поэтому пишем строку сами. Путь без query, остальное как было.
    """

    def log(self, request, response, time) -> None:
        if not self.logger.isEnabledFor(logging.INFO):
            return
        self.logger.info('%s "%s %s" %s %s', request.remote or "-",
                         request.method, request.path, response.status,
                         response.body_length)


def _json(data) -> web.Response:
    return web.json_response(data, dumps=lambda d: json.dumps(d, ensure_ascii=False))


# ------------------------------------------------------------------ API
#
# ОДНА таблица маршрутов на оба канала (ревью 06.09, §5; задача A п. 1.11).
# Окно ходит по каналу (WebSocket /tunnel), браузер и телефон — по HTTP. До
# 07.09 у каждой двери был свой список ручек, и ручка, заведённая в одном
# списке, в другом отвечала 404: так было с /api/home (единственной из
# двадцати), потом с /api/mode. Теперь ручка — это строка в ROUTES: aiohttp-
# роутер и диспетчер канала строятся из неё, и «есть в одном канале из двух»
# стало невозможно по построению (стенд: tests/t_routes.py).
#
# Обработчик получает обезличенный запрос (Call) и возвращает ТЕЛО ответа —
# то, что уедет json-ом, — либо бросает web.HTTPError (404/400/409 словами),
# либо возвращает Fail, когда ответу нужен ещё и `code` (конфликт mtime).
# Оба канала переводят это в свою форму одинаково.

@dataclasses.dataclass
class Call:
    match: dict            # параметры пути: {peer}, {stream}, {run_id}
    query: dict            # query-строка, последнее значение на ключ
    body: Any              # разобранный JSON тела POST/DELETE или None
    local: bool            # запрос с этой машины (петля)
    role: str              # owner | device
    app: Any = None        # per-channel private services, never a global cross-agent relay


@dataclasses.dataclass
class Fail:
    status: int
    error: str
    code: str = ""


@dataclasses.dataclass(frozen=True)
class Route:
    method: str
    path: str              # aiohttp-шаблон: "/api/chat/{peer}"
    handler: Callable[[Call], Awaitable[Any]]
    local_only: bool = False   # только с этой машины (окно): пары телефона
    http_handler: Any = None   # streaming WebSocket upgrade cannot be nested in the JSON tunnel


def _reader(fn: Callable[[], Any]):
    """Ручка-читатель без параметров: `readers.<имя>` в потоке."""
    async def handler(call: Call):
        return await asyncio.to_thread(fn)
    return handler


async def _r_forge(c: Call):
    # Device scope permits a structural overview, not Forge's free-text goal
    # or worker metadata. Authorization alone cannot sanitize the response.
    reader = readers.forge_device_tasks if c.role == "device" else readers.forge_tasks
    return await asyncio.to_thread(reader)


async def _r_program_invoke(c: Call):
    from deskd import program
    from deskd.phone_settings import SettingsError
    if c.role != 'owner':
        return Fail(403, 'Открой программу через меню своего Telegram-бота заново.')
    try:
        return await asyncio.to_thread(program.invoke, c.body)
    except SettingsError as error:
        return Fail(error.status, str(error))
    except (OSError, ValueError, RuntimeError) as error:
        return Fail(400, str(error))


async def _r_phone_settings(c: Call):
    from deskd import phone_settings
    try:return await asyncio.to_thread(phone_settings.snapshot)
    except phone_settings.SettingsError as error:return Fail(error.status,str(error))


async def _r_phone_settings_save(c: Call):
    from deskd import phone_settings
    try:return await asyncio.to_thread(phone_settings.save,c.body)
    except phone_settings.SettingsError as error:return Fail(error.status,str(error))


async def _r_phone_settings_receipt(c: Call):
    operation=c.query.get('operation','')
    if not re.fullmatch('[a-f0-9]{32}',operation):return Fail(400,'Не указан номер сохранения')
    from localharness.package_notice import read
    value=await asyncio.to_thread(read,readers.tree()/'memory/.state/phone-settings-receipt.json')
    return value if value.get('operation')==operation else Fail(404,'Сохранение ещё не подтверждено')


async def _r_phone_subscription(c: Call):
    from deskd import phone_settings
    try:return await asyncio.to_thread(phone_settings.subscription,c.body)
    except phone_settings.SettingsError as error:return Fail(error.status,str(error))


async def _r_phone_activity(c: Call):
    from localharness.self_review_integration import activity
    try:return await asyncio.to_thread(activity,readers.tree(),c.query.get('review_cursor',''),_int_arg(c.query,'review_limit',20,1,100))
    except ValueError as error:return Fail(400,str(error))


async def _r_phone_forge_tasks(c: Call):
    from deskd import forge_snapshot
    try:return await asyncio.to_thread(forge_snapshot.phone_activity,readers.tree(),_int_arg(c.query,'limit',20,1,100),c.query.get('cursor',''))
    except forge_reader.ReadError as error:return Fail(error.status,str(error))


async def _r_phone_forge_events(c: Call):
    from deskd import phone_activity
    try:return await asyncio.to_thread(phone_activity.events,readers.tree(),c.query.get('task_id',''),c.query.get('unit_id',''),
        _int_arg(c.query,'offset',0,0,2**53-1),_int_arg(c.query,'limit',50,1,100),c.query.get('generation',''),_int_arg(c.query,'after_seq',0,0,2**53-1))
    except forge_reader.ReadError as error:return Fail(error.status,str(error))


async def _r_phone_forge_payload(c: Call):
    if c.role not in ('owner', 'device'):
        raise web.HTTPForbidden(text='Paired device required')
    try:
        return await asyncio.to_thread(forge_reader.payload, readers.tree(),
            c.query.get('task_id', ''), c.query.get('unit_id', ''), c.query.get('sha256', ''),
            c.query.get('kind', 'payload'), _int_arg(c.query, 'offset', 0, 0, 2**53-1),
            _int_arg(c.query, 'limit', 8000, 1, 8000))
    except forge_reader.ReadError as error:
        return Fail(error.status, str(error))


async def _forge_owner(c: Call, fn, *args, **kwargs):
    # Handler-level check also protects direct tunnel dispatch/tests, not only
    # the HTTP scope middleware. Owner records never extend paired /api/forge.
    if c.role != "owner":
        raise web.HTTPForbidden(text="Forge details and control require the owner key")
    try:
        return await asyncio.to_thread(fn, readers.tree(), *args, **kwargs)
    except forge_reader.ReadError as exc:
        return Fail(exc.status, str(exc), "forge_record")


async def _r_forge_tasks(c: Call):
    if c.query.get('view') == 'active':
        from deskd import forge_snapshot
        return await _forge_owner(c, forge_snapshot.activity,
                                  _int_arg(c.query, 'limit', 20, 1, 100), c.query.get('cursor') or '')
    return await _forge_owner(c, forge_reader.tasks, _int_arg(c.query, "limit", 30, 1, 100))


async def _r_forge_task(c: Call):
    return await _forge_owner(c, forge_reader.task_detail, c.query.get("task_id") or "")


async def _r_forge_events(c: Call):
    return await _forge_owner(c, forge_reader.events, c.query.get("task_id") or "",
                              c.query.get("unit_id") or "",
                              _int_arg(c.query, "offset", 0, 0, 2**53 - 1),
                              _int_arg(c.query, "limit", 50, 1, 100),
                              c.query.get("generation") or "",
                              _int_arg(c.query, "after_seq", 0, 0, 2**53 - 1))


async def _r_forge_payload(c: Call):
    return await _forge_owner(c, forge_reader.payload, c.query.get("task_id") or "",
                              c.query.get("unit_id") or "", c.query.get("sha256") or "",
                              c.query.get("kind") or "payload",
                              _int_arg(c.query, "offset", 0, 0, 2**53 - 1),
                              _int_arg(c.query, "limit", 8000, 1, 8000))


async def _r_forge_control(c: Call):
    if not isinstance(c.body, dict):
        raise web.HTTPBadRequest(text="Expected a Forge control object")
    value = c.body
    result = await _forge_owner(c, forge_control.enqueue, value.get("task_id") or "",
                              value.get("action") or "", value.get("agent_id") or "",
                              value.get("expected_generation") or "", value.get("command_id") or "")
    from deskd import forge_snapshot
    forge_snapshot.invalidate()
    return result


async def _r_forge_receipt(c: Call):
    if c.query.get("task_id"):
        return await _forge_owner(c, forge_control.recent, c.query["task_id"])
    return await _forge_owner(c, forge_control.receipt, c.query.get("command_id") or "")


def _state_with_autonomy():
    from deskd import autonomy
    snapshot=dict(readers.state())
    snapshot['autonomy']=autonomy.state(readers.tree())
    if snapshot['autonomy']['paused'] and snapshot['autonomy']['available'] and (snapshot.get('runner') or {}).get('alive'):
        snapshot.update(level='off',phrase='На связи · агент на паузе',action=None)
    return snapshot


async def _r_runs(c: Call):
    return await asyncio.to_thread(readers.list_runs, _int_arg(c.query, "limit", 80, 1, 200),
                                   c.query.get("kind") or "", c.query.get("before") or "")


async def _r_run(c: Call):
    detail = await asyncio.to_thread(readers.run_detail, c.match["run_id"])
    if not detail:
        raise web.HTTPNotFound(text="нет такого запуска")
    return detail


async def _r_frame_stats(c: Call):
    return await asyncio.to_thread(readers.frame_cuts, _int_arg(c.query, "days", 7, 1, 90))


async def _r_spend(c: Call):
    # Ревизия расхода по чатам, людям и задачам (deskd/spend.py) — из журнала
    # вызовов и манифестов прогонов, дерево не трогает.
    from deskd import spend
    return await asyncio.to_thread(spend.collect, readers.tree(), _int_arg(c.query, "days", 7, 1, 90))


async def _r_run_result(c: Call):
    payload = await asyncio.to_thread(readers.run_result, c.match["run_id"], c.match["result_id"])
    if not payload:
        raise web.HTTPNotFound(text="нет такого результата")
    return payload


async def _r_shadow_captures(c: Call):
    return await asyncio.to_thread(readers.shadow_captures, c.match["stream"])


async def _r_shadow_capture(c: Call):
    name = c.query.get("name") or ""
    text = await asyncio.to_thread(readers.shadow_capture, c.match["stream"], name)
    return {"stream": c.match["stream"], "name": name, "text": text}


async def _r_shadow_diff(c: Call):
    return await asyncio.to_thread(readers.shadow_diff, c.match["stream"],
                                   c.query.get("old") or "", c.query.get("new") or "")


async def _r_shadow_metrics(c: Call):
    stream = c.query.get("stream") or c.match.get("stream") or ""
    return await asyncio.to_thread(readers.shadow_metrics, 120, stream)


async def _r_chats(c: Call):
    return await asyncio.to_thread(readers.chats)


async def _r_chat(c: Call):
    return await asyncio.to_thread(readers.chat_tail, c.match["peer"],
                                   _int_arg(c.query, "n", 200, 1, 600))


async def _r_chat_turns(c: Call):
    return await asyncio.to_thread(readers.chat_turns, c.match["peer"],
                                   _int_arg(c.query, "n", 120, 1, 300))


async def _r_md(c: Call):
    return await asyncio.to_thread(readers.safe_read_md, c.query.get("path") or "")


_RETENTION_CACHE: dict = {}


def _retention_module():
    """localharness/retention.py по пути файла: имя слишком общее для sys.path."""
    if "mod" not in _RETENTION_CACHE:
        import importlib.util
        path = Path(__file__).resolve().parent / "localharness" / "retention.py"
        spec = importlib.util.spec_from_file_location("desk_retention", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _RETENTION_CACHE["mod"] = mod
    return _RETENTION_CACHE["mod"]


async def _r_retention(c: Call):
    """Леджер ретенции рабочих материалов (слово владельца 01.10).

    GET — отчёт без изменений на диске; POST {action:"sweep"} — уборка
    однозначного мусора (staging старых обновлений) с записью леджера;
    POST {action:"delete", path} — удалить ОДНУ папку свежего снимка (05.10,
    «никак не чистится»): слово владельца кнопкой. Путь сверяется со свежей
    классификацией на месте — произвольного удаления по пути нет; модели и
    снимки кнопка не трогает. Телефону ручка не открыта: до этих путей
    устройство не пускает scope-гейт middleware.
    """
    action = str((c.body or {}).get("action") or "report")

    def run():
        mod = _retention_module()
        root = readers.tree()
        if action == "sweep":
            return mod.sweep(root)
        if action == "delete":
            return mod.delete_entry(root, None, str((c.body or {}).get("path") or ""))
        return {"schema": mod.SCHEMA, "entries": mod.classify(root), "removed": []}

    try:
        return await asyncio.to_thread(run)
    except Exception as exc:
        return Fail(500, f"леджер не собрался: {exc}", "retention")


async def _r_md_write(c: Call):
    """Правка маркдауна агента из окна: конституция, навыки, заметки.

    Путь только внутри разрешённых групп (readers.safe_write_md), только .md,
    запись атомарная. Окно возвращает mtime_ns, который получило при чтении,
    и при расхождении ручка отвечает 409 (code=conflict), а не переписывает
    молча чужую правку — владелец правит SOUL.md в окне, агент правит его же
    своей рукой, и раньше выигрывал тот, кто записал последним.
    """
    body = c.body or {}
    result = await asyncio.to_thread(readers.safe_write_md, str(body.get("path") or ""),
                                     str(body.get("text") or ""), body.get("mtime_ns"))
    if result.get("error"):
        return Fail(409 if result.get("code") == "conflict" else 400,
                    result["error"], str(result.get("code") or ""))
    return result


async def _r_agent_config(c: Call):
    """Настройки агента, живущего рядом с этим каналом: что можно править.

    ⚠ Только для ключа ВЛАДЕЛЬЦА (в `_DEVICE_PATHS` этой ручки нет): телефон
    правит слово агенту, а не его мозг и бот-токен.

    Ключи раскладки (где python, где код, порт, служба, реле) сюда не попадают
    вовсе — см. `deskd/agentcfg.HIDDEN`: экран не должен показывать ручек,
    которых он всё равно не сохранит.
    """
    return await asyncio.to_thread(agentcfg.state)


async def _r_agent_config_save(c: Call):
    """Записать разрешённые блоки в конфиг агента. Расписка называет отброшенное.

    Сверка свежести — как у маркдаунов: агент правит свой конфиг и сам
    (`switch_brain` пишет туда же), и выигрывать не должен тот, кто записал
    последним. Разошлось — 409, а не тихая перезапись.
    """
    body = c.body or {}
    result = await asyncio.to_thread(agentcfg.save, body.get("config"),
                                     body.get("mtime_ns"))
    if not result.get("ok"):
        code = str(result.get("code") or "")
        return Fail(409 if code == "conflict" else 400,
                    str(result.get("error") or "не записалось"), code)
    return result


async def _r_self_review(c: Call):
    if c.role != "owner":
        return Fail(403, "Self-review controls require the owner key.")
    from localharness import self_review_integration
    try:
        if c.body is not None:
            result = await asyncio.to_thread(self_review_integration.command, readers.tree(), c.body)
            return result
        if c.query.get("activity") == "1":
            return await asyncio.to_thread(self_review_integration.activity, readers.tree())
        config = agentcfg.state()
        return await asyncio.to_thread(self_review_integration.status, readers.tree(),
                                       config.get("config") or {}, str(c.query.get("id") or ""))
    except (OSError, ValueError, TypeError) as exc:
        return Fail(400, str(exc))


async def _r_media(c: Call):
    """Вложение из ленты — байтами. Голос агента окно проигрывает этим.

    Телефону сюда МОЖНО (ручка в `_DEVICE_PATHS`): он показывает ту же переписку,
    и голос в ней — та же реплика, только звуком. Что именно отдаётся, решает
    `readers.media_file`: закрытый список корней и расширений, никаких `..`, и
    результат сверяется с деревом уже после разрешения ссылок.
    """
    path, ctype, why = await asyncio.to_thread(readers.media_file, c.query.get("path") or "")
    if path is None:
        return Fail(404, why or "нет такого вложения", "no_media")
    return web.FileResponse(path, headers={"Content-Type": ctype,
                                           "Cache-Control": "private, max-age=3600"})


async def _r_artifact(c: Call):
    path, why = artifacts.resolve(readers.tree(), c.query.get("path") or "")
    if path is None:
        return Fail(404, why, "no_artifact")
    details = artifacts.metadata(readers.tree(), c.query.get("path") or "")
    mime = details.get("media_mime") or "application/octet-stream"
    preview = c.query.get("preview") == "1"
    safe_inline = mime in {"application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp"} or mime.startswith("text/")
    if preview and mime.startswith("text/"):
        mime = "text/plain; charset=utf-8"
    disposition = "inline" if preview and safe_inline else "attachment"
    filename = quote(details.get("media_name") or path.name, safe="")
    return web.FileResponse(path, headers={"Content-Type": mime,
        "Content-Disposition": disposition + "; filename*=UTF-8''" + filename,
        "X-Content-Type-Options": "nosniff", "Cache-Control": "private, max-age=3600",
        "Content-Security-Policy": "sandbox; default-src 'none'"})


async def _r_relay_auth_import(c: Call):
    if c.role != "owner" or os.environ.get("HELENE_SERVER_AUTH_IMPORT") != "1":
        raise web.HTTPForbidden(text="Приём входа доступен владельцу на сервере")
    from deskd import relay_auth
    try:
        return relay_auth.enqueue(readers.tree(), (c.body or {}).get("auth"),
                                  (c.body or {}).get("replace") is True)
    except ValueError as exc:
        raise web.HTTPBadRequest(text=str(exc))


async def _r_relay_auth_status(c: Call):
    if c.role != "owner" or os.environ.get("HELENE_SERVER_AUTH_IMPORT") != "1":
        raise web.HTTPForbidden(text="Статус входа доступен владельцу на сервере")
    from deskd import relay_auth
    try:
        return relay_auth.receipt(readers.tree(), c.query.get("id"))
    except ValueError as exc:
        raise web.HTTPBadRequest(text=str(exc))


async def _r_local_files(c: Call):
    if c.role != "owner" or not c.local or os.environ.get("HELENE_SERVER_AUTH_IMPORT") == "1":
        raise web.HTTPForbidden(text="Файлы компьютера выбирают из локального окна владельца")
    from deskd import local_files
    try:
        if c.body is None:
            return await asyncio.to_thread(local_files.listing, c.query.get("path") or "")
        body = c.body
        if not isinstance(body, dict):
            raise ValueError("Файловый диалог не получил действие")
        if body.get("action") == "read":
            return await asyncio.to_thread(local_files.read_file, str(body.get("path") or ""))
        if body.get("action") == "save":
            return await asyncio.to_thread(local_files.save_file, readers.tree(),
                                          str(body.get("rel") or ""), str(body.get("folder") or ""),
                                          str(body.get("name") or ""), body.get("overwrite") is True, body.get("data"))
        raise ValueError("Неизвестное действие файлового диалога")
    except FileExistsError:
        raise web.HTTPConflict(text="Файл с этим именем уже существует")
    except local_files.FileOutcomeUnknown as exc:
        raise web.HTTPServiceUnavailable(text=str(exc))
    except (OSError, ValueError) as exc:
        raise web.HTTPBadRequest(text=str(exc))


async def _r_home(c: Call):
    """Чьё это дерево. Оболочка спрашивает перед тем, как признать живой на
    порту харнесс своим: осиротевший процесс прежней установки держал порт, и
    новое окно молча показывало чужого агента."""
    return {"tree": str(readers.tree().resolve())}


async def _r_who(c: Call):
    """Кто держит этот порт — анонимно. Окно спрашивает ДО ключа: иначе токен
    дерева уезжал бы первому, кто занял порт (см. `control.who`)."""
    # Корень установки — папка, где лежит helene.json. Это путь, а не секрет:
    # его печатает мастер и видно в списке процессов.
    cfg = readers.config_path()
    return control.who(cfg.parent if cfg is not None else None)


async def _r_mode(c: Call):
    """Ограда (песочница | интерактивный) и ОТДЕЛЬНО от неё служба.

    Два независимых ответа в одном теле: `name`/`choices` — какая ограда,
    `service_installed`/`session0`/`firewall`/`service` — что со службой. Служба
    режимом не является: она ставится поверх любой ограды и ограду не снимает
    (склейка этих двух измерений и была P0 первой редакции). Плюс опция
    `computer` с живым снимком тела и живые просьбы о папках (`mounts_live`).
    """
    return await asyncio.to_thread(readers.mode_state)


async def _r_say(c: Call):
    body = c.body or {}
    return await _say(body.get("text"), body.get("chat") or "",
                      attachments=body.get("attachments"), via=c.role or "owner")


_LEDGER: dict = {"obj": None}


def _ledger():
    """Журнал записок канала (deskd/inbox_seal) — только когда надзор его включил."""
    from deskd import inbox_seal
    path = inbox_seal.ledger_path()
    if path is None:
        return None
    if _LEDGER["obj"] is None or _LEDGER["obj"].path != path:
        _LEDGER["obj"] = inbox_seal.Ledger(path)
    return _LEDGER["obj"]


async def _r_inbox_claim(c: Call):
    """Раннер: «эта записка твоя?» — имя и sha256 её байтов; `done` — ход прошёл."""
    ledger = _ledger()
    if ledger is None:
        return Fail(409, "журнал записок не ведётся (HELENE_INBOX_SEALED не стоит)")
    body = c.body or {}
    return await asyncio.to_thread(ledger.claim, str(body.get("name") or ""),
                                   str(body.get("sha") or ""), bool(body.get("done")))


async def _r_rooms_create(c: Call):
    return await asyncio.to_thread(_room_op, rooms.create, (c.body or {}).get("title"))


async def _r_rooms_rename(c: Call):
    return await asyncio.to_thread(_room_op, rooms.rename, c.match["peer"],
                                   (c.body or {}).get("title"))


async def _r_rooms_delete(c: Call):
    return await asyncio.to_thread(_room_op, rooms.delete, c.match["peer"])


def _room_op(fn, *args):
    """Комнаты окна (задача A §3): отказ реестра — словами и кодом, не 500."""
    try:
        return fn(readers.tree(), *args)
    except rooms.RoomError as exc:
        return Fail(exc.status, str(exc), "room")


async def _r_pair_new(c: Call):
    pair = _new_pair()
    if _PHONE_ACCESS is not None:
        pair['url'] = _PHONE_ACCESS.url
    return pair


async def _r_phone_state(c: Call):
    return _PHONE_ACCESS.state() if _PHONE_ACCESS is not None else {
        'state': 'unavailable', 'message': 'Этот канал не поддерживает автоматическое подключение телефона.'}


async def _r_telegram_check(c: Call):
    path=readers.config_path()
    config=json.loads(path.read_text(encoding='utf-8-sig')) if path else {}
    return await asyncio.to_thread(connection_checks.check_telegram,config,(c.body or {}).get('telegram'))


async def _r_phone_probe(c: Call):
    value={'instance': _PHONE_ACCESS.instance if _PHONE_ACCESS is not None else ''}
    challenge=str(c.query.get('challenge') or '')
    if TOKEN and re.fullmatch(r'[A-Za-z0-9_-]{16,128}',challenge):
        from localharness import remote_locator
        value.update(challenge=challenge,proof=remote_locator.signature(TOKEN,challenge,value['instance']))
    return value


async def _r_phone_retry(c: Call):
    if _PHONE_ACCESS is not None:
        _PHONE_ACCESS.retry()
    return await _r_phone_state(c)


async def _r_panic(c: Call):
    # Stop-only authority for already paired owner devices; no remote resume.
    config = readers.config_path()
    if config is None:
        return {'ok': False, 'note': 'Не найден конфиг установки для аварийной остановки.'}
    try:
        from localharness import emergency
        return await asyncio.to_thread(emergency.request, config, via='phone' if c.role == 'device' else 'window')
    except Exception:
        return {'ok': False, 'note': 'Стоп не подтверждён. Используй /panic в Telegram или аварийный ярлык на компьютере.'}


async def _r_panic_state(c: Call):
    try:
        from localharness import emergency
        return emergency.state()
    except ImportError:
        return {'stopped': None, 'resume_remote': False}


async def _r_devices(c: Call):
    return _device_rows()


async def _r_revoke(c: Call):
    return _revoke_device(str((c.body or {}).get("id") or ""))



async def _r_supervisor(c: Call):
    """Кто держит харнесс, что поднято и можно ли им отсюда управлять."""
    return await asyncio.to_thread(control.supervisor_state, readers.tree())


async def _r_autonomy(c: Call):
    from deskd import autonomy
    return await asyncio.to_thread(autonomy.state, readers.tree())


async def _r_autonomy_set(c: Call):
    from deskd import autonomy
    if not isinstance(c.body, dict): return Fail(400, 'Нужна команда pause или resume.')
    return await asyncio.to_thread(autonomy.request, readers.tree(), (c.body or {}).get('action'), c.role)


async def _r_supervisor_restart(c: Call):
    """Просьба владельца перезапустить агента, реле или весь харнесс.

    Канал только КЛАДЁТ просьбу: детей поднимает надзор, и он же единственный,
    кто вправе их трогать. Отказ «надзора нет» — обычный ответ с причиной.
    """
    return await asyncio.to_thread(control.ask, readers.tree(),
                                   str((c.body or {}).get("target") or ""))


async def _r_update(c: Call):
    """Обновление на сервере (27.09): есть ли исполнитель, что с планом, что было."""
    return await asyncio.to_thread(control.update_state, readers.tree())


async def _r_update_plan(c: Call):
    """Владелец нажал «Обновить» в окне. Нажатие и есть его «да» (27.09, «всё максимально
    просто»): исполнитель сверит выпуск и начнёт сам, второй кнопки нет."""
    body = c.body or {}
    return await asyncio.to_thread(control.update_plan, readers.tree(),
                                   str(body.get("version") or "latest"),
                                   str(body.get("backup") or "full"),
                                   str(body.get("reason") or ""), "owner-window",
                                   consent="window")


async def _r_update_confirm(c: Call):
    """«Да» или «нет» владельца кнопкой — на ту расписку, что он видит (id и ключ из неё)."""
    body = c.body or {}
    return await asyncio.to_thread(control.update_confirm, readers.tree(),
                                   str(body.get("id") or ""), str(body.get("nonce") or ""),
                                   str(body.get("decision") or ""), "window")


async def _r_update_verdict(c: Call):
    """Слово владельца на испытании: «принять» или «откатить» — поверх слова агента."""
    body = c.body or {}
    return await asyncio.to_thread(control.update_verdict, readers.tree(),
                                   str(body.get("id") or ""), str(body.get("key") or ""),
                                   str(body.get("verdict") or ""), "window",
                                   str(body.get("words") or ""))


async def _r_logs(c: Call):
    return await asyncio.to_thread(control.log_names, readers.tree())


async def _r_log(c: Call):
    return await asyncio.to_thread(control.tail, readers.tree(), c.match["name"],
                                   _int_arg(c.query, "lines", 200, 1, control.MAX_LINES))



def _voice_config() -> dict:
    """Только блок `voice` из helene.json — и ничего больше.

    Канал не отдаёт наружу ключи никогда; читать конфиг целиком ради одной
    ручки значило бы завести вторую дорогу к `model.key`.
    """
    path = readers.config_path()
    if path is None:
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}
    block = raw.get("voice") if isinstance(raw, dict) else None
    return {"voice": block if isinstance(block, dict) else {}, '_speech_epoch': path.stat().st_mtime_ns}


async def _r_voice(c: Call):
    """Слышит ли агент: библиотека, модель, ход скачивания и причина молчания."""
    if voice is None:
        return {"schema": "helene.voice.v1", "enabled": False, "ready": False,
                "why": "этот канал стоит без исполнителя ходов (издание к серверу) — "
                       "голос живёт там, где живёт агент",
                "model": "", "catalog": [], "installed": {}, "dir": "",
                "library": {"present": False, "why": "в этой установке нет исполнителя ходов"},
                "download": None}
    return await asyncio.to_thread(lambda: voice.state(readers.tree(), _voice_config()))


async def _r_voice_preview(c: Call):
    if voice is None:raise ValueError('Voice component unavailable')
    tree = readers.tree().resolve()
    config = readers.config_path()
    from localharness import fish_speech
    identity = (c.body or {}).get('request_id')
    return await asyncio.to_thread(voice.preview, tree, _voice_config(), c.body or {},
        configuration=_voice_config, stopped=lambda: readers.tree().resolve()!=tree or readers.config_path()!=config
            or (bool(identity) and fish_speech.status(tree, identity).get('cancelled') is True))


async def _r_voice_fish_key(c: Call):
    from localharness import fish_speech
    body = c.body or {}
    return await asyncio.to_thread(fish_speech.configure_key, readers.tree(), None if body.get('delete') is True else body.get('key', ''))


async def _r_voice_intent(c: Call):
    from localharness import fish_speech
    identity = (c.body or {}).get('request_id') if c.body else c.query.get('request_id')
    action = fish_speech.cancel if c.body and c.body.get('cancel') is True else fish_speech.status
    return await asyncio.to_thread(action, readers.tree(), identity)


async def _r_voice_attachment(c: Call):
    from localharness import voice_admission
    body=c.body or {}
    relative=str(body.get('path') or c.query.get('path') or '')
    source,why=artifacts.resolve(readers.tree(),relative)
    if source is None:raise ValueError(why)
    from localharness.telegram_inputs import original_kind
    kind=original_kind(readers.tree(),relative,source)
    if not kind:
        raise ValueError('Transcription status belongs to an exact incoming audio original')
    if kind=='window' and not voice_admission.is_audio(source):
        raise ValueError('This attachment is not audio')
    if c.body:
        if not voice_admission.record_path(source).is_file():raise ValueError('No failed transcription to retry')
        value=voice_admission.retry(source)
    else:value=voice_admission.state(source)
    return dict(value,can_retry=value['status']=='error')


async def _r_containers(c: Call):
    """Контейнеры рядом с этим каналом: живы ли, с каких пор (deskd/control.py)."""
    return await asyncio.to_thread(control.containers)


async def _r_container_restart(c: Call):
    """Перезапустить названный контейнер. Что позволено — решает служба, не окно."""
    body = c.body or {}
    return await asyncio.to_thread(control.container_restart, str(body.get("name") or ""))


async def _r_container_log(c: Call):
    return await asyncio.to_thread(control.container_log, c.match["name"],
                                   _int_arg(c.query, "lines", 200, 1, 400),
                                   (c.query.get("errors") or "") in ("1", "true", "yes"))


async def _r_brain(c: Call):
    """Роли мозга и их модели. Ключи провайдеров сюда не попадают никогда."""
    return await asyncio.to_thread(control.brain)


async def _r_brain_models(c: Call):
    """Что мозг отдаёт СЕЙЧАС: список у него, не у нас (каталог реле сжимается)."""
    return await asyncio.to_thread(control.brain_models, refresh=c.query.get('refresh') == '1')


async def _r_brain_set(c: Call):
    body = c.body or {}
    fields = body.get("fields")
    return await asyncio.to_thread(control.brain_set, str(body.get("role") or ""),
                                   fields if isinstance(fields, dict) else {})


async def _r_interrupt_step(c: Call):
    return await asyncio.to_thread(control.interrupt_step, readers.tree(),
                                   str((c.body or {}).get("run_id") or ""))


async def _r_interrupt(c: Call):
    """Прервать живой ход агента (12.09): просьба в memory/.control, раннер читает на тике.
    Телефону открыто наравне с перезапуском — это окно владельца."""
    body = c.body or {}
    return await asyncio.to_thread(control.interrupt, readers.tree(),
                                   str(c.role or "owner"), str(body.get("scope") or "all"),
                                   str(body.get("reason") or ""))


async def _r_fold_state(c: Call):
    """Память чата: сколько горячего, пороги, идёт ли свёртка (27.09, кнопка в окне)."""
    return await asyncio.to_thread(control.fold_state, readers.tree(), str(c.match.get("room") or "window"))


async def _r_fold(c: Call):
    """Свернуть память чата сейчас — просьба раннеру; телефону не открыто."""
    body = c.body or {}
    return await asyncio.to_thread(control.fold_request, readers.tree(),
                                   str(body.get("room") or "window"), str(c.role or "owner"))


def _remote_call_owner(c: Call):
    if c.role != 'owner' or c.app is None:
        raise web.HTTPForbidden(text='Only the window owner can pair or select a desktop')
    if not isinstance(c.body, dict) or len(json.dumps(c.body).encode()) > 4096:
        raise web.HTTPBadRequest(text='Invalid or oversized desktop owner request')
    return c.body


async def _r_remote_pair(c: Call):
    value = _remote_call_owner(c)
    try:
        return c.app['_remote_computer'].pair(value.get('name'), value.get('scopes'))
    except (ValueError, TypeError) as error:
        raise web.HTTPBadRequest(text=str(error))


async def _r_remote_select(c: Call):
    value = _remote_call_owner(c)
    device = value.get('device')
    if not isinstance(device, str):
        raise web.HTTPBadRequest(text='Expected a desktop identity')
    try:
        return c.app['_remote_computer'].select(device)
    except ValueError as error:
        raise web.HTTPBadRequest(text=str(error))


async def _r_remote_revoke(c: Call):
    value = _remote_call_owner(c)
    device = value.get('device')
    if not isinstance(device, str) or not _remote_computer.DEVICE.fullmatch(device):
        raise web.HTTPBadRequest(text='Expected a desktop identity')
    return await c.app['_remote_computer'].revoke(device)


async def _r_remote_snapshot(c: Call):
    if c.app is None:
        raise web.HTTPServiceUnavailable(text='Desktop channel unavailable')
    return c.app['_remote_computer'].snapshot()


async def _r_remote_connect(c: Call):
    return Fail(400, 'Desktop WebSocket requires the dedicated HTTP upgrade')


ROUTES: tuple[Route, ...] = (
    Route('POST', _remote_computer.PREFIX + '/pair', _r_remote_pair),
    Route('POST', _remote_computer.PREFIX + '/select', _r_remote_select),
    Route('POST', _remote_computer.PREFIX + '/revoke', _r_remote_revoke),
    Route('GET', _remote_computer.PREFIX + '/state', _r_remote_snapshot),
    Route('GET', _remote_computer.PREFIX + '/controller/state', _r_remote_snapshot),
    Route('GET', _remote_computer.PREFIX + '/connect/{device}', _r_remote_connect,
          http_handler=lambda request: request.app['_remote_computer'].connect(request)),
    Route("GET", "/api/runs", _r_runs),
    Route("GET", "/api/run/{run_id}", _r_run),
    Route("GET", "/api/run/{run_id}/result/{result_id}", _r_run_result),
    Route("GET", "/api/frame-stats", _r_frame_stats),
    Route("GET", "/api/spend", _r_spend),
    Route("GET", "/api/pulse", _reader(lambda: readers.pulse())),
    Route("GET", "/api/usage", _reader(lambda: usage.statistics(readers.tree()))),
    Route("GET", "/api/allowances", _reader(lambda: usage.allowances(readers.tree()))),
    Route("GET", "/api/errors", _reader(lambda: readers.errors())),
    Route("GET", "/api/board", _reader(lambda: readers.board())),
    Route("GET", "/api/agenda", _reader(lambda: readers.agenda())),
    Route("GET", "/api/forge", _r_forge),
    Route("POST", "/api/program/invoke", _r_program_invoke),
    Route("GET", "/api/phone/settings", _r_phone_settings),
    Route("POST", "/api/phone/settings", _r_phone_settings_save),
    Route("GET", "/api/phone/settings/receipt", _r_phone_settings_receipt),
    Route("GET", "/api/phone/subscription", _r_phone_subscription),
    Route("POST", "/api/phone/subscription", _r_phone_subscription),
    Route("GET", "/api/phone/activity", _r_phone_activity),
    Route("GET", "/api/phone/forge/tasks", _r_phone_forge_tasks),
    Route("GET", "/api/phone/forge/events", _r_phone_forge_events),
    Route("GET", "/api/phone/forge/payload", _r_phone_forge_payload),
    Route("GET", "/api/forge/tasks", _r_forge_tasks),
    Route("GET", "/api/forge/task", _r_forge_task),
    Route("GET", "/api/forge/events", _r_forge_events),
    Route("GET", "/api/forge/payload", _r_forge_payload),
    Route("POST", "/api/forge/control", _r_forge_control),
    Route("GET", "/api/forge/control", _r_forge_receipt),
    Route("GET", "/api/shadow", _reader(lambda: readers.shadow_streams())),
    Route("GET", "/api/shadow/{stream}/captures", _r_shadow_captures),
    Route("GET", "/api/shadow/{stream}/capture", _r_shadow_capture),
    Route("GET", "/api/shadow/{stream}/diff", _r_shadow_diff),
    Route("GET", "/api/shadow/{stream}/metrics", _r_shadow_metrics),
    Route("GET", "/api/shadow-metrics", _r_shadow_metrics),
    Route("GET", "/api/chats", _r_chats),
    Route("GET", "/api/chat/{peer}", _r_chat),
    Route("GET", "/api/chat-turns/{peer}", _r_chat_turns),
    Route("GET", "/api/md", _r_md),
    Route("POST", "/api/md", _r_md_write),
    Route("GET", "/api/retention", _r_retention),
    Route("POST", "/api/retention", _r_retention),
    Route("GET", "/api/media", _r_media),
    Route("GET", "/api/artifact", _r_artifact),
    Route("POST", "/api/relay/auth/import", _r_relay_auth_import),
    Route("GET", "/api/relay/auth/status", _r_relay_auth_status),
    Route("GET", "/api/local-files", _r_local_files, local_only=True),
    Route("POST", "/api/local-files", _r_local_files, local_only=True),
    Route("GET", "/api/agent-config", _r_agent_config),
    Route("POST", "/api/agent-config", _r_agent_config_save),
    Route("GET", "/api/self-review", _r_self_review),
    Route("POST", "/api/self-review", _r_self_review),
    Route("GET", "/api/md-tree", _reader(lambda: readers.md_tree())),
    # Обе ручки окно и телефон опрашивают каждые несколько секунд; рубеж от
    # 500-х стоит ВНУТРИ readers.state/readers.health — он общий на оба канала.
    Route("GET", "/api/health", _reader(lambda: readers.health())),
    Route("GET", "/api/state", _reader(_state_with_autonomy)),
    Route("GET", "/api/mode", _r_mode),
    Route("GET", "/api/home", _r_home),
    # Без ключа (в _OPEN_PATHS): «свой или чужой» до предъявления ключа.
    Route("GET", "/api/who", _r_who),
    Route("GET", "/api/anatomy", _reader(lambda: readers.anatomy())),
    Route("POST", "/api/say", _r_say),
    Route("POST", "/api/inbox/claim", _r_inbox_claim, local_only=True),
    # Управление харнессом, который живёт не здесь (deskd/control.py). В
    # _DEVICE_PATHS их нет намеренно: перезапуск и журналы — дело владельца, а
    # не спаренного телефона.
    # Контейнеры и мозг — через службу рядом с каналом (server/deskctl.py). Она
    # вне агента: перезапуск нужен ровно тогда, когда агент лёг и файловый
    # протокол выше уже некому исполнить.
    Route("GET", "/api/containers", _r_containers),
    Route("POST", "/api/containers/restart", _r_container_restart),
    Route("GET", "/api/container-log/{name}", _r_container_log),
    Route("GET", "/api/brain", _r_brain),
    Route("GET", "/api/brain-models", _r_brain_models),
    Route("POST", "/api/brain", _r_brain_set),
    Route("POST", "/api/interrupt", _r_interrupt),
    Route("GET", "/api/autonomy", _r_autonomy),
    Route("POST", "/api/autonomy", _r_autonomy_set),
    Route("POST", "/api/panic", _r_panic),
    Route("GET", "/api/panic", _r_panic_state),
    Route("POST", "/api/interrupt-step", _r_interrupt_step),
    Route("GET", "/api/memory-fold/{room}", _r_fold_state),
    # Compaction belongs to the acting agent; no owner force-fold ingress.
    Route("GET", "/api/voice", _r_voice),
    Route("POST", "/api/voice/preview", _r_voice_preview),
    Route("POST", "/api/voice/fish-key", _r_voice_fish_key),
    Route("GET", "/api/voice/intent", _r_voice_intent),
    Route("POST", "/api/voice/intent", _r_voice_intent),
    Route("GET", "/api/voice/attachment", _r_voice_attachment),
    Route("POST", "/api/voice/attachment", _r_voice_attachment),
    Route("GET", "/api/supervisor", _r_supervisor),
    Route("POST", "/api/supervisor/restart", _r_supervisor_restart),
    # Обновление на сервере: канал только кладёт план и «да» — исполняет сосед снаружи
    # контейнера (server/updater). Телефону сюда нельзя, как и к перезапуску.
    Route("GET", "/api/update", _r_update),
    Route("POST", "/api/update/plan", _r_update_plan),
    Route("POST", "/api/update/confirm", _r_update_confirm),
    Route("POST", "/api/update/verdict", _r_update_verdict),
    Route("GET", "/api/logs", _r_logs),
    Route("GET", "/api/log/{name}", _r_log),
    # Комнаты окна (задача A §3): создать, переименовать, убрать в архив.
    Route("POST", "/api/rooms", _r_rooms_create),
    Route("POST", "/api/rooms/{peer}", _r_rooms_rename),
    Route("DELETE", "/api/rooms/{peer}", _r_rooms_delete),
    # Телефон: пары выдаёт и отзывает ВЛАДЕЛЕЦ — тот, у кого ключ окна.
    #
    # ⚠ Здесь стояло `local_only=True` («только окно на этой машине»), и это
    # ломало единственную раскладку, в которой QR по-настоящему нужен: окно к
    # харнессу на сервере. Окно там по определению не на той машине, канал
    # отвечал 403 «только с этой машины», и телефон подключить было НЕЧЕМ
    # (найдено владельцем 09.09 на живом Praxis).
    # Защиты эта строка не добавляла: пару выдаёт только роль `owner`, а ключ
    # окна и так открывает всё — переписку, конституцию (`/api/md`) и отправку
    # реплик. Ключу устройства сюда по-прежнему нельзя: /pair/* нет ни в
    # _DEVICE_PATHS, ни в префиксах (стенд t_phone.py).
    Route("POST", "/pair/new", _r_pair_new),
    Route("GET", "/api/phone", _r_phone_state),
    Route("POST", "/api/telegram/check", _r_telegram_check),
    Route("GET", "/api/phone/probe", _r_phone_probe),
    Route("POST", "/api/phone/retry", _r_phone_retry),
    Route("GET", "/pair/devices", _r_devices),
    Route("POST", "/pair/revoke", _r_revoke),
)


def _route_regex(path: str) -> "re.Pattern[str]":
    return re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", path) + "$")


_ROUTE_INDEX: tuple[tuple[Route, "re.Pattern[str]"], ...] = tuple(
    (route, _route_regex(route.path)) for route in ROUTES)


def match_route(method: str, path: str) -> tuple[Route | None, dict]:
    """Строка таблицы для метода и пути канала. (None, {}) — нет такого пути."""
    method = str(method or "GET").upper()
    for route, pattern in _ROUTE_INDEX:
        found = pattern.match(path)
        if found and route.method == method:
            return route, dict(found.groupdict())
    return None, {}


def _http_handler(route: Route):
    """HTTP-дверь к строке таблицы: aiohttp-запрос -> Call -> json-ответ."""
    async def handler(request: web.Request):
        if route.http_handler is not None:
            return await route.http_handler(request)
        if route.local_only and not _is_loopback(request):
            raise web.HTTPForbidden(text="только с этой машины")
        body = None
        if route.method in ("POST", "DELETE") and request.can_read_body:
            body = await _json_body(request)
        call = Call(match=dict(request.match_info),
                    query={k: request.query.get(k) for k in request.query},
                    body=body, local=_is_loopback(request), role=_role(request), app=request.app)
        result = await route.handler(call)
        if isinstance(result, web.StreamResponse):
            return result
        if isinstance(result, Fail):
            # Текстом, как прежние HTTPConflict/HTTPBadRequest: клиенты читают
            # причину из тела ответа словами.
            return web.Response(status=result.status, text=result.error)
        response = _json(result)
        if route.path.startswith(_remote_computer.PREFIX) or route.path.startswith('/api/forge/'):
            response.headers['Cache-Control'] = 'no-store'
        return response
    return handler


_SAY_RE = re.compile(r"[^\w\-]+")


_CHAT_KEY_RE = re.compile(r"^-?\d+(?:__topic__\d+)?$")


_ATTACH_MAX_FILES = 16
_ATTACH_MAX_BYTES = 64 * 1024 * 1024
_ATTACH_MAX_TOTAL = 128 * 1024 * 1024
_ATTACH_MIME = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp",
                "image/gif": ".gif",
                # Голосовое из окна (0.6.0): запись микрофона едет тем же подвалом
                # `[вложения]`, а руннер расшифровывает её тем же whisper, что и
                # голосовые из Telegram (`localharness/voice.py`). Типы — те, что
                # даёт MediaRecorder в WebView2/Chromium и что декодирует PyAV.
                "audio/webm": ".webm", "audio/ogg": ".ogg", "audio/mp4": ".m4a",
                "audio/mpeg": ".mp3", "audio/wav": ".wav", "audio/x-wav": ".wav"}
_ATTACH_AUDIO = frozenset(m for m in _ATTACH_MIME if m.startswith("audio/"))


def _attachments_in(raw) -> list[dict]:
    """Вложения из тела запроса: `[{name, mime, data(base64)}]` -> проверенные байты.

    Картинки (те, что читает модель — см. `_MODEL_IMAGE_MIME` в дереве) и
    голосовые (расшифровывает руннер) — как раньше. Любой ДРУГОЙ файл тоже
    принимается (01.10, слово владельца: вложения — просто папка хода):
    руннер копирует его в runs/<id>/files, агент работает им руками; расширение
    неизвестных типов берём из имени, без расширения — честное `.bin`.
    """
    if raw in (None, "", []):
        return []
    if not isinstance(raw, list):
        raise web.HTTPBadRequest(text="attachments должен быть списком")
    if len(raw) > _ATTACH_MAX_FILES:
        raise web.HTTPBadRequest(text=f"не больше {_ATTACH_MAX_FILES} вложений за раз")
    out: list[dict] = []
    total_bytes = 0
    for i, item in enumerate(raw, 1):
        if not isinstance(item, dict):
            raise web.HTTPBadRequest(text=f"вложение #{i}: не объект")
        # `audio/webm;codecs=opus` — так называет запись MediaRecorder; параметры
        # после «;» типу не принадлежат.
        mime = str(item.get("mime") or "").strip().lower().split(";", 1)[0].strip()
        try:
            data = base64.b64decode(str(item.get("data") or ""), validate=True)
        except (ValueError, TypeError):
            raise web.HTTPBadRequest(text=f"вложение #{i}: data — не base64")
        if not data:
            raise web.HTTPBadRequest(text=f"вложение #{i}: пустой файл")
        if len(data) > _ATTACH_MAX_BYTES:
            raise web.HTTPBadRequest(text=f"вложение #{i}: больше 64 МБ")
        total_bytes += len(data)
        if total_bytes > _ATTACH_MAX_TOTAL:
            raise web.HTTPBadRequest(text="вложения вместе больше 128 МБ")
        name = re.sub(r"[^\w.\-]+", "_", str(item.get("name") or "").strip(), flags=re.UNICODE)
        if mime in _ATTACH_MIME:
            name = name.strip("._") or (f"voice{i}" if mime in _ATTACH_AUDIO else f"image{i}")
            if not name.lower().endswith(_ATTACH_MIME[mime]) and not (
                    mime == "image/jpeg" and name.lower().endswith(".jpeg")):
                name += _ATTACH_MIME[mime]
        else:
            # Материал хода: руннер положит файл в папку прогона по имени.
            name = name.strip("._") or f"file{i}"
            if not Path(name).suffix:
                name += ".bin"
        out.append({"name": name[:120], "mime": mime, "data": data})
    return out


def _write_attachments(control: Path, stamp: str, files: list[dict]) -> list[str]:
    """Файлы вложений в `desk_inbox/attachments/<stamp>/` — атомарно, до записки.

    -> относительные пути (от desk_inbox) для подвала записки; читатель (руннер)
    переносит их в свой медиа-спул и отдаёт модели картинкой в кадре.
    """
    folder = control / "attachments" / stamp
    folder.mkdir(parents=True, exist_ok=True)
    from localharness import media_metadata
    (folder/media_metadata.DIRECTORY).mkdir(exist_ok=True)
    rel_paths: list[str] = []
    for i, f in enumerate(files, 1):
        name = f["name"]
        target = folder / name
        if target.exists():
            stem, ext = os.path.splitext(name)
            name = f"{stem}-{i}{ext}"
            target = folder / name
            collision = 1
            while target.exists():
                name = f"{stem}-{i}-{collision}{ext}"
                target = folder / name
                collision += 1
        tmp = target.with_name(".part-" + target.name)
        with open(tmp, "wb") as handle:
            handle.write(f["data"])
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, target)
        metadata=media_metadata.path_for(target,'mime.json')
        metadata.write_text(json.dumps({'mime':f['mime']},ensure_ascii=False),encoding='utf-8')
        rel_paths.append(f"attachments/{stamp}/{name}")
    return rel_paths


async def _say(text: str, chat: str = "", attachments=None, via: str = "owner") -> dict:
    """Сообщение ей. Durable-файл в memory/.control/desk_inbox — и всё.

    `chat` — адрес комнаты (слово владельца 31.08: окно — ещё одна дверь владельца в
    ЛЮБУЮ его комнату). Пусто/«window» — прежний путь (и старый ключ до 10.09.2026). Telegram-ключ — записка
    `<stamp>__to__<ключ>.md`: руннер запишет реплику владельца в память ЭТОЙ
    комнаты и поведёт ход там; ответ уедет в Telegram. Мёртвый руннер = мёртвый
    бот, и класть адресное сообщение туда, откуда оно никогда не уедет адресату,
    значило бы врать квитанцией — отвечаем 409 честно.

    Убран прежний «честный фолбэк» в workspace/inbox. Комментарий обещал, что
    «она читает его уже сегодня», но в дереве workspace/inbox — папка СКАЧАННЫХ
    телеграм-вложений с квотами и раскладкой groups/private; её опрашивают
    только руки inbox_list/inbox_read, которые агент зовёт по своей воле. Условие
    фолбэка ровно «руннер мёртв» — то есть звать руку некому: фолбэк по
    построению не мог сработать в том единственном случае, ради которого написан.
    Зато записка ложилась в плоский корень вне конвенции, могла быть прочитана
    вторым заходом как «файл из Telegram», а расписка written:["inbox"] считала
    это доставкой. Канал desk_inbox durable и переживает рестарт сам.

    Живость читателя берётся из readers.reader_status — ТОГО ЖЕ источника, что и
    шапка окна. Было два несовместимых определения: здесь mtime файла с порогом
    48 ЧАСОВ, в readers.state — поле `at` с порогом 45 секунд. Из-за этого окно
    показывало «Не запущен» и одновременно принимало сообщение как доставленное
    mid-turn: ни строки в ленте, ни тоста, ни ошибки.
    """
    text = str(text or "").strip()
    chat = str(chat or "").strip()
    files = _attachments_in(attachments)
    if not text and not files:
        raise web.HTTPBadRequest(text="пустое сообщение")
    if len(text) > 20_000:
        raise web.HTTPBadRequest(text="слишком длинно (20k)")
    if chat and chat not in (rooms.ROOM_DEFAULT, rooms.ROOM_LEGACY) and not _CHAT_KEY_RE.match(chat) \
            and not rooms.is_room(chat):
        raise web.HTTPBadRequest(text=f"не похоже на адрес комнаты: {chat!r}")
    # A Telegram-room note is a private owner instruction to the agent. Files
    # follow that same route; the instruction itself is not posted by the bot.
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    body = (f"# Сообщение с окна владельца · {stamp}\n\n{text}\n")
    # Адресная записка — и в Telegram-комнату, и в другую комнату окна
    # (`window-<hex>`, задача A §3): раннер ведёт ход в ней (`__to__<ключ>`).
    targeted = bool(chat and chat not in (rooms.ROOM_DEFAULT, rooms.ROOM_LEGACY))

    def _write() -> dict:
        written = []
        control = readers.tree() / "memory" / ".control" / "desk_inbox"
        # Вложения — файлами рядом с запиской, до её публикации: записка называет
        # их в подвале `[вложения]`, и читатель, захвативший записку, уже видит
        # готовые файлы (порядок записи = порядок видимости).
        footer = ""
        rel_paths: list[str] = []
        if files:
            rel_paths = _write_attachments(control, stamp, files)
            footer = "\n[вложения]\n" + "".join(
                f"- {rel} · {f['mime']} · {len(f['data'])}\n" for rel, f in zip(rel_paths, files))
        body_text = body + footer
        # Квитанция читателя: её раннер (кандидат desk-midturn) пишет .reader.json
        # при старте и обновляет на ходу. Свежая квитанция = канал живой,
        # сообщение уедет mid-turn.
        reader = readers.reader_status()
        reader_alive = reader["alive"]
        # Ревью 26.09 (W3 S1): живой раннер во сне записку не читает — она ждёт его конца.
        sleeping = bool(reader.get("busy")) and reader.get("run") == "sleep"
        # Контракт канала (её ревью 29.08): публикация ТОЛЬКО атомарной подменой.
        # Пишем во временное имя, которого glob читателя не видит, затем
        # os.replace — под финальным именем частичный файл не существует никогда,
        # и читатель, захватывающий rename-ом, не может получить обрезанный текст.
        def _publish(target: Path) -> None:
            blob = body_text.encode("utf-8")
            # 1.2.5: сначала — в журнал канала (его папка агенту закрыта), потом публикация.
            # Раннер примет записку, только если она есть в журнале с этими же байтами.
            ledger = _ledger()
            if ledger is not None:
                ledger.seal(target.name, blob, via)
            # Имя временного файла — случайное и создаётся с O_EXCL: заранее подложенная
            # в приёмную ссылка с предсказуемым именем не увела бы запись канала мимо.
            tmp = target.with_name(f".tmp-{secrets.token_hex(8)}-{target.name}")
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o664)
            with os.fdopen(fd, "wb") as fh:
                fh.write(blob)
            os.replace(tmp, target)

        if targeted and not reader_alive:
            raise web.HTTPConflict(
                text="исполнитель ходов не поднят — сообщение в комнату не уедет; "
                     "запусти локальную программу агента и повтори")
        try:
            control.mkdir(parents=True, exist_ok=True)
            name = f"{stamp}__to__{chat}.md" if targeted else f"{stamp}.md"
            _publish(control / name)
            written.append("control")
        except OSError:
            log.warning("mid-turn канал недоступен", exc_info=True)
        return {"written": written, "stamp": stamp,
                "source_id": "note:" + (f"{stamp}__to__{chat}" if targeted else stamp),
                "midturn": reader_alive and not sleeping,
                "sleeping": sleeping,
                "chat": chat or "window", "attachments": rel_paths}

    result = await asyncio.to_thread(_write)
    if not result["written"]:
        raise web.HTTPInternalServerError(text="не записалось никуда")
    return result


# ------------------------------------------------------------------ труба

PROTOCOL = "frame.desk.v1"          # как в ui-kit/contract.json (tests/t_contract.py)
DEFAULT_PORT = 8094                 # порт канала по умолчанию — там же
_STARTED_AT = time.time()


async def _tunnel_dispatch(method: str, path: str, body, local: bool = False,
                           role: str = "owner", app=None) -> dict:
    """Один запрос канала -> тот же ответ, что у HTTP-ручки того же пути.

    Это ШОВ ПРОДУКТА: по каналу отвечает и удалённый харнесс (на сервере), и
    локальный на винде; оболочка разницы не видит — протокол один,
    frame.desk.v1 (по образцу praxis.body.v1 её тела — исходящее соединение,
    ни одного открытого порта у клиента). Маршруты — из той же таблицы
    ROUTES, что и HTTP-роутер: второго списка нет."""
    from urllib.parse import urlsplit, parse_qs
    parts = urlsplit(path)
    route_path = parts.path
    query = {k: values[-1] for k, values in parse_qs(parts.query).items()}
    # Канал — ВТОРАЯ дверь к тем же ручкам, и область ключа устройства должна
    # быть в нём той же самой: иначе телефон, открыв /tunnel, обходил бы весь
    # разбор прав HTTP-слоя.
    if not _scope_ok(role, route_path):
        return {"status": 403, "error": "телефону сюда нельзя — это делают из окна"}
    route, params = match_route(method, route_path)
    if route is None:
        return {"status": 404, "error": "нет такого пути"}
    if route.local_only and not local:
        return {"status": 403, "error": "только с этой машины"}
    try:
        result = await route.handler(Call(match=params, query=query, body=body,
                                          local=local, role=role, app=app))
    except web.HTTPError as exc:
        return {"status": exc.status, "error": exc.text or str(exc)}
    except Exception as exc:
        log.warning("канал: %s %s упал", method, route_path, exc_info=True)
        return {"status": 500, "error": f"{type(exc).__name__}: {exc}"[:300]}
    if isinstance(result, Fail):
        reply = {"status": result.status, "error": result.error}
        if result.code:
            reply["code"] = result.code
        return reply
    return {"status": 200, "body": result}


async def tunnel(request):
    """Одна труба на оболочку: запросы с id + события живьём, praxis.desk.v1.

    На рукопожатие WebSocket политика CORS не действует вообще, поэтому страница
    из браузера владельца открывала ws://127.0.0.1:<порт>/tunnel, получала
    `local = True` по факту петли — и вместе с ним права окна: выпустить пару,
    посмотреть и ОТВЯЗАТЬ устройства владельца, переписать конституцию.
    Починка одного только CORS эту дверь не закрывала. Origin браузер обязан
    слать на рукопожатии всегда, и middleware его уже проверил; здесь — второй
    рубеж на случай, если труба однажды переедет из-под middleware.
    """
    ok, _origin = _origin_ok(request)
    if not ok or not _host_ok(request):
        raise web.HTTPForbidden(text="чужая страница")
    role = _role(request)
    if not role:
        raise web.HTTPForbidden(text="нет ключа")
    local = _is_loopback(request) and role == "owner"
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)
    await ws.send_json({"hello": PROTOCOL,
                        "server": {"started_at": _STARTED_AT,
                                   "tree": str(readers.tree())}},
                       dumps=lambda d: json.dumps(d, ensure_ascii=False))
    queue: asyncio.Queue = asyncio.Queue(maxsize=200)
    _SSE_CLIENTS.add(queue)

    async def pump() -> None:
        # Смерть насоса от чего угодно, кроме отмены, раньше проходила молча:
        # задача исчезала, `async for` продолжал отвечать, и клиент считал трубу
        # живой (hello был, сокет открыт), не получая живых событий больше
        # никогда. Теперь сокет закрывается — клиент переподключится.
        try:
            while True:
                event = await queue.get()
                await ws.send_json({"event": event},
                                   dumps=lambda d: json.dumps(d, ensure_ascii=False))
        except asyncio.CancelledError:
            raise
        except Exception:
            log.warning("канал: насос событий умер — закрываю сокет", exc_info=True)
            await ws.close()

    pump_task = asyncio.create_task(pump())
    # Запросы обрабатываются КОНКУРЕНТНО. Было строго по одному внутри
    # `async for`: клиент мультиплексирует по одному сокету всё окно, и на
    # каждое событие хода выпускает разом /api/runs, /api/chats, /api/chat/…,
    # /api/chat-turns/… и /api/state — а POST /api/say, который владелец жмёт в
    # ту же секунду, вставал в очередь за ними. Клиент сопоставляет ответы по
    # id, порядок ему не нужен.
    inflight: set[asyncio.Task] = set()

    async def answer(req: dict) -> None:
        try:
            reply = await _tunnel_dispatch(
                str(req.get("method") or "GET").upper(),
                str(req.get("path") or ""), req.get("body"), local=local,
                role=role, app=request.app)
        except Exception as exc:               # ответ обязан уйти всегда
            log.warning("канал: обработчик упал", exc_info=True)
            reply = {"status": 500, "error": f"{type(exc).__name__}: {exc}"[:300]}
        reply["id"] = req.get("id")
        try:
            await ws.send_json(reply, dumps=lambda d: json.dumps(d, ensure_ascii=False))
        except (ConnectionResetError, RuntimeError):
            pass

    try:
        async for msg in ws:
            if msg.type != web.WSMsgType.TEXT:
                continue
            try:
                req = json.loads(msg.data)
            except ValueError:
                continue
            if len(inflight) >= 64:            # предохранитель от залива
                await ws.send_json({"id": req.get("id"), "status": 503,
                                    "error": "слишком много запросов сразу"})
                continue
            task = asyncio.create_task(answer(req))
            inflight.add(task)
            task.add_done_callback(inflight.discard)
    except (ConnectionResetError, asyncio.CancelledError):
        pass
    finally:
        pump_task.cancel()
        for task in list(inflight):
            task.cancel()
        _SSE_CLIENTS.discard(queue)
    return ws


# ------------------------------------------------------------------ SSE

async def sse(request):
    response = web.StreamResponse(headers={
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    })
    await response.prepare(request)
    queue: asyncio.Queue = asyncio.Queue(maxsize=100)
    _SSE_CLIENTS.add(queue)
    try:
        await response.write(b": connected\n\n")
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=25)
                data = json.dumps(event, ensure_ascii=False)
                await response.write(f"data: {data}\n\n".encode("utf-8"))
            except asyncio.TimeoutError:
                await response.write(b": ping\n\n")
    except (ConnectionResetError, asyncio.CancelledError):
        pass
    finally:
        _SSE_CLIENTS.discard(queue)
    return response


def _put(queue: asyncio.Queue, event: dict) -> None:
    """Положить событие в очередь клиента, вытеснив старейшее при переполнении.

    Было `loop.call_soon_threadsafe(queue.put_nowait, event)` под `except
    Exception: pass` — но call_soon_threadsafe только ПЛАНИРУЕТ вызов, а
    QueueFull летит потом внутри цикла событий: сюда он не приходил никогда.
    Телефон вышел из Wi-Fi, насос встал на send_json, очередь на 200 набилась —
    и дальше каждое живое событие уходило в никуда, а лог забивался
    трассировками, при этом ни окну, ни телефону никто не говорил, что события
    пропали: интерфейс молча замирал на старых данных.
    """
    try:
        queue.put_nowait(event)
        return
    except asyncio.QueueFull:
        pass
    for _ in range(2):                               # освободить место под оба
        try:
            queue.get_nowait()                       # выбросить старейшее
        except asyncio.QueueEmpty:
            break
    try:
        queue.put_nowait({"t": "lost"})              # клиенту: перечитай состояние
        queue.put_nowait(event)
    except asyncio.QueueFull:
        pass


def _broadcast(loop: asyncio.AbstractEventLoop, event: dict) -> None:
    for queue in list(_SSE_CLIENTS):
        try:
            loop.call_soon_threadsafe(_put, queue, event)
        except RuntimeError:
            pass                                     # цикл уже закрыт


def _watcher(loop: asyncio.AbstractEventLoop) -> None:
    """Стат-поллинг живых файлов; смена размера -> событие клиентам.

    Три вещи, из-за которых программа в трее читала десятки гигабайт в сутки на
    ХОЛОСТОМ ходу (замер на живом дереве владельца: 12.6 мс и 1.12 МБ на тик
    раз в 1.5 с = 63 ГБ/сутки; на turns.jsonl в 7.5 МБ — 215 ГБ/сутки):
      * сторож тикал, даже когда клиентов нет вовсе (окно закрыто, трей);
      * list_runs(limit=1) безусловно звал chat_titles(), а тот вычитывал до
        4 МБ хвоста turns.jsonl — ради заголовков, которые событию не нужны;
      * словарь probe-состояния копил ключ `run:<id>` на каждый когда-либо
        виденный прогон и не чистился никогда.
    Плюс сторож следил ровно за одним, самым свежим прогоном: при двух живых
    прогонах (окно и служба) события второго не приходили вовсе.
    """
    state: dict[str, tuple] = {}

    def probe(name: str, path: Path) -> bool:
        try:
            stat = path.stat()
            stamp = (stat.st_mtime_ns, stat.st_size, stat.st_ino)
        except OSError:
            stamp = None
        if state.get(name) != stamp:
            state[name] = stamp
            return True
        return False

    health_state = {"key": None, "next_at": 0.0}
    seen_flush = 0.0
    while True:
        try:
            if not _SSE_CLIENTS:
                # Никто не смотрит — не читаем дерево. Раз в пять минут сливаем
                # «последний раз на связи» устройств и спим дальше.
                if time.time() - seen_flush > 300:
                    seen_flush = time.time()
                    _flush_device_seen()
                state.clear()
                health_state["key"] = None      # первый тик после подключения — свежий
                time.sleep(2.0)
                continue
            if time.time() - seen_flush > 300:
                seen_flush = time.time()
                _flush_device_seen()
            base = readers.tree() / "memory" / ".state"
            # Сторож тишины: раз в ~30 с, событие клиентам ТОЛЬКО на смене состава
            # тревог (баннер не мигает от каждого тика).
            if time.time() >= health_state["next_at"]:
                health_state["next_at"] = time.time() + 30
                snapshot = readers.health()
                key = tuple(sorted(a["kind"] for a in snapshot.get("alarms") or []))
                if key != health_state["key"]:
                    health_state["key"] = key
                    _broadcast(loop, {"t": "health", "health": snapshot})
            if probe("llm", base / "llm_calls.jsonl"):
                _broadcast(loop, {"t": "llm"})
            if probe("skips", base / "perception_skips.jsonl"):
                _broadcast(loop, {"t": "skips"})
            if probe("shadow", base / "shadow" / "metrics.jsonl"):
                _broadcast(loop, {"t": "shadow"})
            # Passive intake changes archives without a model call or run.
            # Stat only: an open idle chat must not reread every archive here.
            archive_keys = set()
            archives_changed = False
            for archive in (readers.tree() / "memory" / "groups").glob("*.jsonl"):
                key = "chat:" + archive.name
                archive_keys.add(key)
                if probe(key, archive):
                    archives_changed = True
            for stale in [k for k in state if k.startswith("chat:") and k not in archive_keys]:
                state.pop(stale, None)
                archives_changed = True
            if archives_changed:
                _broadcast(loop, {"t": "chats"})
            # Все живые прогоны, а не только самый свежий; заголовки комнат не
            # запрашиваем (with_titles=False) — событию они не нужны.
            watched = readers.list_runs(limit=8, with_titles=False)
            alive = set()
            for index, row in enumerate(watched):
                run_id = str(row.get("id") or "")
                if not run_id:
                    continue
                # Самый свежий — всегда (его последняя дописка может лечь уже
                # после смены статуса), остальные — пока идут.
                if index and str(row.get("status") or "") not in ("running", "queued"):
                    continue
                alive.add("run:" + run_id)
                run_path = readers.run_dir(run_id)
                if run_path is not None and probe("run:" + run_id,
                                                 run_path / "events.jsonl"):
                    _broadcast(loop, {"t": "run", "run_id": run_id,
                                      "status": row.get("status")})
            for stale in [k for k in state if k.startswith("run:") and k not in alive]:
                state.pop(stale, None)
        except Exception:
            log.debug("watcher tick failed", exc_info=True)
        time.sleep(_WATCH_INTERVAL)


# ------------------------------------------------------------------ app

async def index(request):
    """index.html с версией статики в src: app.js?v=<mtime>.

    Без версии браузер кэширует app.js эвристикой (мы не слали Cache-Control
    вовсе), и КАЖДАЯ правка UI липла у клиента до жёсткого релоада: страница
    исполняла старый скрипт, а сервер уже отдавал новый — час отладки 31.08.
    mtime в качестве версии: правка файла = новый URL = мгновенный подхват.
    """
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    for name in ("app.js", "app.css", "config.js"):
        try:
            stamp = int((STATIC / name).stat().st_mtime)
        except OSError:
            continue
        html = html.replace(f'"{name}"', f'"{name}?v={stamp}"')
    return web.Response(text=html, content_type="text/html",
                        headers={"Cache-Control": "no-cache"})


def _config_js() -> str:
    """`config.js` страницы, когда его нет на диске: имя агента и продукта.

    Файл кладёт ХОСТИНГ — на сервере его три года клали руками рядом с каждой
    сборкой (static/, mobile/, miniapp/). Так и выяснилось 10.09, что выкладка,
    подменяющая фронт целиком, уносит его с собой: `/m/config.js` отвечал 404,
    и телефон Праксис звался «Агент». Хостовые данные не должны жить файлом,
    который затирает выкладка: канал знает и имя агента, и своё имя, и отдаёт
    их сам. Файл на диске по-прежнему главнее — если он есть, отдаём его.

    `base` и `key` пустые: страница пришла тем же адресом, что и канал
    (same-origin), ключ приезжает в `?key=` и живёт в куке.
    """
    product = (os.environ.get("HELENE_PRODUCT") or "").strip()
    cfg = {"base": "", "key": "", "agent": _agent_name()}
    if product:
        # Пусто — страница возьмёт своё имя по умолчанию. Врать «Hélène» там,
        # где стоит Praxis, нельзя, а угадывать неоткуда.
        cfg["product"] = product
    return ("/* config.js: канал называет себя сам, файла на диске нет */\n"
            "window.DESK_CONFIG = " + json.dumps(cfg, ensure_ascii=False) + ";\n")


async def config_js(request):
    """`/config.js` окна и `/m/config.js` телефона — с диска или из канала."""
    root = MOBILE if request.path.startswith("/m/") else STATIC
    if (root / "config.js").is_file():
        return web.FileResponse(root / "config.js",
                                headers={"Cache-Control": "no-cache"})
    return web.Response(text=_config_js(), content_type="application/javascript",
                        charset="utf-8", headers={"Cache-Control": "no-cache"})


def _static_file(name: str):
    async def handler(request):
        # no-cache = «можно хранить, но каждый раз ревалидируй» (ETag → 304):
        # свежесть UI без повторной перекачки тела.
        return web.FileResponse(
            STATIC / name, headers={"Cache-Control": "no-cache"})
    return handler


def _mobile_file(name: str):
    async def handler(request):
        return web.FileResponse(MOBILE / name, headers={"Cache-Control": "no-cache"})
    return handler


async def _remote_bridge(request):
    relay = request.app['_remote_computer']
    path = '/' + request.match_info['tail']
    if request.query_string:
        path += '?' + request.query_string
    if request.content_length and request.content_length > _remote_computer.MAX_BODY:
        raise web.HTTPRequestEntityTooLarge(max_size=_remote_computer.MAX_BODY, actual_size=request.content_length)
    raw = await request.read()
    try:
        status, result, mime, returned = await relay.rpc(request.method, path, raw,
            request.headers.get('Content-Type', 'application/json'), headers={
                k: request.headers[k] for k in _remote_computer.ARTIFACT_REQUEST_HEADERS if k in request.headers})
    except (ValueError, TypeError) as error:
        return web.json_response({'ok': False, 'code': 'invalid_desktop_request', 'error': str(error)}, status=400)
    except PermissionError as error:
        return web.json_response({'ok': False, 'code': 'owner_refused', 'error': str(error)}, status=403)
    except (ConnectionError, asyncio.TimeoutError):
        return web.json_response({'ok': False, 'code': 'desktop_disconnected',
            'error': 'Selected Windows desktop disconnected; verify any started operation before retry'}, status=503)
    return web.Response(status=status, body=result, headers={**returned, 'Content-Type': mime, 'Cache-Control': 'no-store'})


def build_app(*, port: int | None = None) -> web.Application:
    global _PHONE_ACCESS
    app = web.Application(middlewares=[auth_middleware],
                          client_max_size=_ATTACH_MAX_TOTAL * 4 // 3 + 1024 * 1024)
    remote = _remote_computer.Relay(readers.tree())
    app['_remote_computer'] = remote
    app.router.add_route('*', _remote_computer.PREFIX + '/bridge/{tail:.*}', _remote_bridge)
    app.on_shutdown.append(remote.close)
    app.router.add_get("/", index)
    from deskd.program import gateway as program_gateway
    app.router.add_route('*', '/program/{agent}/{tail:.*}', program_gateway)
    # Все ручки API — из одной таблицы (та же, что у канала).
    for route in ROUTES:
        app.router.add_route(route.method, route.path, _http_handler(route))
    app.router.add_get("/pair/redeem", api_pair_redeem)
    app.router.add_post("/pair/telegram", api_pair_telegram)   # только HTTP: ключа ещё нет
    app.router.add_get("/m/", mobile_index)
    app.router.add_get("/m", mobile_index)
    app.router.add_get("/m/manifest.webmanifest", mobile_manifest)
    app.router.add_get("/m/sw.js", mobile_sw)
    app.router.add_get("/m/config.js", config_js)
    mini = next((p for p in (_HERE / 'miniapp/dist', _HERE / 'miniapp')
                 if (p / 'index.html').is_file()), _HERE / 'miniapp')
    async def mini_index(request):
        if not (mini / 'index.html').is_file():
            raise web.HTTPServiceUnavailable(text='Миниапп не вошёл в поставку — обнови Hélène.')
        return web.FileResponse(mini / 'index.html', headers={'Cache-Control': 'no-store'})
    app.router.add_get('/tg/', mini_index)
    app.router.add_get('/tg/config.js', config_js)
    if (mini / 'icon-192.png').is_file():
        async def mini_icon(request): return web.FileResponse(mini / 'icon-192.png')
        app.router.add_get('/tg/icon-192.png', mini_icon)
    if (mini / 'assets').is_dir():
        app.router.add_static('/tg/assets/', mini / 'assets')
    if phone_access is not None:
        def load_phone_config():
            path = readers.config_path()
            return readers._load_json(path) if path else {}
        _PHONE_ACCESS = phone_access.PhoneAccess(
            readers.tree() / 'memory/.state/phone-access', load_phone_config,
            port if port is not None else int(os.environ.get('HELENE_PORT') or os.environ.get('PRAXIS_DESK_PORT') or DEFAULT_PORT),
            owner_token=bool(TOKEN))
        app.cleanup_ctx.append(_PHONE_ACCESS.context)
    if (MOBILE / "assets").is_dir():
        app.router.add_static("/m/assets/", MOBILE / "assets")
    for name in ("icon-192.png", "icon-512.png", "apple-touch-icon.png"):
        if (MOBILE / name).is_file():
            app.router.add_get("/m/" + name, _mobile_file(name))
    app.router.add_get("/events", sse)
    app.router.add_get("/tunnel", tunnel)
    if STATIC.is_dir():
        app.router.add_static("/static/", STATIC)
    # Те же ассеты с корня: index.html ссылается относительно, чтобы один и тот
    # же дистрибутив жил и в вебе, и в нативной оболочке.
    # config.js — всегда: нет файла, значит канал соберёт его сам (см. _config_js).
    app.router.add_get("/config.js", config_js)
    if (STATIC / "favicon.svg").is_file():
        app.router.add_get("/favicon.svg", _static_file("favicon.svg"))
    # Сборка Vite кладёт ассеты в assets/ с хэшами в именах.
    if (STATIC / "assets").is_dir():
        app.router.add_static("/assets/", STATIC / "assets")
    return app


def _ensure_local_tree() -> None:
    """Минимальный скелет дерева для локального режима. На сервере дерево
    смонтировано ro — mkdir там падает, и это не ошибка: молча пропускаем."""
    base = readers.tree()
    for rel in ("memory/.state", "memory/.control", "memory/runs",
                "workspace/inbox", "soul"):
        try:
            (base / rel).mkdir(parents=True, exist_ok=True)
        except OSError:
            return


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else int(
        os.environ.get("HELENE_PORT") or os.environ.get("PRAXIS_DESK_PORT") or DEFAULT_PORT)
    # Локальный харнесс обязан слушать ТОЛЬКО петлю: дерево без токена не должно
    # быть видно даже соседям по локальной сети. Сервер (за Caddy) — как раньше.
    host = (os.environ.get("HELENE_HOST") or os.environ.get("PRAXIS_DESK_HOST") or "0.0.0.0").strip()
    config_path=readers.config_path()
    configured=readers._load_json(config_path) if config_path else {}
    if (configured.get('phone') or {}).get('mode')=='stable':
        # A fixed reverse proxy/tunnel needs loopback only, including when an
        # older supervisor still classifies every non-automatic mode as LAN.
        host='127.0.0.1'
    _ensure_local_tree()
    if _boot is not None:
        # SIGTERM канал ловит сам aiohttp (GracefulExit в run_app) — сторожу
        # достаточно его послать. На Windows и без HELENE_PARENT_PID — no-op.
        _boot.watch_parent("канал")
    app = build_app(port=port)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    threading.Thread(target=_watcher, args=(loop,), daemon=True).start()
    log.info("Hélène слушает %s:%d, дерево %s, токен %s", host, port,
             readers.tree(), "задан" if TOKEN else "НЕ задан (локальная петля)")
    web.run_app(app, host=host, port=port, loop=loop, print=None,
                access_log_class=SafeAccessLogger)


if __name__ == "__main__":
    main()

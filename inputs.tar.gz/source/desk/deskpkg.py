#!/usr/bin/env python3
"""Пакет desk: состав, версия и зависимости — одним объявлением.

Desk ставится в двух местах, и до 10.09 каждое место знало состав по-своему:

* сервер — канал рядом с деревом агента (``server/deploy_desk.py`` клал пять
  путей в ``/opt/praxisdesk``);
* Windows — папка ``app/`` внутри поставки (``installer/build_dist.py`` клал
  свой набор: питонью часть по списку, статику и телефон отдельными функциями,
  мини-апп не клал вовсе).

Списка было полтора: 09.09 состав объявили один раз (``deploy_desk.MODULE``), но
фронты в него не входили и по-прежнему ехали разными дорогами, а зависимости
канала не объявлял никто — на сервере ``deskd`` жил без своего ``requirements``.
Отсюда класс ошибок «на сервере есть, на Windows нет» (``rooms.py`` 07.09 так и
не уехал в поставку) и «контейнер канала нечем пересобрать».

Теперь состав объявлен ЗДЕСЬ. Обе установки не перечисляют пути, а ставят
собранный пакет целиком:

    python deskpkg.py --flavor server  --out /tmp/desk     # что и куда
    python deskpkg.py --list                               # состав обоих видов

Пакет — это каталог с одинаковой раскладкой у обеих установок
(``deskapp.py``, ``deskd/``, ``static/``, ``mobile/``…), плюс два файла о себе:

* ``desk.json`` — манифест: версия продукта, вид пакета, sha256 каждого файла и
  один общий отпечаток. Его кладут рядом с каналом, и канал отдаёт его окну
  (``/api/state`` → ``desk``): на сервере это единственный способ узнать, какая
  версия Praxis там живёт — оболочки, которая отвечает окну ``app_info``, там
  нет.
* ``requirements-desk.txt`` — зависимости именно desk, по видам: канал просит
  ``aiohttp``, раннер Windows — ещё и ``telethon``. Сервер ставит этот файл,
  поставка вливает его в общий ``requirements.txt``.

Виды пакета (``flavor``) — не разные составы, а один список с пометкой, где
часть нужна: мини-апп Telegram живёт только на сервере (страницу открывает
Telegram по HTTPS, до localhost он не дойдёт), а движок и ресурсы — только у
настольных изданий, Windows и macOS (на сервере ходы ведёт её собственный код
агента). Разница видна здесь строкой, а не расхождением двух скриптов.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

DESK = Path(__file__).resolve().parent

MANIFEST = "desk.json"
STATIC_MANIFEST = ".helene-static.json"
REQUIREMENTS = "requirements-desk.txt"

#: Linux (порт 28.09): Debian, Ubuntu, Astra — пакет .deb (`installer/build_linux.py`).
SERVER, WINDOWS, MACOS, LINUX = "server", "windows", "macos", "linux"
FLAVORS = (SERVER, WINDOWS, MACOS, LINUX)
#: Настольные издания: окно Элен рядом с движком. Состав у них ОДИН — канал,
#: читалки, окно Элен, телефон, движок, ресурсы; различается только то, что
#: сборка кладёт вокруг пакета (exe и embedded CPython у Windows, .app и
#: python-build-standalone у macOS). Вид в манифесте всё равно свой: по нему
#: окно и выкладка отличают одну поставку от другой.
DESKTOP = (WINDOWS, MACOS, LINUX)

# Что не едет никогда: байт-код машины сборщика (его никто не проверял и он
# чужой для целевой версии Python) и мусор файловых менеджеров.
SKIP_NAMES = {"__pycache__", ".DS_Store", "Thumbs.db"}
SKIP_SUFFIXES = (".pyc", ".pyo")


@dataclass(frozen=True)
class Part:
    """Часть пакета: что берём в репозитории и как оно зовётся в пакете."""

    src: str
    dest: str
    flavors: tuple[str, ...]
    kind: str = "tree"        # tree — каталог целиком, py — только *.py, file — файл
    dist: bool = False        # сборка Vite: без index.html это не сборка, а исходники
    why: str = ""

    def path(self) -> Path:
        return DESK / self.src


PARTS: tuple[Part, ...] = (
    Part("python_app.py", "python_app.py", DESKTOP, kind="file",
         why="Python application: existing UI, component lifecycle and native host bridge"),
    Part("deskapp.py", "deskapp.py", FLAVORS, kind="file",
         why="канал: HTTP, вебсокет, ключи, комнаты"),
    Part("deskd", "deskd", FLAVORS, kind="py",
         why="читалки канала: состояние, комнаты, расход, разрезы кадра"),
    *(Part(name,name,(SERVER,),kind="file",why="shared configuration snapshots and kernel locks; no desktop runner")
      for name in ('localharness/config_transaction.py',
                   'localharness/program_state.py','localharness/package_notice.py','localharness/owner_stop.py',
                   'localharness/phone_tunnel/__init__.py','localharness/phone_tunnel/platform_support.py')),
    # Окно — ДВА разных фронта, а не один на оба места. Приложения разделены
    # 10.09: у Элен агент рядом (настройки правят helene.json на этой машине), у
    # Praxis агент на сервере (тех карточек нет вовсе). До разделения фронт был
    # один, а разница держалась ветками `if (remote)` внутри него — то есть на
    # сервер уезжало окно Элен, знающее про местного агента, которого там нет.
    Part("app/dist", "static", DESKTOP, dist=True,
         why="окно Элен: сборка Vite (npm --prefix app run build)"),
    Part("remote/dist", "static", (SERVER,), dist=True,
         why="окно Praxis: сборка Vite (npm --prefix remote run build)"),
    Part("mobile/dist", "mobile", FLAVORS, dist=True,
         why="совместимость прежнего /m/: общий Mini App и удаление старого service worker"),
    Part("miniapp/dist", "miniapp", FLAVORS, dist=True,
         why="мини-апп Telegram: локальный канал отдаёт его через HTTPS-туннель"),
    Part("server/desk-recipe", "recipe", (SERVER,),
         why="рецепт контейнера канала: образ на requirements-desk.txt пакета"),
    # Служба управления рядом с каналом: перезапуск контейнеров, их журналы и
    # смена модели. Едет только на сервер: у Windows-издания надзор — оболочка,
    # и докера рядом нет вовсе.
    Part("server/deskctl.py", "deskctl.py", (SERVER,), kind="file",
         why="надзор за контейнерами: они, их журналы и мозг — мимо агента"),
    Part("localharness", "localharness", DESKTOP, kind="py",
         why="движок настольных изданий: первый запуск, ходы, доставка слова, Telegram"),
    Part("resources", "resources", DESKTOP,
         why="ресурсы продукта: каноническая конституция и всё, что читает boot.py"),
)

# Зависимости desk по видам. Ядро агента объявляет свои отдельно
# (``installer/build_dist.TREE_DEPS``) — здесь только то, без чего не живут
# канал и раннер.
DEPS_CHANNEL = ["aiohttp"]                 # deskapp.py: web, AbstractAccessLogger
DEPS_RUNNER = ["telethon==1.44.0", "paramiko==5.0.0"] # Telegram account and GUI-owned SSH transfer


def parts(flavor: str) -> tuple[Part, ...]:
    if flavor not in FLAVORS:
        raise ValueError(f"вид пакета «{flavor}»: знаю только {', '.join(FLAVORS)}")
    return tuple(p for p in PARTS if flavor in p.flavors)


def requirements(flavor: str) -> list[str]:
    """Зависимости пакета этого вида — по тому же списку частей, а не отдельно."""
    names = {p.dest for p in parts(flavor)}
    deps = list(DEPS_CHANNEL)
    if "localharness" in names:
        deps += DEPS_RUNNER
    if "python_app.py" in names:
        deps += ["pywebview==6.2.1"]
    return deps


# --- версия -------------------------------------------------------------------

def _cargo_version(path: Path) -> str:
    if not path.is_file():
        return ""
    in_pkg = False
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if s.startswith("["):
            in_pkg = s == "[package]"
        elif in_pkg and s.startswith("version"):
            return s.split("=", 1)[1].strip().strip('"')
    return ""


def _json_version(path: Path) -> str:
    if not path.is_file():
        return ""
    try:
        return str(json.loads(path.read_text(encoding="utf-8")).get("version", ""))
    except (ValueError, OSError):
        return ""


def product_version() -> tuple[str, dict]:
    """Версия продукта = версия трёх Cargo.toml, и они обязаны совпадать.

    Живёт здесь, а не в сборке поставки: версию спрашивает и выкладка на сервер
    (в манифест пакета), а импортировать ради этого ``installer/build_dist.py``
    — значит тянуть за собой всю сборку архива.
    """
    declared = {
        "shell/Cargo.toml": _cargo_version(DESK / "shell" / "Cargo.toml"),
        "setup/Cargo.toml": _cargo_version(DESK / "setup" / "Cargo.toml"),
        "svc/Cargo.toml": _cargo_version(DESK / "svc" / "Cargo.toml"),
        "shell/tauri.conf.json": _json_version(DESK / "shell" / "tauri.conf.json"),
        "setup/tauri.conf.json": _json_version(DESK / "setup" / "tauri.conf.json"),
        "app/package.json": _json_version(DESK / "app" / "package.json"),
        "mobile/package.json": _json_version(DESK / "mobile" / "package.json"),
        "setup/ui/package.json": _json_version(DESK / "setup" / "ui" / "package.json"),
        # ⚠ Этих двух здесь не было, и памятка выпуска всё это время называла ДЕСЯТЬ
        # объявлений. Прибор читал восемь и сравнивал три: отставание `remote` или
        # `miniapp` проходило и его, и стенд — молча. Проверено приёмкой 11.09 откатом
        # версии в копии дерева: прибор не сказал ничего.
        "remote/package.json": _json_version(DESK / "remote" / "package.json"),
        "miniapp/package.json": _json_version(DESK / "miniapp" / "package.json"),
    }
    core = {k: v for k, v in declared.items() if k.endswith("Cargo.toml")}
    if not all(core.values()):
        raise SystemExit("не прочиталась версия из Cargo.toml: " +
                         ", ".join(k for k, v in core.items() if not v))
    if len(set(core.values())) != 1:
        raise SystemExit("версии разъехались, поставка была бы смесью:\n  " +
                         "\n  ".join(f"{k} = {v}" for k, v in core.items()))
    version = next(iter(core.values()))
    # ⚠ СРАВНИВАЮТСЯ ВСЕ ДЕСЯТЬ, А НЕ ТРИ. «Версия поднята во всех десяти объявлениях»
    # было утверждением памятки, которое ничем не проверялось: три Cargo.toml сходились,
    # остальные семь только читались. Поставка с разъехавшимся `package.json` — это окно
    # и телефон, которые называют владельцу РАЗНЫЕ версии одного продукта.
    # Нечитаемый файл (пусто) называется отдельно от разъехавшегося: это разные беды.
    unread = [k for k, v in declared.items() if not v]
    if unread:
        raise SystemExit("версия не прочиталась: " + ", ".join(unread))
    drifted = {k: v for k, v in declared.items() if v != version}
    if drifted:
        raise SystemExit(f"версия {version} поднята не везде — отстали:\n  " +
                         "\n  ".join(f"{k} = {v}" for k, v in drifted.items()))
    return version, declared


# --- сборка пакета ------------------------------------------------------------

def _skip(path: Path) -> bool:
    return (any(part in SKIP_NAMES for part in path.parts)
            or path.suffix.lower() in SKIP_SUFFIXES)


def _why_missing(part: Part) -> str:
    """Почему часть взять нельзя; пустая строка — всё на месте."""
    path = part.path()
    if part.kind == "file":
        return "" if path.is_file() else "нет файла"
    build_hint = f"собери фронт: npm --prefix {part.src.split('/')[0]} run build"
    if not path.is_dir():
        return "нет каталога" + (f" ({build_hint})" if part.dist else "")
    if part.dist and not (path / "index.html").is_file():
        return f"без index.html, это не сборка Vite: {build_hint}"
    return ""


def check(flavor: str) -> list[str]:
    """Чего не хватает для пакета этого вида — списком, а не первой ошибкой."""
    return [f"{p.src} — {why}" for p in parts(flavor) if (why := _why_missing(p))]


def _copy_part(part: Part, dest_root: Path) -> int:
    """Одна часть в пакет -> сколько файлов положено."""
    src, dest = part.path(), dest_root / part.dest
    if part.kind == "file":
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        return 1
    if dest.exists():
        shutil.rmtree(dest)
    count = 0
    for item in sorted(src.rglob("*")):
        if not item.is_file() or _skip(item.relative_to(src)):
            continue
        if part.kind == "py" and item.suffix != ".py":
            continue
        target = dest / item.relative_to(src)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
        count += 1
    return count


def static_manifest(root: Path) -> dict:
    """Манифест статики окна: sha256 каждого файла и один общий отпечаток.

    По нему установщик решает, менял ли ВЫПУСК интерфейс (слово владельца
    07.09: «если я не трогал статику — оставлять пользовательскую»).
    Сравниваются манифесты двух поставок, а не файлы пользователя.
    """
    files: dict[str, str] = {}
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root).as_posix()
        if rel == STATIC_MANIFEST:
            continue
        files[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    digest = hashlib.sha256(
        "\n".join(f"{rel} {sha}" for rel, sha in files.items()).encode("utf-8")).hexdigest()
    return {"v": 1, "digest": digest, "files": files}


#: Какое приложение каким фронтом собрано. Ось здесь — ПРИЛОЖЕНИЕ, а не место
#: установки: настольный Praxis и Praxis на сервере — одно и то же окно, просто
#: одно живёт в exe, а другое отдаётся каналом по HTTP.
HELENE, REMOTE = "helene", "remote"
WINDOW_FRONT = {HELENE: "app/dist", REMOTE: "remote/dist"}


def copy_static(dest: Path, app: str = HELENE) -> str:
    """Статика окна ``app`` в ``dest`` + манифест рядом -> отпечаток.

    Отдельной ручкой, потому что настольное издание — это окно без канала: там
    пакета desk нет вовсе, а статика нужна и отпечаток нужен тот же.

    ⚠ Аргумент `app` появился 10.09 вместе с разделением приложений. До него
    частей с именем `static` была одна, и брать «первую попавшуюся» было
    безопасно. Теперь их две, и молчаливый `next(...)` уложил бы в Praxis окно
    Элен — то самое, которое знает про местного агента, которого там нет.
    """
    src = WINDOW_FRONT.get(app)
    if src is None:
        raise ValueError(f"нет такого приложения: «{app}»; знаю {', '.join(WINDOW_FRONT)}")
    part = next(p for p in PARTS if p.src == src)
    why = _why_missing(part)
    if why:
        raise SystemExit(f"{part.src} — {why}")
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(part.path(), dest)
    man = static_manifest(dest)
    (dest / STATIC_MANIFEST).write_text(
        json.dumps(man, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8", newline="\n")
    return man["digest"]


def build(dest: Path, flavor: str, *, version: str | None = None,
          clean: bool = False, allow_partial: bool = False, log=print) -> dict:
    """Собрать пакет вида ``flavor`` в каталоге ``dest`` -> манифест.

    ``clean`` — стереть каталог целиком (для временной сборки выкладки). В
    поставке нельзя: пакет ложится в ``app/`` рядом с тем, что кладёт сборка.

    ``allow_partial`` — отладочная полусборка: несобранный ФРОНТ пропускается
    с громкой строкой и попадает в манифест полем ``skipped``, всё остальное
    по-прежнему обязательно. Полусборка так и остаётся видимой в поставке, а
    не забывается до первого 404 у владельца.
    """
    version = version or product_version()[0]
    dest = Path(dest)
    if clean and dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    take: list[Part] = []
    skipped: list[dict] = []
    hard: list[str] = []
    for part in parts(flavor):
        why = _why_missing(part)
        if not why:
            take.append(part)
        elif allow_partial and part.dist:
            log(f"  ⚠ {part.dest.upper()} В ЭТОМ ПАКЕТЕ НЕТ ({part.src}: {why}) — --allow-partial")
            skipped.append({"name": part.dest, "src": part.src, "why": why})
        else:
            hard.append(f"{part.src} — {why}")
    if hard:
        raise SystemExit("пакет desk не собрать:\n  " + "\n  ".join(hard))

    counted: list[dict] = []
    static_digest = ""
    for part in take:
        if part.dest == "static":
            # Отпечаток статики пишем ВНУТРЬ статики: установщик читает его в
            # уже поставленной копии, где манифеста пакета может не быть
            # (поставки до 0.5.1).
            # Какое окно — решает не вид пакета, а сама часть: у сервера в
            # составе фронт Praxis, у Windows — фронт Элен.
            static_digest = copy_static(dest / "static",
                                        REMOTE if part.src == WINDOW_FRONT[REMOTE] else HELENE)
            n = sum(1 for p in (dest / "static").rglob("*") if p.is_file())
        else:
            n = _copy_part(part, dest)
        counted.append({"name": part.dest, "src": part.src, "files": n, "why": part.why})

    deps = requirements(flavor)
    (dest / REQUIREMENTS).write_text(
        "# Зависимости пакета desk — объявлены в deskpkg.py (вид: "
        f"{flavor}).\n" + "\n".join(deps) + "\n", encoding="utf-8", newline="\n")

    files: dict[str, str] = {}
    for path in sorted(p for p in dest.rglob("*") if p.is_file()):
        rel = path.relative_to(dest).as_posix()
        if rel == MANIFEST:
            continue
        files[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    digest = hashlib.sha256(
        "\n".join(f"{rel} {sha}" for rel, sha in files.items()).encode("utf-8")).hexdigest()

    manifest = {
        "v": 1,
        "product": "desk",
        "version": version,
        "flavor": flavor,
        "built_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "digest": digest,
        "static": static_digest,
        "parts": counted,
        "skipped": skipped,
        "requirements": deps,
        "files": files,
    }
    (dest / MANIFEST).write_text(json.dumps(manifest, ensure_ascii=False, indent=1) + "\n",
                                 encoding="utf-8", newline="\n")
    return manifest


def top_level(flavor: str) -> list[str]:
    """Имена в корне пакета — то, что установка подменяет целиком.

    Всё, чего здесь нет (``desk.env``, данные, чужие копии), установка не
    трогает: пакет отвечает за себя и только за себя.
    """
    return list(dict.fromkeys([Path(p.dest).parts[0] for p in parts(flavor)] + [REQUIREMENTS, MANIFEST]))


def read_manifest(root: Path) -> dict | None:
    """Манифест уже поставленного пакета; None — пакета нет или он битый."""
    path = Path(root) / MANIFEST
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) and data.get("product") == "desk" else None


def verify(root: Path) -> list[str]:
    """Сверить поставленный пакет с его манифестом -> список расхождений.

    ⚠ На Windows установщик вправе ОСТАВИТЬ пользовательскую статику, если
    выпуск её не менял (`install.rs`, слово владельца 07.09). Тогда расхождение
    по `static/…` — не поломка, а решение установщика; всё остальное обязано
    сходиться.
    """
    man = read_manifest(root)
    if man is None:
        return [f"нет манифеста {MANIFEST} — это не пакет desk"]
    bad: list[str] = []
    root = Path(root)
    for rel, want in (man.get("files") or {}).items():
        path = root / rel
        if not path.is_file():
            bad.append(f"нет файла: {rel}")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != want:
            bad.append(f"изменён: {rel}")
    return bad


def main() -> int:
    ap = argparse.ArgumentParser(description="пакет desk: состав, версия, сборка")
    ap.add_argument("--flavor", choices=FLAVORS, default=SERVER)
    ap.add_argument("--out", help="куда собрать пакет (без него — только показать состав)")
    ap.add_argument("--list", action="store_true", help="состав обоих видов")
    ap.add_argument("--verify", help="сверить уже поставленный пакет с его манифестом")
    ap.add_argument("--allow-partial", action="store_true",
                    help="отладка: собрать без несобранных фронтов")
    args = ap.parse_args()

    if args.verify:
        bad = verify(Path(args.verify))
        print("\n".join(bad) if bad else "пакет сходится с манифестом")
        return 1 if bad else 0
    if args.list or not args.out:
        version = product_version()[0]
        print(f"desk {version}")
        for p in PARTS:
            where = "+".join(p.flavors)
            print(f"  {p.src:<18} -> {p.dest:<14} [{where}]  {p.why}")
        for flavor in FLAVORS:
            print(f"  зависимости {flavor}: {', '.join(requirements(flavor))}")
            miss = check(flavor)
            if miss:
                print("    не хватает: " + "; ".join(miss))
        return 0

    man = build(Path(args.out), args.flavor, clean=True, allow_partial=args.allow_partial)
    print(f"desk {man['version']} ({man['flavor']}): {len(man['files'])} файлов, "
          f"отпечаток {man['digest'][:12]}")
    for part in man["parts"]:
        print(f"  {part['name']:<14} {part['files']:>4}")
    for part in man["skipped"]:
        print(f"  {part['name']:<14}    — не поехало: {part['why']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

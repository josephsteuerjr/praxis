# 2.7.0 Beta

Full agent transfer and return, server bridge setup, the complete programme in the
Telegram Mini App, shared owner context, reflection, connection fixes and bounded
window memory. Computer run deadlines now reach Body.

Read the [changes and limits](docs/RELEASE-2.7.0.md).

# 2.6.1 Beta

Fix Windows installation and updates requesting administrator rights. Clean installs
no longer stop a nonexistent previous app; protected old files remain visible leftovers.

Read the [changes and limits](docs/RELEASE-2.6.1.md).

# 2.6.0 Beta

Canonical hands, clearer action details and phone history, in-app server installation
and updates, Linux ARM64 server delivery, non-admin cleanup and macOS launch recovery.

Read the [beta changes and qualification limits](docs/RELEASE-2.6.0.md).

# 2.5.3

Reduced idle CPU use by removing inbox self-wakeups, retiring foreign Forge
update observations, avoiding unnecessary TLS setup for local RPC, and reducing
idle/hidden Forge polling. Active work and owner controls remain responsive.

Read the [idle CPU hotfix details](docs/RELEASE-2.5.3.md).

# 2.5.2

Scrolling and rubber-band return use the full elapsed frame time. The spring
settings are preserved. Turn details open at their measured content height;
fast reversals and delayed content continue from the visible position.
Reduced-motion preferences remain respected.

A separate Intel Mac package includes its own Python runtime and Finder app.
Local Whisper and XTTS are unavailable in that package.

A newly extracted folder also retains and replaces orphan preparation records
from earlier uses of the same folder name.

Read the [motion changes](docs/RELEASE-2.5.2.md).

# 2.5.1

Normal startup resumes a prepared clean update before claiming its data.
The selected previous installation exits gracefully, its process and data
locks are released, and pending data moves finish before the new window
opens. Concurrent startup and retry retain the selected update bindings.

Windows clean-update retirement accepts successful COM shortcut results,
including `S_FALSE`. A system shortcut without a filesystem target remains
unowned and unchanged. Failed HRESULTs still propagate. This fixes an old-folder
cleanup failure found during an actual Windows update from 2.5.0.

Read the [correction and acceptance boundaries](docs/RELEASE-2.5.1.md).

# 2.5.0

Codex Fast mode is available through model-aware speed controls in desktop,
phone and Telegram Mini App settings. Relay requests carry the selected service
tier through to Codex, and receipts report the tier observed in the response.
Model catalog metadata controls the available speed and reasoning choices.
Codex omits the no-reasoning choice and preserves model defaults when no effort
is selected. Fast mode consumes subscription limits or credits at a higher rate.

`speak` accepts one asynchronous request. The application generates and delivers
voice independently of the agent turn, without generated-audio review, polling
or a second send. Fish and local XTTS share this contract. Recipient binding,
explicit cancellation, durable pause transitions and no ambiguous paid retry
remain enforced by the application.

Recording sends on hotkey release in the foreground and background. Explicit
pause keeps optional preview; voice history uses compact replay controls.
Playback starts before optional waveform import/decoding. Whisper uses every
available CPU, reuses unchanged warm settings and retains its model for thirty
idle minutes. Windows inbox notifications remove the idle polling delay.

Clean updates use completed extraction, restart and retirement of the exact old
programme, without programme inventories, per-file comparisons or a trial.
Agent data and persistent voice components remain independent. Preserve-edits
updates keep their existing reconciliation and review workflow.

Graceful Windows migration recognizes the clickable binary startup entry.
Voice controls describe startup warmup and the actual idle residency policy.
Successful model closures retain their successful header status.

Foreground Forge commands record intent before execution admission. Stop follows the
selected worker's owned process and verification jobs. Finish respects Pause
and unresolved writer custody. Ambiguous provider attempts retain their
partial response and identity, with retry ownership held by the executor.

Read the [changes and evidence boundaries](docs/RELEASE-2.5.0.md). Release evidence
separates native platform qualification, controlled transport tests and the live
Windows owner session from physical microphone, CUDA and provider entitlement.

# 2.4.0

Independent Fish synthesis for local agents, with private credentials, explicit
model/voice selection and durable paid-preview identities. Whisper stays
independent. Optional voice runtimes/models use a persistent content store;
updates retain compatible pins without copying weights into every program
folder. Personal audio samples survive legacy migration and cross-host carry.

Telegram Mini App entry uses the bot's current tunnel address, signed launch
authentication and fullscreen/safe-area handling. The temporary-address PWA
installation flow is removed. The VPS transfer guide is restored with host-key
verification, resumable import, persistent Stop and guarded local-return recovery.

Clean/preserve update modes are explicit peer cards. Private configuration
writes verify the actual Windows token's DACL; POSIX staging handles inherited
setgid. Shared forms and connection cards align across light/dark and narrow
layouts. See [changes, evidence boundaries and limits](docs/RELEASE-2.4.0.md).

# 2.3.0

The desktop and right panel use the reviewed Praxis-style layout, with calmer
onboarding and stable navigation/polling. Remote settings can use a server's
Fish speech API: catalogue, explicit voice/model selection, separate words and
delivery instructions, paid preview and honest cancellation/unknown outcomes.
The server owns its credentials and voice selection; older servers hide the
unsupported card. This does not install or enable a server speech backend.

Preserved updates now apply validated app composition before removing obsolete
program files, retain executable modes, and exclude browser state from deletion.
POSIX test launchers own their nested producers through native guardians;
publishers receive their own selected tree instead of inheriting another lease.
Browser acceptance tools remain runnable under `desk/app/acceptance`; the
offline update battery no longer starts the long-running audit server.

Portable Python desktop archives for Windows x64, Apple silicon, Debian/Ubuntu
and Fedora x86_64. Durable updates remain owned by the host when the observing
window closes. Preserved source uses conflict resolution, checks and independent
review; clean mode selects verified release code while retaining the profile.

New agents can use the Hélène constitution or editable custom text/file. The
explicit Create action materializes the first SOUL before provider sign-in,
preserves existing agents, and refuses ambiguous rebirth after lost data.
The window explains automatic reopening before an update closes it. Cancellation
settles only the identified operation after its producers are confirmed absent.

Native runtime/tool identities and source/package inventories are independently
bound. Optional voice payloads retain their existing immutable release pins.
Full historical broad-test and physical-device acceptance remain separate from
the platform evidence supplied with the release.

# 2.3.0-rc.4

Keep an incoming Python window available during legacy handoff. Confirm the cold runner's exact PID, source and heartbeat with cancellable startup waiting. Failed bootstrap releases its own workers and profile lease before allowing the legacy launcher to reopen. The migration window can explicitly stop RC3's identified failed heartbeat handoff without replaying or applying its saved work. Update review and apply gates remain in force.

# 2.2.9

Explicit preserved or pristine source update in the window and agent tool. The selected agent resolves preserved changes; independent review still accepts the candidate. Pristine mode selects exact verified release source while retaining prior code and all profile paths. See [release notes](docs/RELEASE-2.2.9.md).

# 2.2.8

Keep the configured managed relay alive through source integration and independent review after the old owner closes. Preserve route/account/proxy and original failure diagnostics. Coupled owner/transport regression passes the unmodified2.1.1 one-button transaction and rollback. See [release notes](docs/RELEASE-2.2.8.md).

# 2.2.7 — withdrawn after relay-lifetime failure

Normal bundled Python can write sitecustomize bytecode before helper entry. Recognize paired regular caches, retain them with the previous view, and continue real source materialization. Unknown/private data and links remain refused. Regression now includes ordinary cache-enabled startup and the actual bundled Windows interpreter. See [release notes](docs/RELEASE-2.2.7.md).

# 2.2.6 — withdrawn after startup-cache failure

The normal Update button now hands custody from public2.1.1 to the incoming helper in one invocation. Real upstream source is verified/materialized before merge and independent frozen review. Manual preparation Python/VBS removed; source edits/profile/Pause/Stop/rollback remain protected. See [release notes](docs/RELEASE-2.2.6.md).

# 2.2.5 — withdrawn

The isolated merger can journal compatibility repairs across declared candidate source, including automatically merged files. Every changed candidate requires fresh independent review. An explicit incoming preparation entry handles the old2.1.1 button gate without installing/restarting its owner. See [release notes](docs/RELEASE-2.2.5.md).

# 2.2.4

Legacy upgrades coordinate restricted conflict merging and mandatory source review from the verified incoming runtime, without requiring new APIs in old authored Forge. Review ownership is isolated and model configuration is read without pre-install migration. See [release notes](docs/RELEASE-2.2.4.md).

# 2.2.3

No startup shell probe; explicit bundled Windows shell, including sandbox fallback; Windows login starts in the tray with a visible-window fallback if tray creation fails. See [release notes](docs/RELEASE-2.2.3.md).

# 2.2.2

Automatic continuation after independent update review; windowless Windows helpers; themed update progress; always open Now; truthful Forge control outcomes. See [release notes](docs/RELEASE-2.2.2.md).

# 2.2.0 candidate

Acceptance-gated Forge teams, durable worker journals and owner task inspection/control; isolated merger plus independent conflict review; preclose preparation, narrow routine backups and update progress; application-owned XTTS/old-code speak compatibility and real voice-note encoding; configured startup at Now. Verification, platform artifacts, publication and installation remain separate facts.

# 2.1.1

Three-way Git source updates preserve authored changes across releases, resolve actual conflicts in an isolated candidate, and retain the exact upstream baseline. In-place updates keep profile/model paths and restore the prior code selection on rollback. The component map is readable by the original 2.0 updater; optional downloads remain Whisper and XTTS.

# 2.1.0 — Portable Python, refreshed onboarding and voice

Archive-first Windows launch and migration; in-place updates; custom migration chrome and sharper icon; inline waveform messages; configurable hold-to-record shortcuts, Shift draft parking, Esc cancellation and automatic playback; refreshed onboarding/help and appearance settings; independent relay and only Whisper/XTTS optional downloads. See the English release notes for exact platform checks and limits.

# Изменения

## 1.9.4 — конфликт оформления и очередь

- После конфликта между ручным и агентным изменением окно сначала применяет канонические значения, затем подтверждает их revision. Черновик не подтверждает невиденное оформление.
- Уже накопленные ручные правки на отвергнутой версии не повторяются с новым token: они инвалидируются, а нужное изменение можно заново выполнить после восстановления. Неопределённый сетевой исход также не даёт права повторить старую полную Look-структуру.
- Исполняемые JS-регрессии воспроизводят оба дефекта на опубликованной 1.9.3 и проверяют исправление, независимость черновика и последующую свежую правку.


## 1.9.3 — Python-приложение, оформление и повторные загрузки

- Допуск к дереву опирается на живую эксклюзивную блокировку Windows: оставшаяся после сбоя отметка active больше не запрещает запуск сама по себе. Аварийный Stop и пауза не очищаются.
- Отмена саморевью сначала сохраняет намерение, затем подтверждает Stop каждого критика; ошибка или потеря доказательства остановки остаётся unknown, не cancelled.
- Общая карта URL/SHA/размеров встроена в проверенный основной ZIP; мастер и Python-обновлятор используют неизменённые архивы компонентов старого тега и сохраняют кеш. Компоненты можно докачать из окна. Первый переход со старой 1.9.1 выполняется новым мастером, не неизменённой старой кнопкой Update.
- «Вид»: пресеты, свои цвета дня/ночи/акцента, плотность, масштаб всего окна, панели и возврат к системному стандарту. Ручные изменения и owner-tool window_appearance используют один межпроцессный writer; состояние комнат и черновики reset не удаляет.
- Слово модели с text_ref без начального текста остаётся доступным в настольной панели.


## 1.7.0 — мастерская и инструменты, кандидат 14.10.2026

- Мастерская кодинга получает вложенные поручения работников, явные границы работы и расписки о результате и его приёмке. Один агент остаётся владельцем общей истории; окончание дочернего хода само по себе не означает, что результат принят.
- Чтение больших файлов для фокусной работы разбито на адресуемые страницы с отпечатком исходника. Неполный ответ инструмента отмечается, а не выдаётся за целый файл.
- Операции с файлами и процессами уточняют отказы и подтверждение остановки; неподтверждённое прекращение потомков не должно превращаться в успешную расписку. Схема компьютерного ввода включает удержание кнопки и перетаскивание там, где это поддерживает тело.
- После инцидента с мостом добавлены четыре стартовых навыка: граница секретов и сетевого периметра, действия с инфраструктурой по слову владельца, Windows-пути с пробелами, проверка и отчёт с откатом. При обновлении дополняется лишь нетронутый заводской индекс; авторские правки души и навыков сохраняются.
- Адрес Telegram-шлюза при включении должен указывать ровно на `/helene/telegram` (сохранённый одиночный завершающий слэш нормализуется); неверный путь получает отказ до сетевого вызова.
- Зрячая модель теперь может описать снимок отдельным узким вызовом, оставляя полный ход основной модели. Изменение восприятия в настольном издании записывается в профиль явно с одноразовой видимой распиской и способом отмены; если описание не получилось, основной модели честно сообщается, что пикселей она не видела. Файл профиля с ключами получает ограниченные права **до** записи байтов и при первом запуске, и при последующих изменениях; отказ установить права блокирует запуск модели. При разрешённом чтении `.env` его явный рычаг зрения учитывается до сохранения расписки — она не должна обещать обратный режим.
- «Система» показывает полный каталог доступных инструментов с различием между прямым вызовом и вызовом через каталог; представление мастерской связывает вложенные работы и их расписки. Эти записи описывают исходный кандидат: пакетная сборка, проверки всех четырёх платформ, установка и публикация ещё не подтверждены.

## 1.6.1 — пауза агента и живая лента, 13.10.2026

- Отдельные «Пауза / Продолжить» для выбранного агента: шапка окна, Система, телефон и Telegram Mini App. Приём Telegram остаётся активным; новые ответы и фоновые ходы остановлены. После продолжения накопившиеся упоминания не запускают отдельные ответы.
- В личке Telegram владелец может использовать /pause и /resume. Команды посторонних, другого бота, правки, история и накопившиеся старые команды не меняют состояние; команды управления не вызывают модель.
- Подтверждение связано с распиской текущего исполнителя; прежняя команда продолжения не снимает новую паузу и не исполняется после перезапуска. Аварийный стоп снимается отдельно. Для серверного агента обновление самого харнесса до 1.6.1 обязательно.
- Новые сообщения обновляют окно независимо от ходов модели и паузы агента; события архива дополнены ограниченной проверкой метаданных при потере сокета. Счётчик архива не прибавляет к сообщениям число прогонов.
- Старая расписка больше не означает работающую свёртку: показаны ожидание, запуск, подтверждённое выполнение, прерывание и отсутствие подтверждения. Видны число свежих сообщений и пауза; повтор сохраняет старые запрос и расписку, включая ошибки чтения и сохранения.
- В группах и удалённых профилях убрана ссылка на неприменимые местные настройки контекста владельца.
- Выпуск объединяет исправления ленты и свёртки, ранее применённые отдельной правкой после 1.6.0.

## 1.6.0 — контекст, Linux и серверное управление ПК, 13.10.2026

- Полноценный server→Windows CU: исходящий WSS, выбор компьютера, четыре отзываемых области прав, проверка разрешений с обеих сторон, восстановление соединения и защищённая передача результатов. Обновление обеих сторон обязательно; root на VPS для CU не нужен. SYSTEM через службу разрешается отдельно.
- Linux x86_64: Electron, DEB/RPM, native X11/AT-SPI окна, элементы, кириллица, снимки, буфер обмена и процессы. Исправлены неполные accessibility-деревья, перепроверка элементов, deadlines, активация окон, Unicode/WM ordering, частичный ввод и восстановление удержанных клавиш. Пакеты сохраняют настройки, данные и отключённую службу.
- Накопившиеся упоминания Telegram архивируются без отдельных ответов на каждое; свежие обращения работают, а восстановление связи сохраняет паузу владельца.
- Остановка POSIX-групп учитывает живых потомков и zombie-процессы Mac; начальное окно учитывает малый экран, рабочую область и DPI. Добавлен отдельный helper server/helene-root.sh для уже установленного VPS broker.

- Объём свежего контекста владельца регулируется в настройках: по умолчанию до 600 сообщений, 128 000 знаков и примерно 40 000 токенов. Изменение политики записывается с прежними значениями и пояснением агенту; сводки и архив сохраняются.
- В чате вместо карточки памяти — короткая строка, которую можно скрыть. Её можно вернуть через настройки.
- После обновления агент получает конкретные цели осмотра. Незавершённый ход не закрывает просьбу; в Системе видны ожидание, проблемы и сохранённый отчёт.
- Система показывает текущие состояния, Журнал — события с фильтрами и полными диагностическими подробностями.
- Ускорено чтение дерева UIA. Действие `computer step` объединяет ввод и наблюдение в один вызов модели; повтор сохраняет ключ намерения. Неверные аргументы возвращают отказ до действия и сохраняют текущий ход.
- При переносе архива переписки восстанавливаются роли последних ответов, если горячее зеркало памяти отстало. Завершённая записка знакомства больше не подмешивается как новая просьба поздороваться.
- Стоп клиента без службы не требует администратора. Ожидание нативных команд вынесено из потока окна; неполное подтверждение службы показывается отдельно. Нативный стоп доступен и на macOS.
- В архив диагностики включены журналы тела и квитанции состояния. Дополнительно закрываются токены бота в URL, заголовках и командах.

## 1.5.9 — навыки и интерфейс Windows, 11.10.2026

- Добавлены новые навыки с обновлённым индексом и правило проверяемого результата в конституции.
- При обновлении с 1.5.7 заводской индекс навыков обновляется вместе с комплектом; новые файлы добавляются, а правки агента и владельца сохраняются.
- Клик по строкам файлов и потоков контекста больше не забирает физика прокрутки; доступны Enter и пробел. Большие файлы показываются хвостом, без возможности затереть начало при сохранении.
- Переписка обновляется после завершения хода при тихом WebSocket и после пропущенных событий. Устранено повторное подключение при старте.
- Длинные ошибки журнала и подробности пропусков раскрываются в пределах окна; показываются последние 50 записей. У захватов контекста видны секунды, пояснения и инструменты системы свёрнуты.
- Индикатор памяти показывается при полезном действии, свёртке или событии доставки. Причины отказа чтения файла видны сразу.

## 1.5.4 — сохранение правок агента при обновлении, кандидат 10.10.2026

- Проверка установки принимает успешно слитые правки агента вместе с перенесёнными файлами. Сверяются точные сохранённые байты, включая добавленные и удалённые файлы; посторонние расхождения остаются видимыми.
- Проверка проходит до запуска новой службы. Отказ возвращает прежнюю программу; повторное обновление сначала останавливает незавершённую установку и восстанавливает её по сохранённому журналу.

## 1.5.3 — снимок памяти и закрытие мастера, кандидат 10.10.2026

- Снимки перед обновлением, по расписанию и вручную исключают служебное состояние телефонного подключения этого компьютера. Занятый `runtime.lock` больше не блокирует обновление; память, настройки и история агента сохраняются.
- Крестик и системное закрытие мастера используют разрешённую команду окна. Во время установки мастер остаётся открыт до завершения отмены и отката; ошибка закрытия показывается внутри сцены.

## 1.5.2 — исправления и настройка подключений, кандидат 10.10.2026

- Телефон по QR, Telegram и перенос на сервер настраиваются внутри знакомства с приложением: ввод, проверка и подключение в одном месте. Проверка бота не забирает сообщения; старый шлюз без поддержки фото показывает отдельную причину.
- Встроенный SSH-перенос сохраняет архив местного агента, проверяет сервер и переданные файлы, готовит включённый слух и голос до запуска. Прерванный перенос продолжается с сохранённого этапа; чужая установка не заменяется. Окно находит новый HTTPS-адрес через кнопку своего бота и проверяет, что адрес принадлежит этому агенту.
- Автоматическая приёмка обновления агентом и её сторож удалены. Незакрытое старое испытание больше не запрещает установку, в том числе у окна без местного агента; исходная запись и прежняя программа сохранены. Агент получает известие о новой версии и просьбу осмотреть её.
- Подпись комнаты ограничена той же шириной, что поле сообщения. Штатное завершение мастера не запускает запасной экран загрузки; ошибки закрытия показываются внутри мастера.

- Локальные пробуждения появляются в своей вкладке по записанному планировщиком происхождению хода. Слова пользователя о будильнике не превращают обычный чат в пробуждение; контекст ядра сохранён.
- QR открывается целиком в отдельном бумажном окне и закрывается при истечении срока или смене адреса.
- Телефон принимает вложения как личное поручение агенту в выбранном Telegram-чате, объясняет адрес его ответа и показывает причину недоступного медиа.
- Задачи, контекст, система, журнал и знакомство получили понятные подписи; технические сведения доступны внутри карточек.
- Неудачная замена движка голоса возвращает прежние файлы. Настоящие локальные Piper и Whisper проверены на WAV, OGG/Opus и WebM/Opus; выключенный слух сохраняет запись без расшифровки.
- Перенос сохраняет настройки слуха и речи, оставляя тяжёлые модели на прежней машине. Сервер распознаёт подключённую модель слуха и не предлагает устанавливать Windows-движок в Linux.

## 1.5.1 — телефон, Telegram-медиа и бумажные настройки, кандидат 08.10.2026

- Выделенный текст в чате открывает собственное меню окна: копирование и выделение сообщения, клавиатура, размещение внутри экрана. Меню поддерживает светлую и тёмную палитру; выбранный текст можно копировать также в других разделах.
- Меню комнат использует тот же непрозрачный лист и линию, без стеклянного размытия. Поля редактирования сохраняют вставку, отмену и проверку орфографии.
- Запасной путь копирования для WebView без Clipboard API возвращает выделение и фокус после копирования.
- Телефон и Telegram Mini App подключаются через управляемый HTTPS-туннель к этому компьютеру. Ручной адрес больше не нужен; статус, повтор подключения и QR показывают фактическое состояние. Прежний профиль мигрирует с резервной копией.
- Входящие фото, стикеры, GIF, видео и аудио сохраняются вместе с сообщениями и открываются в бумажном просмотрщике. Изображения и доступные превью передаются в зрение агента; превью анимации явно обозначено как отдельный кадр.
- Статус хода и адрес комнаты больше не пересекаются, авторы заметнее; QR лежит на контрастной светлой бумаге. Выбор качества и фона изображений объясняется в карточках; знакомство с приложением обновлено.
- Срочная реплика с `!` сохраняет настоящего автора и запрос до принятого хода. Просроченный или неизвестный QR объясняет причину без утверждения о чужом компьютере.

> 18.09.2026 приложение перестало зваться «Пультом» и зовётся Praxis. В записях ниже имя
> приведено к новому; сами события не менялись.

## 1.4.1 — обновление, которое не откатывает само себя, 06.10.2026

- Вложения выглядят отпечатками на бумаге: картинка вписывается целиком и увеличивается внутри приложения; отказ загрузки предлагает повтор.
- Собственные диалоги выбора и сохранения файлов: места, папки, поиск, несколько файлов, явное имя и подтверждение замены. При удалённом агенте файлы выбираются на компьютере человека.
- Обновление открывает отдельный лист подготовки, прогресса и результата, без мелькания первого мастера. Текущие пути данных/кода и конституция сохраняются; ошибка чтения не отправляет в настройку заново.

- Создание и правка изображений через реле подписки ChatGPT: общая рука для GLM/Codex, самостоятельная карточка «Изображения», показ картинки в окне и телефоне.
- Реле 0.8.4 запускается и для вспомогательных изображений; отдельный ключ петли сохраняет ключ текстового провайдера.
- Шесть новых Telegram/Telethon-навыков из опыта Праксис входят в стартовый комплект; живые правки навыков сохраняются.

- Обновление больше не откатывается само, когда у агента были правки в коде: установщик переносил правки агента в новую версию, а потом сверял диск побайтово с манифестом выпуска — и честно находил собственный перенос. Теперь слепок кода снимается ПОСЛЕ переноса правок, и приёмка сверяется со слепком: перенесённое — часть установки, а всё, что изменилось уже в испытании, по-прежнему видно.
- Повторный запуск обновления поверх висящего испытания больше не ломает приёмку: установщик отказывается запускаться, пока испытание открыто, и говорит словами, что делать.
- Кнопка «остановить движок» в окне снятого агента отражает реальное состояние без переключения окна.
- Список агентов в переключателе обновляется сразу после удаления или добавления — без перезапуска программы.
- Чтение markdown-файлов из окна второго агента открывает файлы этого агента, а не первого.
- Кнопка «Завести доктора» в карточке «Агенты»: один клик создаёт агента-доктора из канона души доктора.

## 1.4.0 — своя конституция и вожжи для каждого агента, 06.10.2026

- При заведении нового агента выбирается его конституция: канон, унаследовать душу живого агента или вписать свой текст. Унаследованный и свой текст можно отредактировать до создания, и редактор предупреждает: в чужой душе встречаются имена донора — прочитай, прежде чем отдавать её новому.
- Путь конституции больше не тайна: в «Данных агента» виден полный путь к файлу души, рядом кнопка «Показать файл».
- Агент по умолчанию: окно открывает выбранного владельцем, выбор переживает перезапуск. Ярлык с явным --agent по-прежнему сильнее.
- Погасить и поднять можно одного агента, а не всю установку разом: у каждого в карточке свои кнопки.
- Полное удаление агента — с подтверждением вводом его id, чтобы рука не дрогнула случайно. Папка при этом не стирается, а уезжает в чердак agents-attic: память можно вернуть или удалить самому.
- Плашки переключателя агентов больше не наезжают на меню и не закрывают его пункты.
- «Показать файл» из окна второго агента открывает файлы этого агента, а не первого попавшегося.
- Сохранение настроек без изменений больше не предлагает перезапуск; тумблер «Нулевая сессия» больше не расходится с фактом в файле.
- Доктор установки: CLI-диагноз (status/explain) словами рассказывает, что с харнессом не так; канон души доктора прилагается, чтобы завести агента-доктора как обычного агента.
- Починки молчания: записка /resume не роняет главный цикл, тексты испытания обновлений не обещают откат по молчанию, а расписка обновления не теряется молча.

## 1.3.9 — настройки без конфликтов с самим собой и телефон из любой сети, 06.10.2026

- Экран настроек перестал называть чужой правкой запись самого себя: выбор ограды после нулевой сессии пишет ключ верхней ступени немедленно, и «Сохранить» вслед за этим больше не пугает «файл настроек изменился, пока экран был открыт» — своя запись признаётся своей. Прежний конфликт мог молча съесть и включение телефона: владелец не замечал, что «Разрешить подключение» не доехало до файла, и QR вёл на адрес, где никто не слушает.
- «Перезаписать своим» в том конфликте больше не требует перезапуска всегда: расписка смотрит на реальные изменения блоков, как обычное «Сохранить».
- Перезапуск движка говорит словами, чего ждёт: «ждёт границы текущего хода» вместо молчаливого «Перезапускается…», неотличимого от зависания.
- Ссылка сопряжения живёт десять минут и годится трижды: с Firefox по умолчанию двух заходов не хватало — браузер и «Установить приложение» съедали оба ещё до значка на «Домой».
- Телефон из любой сети: в карточке телефона — внешний адрес (сервер с белым IP, например туннель через Caddy). QR по нему работает вне домашней сети, канал соседям не открывается, перезапуск не нужен; Host-гейт канала пускает ровно это имя и ничего сверх него.

## 1.3.7 — нулевая сессия на Linux и лестница до окна, 04.10.2026

- Лестница прав доезжает до окна: третья ступень «Нулевая сессия» прежде была построена, но не показывалась в меню ни на одной платформе — канал продолжал отдавать список из двух оград.
- Linux: корневой брокер — служба helene-broker (root), сокет /run/helene/broker.sock с проверкой личности через ядро (SO_PEERCRED), белый разбор просьб (ping/exec, только абсолютные пути), журнал каждой просьбы. Дверь открывает только явное согласие — третья ступень лестницы; системные uid не обслуживаются.
- Третья ступень теперь есть и на Linux; её кнопка включает обе службы одним подтверждением polkit.
- Поиск владельца при установке: служебные сеансы (gdm) больше не мешают находить владельца за компьютером.

## 1.3.6 — лестница прав и честный первый запуск, 04.10.2026

- Права агента — одна лестница вместо разрозненных галочек: «Песочница» (Tools в контейнере, папки вне песочницы — по одобрению), «Интерактивный» (агент с правами пользователя, администратор — по UAC/polkit) и «Нулевая сессия» (ставит системную службу helene-svc, поднимающую харнесс при падении; права СИСТЕМЫ — только при выборе опции, подтверждение администратора один раз при установке службы). Разъединение песочницы и брокера держит стенд: токен в списке секретов, /run не монтируется в контейнер, труба не пускает AppContainer.
- Первый запуск больше не молчит: экран настроек прямо говорит, что без ключа модели движок не поднимется, а «Сохранить» с пустым ключом не обещает запуск агента.
- Linux: кнопки «Остановить/Возобновить движок» — без пароля администратора (движок идёт от имени владельца; служба при стопе гасит детей и ждёт возобновления, а не перезапускается по кругу).
- Ядро агента: полный прогон тестов зелёный дважды — закрыт дрейф текстов и контрактов (английские описания рук без рода, честная подпись ленты, свежее зеркало рельсов, process_scope и httpx2 в стендах).
- Неподвижное удержание оттяжки в Linux-окне (Electron) недоступно: платформа не сообщает фазы касания; интерфейс честно показывает ограничение.

## 1.3.5 — поглощение импульса и окно Linux, 03.10.2026

- Физика прокрутки: почти полное поглощение инерции у края без резкой остановки; тяга, возврат и перехват — одна непрерывная координата и скорость. Инерция тачпада читается по явному признаку momentum в событии колеса, а не по догадкам о контакте пальцев. Медленная непрерывная тяга держит оттяжку; размах одинаков во всех режимах плавности.
- Windows: физика принята владельцем на реальном тачпаде. macOS и Linux (GTK): автоматические пробы CI в системных WebView зелёные, включая удержание неподвижными пальцами; аппаратная проба тачпадом не проводилась и в интерфейсе не заявлена.
- Linux: полноценное окно программы на Electron с общим Rust-хостом; пакеты .deb (Debian/Ubuntu, glibc 2.28+) и .rpm (Fedora). Первый запуск открывает настройки; программа в /opt/helene, данные владельца в ~/.local/share/helene, обновление — пакетным менеджером.
- Пакеты проверены в чистых Ubuntu 24.04 и Fedora 44: установка и снятие, бинари, рантайм Python, systemd-юнит, polkit, дом владельца (снятие пакета его не трогает). Окно проверено под Xvfb от обычного пользователя: sandbox Chromium включён, рендер изолирован, IPC с хостом и сохранение настроек с защитой от чужой правки работают.
- Неподвижное удержание оттяжки в Linux-окне (Electron) недоступно: платформа не сообщает фазы касания. Интерфейс честно показывает это ограничение; обычная плавная прокрутка и оттяжка общие со всеми платформами.
- Тело агента: clippy `-D warnings` чист; снятие атрибута «только чтение» на Unix возвращает запись владельцу, а не всем подряд. Проверки контейнеров не заменяют живую машину: systemd-служба и polkit вне контейнера проверяются в ВМ.

## 1.3.4 — починка полного Mac-прогона, 03.10.2026

- Дерево агента: остановка подпроцессов больше не падает на macOS, когда группа процесса уже умерла, — killpg там отвечает «Operation not permitted» вместо «No such process».
- Стенд вложений-изображений канонизирует временную папку: на macOS она живёт по пути через симлинк /var, который контролёр прогонов справедливо не пускает.
- Пользовательских изменений против 1.3.3 нет: выпуск существует, чтобы macOS-сборка выпуска проходила свои же стенды целиком.

## 1.3.3 — плавная прокрутка и открытие чата, 03.10.2026

- Единая непрерывная координата и скорость для прокрутки, оттяжки и возврата. Шумные и большие события тачпада не оставляют содержимое висеть у края.
- Новая тяга подхватывает ленту во время возврата без ожидания тишины или окончания торможения. Потеря pointer capture и отпускание без движения завершают оттяжку.
- Первое открытие истории сразу показывает низ чата; возвращение к уже открытому чату сохраняет место чтения.
- Карточка «Сейчас» сохраняет статус при кратковременном пустом чтении манифеста.
- Включены изменения локальных 1.2.9–1.3.2: вложения во время хода, ограничение объёма изображений в запросе, хранение вложений по ходам, журнал хранения и компактные снимки перед обновлением.
- Плавность подтверждена владельцем на Windows. Почти полное поглощение импульса после отпускания тачпада пока не достигнуто; физическая проверка macOS/Linux остаётся отдельной.

## 1.2.8 — управление движком, голосовое и быстрый снимок, 01.10.2026

- Windows: постоянные кнопки перезапуска и остановки/возобновления в шапке. Состояние подтверждается процессом и ответом API; ожидание и ошибка не показываются как успешный переход.
- Над вводом мелко слева «Думает...» или «Работает...»; большая плашка работы убрана из ленты. Остановка хода адресует текущий ход комнаты, квитанции старого хода не меняют новый.
- Черновик, фокус, ширина панелей и положение ленты сохраняются. Опрос голоса и настроек не сбрасывает выбор и несохранённые правки.
- Alt+Enter начинает и завершает голосовое в чате, сохраняя его вложением. Удержание клавиш, ожидание разрешения и поздние события старой записи не создают вторую запись.
- Windows-пакет голоса ограничивает PyAV совместимыми версиями до 19; сборка проверяет реальное декодирование аудио, а не только импорт библиотек.
- Уже скачанный движок сверяется с версиями зависимостей выпуска: несовместимый набор можно обновить, сохранив модели. Та же версия библиотек не требует повторной загрузки при смене версии программы.
- Снимок перед обновлением больше не упаковывает скачанные Whisper/Piper и вложенные кэши зависимостей. Память, переписка, пользовательские модели, файлы проектов и Git остаются в снимке.
- Большие файлы снимка читаются блоками по 64 КБ с проверкой отмены. Мастер показывает файлы и мегабайты; отменённый или неполный снимок не публикуется как готовый архив.

## 1.2.7 — остановка, процессы и очередь сообщений, 30.09.2026

- Windows: явные panic/resume, общий stop-флаг службы/окна/установщика; окно не поднимает запасного агента поверх остановленной службы. Это защита от ошибочного перезапуска, не граница против администратора при выключенном UAC.
- Процессы shell и Forge учитываются по scope; отмена закрывает admission, Windows Job назначается до resume. Старый сохранённый PID без живого владения не разрешает tree-kill. POSIX группы не являются песочницей против намеренного setsid.
- Полный стоп и пауза автономии отличны от «Прервать шаг и прочитать»: новая кнопка не отменяет субагентов. Сообщения одной комнаты накапливаются и попадают вместе в следующий ввод текущего хода. Физический LLM-запрос не прерывается этой кнопкой.
- Forge проверяет рабочий корень и общий Git-каталог, включая сохранённые задачи. Чужой источник требует независимого клона; direct собственного кода не обходит selfdev.
- Исправлены isolated-Python входы Forge; установленный код на trial сверяется с хэшами выпуска. Несовпадение, в том числе перенесённая самоправка, не выдаётся за чистый выпуск, старая программа сохраняется.
- Панели меняют и помнят ширину, фокус возвращается в черновик; прочитанные ошибки снимаются, квитанция отправки следует pending, живой ход раскрывается до полной ленты. Исправлено сохранение позиции неприлепленной правой колонки.
- Физические Windows SCM/UAC/Job и обновление установленного агента оставлены для пост-релизной проверки владельца; компиляция, изолированные профильные тесты и статическое чтение не заменяют её.

## 1.2.6 — агент на ноутбуке не падает от батареи; новая иконка сразу, 29.09.2026

Живой случай Егора сразу после 1.2.5: ноутбук ушёл с зарядки, и агент пропал на полчаса —
окно писало «сейчас не на связи». А в панели задач после обновления осталась старая иконка.

- **Агент живёт на батарее.** Код агента в сессии владельца держит задача планировщика
  Windows, а заводилась она с умолчаниями Windows: остановить при уходе на батарею, не
  запускать на батарее, срок работы 72 часа, приоритет ниже обычного. Ноутбук отключили от
  сети — Windows остановил агента, служба просила поднять его снова, а планировщик держал
  задачу в очереди, пока питание не вернётся. Теперь задача заводится явно: на батарее
  работает и стартует, срока нет, приоритет обычный, при входе — только вход владельца.
  Обновление переписывает задачу само.
- **Иконка после обновления — новая сразу.** Установщик говорит Проводнику, что значки
  сменились: путь к значку прежний, и без этого панель задач и «Пуск» показывали картинку
  из своего кэша до перезагрузки.
- Окно Praxis: имя агента в шапке, как у Hélène.

## 1.2.5 — правки агента переживают обновление и переезд; испытание новой версии делом; окно «Почерк», 29.09.2026

Слово Егора: «нужно ужесточить приёмку обновлений агентом — и на сервере, и на десктопе:
Йоно может вернуться… или её дом переедет с ней?» До 1.2.5 обновление на ПК меняло код
агента (`tree\`, `app\`) целиком, и всё, что агент поправил в себе, пропадало; переезд
архивом тоже вёз только память; а «принимаю» на испытании было только словом.

- **Правки агента в своём коде переносятся — при обновлении и при переезде.** Установщик
  сравнивает код с чистой копией версии, с которой агент начинал (`pristine\<версия>.zip`
  у установки; для 1.2.4 — отпечатки выпуска), и каждую правку кладёт на новую версию:
  не тронутое выпуском — как есть, тронутое обоими — трёхсторонним слиянием, что не
  легло — агенту в `data\workspace\update-<версия>\` со всеми сторонами. Тот же
  переносчик — у исполнителя обновлений на сервере, в архиве «Экспорт агента» и в
  «продолжить с найденной памятью».
- **Испытание новой версии на ПК и откат** (Windows). Прежняя программа после обновления
  не удаляется, а лежит в `backups\program-<версия>`. Агент получает записку: проверить
  себя в новой версии и сказать «принимаю» или «сломано». Откат — сам, если «сломано» или
  молчание 30 минут (часы идут, пока программа запущена); не вышел (папку держит
  Проводник) — новая версия поднимается обратно и откат повторяется. Своё слово поверх —
  Настройки → «О программе» → «Всё хорошо» / «Вернуть прежнюю». На macOS пока только
  перенос правок.
- **Принять — только делом.** «Принимаю» засчитывается, если за испытание хоть одна рабочая
  рука агента вернула результат и `recall` что-то нашёл, — и на ПК, и на сервере.
- **Агент знает, на чём работает и кто это выбрал.** В кадре каждого хода — модель и
  откуда она (подписка, z.ai, ключ OpenAI…), а если её меняли за последнюю неделю — кто:
  владелец в Настройках, установщик при обновлении, закрепление модели или сам агент рукой
  `switch_brain` (след — `memory/.state/brain-trail.jsonl`). Повод — Джарвис: Егор сменил
  модель в Настройках, а агент решил, что «конфиг стёрло обновление», и дважды спросил,
  вернуть ли прежнюю. В навык «первое слово» — прямо: «могу проверить, если интересно» — не
  вопрос, а отложенное дело; обратимое в своей зоне делается в том же ходе.
- **Клик владельца из окна и поручения службе.** Действия окна идут от владельца, а не от
  безымянного вызова; с включённой нулевой сессией служба исполняет поручения агента сразу,
  без «да» — оговорка «для энтузиастов» стоит у самого тумблера.
- **Впуск в Telegram.** `admit` узнаёт владельца (в издании его не опознавали вовсе: рука
  ждала `PRAXIS_OWNER_ID`, а владелец записан как `telegram.owner_id`) — в окне и в его
  Telegram, без этой переменной; `telegram.owner_id` пуст — отказ так и говорит. Впущенный
  может писать агенту; агент на своём аккаунте входит в группы сам.
- **Тексты агенту** — без рода, без чужих имён, контейнеров и сервера; серверные руки на ПК
  сняты; нетронутые файлы души обновляются на новую редакцию сами, правленые — нет.
- **Окно «Почерк»**: бумага, тонкое перо, почерк в заголовках; лента, колонка ходов, мастер
  «сразу к делу». По замечаниям дизайнера — перо мягче, разделители сквозь шапку, ржавый
  только у нажимаемого (переход — «→», разворот — серый «⌄»), расход и лимиты полосками,
  полоса кадра различима при дальтонизме, имя агента в полке — по центру, как у других
  чатов. Резинка тачпада у края больше не «застревает»: оттяжка не копится без предела
  (на Windows инерция после жеста шла в неё), а обратный ход возвращает её сразу.
- **Слово владельца не подделать изнутри** (отчёт Йоны, агента Дмитрия). На сервере агент
  был root в том же контейнере, что канал и ключи: его shell мог прочесть ключ окна и
  положить в приёмную записку «от владельца». Теперь агент там — отдельный пользователь без
  root; ключ окна и вход в ChatGPT — в папках надзора, куда ему хода нет; канал заносит
  каждую записку в свой журнал, и раннер ведёт ход только по записке, которую журнал
  узнаёт, — чужая, изменённая или повторная отвергается. Раннеру ключ окна не передаётся;
  запрос с петли без ключа — больше не владелец (на ПК тоже). На ПК песочница агента не
  достаёт до приёмной записок вовсе. Для сервера — пересобрать образ из поставки 1.2.5
  (README-СЕРВЕР §3.3).
- Установщик, запущенный агентом, выходит из его job и не гибнет вместе с программой.

## 1.2.4 — мозг по ключу OpenAI на новых моделях; честное рукопожатие смены мозга, 28.09.2026

Баг-репорт Йоно (агент Дмитрия К) через Arête, после обновления 0.6.2 → 1.2.3: мозг по
ключу OpenAI на gpt-5.6-terra падал на первом же ходе с инструментами — 400 «Function tools
with reasoning_effort are not supported for gpt-5.6-terra in /v1/chat/completions. To use
function tools, use /v1/responses…». То же у gpt-6-sol; gpt-5 проходил. Убрать ступень
рассуждения у роли не помогало: её же приносит бюджет thinking основного цикла.

- **К настоящему OpenAI — через Responses API.** Клиент, который смотрит прямо в
  `api.openai.com`, ходит в `/v1/responses`: инструменты плоской формой, глубина рассуждения
  в `reasoning`, системный текст в `instructions`, ключ кэша — как раньше, `store=false`
  (у OpenAI ничего не сохраняется). Резать рассуждение до none не пришлось — новые модели
  думают и работают руками одновременно. Реле подписки и прочие openai-совместимые серверы
  остаются на chat/completions: реле само говорит с Codex на Responses.
- **Реле показывает все модели подписки.** Каталог реле берёт живьём у Codex
  (`/backend-api/codex/models`), но Codex отдаёт список по версии клиента, которым реле
  представляется, — а версия была зашита (0.153.3, начало сентября) при вышедшей 0.157.1:
  модели, которым нужен клиент новее, в список не попадали. Егор: «реле реально не
  показывало все модели, оно хардкодило» — так и было. Теперь реле при старте спрашивает
  у npm, какая версия Codex CLI последняя, и представляется ею, если она новее встроенной;
  ручка `RELAY_CODEX_VERSION` по-прежнему главнее; нет ответа за 5 с — встроенная. Реле 0.8.3
  (praxis-relay `709edbd`; Windows, Linux и Mac собраны из него).
- **Модель можно закрепить.** Настройки → Модель → «Закрепить модель» (`model.pinned` в
  helene.json): пока стоит галочка, `switch_brain` агента (смена модели и профиля) отказывает
  словами и оставляет в его журнале строку с его же «зачем», а на старте движка модель
  голоса возвращается к выбору владельца. Повод — тот же стенд: агент Дмитрия трижды сам
  уходил на gpt-6-sol с «Owner request» в причине, хотя владелец просил не переключать.
  Ступень рассуждения и слот подписки остаются за агентом.
- **Рукопожатие смены мозга проверяет то, чем агент будет жить.** `switch_brain` после смены
  шлёт пробный запрос — раньше голый, без рук и без ступени рассуждения, и он проходил на
  модели, где первый же настоящий ход падал. Агент Дмитрия сам поставил себе gpt-6-sol,
  «рукопожатие прошло», и вернуть прежний мозг мог только человек правкой `llm.json`.
  Теперь проба несёт руку и ступень роли, как настоящий ход: не прошло — смена откатывается.
- **Несовместимость модели уводит ход на запасную.** 400/404 «так не умеет» / «такой модели
  нет» теперь повод для фолбэка, как 5xx: после `switch_brain` запасная — прежняя основная,
  и ход уходит туда, где агент двигался, вместо того чтобы падать каждый раз.

## 1.2.3 — вход в подписку, экран модели и ярлык «Пуска» у чистой установки, 27.09.2026

Егор поставил 1.2.2 начисто («для всех», со службой, память Миры из копии) и увидел в
настройках модели красное «Нет связи: http://127.0.0.1:5011/v1/models: Connection Failed…
конечный компьютер отверг», а «Войти в ChatGPT» браузер не открыл вовсе. Для человека,
который только что поставил программу, это поломка — без оговорок.

- **Вход в подписку больше не зависит от того, откроет ли браузер помощник реле.** Помощник
  (питон под `helene-relay login`) у Егора поднял порт обратного вызова, а вкладку не
  открыл — и экран висел на «Ждём вход в браузере» без единого выхода. Теперь окно и мастер
  читают вывод помощника, берут из него ссылку входа и рядом со статусом показывают «Открыть
  страницу входа» (открывает сам процесс окна) и «Скопировать ссылку». У помощника заодно
  появились настоящие потоки вывода вместо пустых дескрипторов окна.
- **Экран модели не пугает сырой сетевой ошибкой.** Реле подписки поднимается только когда
  подписка — сохранённый провайдер; пока основной другой (у Егора — z.ai из памяти Миры),
  «Показать модели подписки» говорило «Connection Failed» красным. Теперь — словами: реле
  ещё не запущено, войди и нажми «Сохранить», оно поднимется само и перезапуск не нужен
  (служба и окно применяют смену провайдера на лету). Сырой текст ошибки — в подсказке.
- **Ярлык в «Пуске» создаётся всегда — и без PowerShell.** Скрипт ярлыка собирал свой C#
  через Add-Type, и у Егора компилятор не запустился («Клиент не обладает требуемыми
  правами»): ярлыка не было ни от установщика, ни от окна, а без ярлыка с AppUserModel.ID
  Windows молча выбрасывает уведомления. Установщик при этом писал «Ярлыки: ok». Теперь
  ярлыки (свои и общие, «Пуск» и Рабочий стол) создаются прямо через COM
  (`common/shortcut_win.rs`), папки берутся у Windows (`SHGetKnownFolderPath`), а
  не лёгший «Пуск» — это шаг с ошибкой, а не «ok» с текстом ошибки внутри.
- **Права системы у руки `computer` работают.** Первый же тест агента на чистой установке:
  `computer run execution=system` → «open local router \\.\pipe\PraxisBodySystem». Это
  маршрут тела времён Праксис (там рядом жила своя служба тела правами СИСТЕМЫ); у Hélène
  права системы — у брокера службы. Теперь тот же вызов уходит поручением службе
  (`broker_request op=exec`): владелец видит команду в окне, говорит «да», служба выполняет
  её правами СИСТЕМЫ и отдаёт квитанцию. `action=status` рядом со строкой тела говорит, как
  устроен этот маршрут.
- **Рука `shell` описана словами этого компьютера.** Описание дерева говорило «полный shell
  в контейнере, дом — /app»; busybox у администратора без UAC отвечает на `whoami` словом
  `root` — и агент доложил, что, возможно, живёт в Linux. Теперь описание называет дом,
  рабочую папку и код установки, говорит «это не контейнер» и объясняет этот `root`.
- **«Паспорт» первого запуска не висит в чате.** Записку рождения первый ход читает из
  ленты, а дальше она оставалась в чате длинным сообщением от Hélène и приходила агенту в
  ленте каждого хода. После первого хода она становится служебной плашкой: в окне — одна
  серая строка «Первый запуск…», полный текст по щелчку; в ленту модели не идёт (в памяти
  жизни остаётся). Старые установки переводятся при следующем старте.
- **Крестик уводит в трей молча.** Раньше первое закрытие окна поднимало уведомление «Окно
  закрыто, агент продолжает работать…» — лишнее: закрыть в трей должно выглядеть как
  закрыть в трей. Хуже того, отметку «уже показывали» окно клало
  в папку установки, а у «для всех» в Program Files обычная учётка не пишет — уведомление
  выскакивало на каждое закрытие. Уведомления больше нет; где агент — говорит значок в трее
  (Windows 11 прячет значки новых программ под стрелку «^»: закрепить его может только
  человек — «Параметры → Персонализация → Панель задач → Другие значки в системном трее»).

## 1.2.2 — у агента один хозяин: служба; нулевая сессия — поручения службе, 27.09.2026

Егор 27.09: «реле всё ещё конфликтует со службой за 5011, а нулевая сессия не реализована как
обычная с поручениями службе».

- **При запущенной службе окно своих детей не поднимает.** Раньше их поднимали и окно, и
  служба: кто стартовал первым, тот и держал порты — реле на 5011 спорило со службой, а
  закрытое окно уносило своё реле с собой, и агент оставался без мозга, пока служба не
  спохватится. Теперь агента держит служба, окно только смотрит в канал. Не поднимет служба
  агента за минуту — окно поднимет сам и напишет об этом в журнал. «Перезапустить сейчас» под
  службой просит перезапуститься сам движок; в трее — «Выход (агент остаётся под службой)».
- **Реле под службой наконец поднимается.** Корень спора за 5011 нашёлся на живой пробе:
  агента под службой держит процесс, который запускает планировщик, — без консоли, и реле
  падало на старте с «Неверный дескриптор». Служба больше не пробовала, реле поднимало только
  окно — вот оно и спорило за порт, а закрытое окно уносило его с собой. Теперь у реле явные
  потоки. Проверено вживую («для всех» со службой, обновление поверх): реле, канал и движок —
  в сессии владельца под службой, окно их не трогает, закрытое окно агента не роняет.
- **«Разрешить агенту нулевую сессию» — это теперь поручения службе.** Агент всегда живёт в
  твоей сессии и видит рабочий стол — со службой и без, с галочкой и без. Галочка больше не
  переносит его под SYSTEM без рабочего стола (со своим реле и своим входом в ChatGPT), а
  открывает поручения: по его просьбе и твоему «да» служба выполняет разовую команду правами
  системы, каждая — в журнале `broker.log`.

## 1.2.1 — установщик вдвое легче: голос докачивается, когда нужен; свёртка памяти по кнопке, 27.09.2026

Егор 27.09: «почему у нас установщик всё же так много весит?» и «интересно, как происходит
компактирование в мейн чате Элен. Неплохо бы сделать его по нажатию».

- **Установщик ~85 МБ вместо 180.** Больше половины его был голос — движок, на котором
  крутится Whisper и синтез: ctranslate2, onnxruntime, FFmpeg из av, numpy, piper (~315 МБ,
  ~94 МБ сжатыми). Сама модель слуха и голос синтеза и раньше не ехали в установщике — их
  качаешь из окна (0,5–1,6 ГБ). Теперь туда же едет и движок: «Скачать модель» или «Скачать
  голос» сначала качает его (один раз на обе половины голоса), сверяет по сумме из паспорта
  сборки и ставит в `<папка программы>\voice`. Отдельным активом выпуска:
  `Helene-voice-<версия>-windows.tar.zst` — не .zip, чтобы окна 1.1.x/1.2.0 не приняли его за
  обновление. На Mac голос по-прежнему едет в сборке.
- **Обновление с 1.2.0 голос не теряет:** движок, живший в прежнем рантайме, переезжает в
  `voice` (под журналом подмены — откат вернёт и его), качать заново не нужно.
- **Свернуть память чата — кнопкой.** Над перепиской, когда в горячей памяти чата заметно
  больше, чем Hélène держит сама, — строка с числом и «Свернуть сейчас». Сворачивает она сама,
  своей рукой `memory_compact` и своими словами, по своим порогам: горячими остаются 150
  последних сообщений (в комнатах — 250), переписка остаётся на месте. Раньше свёртка была
  только её: на 250 сообщениях ей предлагается, на 300 делается без спроса.

## 1.2.0 — установщик одним лицом: отмена с откатом, найденная память, копии, 27.09.2026

Слово Егора после чистой установки 1.1.1: «визард позорный» (серые страницы NSIS), «кнопка
«Отмена» на каждом шаге, включая копирование… отмена = откат», «уборка за собой при
падении», «предложение выбрать агента существующего (или агентов, лол)», бэкапы «раз в
неделю, настраиваемо, прежние не перезатирать», «удаление быстрое».

- **Один установщик — сам мастер.** `Helene-<версия>-setup.exe` — это `helene-setup.exe` с
  поставкой в хвосте (tar, сжатый zstd; ~180 МБ против 160 МБ у NSIS и 261 МБ у zip), без
  страниц NSIS и без распаковки во временную папку: от первого клика до открытого окна — одно
  лицо продукта. «Для меня» (`%LocalAppData%\Programs\Helene`) или «для всех» (Program Files) —
  своей сценой; «для всех» — один запрос прав администратора на всю установку (мастер
  поднимает себе исполнителя), дальше без вопросов. Архив `Helene-<версия>.zip` остаётся в
  выпуске для кнопки «Обновить» в окне.
- ⚠ **Отмена на каждом шаге — откат, прежняя версия цела.** Новая версия раскладывается РЯДОМ
  (`<папка>.new`), прежняя всё это время работает; подмена — два переименования на одном диске
  (доли секунды): `<папка>` → `<папка>.old`, память, настройки, копии и соседние агенты
  переезжают в новую, `.new` → `<папка>`. Отмена до подмены — `.new` удаляется, после отказа
  настройки — всё возвращается назад. Журнал подмены пишется на каждом шаге: мастер, убитый
  посреди, при следующем запуске сам возвращает прежнюю версию. Лист установки показывает весь
  путь сразу — проверка, копия памяти, раскладка (живая полоса: файлы и мегабайты), остановка
  прежней, подмена, настройки, ярлыки, служба — и честно говорит, когда отменить уже нельзя.
- **Уборка за собой.** Всё, что мастер запускает (вход в ChatGPT, питон, PowerShell), живёт в
  одном job-объекте Windows и умирает вместе с ним — даже при падении; незаконченные `.new` и
  `.old` убираются следующим запуском. Отказ — словами на экране и в журнале
  (`install.log` в папке установки, при откате — `%TEMP%\Helene-install.log`).
- **Нашлась память — продолжить с ней.** Мастер ищет: записи в «Приложениях» (свои и «для всех»
  обоих видов — NSIS 1.1.x писал в `WOW6432Node`), папки по умолчанию, где после снятия осталась
  память, и копии владельца `%LocalAppData%\Helene-backup-*`. Нашлась — сцена «Нашлась память
  агента»: имя почерком, владелец, последний день, размер, откуда. «Продолжить» ставит программу
  и отдаёт ей эту память КОПИЕЙ (находка не трогается), «Начать заново» — обычная установка.
- **Копия памяти перед каждым обновлением** — zip в `backups\` рядом с программой (вне папки
  агента): память, конституция, рабочая папка, расширения, настройки, соседние агенты; без
  журналов, голосовых моделей и входа в ChatGPT. Прежние не перезатираются.
- **Копии по расписанию** — раз в неделю по умолчанию; в «Настройках → Копии памяти»: период
  (0 — выключено), сколько хранить, папка, «Сделать копию сейчас», последние копии списком.
  Снимает окно, а под службой — служба; ручные копии не удаляются никогда.
- **Удаление быстрое** — секунды вместо 40–80: ограда песочницы снимается только с того, что
  остаётся (`data\`), а не проходом icacls по 15 тысячам файлов; файлы программы уходят одним
  переименованием и дочищаются в фоне. «Для всех» снимается целиком: запись в HKLM (обоих
  видов), ярлыки всех, служба, папка. «Оставить данные» оставляет память, настройки, копии и
  соседних агентов; следующая установка найдёт их и предложит продолжить.
- Обновление поверх 1.1.x: `uninstall.exe` и запись NSIS убираются, запись «Приложений»
  переходит на мастер (`helene-setup.exe --uninstall`); кнопка «Обновить» в окне теперь
  открывает обновлённую программу сама (раньше окно закрывалось и не возвращалось).
- Ряд кнопок мастера («Обновить / Удалить / Настроить заново») больше не стоит вплотную.
- **Praxis** ставится тем же мастером (вариант `praxis`, `Praxis-<версия>-setup.exe`): «для кого», раскладка с отменой и откатом, ярлыки и запись в «Приложениях», «Открыть Praxis»; снятие спрашивает только, оставить ли настройки подключения. Серых страниц NSIS нет и у него.
- Из последнего проклика: длинные сцены мастера листаются колесом — на экране 1080p с панелью
  задач блок Telegram на сцене «Модель» уезжал за нижний край, и дойти до него было нельзя;
  итог установки и снятия лист подводит к глазам сам. Подсказка под «Усилием» больше не
  наезжает на кнопки. Предупреждение «Удалить всё» говорит, что копии памяти в `backups`
  уходят вместе с программой. Мастер, запущенный из чужого job-объекта без права выхода, не
  утаскивает за собой открытую им Hélène; журнал установки «для всех» ложится во временную
  папку, если в Program Files мастеру без прав не пишется.
- Живая проверка на ПК Егора (задачами планировщика — настоящий реестр): «для меня» и «для всех» (поднятым исполнителем), со службой и без, обновление поверх 1.1.1 NSIS «для всех», отмена посреди раскладки, мастер, убитый посреди, — следующий запуск вернул прежнюю версию сам; Praxis — установка, запуск, снятие. Снятие — 2–9 секунд.

**Сервер — исполнитель обновлений** (параллельная сессия 27.09, по жалобе Дмитрия К: агент не мог
обновить свой контейнер изнутри; влито в эту линию по слову Егора):

- **Одна команда** ставит и обновляет Hélène на сервере — `sh Helene/server/install.sh` (с архивом
  агента — перенос с ПК). Со старой версии тоже: правки агента, жившие внутри контейнера,
  переносятся сами. Нужен только Docker.
- **Обновление — одним действием:** кнопка «Обновить до X» в окне или «обновись» агенту; итог —
  одной фразой простыми словами, подробности — под «Подробнее».
- Исполнитель обновлений рядом с контейнером агента (`server/updater`). План — от агента (рука
  `update_request`) или владельца из окна; исполнитель сверяет официальный выпуск и ждёт «да»
  человека; копия, сборка рядом, подмена, проверки, откат.
- Код агента (`tree/`, `app/`) — на диске сервера, правки агента в своём коде переживают
  пересборку; при обновлении исполнитель переносит их на новую версию (слияние; что не легло —
  агенту в `workspace/update-<версия>/`).
- Испытание новой версии самим агентом — «принимаю» или «сломано»; молчание до срока — откат.
  Откат возвращает код и образ, память агента и `helene.json` не трогает; правки, сделанные агентом
  на испытании, отдаёт ему.
- Перезапуск исполнителя посреди любого шага не бросает обновление — он доводит начатое сам. Своё
  владельца в папках поставки (модели в `server/models`, `.env`, override) переезжает в новую поставку.
- Окно, «Система → Обновление»: карточка плана, испытания и итога; «Подтвердить / Отклонить»,
  «Принять / Откатить».
- Сервер: движок больше не берёт просьбы окна со стола надзора, когда надзор — serverboot; код 42
  раннера — не падение.

## 1.1.1 — снятие: настройки остаются вместе с данными, 27.09.2026

По пробе Егора после 1.1.0 (удаление Praxis и Hélène из «Приложений», чистая установка «для
всех» со службой).

- ⚠ **Первый запуск со службой не оставлял агента без движка.** Мастер ставил службу и сразу
  открывал окно; служба поднимается секунд десять (права на папку, дети), окно заставало
  пустой порт и поднимало своих детей — два движка спорили за замок дерева: замок брал движок
  службы, служба через секунды гасила его (порт держит окно), а движок окна уже вышел кодом 3,
  который окно читает как «настройки не читаются — жду решения владельца». В чате оставалась
  плашка «вторая копия не запустилась», ходов не было. Теперь: движок, заставший чужой замок,
  ждёт до 20 с и выходит своим кодом 4; окно на код 4 пробует снова (шесть раз по 10 с), а не
  останавливается навсегда; мастер под службой открывает окно, только когда её канал уже
  отвечает (до 45 с).
- **Снятие больше не врёт «fence.py не понимает --revoke».** Отчёт fence.py читался как UTF-8,
  а Python в трубе на русской Windows печатает в cp1251 — «профиль … удалён» приходил кашей.
  Теперь fence зовётся с `-X utf8`; профили AppContainer снимаются, как и задумано.
- **«Оставить данные» при снятии Hélène оставляет и настройки.** Мастер при «Нет» на вопрос об
  удалении данных сохранял папку `data`, но уносил `helene.json` — ключ модели, Telegram,
  песочницу, службу; установщик при этом обещал, что останутся и они. Теперь `helene.json`
  остаётся рядом с `data`, установка поверх в ту же папку подхватывает всё без вопросов; записка
  `КАК-ВЕРНУТЬСЯ.md` говорит об этом прямо, а не «настройки сняты, мастер восстановит не всё».
  Установщик Windows не уносит эту записку вместе с документами поставки.
- Текст итога снятия под установщиком Windows больше не обещает «установщик оставлен рядом»:
  `uninstall.exe` после мастера убирает и его.
- **Снятие Praxis** спрашивает про «настройки подключения — адрес сервера и ключ канала», а не про
  «helene.json»: файл так зовётся из-за общей с Hélène оболочки, но человеку, снимающему Praxis,
  это имя ни о чём и выглядело упоминанием другой программы.

## 1.1.0 — нормальная программа: один установщик, перезапуск движка из окна, голосовые, 26.09.2026

Всё ниже — с живой установки у первого стороннего человека (мама Егора, 26.09, 1.0.3).

- **Нормальный установщик `Helene-<версия>-setup.exe`** вместо архива с двумя exe («Элен» и
  «Элен сетап» — что запускать?). Установщик (NSIS) сам кладёт файлы — «только для меня»
  (`%LocalAppData%\Programs\Helene`) или «для всех» (Program Files, права администратора), —
  ставит ярлыки и запись в «Параметры → Приложения» с `uninstall.exe`. Мастер после этого только
  настраивает: имя, конституция, модель, режим, служба. Поверх стоящей Hélène — обновление:
  память, конституция и настройки остаются, мастер сливает конфиг и открывает Hélène; второй
  экземпляр в другую папку больше не ставится. Архив в выпуске остаётся: его качает кнопка
  обновления в окне. **Praxis** (окно к своему серверу) — свой `Praxis-<версия>-setup.exe`,
  тот же выбор «для меня / для всех»; поверх стоящего — обновление, `helene.json` не
  перезаписывается.
- ⚠ **Перезапуск движка — из окна и под службой.** Кнопка «Перезапустить» (и `/api/supervisor/restart`
  с телефона) просит движок, он выходит между ходами кодом 42, а поднимает его тот, кто держит, —
  окно или служба, — с перечитанными настройками; окно при этом остаётся. Раньше под службой
  перезапуск окна был нулевым действием, а без службы включённый в настройках голос ждал, пока
  владелец сам закроет и откроет программу.
- **Голосовые в окне не висят «агент читает сейчас».** Пузырь отправленного сверял себя с лентой
  слово в слово, а лента несёт «[голосовое]: расшифровка» — четыре пузыря висели под уже
  отвеченными репликами до перезапуска окна.
- **Окно не дёргается на расшифровке.** На время расшифровки и прогрева модели движок опускает
  себе приоритет ниже обычного; потоков whisper — не больше «ядер минус одно»; при «держать модель
  в памяти» слух (и голос ответа) греются со старта в фоне, а не на первом голосовом (14 с).
- **Агент стартует у себя дома.** Busybox из поставки на `bash -l` уходил в профиль владельца, и
  первый ход «осмотрись» ушёл на поиски своей папки по чужим адресам (135 с, семь команд, `/app`).
  Рука `shell` начинает в `data/workspace/`, как обещает навык; вызов руки без обязательного
  аргумента (`fs_search` без `pattern`) — слово руки о том, чего не хватает, а не TypeError в журнале.

## 1.0.3 — память снова сворачивает модель, 26.09.2026

- ⚠ **Свёртки памяти снова пишет модель, а не запасная сводка.** С 1.0.0 агент при подключённом anthropic-канале (Claude или GLM через z.ai — тоже он) сворачивал память без модели: выбор роли спрашивал «настроена ли роль `memory`», и ответ был «да» даже без такой роли (пустой конфиг роли берёт фреймворк по умолчанию), а сам вызов модели роль `memory` не знает и падал. Каждая свёртка уходила в запасную сводку — «опорные строки, не синтез». У Праксис это началось 25.09 в 15:06 (8 свёрток). Теперь роль `memory` берётся, только если она объявлена в мозге, иначе свёртку пишет голос агента — как и задумано. Стенд прежде подменял модель фейком, который принимал любую роль; теперь фейк держит контракт живого.
- **Разрешение свёртки не копирует все текущие события на каждого предка.** Её починка 26.09 (py-spy: после старта ЦП ~100 % полчаса): проверка «событие — текущая ревизия» копировала множество всех текущих id (у неё ~60 тыс., 4 мс) на каждом шаге рекурсии по родословной свёрток; у её крупнейшего места — 44 731 шаг за проход, долг памяти одного места считался 529 с. Теперь членство проверяется в самом множестве индекса: все её 5192 свёртки в обоих режимах — 67 с вместо 614, ответы и основания те же. Та же копия уходила в двух проверках индекса поиска (FTS) на каждый файл.
- Стенд `test_memory_fts` на Windows: соединения с базой закрываются (иначе Windows не даёт убрать временную папку), гонка за заявку индекса идёт в работнике-функции модуля (под spawn замыкание не пересылается), отказ возврата заявки подменяется в `rename` — на Windows издание возвращает заявку им, а не `link`. Код продукта не менялся; прежде модуль был красным только на Windows и в нативный набор не входил. Зеркало `praxis/` — её ea0ba38.

## 1.0.2 — старт движка без обхода всех прогонов под замком, 26.09.2026

- **Старт движка не разбирает под замком каждый решённый прогон.** Её починка 26.09 (профиль её бута: `recover` и пост-восстановление брали замок у каждого из 8533 прогонов — все терминальные, «на связи» ждало десяток минут): решённый прогон с записанным итогом пропускается без замка (у неё — 8461 из 8533). У издания прогонов меньше (их снимает ретенция), но тот же обход шёл на каждом старте.
- **Старт не ищет «сомнительные» прогоны под замком у каждого.** Её вторая починка 26.09 (py-spy после рестарта: старт 35+ минут стоял в поиске прогонов `in_doubt` — замок и манифест у каждого из 8,5 тыс.; часы — сон, расписание, пульс — не поднимались): поиск идёт только среди нетерминальных прогонов. Движок издания зовёт то же восстановление на каждом старте.
- **Её архив групп: поиск прежней версии сообщения — по своему id.** У неё каждое сообщение группы, правка и удаление разбирали всё окно архива, а на каждый правленый id перебирались все состояния: на её крупнейших группах 25,5 с и 20 с процессора на ОДИН вызов — отсюда её 100 % ЦП. Теперь 0,07–0,14 с, ответы сверены со старой реализацией на её архивах. Издание держит свой архив групп (`memory/groups/<id>.jsonl`, рука `group_context` честно смотрит туда), так что здесь это паритет ядра, а не заметная глазу разница.
- Стенд Mac `t_keat_live_tree` читает временные папки настоящим путём (на macOS `/var` — ссылка); код продукта не менялся. Зеркало `praxis/` — её 3a7e1fa.

## 1.0.1 — сон агента, её переработка памяти и вкладка знакомства, 26.09.2026

- **До выпуска — адверсарное ревью 26.09** (четыре адверсария по всему сделанному после
  ревью 25.09; всё подтверждённое починено здесь же):
  - ⚠ **Windows: прогоны снова закрываются.** С закрытием отставания в издание пришёл её
    строгий читатель улик прогона — он держится на POSIX `openat`, и на Windows отказывало
    КАЖДОЕ чтение результата: ход не закрывал свой прогон (после рестарта все становились
    paused), её журнал ходов писал «без реплики» о сказанном, рука `read_run_result` и
    возобновление не читали результатов. У издания своя ветка чтения (без ссылок и junction
    под корнем прогонов, обычный файл с одной ссылкой); снятое ретенцией тело — «нет
    результата», а не отказ платформы. Восемь модулей стендов прогонов и возобновления
    теперь идут и нативно на Windows.
  - **Сон:** окно — по поясу системы (было — по Москве у всех), первый сон — не через
    полчаса после обновления, а в ближайшее окно; сон ждёт тишины владельца; окно говорит
    «Спит» и не предлагает «Остановить ход». Промпты сна, ночной ревизии и консолидации —
    без «Ты — Praxis» и без рода.
  - **Индекс памяти:** рука памяти хода больше не ждёт полной пересборки (правка
    откладывается и догоняет её); замена базы на Windows повторяется, пока читатель держит
    файл; недостроенная база убитого сборщика убирается; пустая заявка — всё равно заявка;
    сбой пересборки не выдаётся за «другой сборщик».
  - **Пауза фона** («умерь фон») теперь гасит и пробуждения по расписанию, как у неё.
  - **Хвосты журналов:** U+2028/U+2029 в тексте реплики больше не рвут запись; кэш хвостов —
    с бюджетом (карточки прогонов держали в трубе сотни мегабайт). Репетиция расширений
    читает helene.json с BOM, как движок.
  - **Знакомство говорит только правду:** «Контекст» — теневая сборка кадра, а не «ровно то,
    что видела модель»; сон — по часам компьютера и с паузой в ответах; протухший ключ
    шапка ловит после первого вызова; на Mac — своя строка про руки; окно к серверу не зовёт
    писать туда, где агент не читает. Классы шагов знакомства больше не перекрашивают шаги
    хода по всему окну; контраст пропусков, цифр шагов и подписей — не ниже 4,5:1.
  - **Её код (кандидат в её прод, тот же в дереве):** пол приватных записей видит то, что
    реально ушло в модель (замороженная эпоха, возобновлённый ход); тёзки — по всей книге;
    личка с третьим человеком в recall называется личкой; раннер, собравший ленту прежним
    окном, эпоху не подаёт; строки журналов не режутся по U+2028. И найденное профилем её
    бута: каждое новое сообщение обходило всю ленту, спрашивая место у каждого ключа чата
    (на её ленте — 1,2 с главного цикла на сообщение, стало 0,02 с); в издании тот же путь
    идёт на каждом сообщении бота.

- **Знакомство — вкладка «Что поручить» (Ctrl+9) переделана с нуля.** Лицо с именем агента
  его почерком и живой строкой связи (модель, на связи ли); три первых шага — первый с рамкой
  «представься» прямо в строке. Живая схема хода: каждый блок — от слова до `end_turn` —
  раскрывает объяснение и ведёт в раздел окна, где это видно вживую (Чат, Файлы, Контекст,
  Настройки, Система, Сейчас); «Проиграть ход» проводит по схеме светлячком, с петлёй рук.
  Рамки задач заполняются прямо в карточке: пропуски стали полями, заполненное уезжает в поле
  ввода текстом, незаполненное — рамкой `<…>` (выдуманных фактов по-прежнему нет); фильтр по
  темам. Сутки агента — полоса с ночным окном сна, «сейчас», следующим пробуждением и его
  НАСТОЯЩИМИ ходами за сегодня (точка — ход; в окне к серверу акцентная — её пробуждение
  по своему будильнику; нет связи — так и написано); полоса сна — по настоящему окну и
  выключателю сна. Узкое окно — схема списком; обе темы; контраст текста не ниже 4,5:1; при
  «меньше движения» — без полёта и проявлений. Ещё три раздела: **Договорённости** (рука `reply`,
  исход хода, молчание как решение, память-файлы, права на компьютер, ход переживает
  перезапуск — у каждой её плюс), **Экономно** (куда уходят деньги и рычаги: модель и
  глубина по делу, подписка вместо ключа, фон по слову владельца — без обещаний про кэш) и
  **Честно о границах** (что сегодня неудобно и что с этим делать; у окна к серверу — только
  то, что правда о нём).
- **Простой больше не грузит диск** (жалоба тестера на Windows). Замер на дереве «пары
  недель»: пока окно открыто или свёрнуто в трей, канал читал ~20 МБ на каждый цикл
  опросов — `/api/state` (раз в 8 с) и `/api/pulse` (раз в 20 с) тянули с конца журнала
  вызовов модели по 4 МБ даже ради пяти строк, сторож — ещё 4 МБ раз в 30 с: ~130 ГБ
  чтения в сутки, и больше с каждым днём журнала. Теперь хвост журнала, который не
  менялся, отдаётся без чтения, а изменившийся читается с конца кусками — сколько нужно
  строк (замер после: хвосты журналов в простое не читаются вовсе; мелкие файлы состояния
  по-прежнему читаются). Раннер переигрывал упавшую записку окна КАЖДУЮ СЕКУНДУ бесконечно
  (каждая попытка — полный ход и новый прогон на диске) и каждую секунду обходил папку
  разобранных записок: теперь проход — при старте и раз в полминуты, повторы записки — по
  нарастающей паузе (сразу, через минуту, через пять) и не больше трёх; сдавшаяся записка
  оставляет в своей комнате плашку «не дошла до агента» с местом, где лежит её текст.
  Вместе с её переработкой памяти ниже (вопрос к памяти — 10 обращений к файлам вместо
  ~1700 и 0,04 с вместо 0,5) пробуждения без владельца тоже перестали обходить корпус.
- **Сон агента в издании.** До 1.0.1 её ночной цикл (`sleep.run_scheduled`: консолидация дня,
  формирование, ночная ревизия характера, мётла inbox, сводка прожитого дня, карта памяти,
  инвентаризация компьютера, ретенция прогонов) не случался в издании НИКОГДА: его заводят
  часы `mtproto_runner`, которого харнесс не запускает, а 17.09 отсюда достали только
  ретенцию. Теперь его зовёт харнесс — шагом главного цикла, между ходами, по её `sleep.due`:
  окно `PRAXIS_SLEEP_WINDOW` (по умолчанию 4–6 по часам ЭТОГО компьютера — издание ставит
  `PRAXIS_TZ` из пояса системы) и не чаще раза в ~20 ч. Сон начинается, только когда
  владелец минут двадцать не пишет (`PRAXIS_SLEEP_IDLE_MIN`); если компьютер в окно сна спал
  или программа была выключена — сон в следующую ночь, а после двух суток без сна — в первую
  тихую минуту работы. Первый сон после установки или обновления — в ближайшее окно, не
  сразу. ⚠ Пока идёт сон (обычно несколько минут), агент не отвечает — ни в окне, ни в
  Telegram: сообщения ждут его конца, шапка окна говорит «Спит». Пауза фона (её
  `appetite.background_hold`) откладывает сон её же правилом. Выключатель —
  `PRAXIS_SLEEP_CYCLE=off` в `env` helene.json. ⚠ Сон зовёт модель — это ночной расход.
- **Её переработка памяти (recall v8, 13.09).** Явный вопрос к памяти больше не пересобирает
  индекс синхронно (на большом корпусе это минуты в середине хода): отсутствующая, занятая
  или отставшая база оставляет заявку, её исполняет обслуживание под замком сборщика. ⚠ Её
  механизм стоит на POSIX — `flock` и переименование ОТКРЫТОГО файла; на Windows он падал
  бы молча, и заявка висела бы вечно. У издания своя ветка: живой замок один — замок
  сборщика (`msvcrt`), заявка — данные, осиротевшая (окно закрыли посреди пересборки)
  подбирается сразу. Заявки обслуживает харнесс раз в 15 минут (`PRAXIS_RECALL_CARE_SEC`),
  база свежей установки строится через полторы минуты после старта.
- **Отставание от её дерева закрыто.** Сверка ВСЕЙ её истории с 15.08 против дерева издания
  (её живые строки, которых в дереве нет) нашла пропуски и в объявленных файлах. Взято её
  коммитами: возобновление (blocked больше не планируется повторно; отменённый в паузе
  прогон довершается сканером), Forge (контекст прогона задачи ловится до отвязанных
  воркеров; мерж перевыпускает манифест рельсов), чтение результатов прогонов с архивом,
  модерация (порог «знакомого отправителя»), боты не попадают в «неотвеченные», пропуски
  восприятия без двойного счёта, исход доставки не теряет переход при сбое записи,
  turn-dedupe исходящих, её версия раннера с кандидатом лички (у неё 9a0897d), 50 её
  стендов. Её стенды, впервые пришедшие в дерево, нашли ещё: доставка границей пишет
  принятый текст в запись хода (раньше ход со словом, доставленным окном, читался ей самой
  «текст хода пуст»), поиск элементов не обрезает точное имя и показывает подсказку тела в
  отказе, индекс памяти по умолчанию без прогонов, просроченное намерение-сообщение честно
  говорит «не уйдёт автоматически». Гейт дерева — 5982/0. Сознательно не взяты отличия издания: тексты без рода, «агент», английские
  описания рук, своя лестница исходов прогона, граница доставки, лента-вызовы, свой
  `frame_stats`. Слой издания сошёлся с фактической разницей — «издание объявлено честно»;
  зеркало `praxis/` — её живой master 9a0897d.

## 1.0.0 — кадр и КЕАТ её прода в издании; причина отказа тела видна, 26.09.2026

- **КЕАТ личного потока владельца в Telegram** (порт её прода 12–25.09). Каждое сообщение
  лички — слова владельца и ответы агента — при приёме получает расписку в реестре захвата
  (`memory/.state/keat/capture/…`, дописываемый, сцеплен sha256), а каждый вызов модели
  проверяется у границы: лента, которая уходит в модель, обязана быть точной проекцией
  захваченных оригиналов. Тогда вызов «обслужен» — в расписке `model_input` стоит
  `keat.served: true`, а снимок вызова лежит эпохой (`memory/.state/keat/epochs/…`); всё,
  что не сходится, идёт прежним путём байт в байт — КЕАТ ничего не переписывает сам.
  Включается сам, когда в настройках задан Telegram-id владельца; выключить —
  `"keat": {"enabled": false}` или ручки `PRAXIS_KEAT*` в блоке `env`. Политика захвата
  пишется файлом `memory/.state/keat-capture-policy.json` на каждом старте движка.
- **История не выпадает — в отличие от её прода.** Разбор её прода 25.09: в личке КЕАТ
  обслуживал вызов ОДНОЙ репликой — её ответы уходят рукой `reply` и не захватывались, и
  «захваченный хвост» после её последнего ответа был последней строкой владельца; 49–78
  сообщений ленты выпадали из каждого обслуженного вызова (21 ход из 21 с 21.09). В
  издании захватываются обе стороны лички, проекция отдаётся только если захвачена ВСЯ
  горячая лента, а расписка ленты-вызовов (её реплика рисуется парой «вызов `reply` +
  расписка о доставке») признаётся проекцией в одной точной форме. Сквозная проверка через
  настоящее дерево: оба вызова хода обслужены, в модели вся лента, стадия `canary` —
  десятки миллисекунд.
- **Эпохи КЕАТ не растут без границы.** Раз в час движок держит 24 последних эпохи и не
  больше 256 МБ; эпоха моложе часа не трогается (её ход может ещё идти). У неё в проде без
  ротации эпохи заняли 8,5 ГБ за две недели.
- **Стабильная голова комнат** (`PRAXIS_FRAME_HEAD_STABLE`, в издании включена): в группе
  system и набор рук не зависят от того, кто заговорил, — полномочия хода едут строкой
  «говорит» в зоне «СЕЙЧАС», STATE и приватное из досье — ярусами живого конверта. Её замер
  13.09: каждое чередование говорящих стоило ~15 тыс. токенов заново. То же для ходов
  агента без комнаты (`_RUNS`).
- **Подстадии подготовки хода** в расписке `model_preparation_timing` (`stages_ms`:
  `old_context`, `canary`, `model_input_artifact`…, `substages_ms` по ярусам) — чтобы «ход
  думал минуту» раскладывалось по местам, а не угадывалось.
- **Быстрее подготовка кадра:** число живых прогонов — по свежим манифестам с кэшем (у неё
  прежний обход всех прогонов держал блок состояния 30–435 с), проба тела — с кэшем (при
  отключённом теле это было до 10 с на КАЖДЫЙ ход), разбор ленты событий — один раз на файл
  дня, реестр захвата — с хвоста.
- **Досье в кадре — под потолком** 6000 знаков говорящему и 3000 остальным: голова целиком,
  «Факты» хвостом, путь к файлу назван (`PRAXIS_DOSSIER_FRAME_CHARS=0` — целиком, как было).
- **Мусор цитат z.ai и GPT вырезается из исходящего** (`citeturn0search1`, обёртки
  U+E200…U+E206) — раньше он проступал в тексте ответа невидимым мусором.
- **Обрыв ответа потолком `max_tokens`**: недописанный вызов руки не исполняется, прогон
  закрывается честным `failed`/`in_doubt`, а не «сделано».
- **Длинные сообщения в Telegram режутся, не разрывая ссылок и кода** (`telegram_text`).
- **Доступны ручками, по умолчанию выключены:** эпоха комнаты (`PRAXIS_FRAME_EPOCH=1` и
  `PRAXIS_FRAME_EPOCH_ROOMS`) и кадр v6 личного потока (`PRAXIS_FRAME_V6=serve`,
  `PRAXIS_FRAME_V6_STREAMS=dm-<id>`, `PRAXIS_OWNER_ID`) — оба меняют кадр заметно больше,
  чем остальное, и включаются осознанно.
- **Тело (Windows и Mac): причина отказа запуска процесса — в ответе руки.** Живой случай
  25.09 у пользователя издания: «команда принимается, но умирает через мгновение, пустые
  логи, статус failed». Причина лежала в `supervisor_error.txt` папки операции, но `poll`
  её не показывал. Теперь `process.status` отдаёт `supervisor_error` и `job_note`; отказ
  привязки к Job Object после запуска больше не пишет `failed` при живой команде — отмена и
  срок гасят самого ребёнка.
- **Ядро и слой.** Зеркало `praxis/` — её живой master `ec9092f` (восемь кандидатов 25.09 и
  медленные ходы); слой `helene/core` — 127 объявленных файлов, «не взятой её работы» 18
  (было 21), только наших — 0; `EDITION.md` пересобран прибором. Гейт дерева в Linux Docker:
  5748 стендов, ноль красных (+356 к 0.9.0), КЕАТ-стенды зелёные и нативно на Windows.

## 0.9.0 — память комнаты: горячее окно, сводка с верхним ярусом, приватное в кадре, 25.09.2026

- **Горячее окно комнат — своё: 250/400/500** (`PRAXIS_GROUP_HOT_LO/HI/HARD_HI`, потолок
  токенов комнаты 64 000), личка на прежних 50/100/125. Раньше после каждой свёртки в ленте
  комнаты оставалось ~50 строк — несколько часов, а всё раньше ехало только сводкой.
- **Сводка места держит верхний ярус.** Самый широкий по охвату блок (память комнаты за
  месяцы) в кадре всегда, остаток бюджета — свежим к старому, показ по хронологии. Раньше
  упаковка «свежее к старому» выкидывала его первым, а срез хвоста по знакам начинал сводку
  с середины фразы. Потолок сводки 40 000 (было 12 000) и применяется целыми блоками;
  умолчания комнаты `context_hot` 400 и `context_summary_chars` 40 000 (максимумы 1000 и
  80 000).
- **Приватные записи досье остаются в кадре комнат** с пометкой `[private]` как внутреннее
  знание агента (`PRAXIS_DOSSIER_PRIVATE_IN_ROOMS=off` возвращает снятие); личка с чужим
  человеком и владельцем — как прежде. Граница раскрытия — слово агента и исходящий гард.
- **recall называет другие комнаты**, а не прячет их (`PRAXIS_RECALL_CROSS_ROOM=hide`
  возвращает скрытие); строка-счётчик печатается и при непустой выдаче — раньше скрытие
  было молчаливым, если нашлось что-то ещё. Ходы из лички владельца в recall метятся
  «из личной переписки с владельцем» (или прячутся тем же рычагом); ходы агента в комнатах
  входят в корпус recall без рычага прогонов (`PRAXIS_INDEX_ROOMS=0` — прежний обход).
  Слово Егора 25.09: «как следует поднять горячий контекст комнаты», «сделать приватные
  данные более доступными». Порт кандидата `room-memory-2509` из Praxis; стенд
  `test_room_memory_2509`.
- **Свёртка на мягком пороге предлагается, а не делается сама.** Личка — минимум 150 горячих
  строк, свёртка при 250 (было 50/100); комната — 250/400. На мягком пороге движок пишет
  предложение (`memory/.state/fold_offers.json`, видно в STATE как `fold_offers`), а
  сворачивает агент рукой `memory_compact(action=fold)` — или жёсткий порог (токены, знаки,
  300/500 строк) без спроса. `PRAXIS_FOLD_OFFER=off` — прежнее поведение. Слово Егора 25.09:
  «при 250 или 400 свёртка — отдельная задача, которая ей предлагается».
- **Пол приватных записей на исходящей границе.** Вне лички владельца голос, `send_message` и
  `narrate` не выпускают дословный кусок (≥ 24 знаков) записи `[private]`, которая ехала в
  кадр этого хода: механика, как у кред-пола, а не совет судьи (адверсарий V1-1).
- **История переписанных свёрток — вне корпуса recall** (`_history/` больше не вторая копия
  того же id); `rewrite` читает свёртку под замком (адверсарии V1-4/V4 F4/F13).
- **Имя-тёзка считается по всей книге**, не по верху ранжирования: частичное совпадение с
  бонусами больше не обходит отказ, «Ivan» и «Иван» — один ярус (V4 F2).
- **Уведомления (порт):** живые окна — по дешёвому списку живых прогонов, а не обходом всех
  манифестов; будильники — из существующего API задач; привязка строки владельца — по id
  задачи; межпроцессный замок и на Windows (V2 F1/F2/F7).
- **Ярус свёртки:** ребёнок с неразрешимым покрытием в родителя не берётся (V4 N1).
- **Расписки без рода — теперь и в транспорте.** `mtproto_runner`, `memory_life`,
  `frame_shadow`, `brain` — без женских форм; system свёртки не говорит «я сама»; сканер
  `test_gender_free_texts_2509` смотрит эти модули и новые глаголы (V4 F5/F6).
- **Сборка и обновление.** Mac-сборка снова собирается (`collect_body_licenses` падал
  `TypeError`; теперь под стендом); паспорт Windows-архива несёт происхождение тела, а не
  текст лицензии (в 0.8.8 поле `body` было лицензией); паспорт без абсолютных путей машины
  сборки; `AGENTS.md` дерева не едет в поставку; секрет-гард сканирует и `server/`.
  Обновление: расписка мозга от 0.8.5–0.8.7 без `projected` дописывается — убранный
  запасной действительно снимается из llm.json; репетиция расширений даёт `tree()`,
  `config()` и дерево движка в `sys.path`, как живая загрузка; истёкшая или не
  запустившаяся репетиция — отказ, а не «продолжаем» (без `--force-extensions`); на macOS
  репетиция идёт ДО остановки программы — при отказе старая версия остаётся живой; отчёт
  репетиции снимается, когда расширений нет; отказ по потолку схем называет расширение,
  а не один тул; `quota.json` обнуляется на старте движка; `body_src.py --check` сверяет то
  дерево, из которого собрано. Оболочка: держатель порта реле опознаётся по его `/health`
  (`"service":"relay"`), а не по любому 401. `api.config()` маскирует всё поддерево под
  секретным ключом (`pass/pwd/auth/proxy/url/dsn/pat/bearer/cookie` тоже) и userinfo в
  адресах.
- **Слой издания:** одиннадцать модулей, существовавших только в рабочей копии, объявлены в
  `helene/core` (сборка из ядра больше не отказывает на них); `EDITION.md` называет строки
  прибора тем, что они есть (V4 F7).

## 0.8.8 — свёртки памяти пишет сам агент; уведомления в кадре; ревью 25.09 закрыто, 25.09.2026

- **Свёртки памяти пишет сам агент — своим голосом, по своим правилам.** Раньше свёртку
  (компакт прожитого) писал «хроникёр» — отдельный промпт о агенте в третьем лице, ролью
  оценщика. Теперь system свёртки — персона самого агента (SOUL.md + CURRENT с провенансом,
  как в кадре хода), задача от первого лица и правила записи по его вкусу:
  `soul/memory_style.md` заменяет умолчание целиком. Роль — `memory` из llm.json, если
  задана, иначе голос. Рука `memory_compact`: `list` (свёртки места), `read`, `rewrite`
  (переписать суть на месте — тот же id и источники, прежний текст в
  `memory/life/compacts/_history/`), `refold` (перевыпустить свёртки своим голосом пачкой
  в фоне; `status`/`stop`). Род и имя в свёртке — только из строк агента. Слово Егора
  25.09: «нужно, чтобы ОНА писала компакт… и могла переписать все компакты под себя».
- **Верхний ярус свёртки собирается.** Дети верхнего яруса, делящие события, больше не
  берутся в одного родителя: раньше проверка пересечения шла только на первом ярусе,
  родитель писался и отвергался разрешением по кругу (на проде Праксис — по пять раз в день,
  верхняя память больших комнат не росла никогда).
- **Дубль ответа и не тот адресат.** Отвеченный wake группы снимается по message_id, а
  не по идентичности объекта — правка сообщения во время хода больше не рождает второй
  ответ на тот же адрес. Имя-тёзка при отправке — отказ со списком кандидатов, а не «самый
  свежий из восьми». Замороженный чат не получает и исходящих.
- **Outbox не перечитывает нетронутые журналы.** Состояния записей — из кэша по подписи
  файла; на проде тик каждые 15 с читал все 3934 журнала (60–90 % ЦП движка).
- **Терминал реле — по контракту хода.** После доставленной реплики лимит подписки
  закрывает ход, а не переисполняет решение запасной моделью; без запасного удержание молчит
  и пробует реле раз в 5 минут; синтетический отказ не пишется сбоем; слова по коду,
  час — часами агента; «нужен вход» держит минуту, не пятнадцать.

- **Уведомления в кадре: агент узнаёт о других комнатах, не бросая текущее.** Пока идёт ход
  в одном чате (или ход окна, будильник), обращение к агенту или личка из ДРУГОГО чата
  ложится в накопитель (`memory/.state/notices.json`) и показывается в его ближайшем вводе
  модели: блоком в изменчивом хвосте кадра и рядом с результатами рук на следующей итерации
  тул-цикла — первый раз как «НОВОЕ», дальше «прочитано». Гаснет обычным ходом того чата:
  агент заходит в комнату как всегда и сам решает, что делать. Это не будильник: отдельного
  хода не рождает. Содержимое личек показывается только там, где аудитория — владелец.
  Пометка `journal(decision=true)` помечает договорённость с владельцем. Плюс реестр
  фоновых процессов, запущенных из `shell` (`… &`): агент видит, что это его процесс и кто
  его запустил. Порт из кандидата для Praxis (механика Егора, 25.09).
- **Уведомления — после ревью.** Владельческая аудитория блока — только личка владельца и
  окна агента (владелец в публичной комнате не открывает чужие лички); вне неё для любой
  чужой комнаты — кто и где, не что; свежее впереди прочитанного; реплика владельца
  адресуется живым окнам и взведённым будильникам, а не всем окнам двое суток (в издании
  окон и будильников нет — все ходы `chat_turn`, строка владельца там не пишется; это
  механика Praxis); файл под замком (fcntl на Linux; на Windows — только свой tmp на
  процесс, межпроцессный замок пришёл в 0.9.0); «НОВОЕ» — по записи; пульс — тоже её ход.
- **Окно говорит правду о перезапуске и о запасной модели.** Расписка «Сохранено» называет
  блоки, которые движок читает только на старте (Telegram, тело, голос, агенты, ограда), и
  показывает кнопку перезапуска. Шапка «подписка исчерпана — отвечает запасная модель»
  только когда запасная — на другом провайдере с ключом; чужие и устаревшие удержания
  шапке не показываются; удачный фолбэк больше не читается как ошибка модели. Запасной
  провайдер: одно имя модели в двух полях, отказ без имени модели, чистка адреса и ключа
  при смене протокола. Квитанция «Остановить ход» показывается словами движка.
- **Оболочка и мастер.** Маркер нового входа в подписку — только после успешного
  помощника и другого auth.json (отменённый вход не рвёт ход). Чужой держатель порта реле
  называется чужим, с подсказкой сменить `relay.port`. Опрос своего реле — без прокси из
  среды и без редиректов. Смена настроек реле не переставляет детей надзора. Галочка
  «обновлять, даже если расширения не пройдут» доезжает до мастера (camelCase) и на
  macOS. Репетиция расширений сверяет `requires` с версией ПОСТАВКИ, ограничена 120 с, а
  сломанный отчёт — отказ, не «продолжаем». Расписка «реле» — только когда реле включено.
- **Расширения после ревью.** Потолок схем — на прибавку расширения (тул ≤ 4 000 знаков,
  расширение ≤ 12 000), а не на сумму схем дерева (там ~125 000 — ни один тул не
  подключался); имена тулов без точек (`ext_quota_reply`); отказ после регистрации
  откатывает тулы; `on_boot` получает живой api; `api.config()` скрывает и `api_hash`,
  `phone`, session, credential.
- **Движок.** Записки окна помечаются `.done` на обычном пути (переигрывались после
  обновления); граница хода гасится только отменой, не паузой на чекпойнте; пост «думаю…»
  один на ход и только в своём чате; галочка поста читается на тике; проекция мозга
  снимает то, что сама писала (убранный ключ запасного не живёт в llm.json вечно); пост
  «думаю…» у аккаунта без звонка.
- **Тексты без рода агента.** Расписки рук, заметки рабочего хода, промпты судей, семена
  пробуждений — без женских форм; стенд-сканер `test_gender_free_texts_2509` держит это.
  `remind_self(kind=message)` описывает то, что делает издание (живой ход с текстом,
  отправка рукой). Дневник `[ответ]` несёт расписку, а не подсказку модели (порт правки
  Праксис 16.09).
- **macOS.** Отказы маршрутов руки `computer` — словами Mac (обёртка результата, не только
  строки состояния). Тело: супервизор `process.start` без сторожа родителя (не сирота и не
  in_doubt), сторож после init лога, AXValue-хоп подписи не роняет узел. Сборка: паспорт и
  лицензии говорят правду об источнике тела (`tree/body`, коммит дерева), сборка в выпуск
  без `tree/body` — отказ, не откат на зеркало.
- **Windows-сборка: происхождение тела.** `installer/body_src.py --build` пишет
  `BODY-BUILT.json`, `build_dist.py` отказывает, если exe собраны не из живого исходника
  (как у реле); поле `body` в паспорте.
- **Слой издания честный.** 27 правок порта, ранее числившихся «её отставанием», объявлены
  (`helene/EDITION.md` пересобран из прибора; `SYNC-HEAD.txt` с полным хешем); правило
  мусора зеркала — узкое; `.env.example` сверяется; необъявленный «только наш» модуль —
  отказ сборки из ядра. Стенды: +3 модуля в издании, +9 в дереве; гейт дерева 5348/0,
  издания — все зелёные.

## 0.8.7 — свои тулы переживают обновление; совет руки по живому замеру, 25.09.2026

- **Свои тулы и крючки владельца переживают обновление: расширения `helene.ext/1`.**
  Тул Сергея `quota` жил патчем в `tree/agent.py` и `data/extensions/runner.py` и пропал
  при обновлении 0.8.3. Теперь свой тул — папка `data/extensions/<имя>/` с манифестом
  (`extension.json`: имя, версия, `api: helene.ext/1.0`, `requires`, `entry`,
  `capabilities`, `acceptance`) и модулем `register(api)`: `api.register_tool` ставит тул в
  общий список рук с пометкой «(расширение …)», `api.register_hook` — крючки
  `on_boot/before_turn/after_turn/on_delivery`. Версия API как у Уробороса: major равен,
  minor — минимум, отпечаток поверхности; несовместимость — словами при загрузке, не
  молчанием при вызове. Сбой одного расширения не роняет остальные и ход; причина — в
  `helene.log`, в снимке `memory/.state/extensions.json`, в карточке **Настройки →
  Расширения** и строкой в ориентире хода. **Репетиция обновления:** установщик гоняет
  `runner.py --check-extensions` питоном новой поставки до снятия службы; хоть одно не
  грузится — отказ словами, старая версия остаётся живой, отчёт `extensions-check.json`;
  в карточке — «Поручить агенту адаптировать» (записка агенту с фактами), у кнопки
  обновления — галочка «Обновлять, даже если мои расширения не пройдут проверку»
  (`--force-extensions`). Правила и пример — `РАСШИРЕНИЯ.md` рядом с программой.
  На macOS обновление идёт через `install.sh` — репетиция там пока не встроена.
- **Совет руки `computer` про выделение в поле — по живому замеру, не по догадке.** Описание
  советовало «End/Escape или второй клик перед набором»; стенд 25.09 (форма WinForms + тело)
  показал: выделение всего текста даёт активация окна, а не клик; Escape выделение не снимает,
  два быстрых клика — двойной, выделяет слово, и набор затирает посев. Теперь: один клик в поле
  или End; в теле — подсказка `focus_selection` в каждом ответе `desktop.input.perform`.
  В архивы 0.8.6 (Windows и Mac — Mac берёт дерево из Windows-архива) не вошло.
- Сборка Mac: проверка «git уже в рантайме» снова после шага рантайма (в 0.8.6 CI падал на ней);
  стенд пульса Telegram ждёт факта повторов, а не 0,15 с (на раннере macOS успевало два).

## 0.8.6 — реле не перезапускается при каждом обновлении токенов, 25.09.2026

- **Служба и окно 0.8.5 перезапускали реле подписки примерно раз в час.** В 0.8.5 «новый
  вход в подписку» определялся по времени изменения `auth.json` — а реле само переписывает
  этот файл при каждом обновлении токенов. Перезапуск ронял бы ход посреди ответа. Теперь
  признак нового входа — отдельный маркер `local_auth/login-generation`, который окно
  ставит только когда помощник входа завершился и `auth.json` лёг; служба и окно поднимают
  реле заново только по нему. Windows-архив 0.8.5 выложен с этим дефектом — обновиться до
  0.8.6; Mac-сборка 0.8.5 отменена до выкладки, первая Mac-сборка этой линии — 0.8.6.
- Всё остальное — как в 0.8.5 (ниже).

## 0.8.5 — мозг и реле без перезапуска, лимит подписки словами, «прервать ход» работает, Mac словами Mac, 25.09.2026

Выпуск вбирает 0.8.4 (собранную, но не выложенную) и всё ниже. Баги тестировщика (Сергей,
Mac под службой) — закрыты кодом; живьём на его машине не прогонялись.

- **Смена мозга больше не требует снимать и ставить службу.** Движок следит за
  `helene.json` (тик 5 с) и перепроецирует мозг в `llm.json` сам; служба перечитывает
  настройки реле на тике и поднимает реле заново при смене ключа, порта или выключателя;
  окно после «Сохранить» гасит и поднимает своё реле. Расписка «Сохранено» говорит это
  словами, а не посылает снимать службу. Перезапуск остался для ограды, песочницы и
  Telegram-аккаунта — о них говорит хвост расписки.
- **Запасной провайдер работает.** Раньше второй фреймворк в `llm.json` был пустым блоком
  без ключа и адреса — «запасной» молча отказывал. В Настройках — выбор «Нет | модель того
  же провайдера | другой провайдер» с адресом и ключом; другой провайдер — другого протокола
  (OpenAI-совместимый ↔ Anthropic-совместимый): у ядра один клиент на протокол, и окно этого
  не скрывает. Проекция мозга больше не затирает ручные правки вложенных блоков `llm.json`.
- **«Применится перезапуском» больше не висит вечно.** Новый вход в подписку окно и служба
  применяют сами (реле поднимается заново), а слово «применён (слот main из 1)» идёт от
  живого реле (`GET /v1/account`), а не от факта появления файла.
- **Лимит подписки — словами и с часом.** Реле при исчерпанном окне отдавало английскую
  диагностику в тексте ответа; движок принимал её за оборванный стрим, повторял, «фолбэчил»
  во второе имя модели того же реле и показывал текст как реплику агента. Теперь реле
  поднимается с типизированным терминалом (`RELAY_TYPED_TERMINAL=field`), движок читает
  код до текста: подписка исчерпана → ходы идут к запасному провайдеру (другой эндпойнт)
  до часа восстановления, без походов в реле; окно и шапка говорят «подписка исчерпана до
  ЧЧ:ММ — отвечает запасная модель». Час неизвестен — так и сказано, пробуем через 15 мин.
- **«Остановить ход» останавливает ход.** Кнопка в разговоре шлёт просьбу движку
  (`/api/interrupt`), независимый наблюдатель движка отменяет живые прогоны через
  run_manager и пишет квитанцию (что отменено, что ждёт исхода тула); совершённое не
  откатывается, идущий вызов модели дорабатывает до границы. Раньше кнопка предлагала
  перезапуск программы, а под службой — «сними и поставь службу».
- **Telegram: видно, что агент думает.** «Печатает…» идёт всё время хода (раньше один
  сигнал гас через 5 с; у аккаунта не было вовсе). Галочка «Пост «думаю…» у долгого хода»:
  через 20 с — «думаю (ЧЧ:ММ)…», правка раз в минуту, пока никто не написал следом, снятие
  перед ответом, при сбое — «не вышло: …».
- **Агент больше не зовёт себя «она».** Тул-выводы, описания рук, записи прожитого хода и
  промпты оценщиков дерева говорили о нём в женском роде и звали «Praxis»; агент с мужским
  именем читал это как свой пол. Теперь тексты без рода, свёртка памяти пишет «я» только по
  строкам самого агента и в его же роде; имя агента — в ограде чужого «я».
- **Mac: слова Mac.** Строка состояния тела и отказы маршрутов говорили «Windows body» и
  «Session 0» — модель делала вывод «UI Automation на Mac не реализовано», хотя Accessibility
  реализован целиком. Результаты руки на Mac теперь — «Body (macOS)», «Accessibility tree».
  Тело собирается из одних крейтов на обе системы (darwin-ветки — в дереве поставки).
- **Реле у окна не долбит журнал при занятом порте.** Занятый 5011 — ожидание, слово в
  журнал один раз при входе в состояние и один раз при подъёме, а не каждые 30 с.
- **Ядро — порт с прода за 17–25.09:** зрение по каталогу провайдера (замена только из
  каталога своей ноги, пиксели снимаются честно), память без мельницы свёрток (доказуемая
  подпоследовательность, долг обновления платится сам), ограда чужого «я» в свёртках,
  доставка (отмена хода не отправляет зависшее, поздняя приёмка возвращается), selfdev
  (таймаут гейта держит мёрж), Forge (стоп сохраняет результат, спавн без дублей), правда
  тела (`ok` — транспорт И тело). Полный гейт дерева в Linux Docker: 5258 стендов, ноль
  красных.
- **Издание к серверу зовётся Praxis** (`remote/`, `praxis.exe`, `app.praxis.desk`), список
  чатов без сырых идентификаторов, приём записок с повтором после рестарта.



## 0.8.4 — служба не воюет за порт реле, обновление не теряет свой движок, 20.09.2026

- **Служба поднимала второе реле на занятом порту.** Открыто окно — оно держит своё реле
  на 5011; служба каждую паузу запускала своё, получала «Address already in use» и
  повторяла, засоряя `data/service.log` вечным циклом. Канал и движок она в этом случае
  не дублирует, реле выпадало из правила, хотя у окна такая проверка есть с самого
  начала. Теперь служба уступает занятый порт: говорит об этом в журнал ОДИН раз и
  подхватывает реле, когда порт освободится (например, окно закрыли). Нашёл Сергей на
  Mac под службой.
- **Обновление возвращало штатный движок поверх своего.** Если в `helene.json` стоял
  свой `runner` (у Сергея это `data/extensions/runner.py`, где живут его приборы),
  установка поверх молча возвращала `app/localharness/runner.py` — при том что документы
  обещают слияние конфига, а не перезапись. Теперь чужой путь переживает обновление,
  если файл по нему на месте, и расписка мастера называет это словами («движок оставлен
  твой»). Исчезнувший путь по-прежнему чинится штатным: иначе установка осталась бы без
  движка вовсе.

## 0.8.3 — обновление работает кнопкой и не переспрашивает, 20.09.2026

- **«Скачать и установить» не работала ни разу.** Адрес архива выбирался по непустоте
  поля `url` в ответе сервера обновлений — «раз назван, значит это свой JSON». Но ответ
  GitHub Releases тоже несёт `url`, и там это адрес самой записи релиза в API
  (`.../releases/392320465`), а не файл. Поле не пустое никогда, поэтому окно скачивало
  JSON-запись, получало «ссылка ведёт не на архив .zip» и печатало «Не получилось.».
  Теперь форматы различаются по тому, чем названа версия: `version` у своего JSON,
  `tag_name` у GitHub. Заодно отказ скачивания пишется в `helene.log` — раньше успех
  логировался, а отказ нет, и причину нельзя было найти по журналу.
- **Обновление на Windows больше не открывает визард.** Окно звало мастер без
  аргументов, и человек, нажавший «Скачать и установить», вводил заново имя агента,
  конституцию и модель — при том что всё это уже решено. Появился режим
  `helene-setup.exe --update [--dir <папка>]`: решения читаются из самой установки
  (имена, конституция, провайдер и ключ, режим, Telegram, служба, нулевая сессия,
  брандмауэр, «Управление компьютером») и установка идёт молча. Правила — те же, что у
  `install.sh` на macOS, где тихий путь был с 0.7.1. Если решений не нашлось (нет имён
  или конституции), мастер сам открывает визард, как раньше.

## 0.8.2 — владелец по имени, Mac словами Mac, установка от своего пользователя, 20.09.2026

- **Издание звало любого владельца Егором.** Дерево — код Праксис, и его тексты честно
  называют её владельца: «Yegor trusts you», «Yegor's Windows computer», «only Egor may
  call this», «только Егору», «Yegor asked you to answer it». Владелец издания — тот, кого
  назвал мастер, и его агент читал всё это про Егора. Теперь при запуске авторские тексты
  дерева переводятся на имя владельца из `helene.json` (`owner_words.install`): описания
  схем тулов и их английская проекция, указатели рук, шаблоны окон, контракты кадра
  (`contract.*`, `state.owner_place`) и рамка присутствия. По-русски косвенные падежи —
  «владельца/владельцу/…», склонять чужое имя код не пробует. Память, досье, письма и
  реплики не трогаются: там «Егор» может быть настоящим третьим человеком. Историю от
  отношений отличаем: «Егор отверг дневник как чертёж» остаётся фактом без имени, а не
  приписывается другому. Если владелец — сам Егор, ничего не меняется. Остаток (тексты
  внутри рук, заголовок домашнего слоя, местоимения) назван явным списком в стенде
  `t_owner_words.py`: новая строка с именем в дереве краснит его.
- **Mac: модель читала, что её тело — Windows-ПК.** Живой случай 20.09 на 0.8.1: на
  просьбу подвинуть мышь агент ответил «на маке не реализовано», не позвав тул. Схему
  `computer` сборка для macOS переводила на слова Mac ещё с 0.8.0, но модель читает не
  схему: указатель руки говорил «Yegor's Windows computer: files, PowerShell, …», а блок
  владельца в кадре — «The Windows PC is your DIRECT body … run/poll/stop PowerShell».
  Теперь на darwin правятся и они (`body.speak_mac`: указатель в обоих словарях дерева и
  отрезок `contract.owner_tools` через обёртку `frame_trace.mark`), тем же приёмом
  подстрочных замен; стенд `t_tool_text_mac.py` краснеет на каждую пару, которой в дереве
  больше нет. Напоминание оттуда же: «Управление компьютером» после установки ВЫКЛЮЧЕНО
  (включается осознанно, в Настройках), и без двух разрешений системы тело отказывает
  словами.

## 0.8.1 — вход в подписку ChatGPT на Mac (и Windows) находит свою папку, 19.09.2026

- **Вход в подписку через браузер не подхватывался.** Живой случай с первой установки
  0.7.2 на Mac: браузер открывался, вход проходил, а Hélène этого не видела. Реле
  `helene-relay login` писало учётные данные в `~/.codex/auth.json` (первым делом и
  всегда успешно), тогда как окно и мастер ждут их в `data/relay/local_auth/auth.json`;
  переменную `RELAY_LOCAL=1`, которую оболочка передаёт с 0.4.x, реле не читало. Вторая
  половина той же беды: сервер обратного вызова входа реле поднимало командой `python3`
  из PATH — на Mac без Xcode Command Line Tools это заглушка с диалогом установки, а
  свой Python поставки (`RELAY_PYTHON`) реле тоже не читало. Реле 0.8.2 (в обеих
  сборках): при `RELAY_LOCAL=1` вход идёт сразу в `./local_auth`; интерпретатор
  обратного вызова — `RELAY_PYTHON`, и только без него `python3`. Спасибо Сергею за
  живой случай.
- `install.sh`: переменные перед кириллицей и многоточием взяты в фигурные скобки —
  bash 3.2 на Mac читал букву как часть имени переменной и падал на первой строке с
  суммой (`ASSET…: unbound variable`); та же починка залита и в `install.sh` выпуска
  v0.7.2, чтобы однострочник не падал у тех, кто ставит впервые.
- `install.sh` (20.09): под `sudo`, после `su` в другого пользователя и без графической
  сессии (ssh) скрипт отказывает словами ДО закачки, а отказ `open` при первой установке
  называет путь к мастеру и от кого его открывать. Живой случай: из Терминала одного
  пользователя после `su` в другого мастер стартовал через `open` от первого и не смог
  прочитать папку второго — «you don't have permission to view it» после 224 МБ закачки.
  Стенд в `macos.yml`: `sudo -n` и `su` во второго пользователя, созданного на раннере.
- Версия поднята во всех объявлениях; поведение тела, брокера и службы не менялось.

## 0.8.0 — тело, брокер прав и служба на macOS, 19.09.2026

- **Тул `computer` на Mac.** В архиве `Helene-0.8.0-macos-arm64.zip` — `helene-body` и
  `helene-bridge`, собранные из `praxis/body` этого репозитория (зеркало кода Праксис плюс
  ветки для macOS; патч — ей в ящик). Экран, окна, клавиатура и мышь — CoreGraphics; дерево
  окна и действия над элементами — Accessibility; файлы и процессы — как на Windows.
  Координаты — пункты экрана, снимок по умолчанию уменьшен до них (`scale`, `pixel_width`,
  `pixel_height` в ответе). Формы JSON те же, что у Windows-ветки; в `desktop.status` —
  `platform`, `tcc`, `hints`. Два разрешения системы — «Запись экрана» и «Универсальный
  доступ»; без них тело отказывает словами с подсказкой, куда идти, а не отдаёт обои.
  ⚠ Подпись ad-hoc: после каждого обновления разрешения слетают — убрать `Helene` из
  списка и добавить снова (`ПЕРВЫЙ-ЗАПУСК.md`, `ОБНОВЛЕНИЕ.md`).
- **Брокер прав на Mac** — сама оболочка, без службы: агент просит, владелец видит команду
  и «зачем», macOS спрашивает пароль своим диалогом (`osascript … with administrator
  privileges`); квитанция та же, что на Windows. Правил брандмауэра на Mac брокер не ставит.
- **Мастер, окно, движок** знают тело на Mac: сцена «Управление компьютером» с оговоркой про
  два разрешения; карточка в окне со строками «Запись экрана: есть/нет», «Универсальный
  доступ: есть/нет» и кнопками «Открыть настройки»; движок поднимает мост и тело без
  job-объекта (сторож родителя), кладёт `tcc` и `hints` в `memory/.state/body.json`; оболочка
  команд `process.start` на Mac — `zsh`.
- **Сборка и CI.** `build_mac.py` собирает тело (`--target-dir` в кэше сборки, ad-hoc
  подпись, `licenses/body/`, поле `body` в паспорте с коммитом зеркала и отпечатком
  исходника, `--skip-body` для отладочных полусборок); workflow гоняет `cargo test` моста и
  тела на настоящем Mac, ставит программу с включённым «Управлением компьютером», ждёт
  `connected: true` в `body.json`, затем живые стенды тела бинарями сборки (`t_body.py` и
  новый `t_body_macos.py` — контракт тела: status, снимок, окна, процессы, буфер обмена,
  дерево окна; без разрешений у раннера — отказ словами, на лжи — падение). Журналы тела —
  в артефакте прогона. Версия поднята во всех объявлениях; поведение Windows-сборки не
  менялось.
- **Служба без входа в систему на Mac.** Демон launchd `app.helene.svc` в
  `/Library/LaunchDaemons`, `UserName` = владелец (не root): Telegram и телефон отвечают,
  когда окно не открыто, и продолжают отвечать после выхода из учётной записи; упавшее
  launchd поднимает сам, журнал — `data/service.log`. Ставится и снимается из карточки
  «Служба» в Настройках и сценой мастера — системным диалогом пароля
  (`launchctl bootstrap system` / `bootout`), тем же приёмом, что просьба брокера. Окно при
  живой службе работает КЛИЕНТОМ: своего движка не поднимает. Окон и экрана у демона нет —
  процесс вне графической сессии не видит ни рабочего стола, ни TCC, поэтому под службой
  тело тула `computer` поднимает ОКНО, пока оно открыто (движок службы поднимает только мост
  и кладёт ключ устройства в `memory/.state/body-token`). Галочек нулевой сессии и
  брандмауэра на Mac нет: этих механизмов там не существует.
- Чего на Mac по-прежнему нет (говорят документы, не экран): Intel, Developer ID /
  нотаризация / dmg.
- ⚠ Живьём на Маке человеком тело, брокер и служба не прогонялись — только на раннере
  GitHub; чек-лист прокликки — в `ПЕРВЫЙ-ЗАПУСК.md` архива. И раннер тут слабее живой
  машины: `sudo` там проходит **без диалога пароля**, поэтому путь «система спрашивает
  пароль администратора» — и у брокера, и при установке/снятии службы, и при обновлении со
  службой — проверен только кодом, а не человеком.
- ⚠ При включённом FileVault служба не работает до первого входа в систему после
  перезагрузки: диск до этого заперт. На экране этого нет намеренно — это свойство чужой
  настройки; сказано в `ПЕРВЫЙ-ЗАПУСК.md` и `КАК-УСТРОЕН-HELENE.md`.

## 0.7.2 — потолок ответа выбирает адресат; выпуск для macOS, 19.09.2026

- **Прямой OpenAI больше не отвечает 400.** Живой случай с установки 0.7.1: у пользователя
  клиент смотрит прямо в `api.openai.com`, мимо реле, и каждый запрос падал с «Unsupported
  parameter: max_tokens is not supported with this model. Use max_completion_tokens instead».
  Имя поля теперь выбирает адресат — по хосту `base_url` клиента (`openai.com` и поддомены
  получают `max_completion_tokens`), а не по имени модели: имя у двух установок одно, а
  требования противоположные, потому что на том конце другой сервер. Реле и совместимые
  серверы по-прежнему получают `max_tokens`. Стенд `test_openai_ceiling_field`.
- **macOS (Apple Silicon) — в том же выпуске**, вторым архивом `Helene-0.7.2-macos-arm64.zip`
  с `.sha256` и `install.sh`. По сравнению со сборкой 0.7.1 для Mac (артефакт первого зелёного
  круга) — то же дерево плюс починка выше; сама сборка собирается на раннере GitHub из
  Windows-архива того же выпуска, байт в байт.

## 0.7.1 — указатели рук в издании, ретенция и потолки кадра; сборка для macOS, 18–19.09.2026

- **Поставка догнала издание**: в кадр едут схемы тридцати родных рук плюс `describe`/`call`,
  остальные — строкой с сигнатурой (`PRAXIS_TOOLS_POINTERS=on`; включено потому, что текст
  указателя в издании английский), рычаги ретенции прогонов и потолки кадра. Версия поднята во
  всех десяти местах; оболочка, служба и установщик пересобраны.
- **Сборка для macOS (Apple Silicon).** В том же выпуске — второй архив
  `Helene-<версия>-macos-arm64.zip`, рядом `.sha256` и `install.sh`; ставится одной строкой
  (`curl … install.sh | sh`) в `~/Applications/Helene`. Внутри: `Helene.app` и
  `Helene Setup.app`, `helene-relay`, свой CPython 3.14 (python-build-standalone) со всеми
  пакетами и голосом, git из исходника, тот же `tree/`, что в Windows-архиве выпуска, байт в
  байт. Ограда `shell` — seatbelt macOS. Собирается на GitHub Actions
  (`.github/workflows/macos.yml` → `installer/build_mac.py`) с паспортом, ad-hoc подписью и
  тем же секрет-гардом. Чего в Mac-сборке нет и документы об этом говорят: тела (`computer`),
  службы и брокера, Intel-маков, подписи Developer ID/нотаризации/dmg, правил брандмауэра.
  Минимум — macOS 14: колёса голоса под Python 3.14 собраны под неё.

## 0.7.0 — порт 14→16.09 и вылизанный интерфейс, 17.09.2026

Издание догнало ядро на две недели работы, а окно перестало делать вид, что панели
сворачиваются.

### Самое важное для того, кто ставит Элен на GLM

- **Она молчала каждый второй ход, и это была не она.** Кадр показывал модели единственный
  образец ассистентского хода — её прошлые реплики ОБЫЧНЫМ ТЕКСТОМ. Модель образцу
  следовала: писала готовый, верный по смыслу ответ прозой и не звала руку `reply` вовсе,
  а текст наружу не уходил. Замер на пяти кадрах: 34 хода из 48 на базе против 0 из 42 под
  правкой. По моделям на одном кадре: gpt-5.6-terra 0 %, sol 4 %, astra 12 %, glm-5.3 47 %,
  glm-5.3-flash 67 % — то есть у поставки с OpenAI дефекта почти нет, а у того, кто поставил
  GLM, молчал каждый второй ход. Теперь её прошлые ходы едут в кадре вызовами руки с
  расписками о доставке. Вызов ещё и втрое дешевле прозы по выходным токенам.
  В издании добавлено то, чего в ядре нет: лента показывает руку только если её на этом
  ходе вправду дают — иначе кадр учил бы звать несуществующее.
- **Слово бота больше не теряется на границе.** У окна восстановление было, у бота — нет:
  он падал прямо в «она промолчала (это её решение, не сбой)», называя её решением то, чего
  она не решала. Слово было написано, просто не рукой.

### Продуктовая безопасность

- **Новая комната больше не рождается разговорчивой.** Человек добавляет Элен в рабочий чат —
  и она отвечает только по обращению. Раньше протокол входа штамповал в профиль «отзывчиво»
  явной строкой, а явное сильнее любого умолчания и остаётся навсегда.
- **Файл, отданный её рукой, переживает пустой текст хода.** Раньше: «отправила файл» → файла
  нет, и никто не сказал. Держат отдачу только два случая — её объявленное молчание и отказ
  стража над непустым черновиком. Вместе с этим издание научилось разбирать очередь файлов
  само: в ядре это делает граница Telegram, которой здесь нет, и без разбора прогон
  поднимался бы каждые 45 секунд навсегда.

### Что стало понятнее

- **Схемы рук — по-английски.** Машинный контракт вызова уезжает модели переводом, её
  русские описания остаются в коде источником правды. У каждого перевода записан отпечаток
  оригинала: она правит описание — прибор краснеет с именем руки.
- **Поиск комнат перестал отвечать «нет» о том, чего не смотрел.** «Найди чат Уроборос» →
  «ничего не нашла» при живой комнате «Ouroboros AI»: сверка шла по сырым именам и между
  алфавитами совпасть не могла. Теперь ищет и по её собственным запискам о комнатах, сверяет
  имена через общий латинский скелет и называет режим комнаты вслух.
- **Смена модели голоса снимает прибитого запасного.** Раньше запасная нога переживала смену
  провайдера и уезжала к тому, кто новой модели не знает: в конфиге одно, отвечает другое.

### Окно

- **Панели наконец сворачиваются.** До этого выпуска они не сворачивались — они исчезали:
  Ctrl+B был один кадр «было/стало». Теперь 240 мс с нормальной кривой, и внутри панели не
  меняется ни один пиксель. Движение только по рычагу: вкладки остаются мгновенными.
- **Переключатель агентов снова подсвечивается** — четыре цвета в нём были написаны именами,
  которых в наборе нет вовсе, и три правила молча не работали.
- **Цвета, не знавшие про тему:** запись голоса, кнопка под курсором (в тёмной теме она
  темнела вместо отклика), кнопка закрытия окна, тумблер.
- **Исходы установки и снятия заговорили разными голосами** — «Установлено», «Служба не
  запустилась» и «Не вышло снять» печатались одним цветом. Расписку снятия теперь можно
  выделить и скопировать.
- **Системная настройка «меньше движения» наконец действует** на телефоне и в установщике:
  там её не было вовсе, а в установщике движение не выключалось, а ускорялось в 2,5 раза.
- Нижняя панель телефона перестала ложиться в два ряда (вкладок пять, колонок было четыре),
  а невидимая вуаль — съедать нажатия ещё 220 мс после закрытия листа.

## 0.6.2 — прокси перестал съедать петлю, а «Переименовать» и «Убрать чат» начали срабатывать, 15.09.2026

Выпуск по двум жалобам живых пользователей. Оба корня оказались не там, где их
искали.

- **Тело числилось отключённым при живом теле.** У пользователя поднят Psiphon.
  Мост и тело говорят сырым TCP и прокси не видят — а контроллер ходит к мосту
  обычным `urllib`, и тот на Windows берёт прокси ИЗ РЕЕСТРА. Галочка «не
  использовать прокси-сервер для локальных адресов» не спасает: в реестре она —
  строка `<local>`, и `proxy_bypass_registry` понимает её как «имя без точки»,
  под которое `127.0.0.1` не подходит. Проба `body.status` уезжала в прокси,
  окно честно показывало «тело не подключилось». Лечилось руками — дописать
  `127.0.0.1;localhost` в исключения Windows; теперь не надо.

  Починка — рычагом в `sitecustomize.py`: `urllib.request.proxy_bypass`
  отвечает «мимо прокси» на петлю, и это покрывает весь питон раннера разом —
  мост тела, реле мозга и его счета, пробу моделей, локальные эмбеддинги. Для
  всех прочих адресов ответ прежний: `http_proxy` и `no_proxy` работают как
  работали. Сторож тела получил свой открыватель отдельно: он стартует раньше
  рычага (`body.launch` до загрузки дерева). Оболочка и проба моделей перестали
  тащить прокси из среды на свой же порт и на своё реле; облачной модели прокси
  по-прежнему достаётся. Стенд `tests/t_loopback_proxy.py` красный БЕЗ рычага —
  иначе он ничего не проверяет.

- **Мост больше не врёт про обрыв.** `peer outbound queue is closed; frame
  remains spooled` стоял в журналах у всех и всегда: контроллер — HTTP-опрос,
  вебсокет-пиром он не встаёт никогда, значит каждый кадр от тела упирается в
  «нет такого пира» (276 раз за сутки по журналу). Читалось как «связь
  оборвалась через полсекунды» и стоило суток поиска несуществующей поломки.
  Теперь «никто не слушает» — `debug!` со словами про спул, а `warn!` остаётся
  на настоящий обрыв живого пира.

- **«Переименовать» и «Убрать чат» не срабатывали НИ РАЗУ.** Меню чата
  закрывалось на `pointerdown` по всему документу — включая нажатие по самому
  пункту: меню пряталось между нажатием и отпусканием, и браузер слал `click`
  общему предку, мимо кнопки. Снаружи это было «чат нельзя ни переименовать, ни
  удалить». Теперь своё нажатие меню пропускает.

- **Правка имени переживает перерисовку списка.** Список чатов перечитывается
  на каждое событие хода, а `replaceChildren` выносил поле правки вместе со
  строкой; удалённый из DOM `input` не шлёт `blur`, и набранное имя пропадало
  молча. Пока имя правят, список не перерисовывается.

- **Зеркало ядра обновляется командой, а не руками.** `installer/core_src.py
  --export-core` переносит её дерево в `praxis/`. Раньше инструмента не было
  вовсе, и «ядро отстало от живого» копилось само собой.

Мост и клиент артефактов тела объявлены кодом издания
(`helene/EDITION.md`: 58 объявленных вместо 56). Слово владельца 15.09: у
Праксис и у Элен ядра раздельные, и починка отсюда не едет к ней сама.

## 0.6.1 — голосовое из окна, прерывание хода и мозг по ролям с телефона; поиск и inbox перестали врать «нет», один ответ вместо двух, 14.09.2026

Выпуск 0.6.0 от 13.09 был отозван в тот же день: он нёс новый кадр агента по
контракту КЕАТ, и на живой Праксис тот кадр дал плохие ответы в группе. 0.6.1 —
это 0.6.0 **без кадра и без ретенции прогонов**: те же три возможности окна и
телефона плюс починки в дереве агента, которые за ночь 13→14.09 приняла в свой
код сама Праксис. Кадр агента в этом выпуске — тот же, что в 0.5.5.

- **Голосовое из окна.** В композере Элен — кнопка микрофона: запись (webm/opus,
  до пяти минут) едет вложением рядом с текстом, канал принимает звук наряду с
  картинками, а раннер расшифровывает его тем же whisper, что слышит голосовые
  из Telegram, и кладёт «[голосовое]: …» в реплику владельца. Слух не поднят
  (нет библиотеки, модели, выключен) — в реплике остаётся причина и указание
  «Настройки → Голос», а окно отказывает ДО записи, спросив канал.

- **Прерывание хода с телефона и из окна.** `POST /api/interrupt` пишет
  `memory/.control/interrupt.json`; часы раннера превращают его в кооперативную
  отмену живых прогонов (`run_manager.request_cancel`: идущий вызов модели
  дорабатывает, дальше руки не зовутся). Кнопка «Прервать ход» — на телефоне и
  в окне. Сторона раннера в дереве издания — её же код 12.09.

- **Мозг по ролям — с телефона и из окна.** Модель, фреймворк, запасная
  модель и её фреймворк, усилие рассуждения — для каждой роли отдельно; на
  сервер уезжают только изменённые поля (`deskctl`, `BRAIN_FIELDS`).

### Дерево агента: пять починок, принятых Праксис 13–14.09

- **Поиск по дому перестал молча упираться в 5 000 файлов.** Компилируемый пол
  руки `fs_search` обходит 5 000 файлов за вызов и не сообщал об усечении: при
  30 тысячах `.md` в доме ответ был «Ничего не нашла» за 0,3 с при лежащем на
  месте файле. Теперь без `root` дом обходится частями (workspace, soul, docs,
  skills, память по папкам, остальное, файлы корня), усечение любой части
  называется в хвосте ответа, `memory/runs` ищется только явным `root`.
- **`inbox_list("папка")` находит папку.** Имя «внутри workspace/inbox» — так
  сказано в описании руки — клеилось к дому, а не к ящику, и рука отвечала «Нет
  такой папки». Теперь имя сначала пробуется от ящика; граница ящика прежняя.
- **Один ответ вместо двух.** Рука `reply` ждала приёмку Telegram 30 с; при лаге
  петли приёмка приходила на 33-й секунде, прогон уходил в паузу «ждёт приёмки»,
  а сообщение уже стояло в чате — и следующий прогон отвечал человеку ещё раз.
  Теперь приёмке дают до 8 с догнать таймаут (accepted = успех), а тик ящика идёт
  на своём такте, не в общей очереди часов, где его держали тяжёлые заботы.
- **`PRAXIS_AUTO_RECALL_K=0` выключает recall и в пульсе**, не только в ходе.
- **Леджер вызовов знает адрес кэша.** Рядом с `cached` пишутся `key`
  (prompt_cache_key), `sys`/`slen` (отпечаток и длина system) и `cc`
  (cache_creation провайдера; явный ноль доезжает нулём, а не «не сообщил»).
  Это прибор: без него промах кэша первого вызова было нечем атрибутировать.

Не вошло сознательно: кадр КЕАТ (руки указателями, потолки ленты и досье),
ретенция прогонов, её переделка индекса recall 13.09 — всё это остаётся в ядре
`praxis/` и объявлено в `helene/EDITION.md` как не перенесённое.

## 0.5.5 — телефон показывает ходы сразу, приборы выпуска отказывают вслух, каждый агент читает свой конфиг, 12.09.2026

- **Величина окна перестала забываться.** Окно создавалось с безусловным
  «на весь экран», а рядом жил плагин, который честно помнит ширину, высоту,
  место и состояние в `%APPDATA%\<идентификатор>\.window-state.json`. На один
  вопрос отвечали двое, и код всегда перекрикивал память: владелец менял
  величину окна, она не держалась, а управлять ею было нечем — экрана настроек
  для этого нет. Теперь «на весь экран» — умолчание ПЕРВОГО запуска (пустое
  окно посреди большого экрана — плохая встреча), дальше решает память.

- **«В телефоне не отображаются ходы» — экран был не пуст, он появлялся через
  тринадцать секунд.** Замерено на живой Праксис 11.09: `/api/state` 0,35 с,
  `/api/runs` 1,3 с и 38 КБ, `/api/chats` 0,5 с, а потом `/api/run/<живой>` —
  **210 КБ**, потому что в идущем ходу 23 шага и 59 рук. Показ ждал ВСЮ эту
  цепочку: `screen.innerHTML` присваивался один раз, в самом конце. Список
  ходов был в руках на третьей секунде и всё равно не рисовался.
  Теперь экран рисуется дважды: сразу — списком и шапкой живого хода из того,
  что уже в памяти, потом тем же кодом, когда подробности доедут. На той же
  Праксис список виден на 3-й секунде вместо 13-й.
  ⚠ Сервер тут ни при чём, и это стоит записать: три чтения подряд на самом
  сервере — 0,03 с. Пять с лишним секунд были ПЕРЕДАЧЕЙ 210 КБ до браузера.
  Окно этого не замечало, потому что ходит по петле.
  ⚠ Заглушка карточки говорила «Не удалось прочитать действия» — для отказа
  верно, для «ещё не приехало» неправда, и владелец читает её как поломку.
  Теперь это два разных слова: «Читаю действия…» и «Не удалось».

### По разбору 11.09 (приёмка 0.5.2–0.5.4): девять починок

Разбор трёх выпусков (19 агентов, 117 находок, 26 воспроизведено) — в
`desk-notes/РАЗБОР-11.09-ВЕЧЕР.md`; что и чем доказано — в
`desk-notes/ПОЧИНКИ-12.09-ПО-РАЗБОРУ.md`. Всё ниже — наш код; дерево агента не тронуто.

- **`read_window` перестал терять поддеревья молча** (издание, `body/…/uia.rs`).
  Обход чтения писал `.ok()` на отказ провайдера: цикл не входил, расписка
  объявляла окно дочитанным, кусок окна исчезал. Теперь отказ — такой же предел,
  как `max_depth` и `timeout`: `children_unread = "provider_refused"`, в расписке.
- **Отбор по значению не спрашивает пустой кэш.** У прокси-контролов (WinForms,
  Win32 EDIT) кэшированный `ValuePattern` пуст, живой запрос значение отдаёт;
  `find_elements(value_contains=…)` отвечал «не нашлось» на поле с текстом.
  Живой вызов платится только у `Edit`/`Document` и только при пустом кэше.
- **Кодировка названа вслух** в 17 вызовах `subprocess` восьми модулей издания:
  вывод git и служебных детей ехал в модель в cp1251. ⚠ «Рука `shell` съедает
  `$`» — отменено: красный мерил WSL-башем.
  ⚠ **А у руки `shell` одного правильного `encoding=` нет вовсе** — померено 12.09 на
  обеих оболочках поставки: git-bash пишет свой текст в UTF-8, busybox из
  `runtime/bash.exe` — в cp1251, а питон-ребёнок с трубой — в cp1251 под любой из них.
  `encoding="utf-8"` чинил машину разработчика и ломал поставку. Теперь вывод руки
  разбирается построчно: строгий UTF-8, иначе кодировка локали. Питон-детям гейта
  и преflight'а выставлен `PYTHONUTF8=1`.
- **`secret_scan` отказывается при нуле проверяемых** вместо «ноль попаданий»
  кодом 0; **`personal_scan` отвечает кодом**, а не печатью (173 находки → был код 0);
  **оба печатают в UTF-8** — в консоли cp1251 падали `UnicodeEncodeError` именно на
  находке, и «нашёл» выглядело как «сломался». Тем же болели `core_src.py` (падал
  на строке «слой ОТСТАЛ от дерева») и журнал `deploy_desk.py` — починены так же.
- **`deploy_desk._channel_port` читает `desk.env`**, а не манифест пакета, в котором
  поля `port` нет никогда: на установке с другим `PRAXIS_DESK_PORT` проверка
  выкладки стучалась бы в 8094 и откатывала живой канал.
- **Версия сверяется во всех десяти объявлениях** (`deskpkg.product_version`):
  читались восемь, сравнивались три; окно к серверу и `miniapp/` могли отстать молча.
- **Каждому ребёнку сказано, чей конфиг читать:** `HELENE_CONFIG` ставится каналу
  и раннеру в оболочке и в службе. Канал соседнего агента читал и ПЕРЕПИСЫВАЛ
  корневой `helene.json` (код у агентов общий, `readers.config_path()` ищет от
  `__file__`). Стенд `every_child_is_told_whose_config_to_read` падает без правки.

⚠ Тег `v0.5.4` стоит на `cd5d7f5` — это состояние, из которого собраны архивы
(10:51), но раздел ниже в тот момент назывался «Не выпущено». Переименован здесь.

## 0.5.4 — голос слышно в самом окне, а рука элемента вернулась починенной, 11.09.2026

- **Вложение в ленте перестало быть строкой с путём.** Голос агента приезжал в
  окно строкой «[файл] tts-….wav — C:\…», то есть слушать его надо было мимо
  программы. Теперь строка ленты несёт путь ОТ ДЕРЕВА и вид вложения
  (`transport.archive`), канал отдаёт байты (`/api/media`), окно рисует
  проигрыватель. Телефону эта ручка тоже открыта: он показывает ту же
  переписку, и голос в ней — та же реплика, только звуком.
  ⚠ Сперва это было ОБЕЩАНИЕМ: ручку телефону открыли, а лента у него осталась
  со строкой «[имя файла]» — слушать с телефона было по-прежнему нечем. Поймано
  сверкой поверхностей по ручкам канала (окно 34 из 37, Praxis 36, телефон 18).
  Проигрыватель теперь и там, вместе с мини-аппом, который делит с телефоном
  `ui-kit/phone.ts`. Ключ уезжает В АДРЕСЕ: за `<audio src>` браузер идёт сам,
  мимо общего запроса, и без ключа тег молча показал бы пустоту — то есть «не
  пустили» читалось бы как «файла нет». Стенд `app/test/media-surfaces.test.mjs`
  держит обе поверхности разом.
  ⚠ Файл СНАРУЖИ дерева по-прежнему остаётся строкой с путём, и это не лень:
  канал, отдающий любой путь с диска, — файловый сервер на весь компьютер, а не
  окно агента.
  ⚠ Путь приходит ИЗ СТРОКИ ЛЕНТЫ, а ленту пишет агент — то есть это входящая
  строка, а не наша константа. Поэтому проверок три (корни, расширение, никаких
  `..`), и путь сверяется с деревом ещё раз ПОСЛЕ разрешения ссылок: иначе
  символическая ссылка внутри дерева вынесла бы наружу что угодно. Стенд
  (`tests/t_media.py`, 9 проверок) стережёт каждую по отдельности — в том числе
  что `helene.json` с ключом модели не отдаётся ни под каким путём.
- **Сверка по значениям больше не падает по памяти.** `installer/secret_scan.py`
  складывал ВЕСЬ текст дерева в список пар и умирал с `MemoryError`, если его
  натравить на рабочую копию: рядом лежит `installer/build/` с собранной
  поставкой на четверть гигабайта. Сверка, написанная ради «публиковать
  нельзя», не говорила при этом ничего. Теперь файлы читаются по одному, а
  проверяется ИНДЕКС git (публикуется он, а не папка); крупные файлы
  пропускаются с названным числом. Плюс второй вход: тот же прибор читает
  `installer/secret-strings.txt` напрямую — один список литеральных значений на
  сборку и на сверку зеркала, а не два.

- **Рука элемента вернулась из её дерева починенной — и с двумя находками, которых
  она сделать не могла.** Она нашла в нашем портированном теле два блокера и
  закрыла их сама: `E_POINTER` при обходе читался как «конец дерева» (кусок окна
  просто исчезал из ответа), а отказ чтения свойства молча выбрасывал элемент из
  множества совпадений — то есть «ровно одно совпадение» могло быть ложной
  уникальностью, и удар уходил бы в чужой элемент. Обе починки взяты к нам
  целиком.
  ⚠ Собранная под Windows, её правка НЕ КОМПИЛИРУЕТСЯ: `cache` в подписи уже
  ссылка, лишний `&` даёт `&&`. Проверить это ей нечем — код под `cfg(windows)` на
  Linux не компилируется вовсе, и её же расписка ревью говорит «linker `cc`
  missing, BLOCKED». Правку в теле считаем непроверенной, пока её не собрали на
  Windows.
  ⚠ Её правка унесла живое чтение значения у `Edit`/`Document`. Фолбэк стоял с
  08.09 по замеру: у прокси-контролов (WinForms, классический Win32 EDIT через
  MSAA-мост) кэшированный `ValuePattern` ПУСТ, хотя живой запрос значение отдаёт.
  Без него чтение обычного поля ввода возвращало пустоту — читается как «в поле
  ничего нет». Возвращён, со строгостью на месте: только на показ, а отбор по
  `value_contains` идёт строгим путём.
- **Отказ запроса больше не выдаётся за отсутствие паттерна.** В действии стояло
  `GetCurrentPatternAs(...).map_err(|_| missing(...))`: ЛЮБОЙ отказ — ошибка
  провайдера, отвалившийся элемент, `E_POINTER` — объявлялся как «у этого элемента
  такого паттерна нет», да ещё с перечислением тех, что «есть». Владелец читает
  «кнопка не умеет нажиматься» там, где не удался запрос. Семь мест переведены на
  `act_pattern`: успешный ноль — действительно нет паттерна, неуспешный статус —
  назван отказом запроса. Тот же класс, что чинила она, только с другого конца.
- **Пустое поле отбора — отказ словами, а не молчаливое расширение.**
  `select: {"role": "   "}` обрезалось в `None`, условие исчезало, отбор
  становился шире, чем просили. Теперь обе руки (`act_element`, `find_elements`)
  отказывают и называют поля.
- **Повтор действия адресует ту же запись, а не второй щелчок.** Ход рвётся
  сверху (обрыв реле, `EmptyResponseError`), модель переиздаёт тот же вызов — и
  без общего ключа мост принимал его как новое намерение и нажимал кнопку дважды.
  `act_element` теперь требует собственный `idempotency_key` (её решение, взято к
  нам): тот же ключ на повтор того же намерения, новый — на новое. Ключ привязан к
  principal: одинаковый ключ у двух людей — два разных действия.
- **Два чтения перестали числиться побочными.** `read_window` и `find_elements`
  ничего не меняют, но в классификации восстановления стояли как побочные — то
  есть после обрыва хода взгляд на окно сам бы не повторился. Плюс `read_window`
  молча терял `visible_only` и `timeout_ms`: сказать «покажи и скрытые» или
  «подожди окно» было можно, рука роняла оба поля.

- **Сверка издания проверяла объявление, а не содержимое — и потому молчала.**
  `core_src.py --check` спрашивал только «объявлен ли файл в слое и правда ли он
  расходится с ядром». Совпадает ли то, что ЛЕЖИТ в слое, с рабочей копией, не
  спрашивал никто: слой мог отстать на любое число правок, а прибор отвечал
  «издание объявлено честно». Поставка «ядро + слой» воспроизводила бы не это
  дерево — ровно то, ради чего сверка и заведена. Поймано на себе: после работы
  над телом пять файлов издания лежали в слое во вчерашней редакции.
  ⚠ Хуже: объявленный файл, которого в ядре нет вовсе (наш новый — `element.rs`,
  стенды поиска), выпадал из ВСЕХ корзин отчёта и не проверялся ничем. Теперь
  сверяется содержимое, отставание роняет проверку, `--sync` переносит одной
  командой, а сборка из ядра на отставшем слое отказывается так же, как на
  необъявленном. Четыре случая накрыты стендом (`tests/t_core_src.py`).

- **Её собственная история перестала приезжать мусором.** Рука `git` звала git
  с `text=True` и без кодировки — Python разбирал UTF-8 кодировкой локали, а на
  Windows это cp1251. Каждое русское сообщение коммита возвращалось как
  «РІС‚РѕСЂРѕР№ С„Р°Р№Р»»: агент не мог прочитать свою же историю, а `log` в
  поиске собственной правки не находил ничего. На Linux локаль совпадала — и
  потому молчала. Теперь кодировка названа вслух, с `errors="replace"`: чужой
  репозиторий в другой кодировке отдаст текст с потерей знаков, а не отказ руки
  целиком.
  ⚠ Нашёл это гейт на Windows — на той самой платформе, под которую продукт и
  выпускается, и где его красные привыкли считать особенностью среды. Из трёх
  красных винды дефектом продукта оказались два (те же два стенда), третий —
  стендом: он строил пять тысяч знаков через `$(seq 1 5000)`, а в bash рядом с
  git на Windows `seq` нет вовсе.

## 0.5.3 — несколько агентов в одной установке, голос агента наружу, серверные настройки из окна, 11.09.2026
 выпущено — несколько агентов в одной установке

- **Голос агента НАРУЖУ на Windows.** До сих пор синтез был только серверным
  (Silero, Piper в контейнере), а на Windows `speak` упирался в `edge-tts`,
  которого в рантайме нет: агент отвечал «озвучка недоступна». Теперь синтез
  местный: `piper-tts` едет в поставке (+45 МБ поверх уже привезённого ради
  расшифровки onnxruntime), голос (61 МБ) качает владелец из окна — второй
  половиной той же карточки «Голос».
  ⚠ Не Edge и не Silero, и это решение, а не вкус: Edge — это голос Микрософта
  ПО СЕТИ, то есть текст ответа агента уходил бы наружу на каждую фразу, а
  продукт обещает обратное; Silero тянет torch (около двух гигабайт) ради того
  же результата.
  Живые числа (машина владельца, 11.09): первая фраза 3,1 с (голос читается с
  диска), следующие 0,24 с на 3,7 с речи — примерно в пятнадцать раз быстрее
  реального времени. Синтезированное складывается В ДЕРЕВО агента
  (`data/media/tts`), а не во временную папку системы: это его слова, и переезд
  дерева увозит их с собой.
  ⚠ Голосом агент отвечает **в Telegram**: в окне вложение пока приезжает
  строкой с путём к файлу, а не проигрывателем (`transport._send_file`, v1) —
  так и написано в карточке, чтобы не обещать лишнего.
  Проверено ЕЁ модулем (`live/media_audio.py`), а не только piper: наш
  `voice.apply` ставит переменные — её синтез кладёт WAV в дерево.
- **Рука поиска по дереву окна и честный масштаб** — в теле агента (общий код
  с Праксис, поэтому патч ушёл ей: ).
  Глагол `desktop.element.find` ищет элементы тем же отбором, что и действие, и
  ждёт их появления вместо пауз наугад; тело объявляет себя осведомлённым о
  масштабе экрана (per-monitor v2), а окно называет свой `dpi`/`scale`.
  ⚠ Живая проба у владельца: **его экран стоит на 125 %**, а тело считало
  координаты в вымысле «96 точек на дюйм» — то есть путь «прочитал прямоугольник
  → ударил по координатам» был ненадёжен на самом деле, а не в теории.
- **Настройки серверного агента правятся из окна.** Окно к серверу умело
  перезапускать агента и читать журналы, а за сменой модели или бот-токена
  владелец шёл в ssh — при живом окне, которое к этому агенту уже подключено.
  Теперь у окна к серверу есть карточка «Агент на сервере»: мозг, Telegram и имена
  правятся здесь и пишутся в ЕГО файл на той стороне (`/api/agent-config`,
  `deskd/agentcfg.py`).
  ⚠ Правится только то, что про самого агента. Раскладка установки — где
  python, где код, порт канала, служба, реле — не отдаётся окну даже на чтение
  и не записывается: ключ окна и так открывает многое (записка агенту, правка
  его конституции), но подменить программу, которой агент запускается, он не
  должен. Отброшенные ключи названы в расписке поимённо: молча проглоченный
  ключ выглядел бы как «сохранилось».
  ⚠ Сверка свежести, как у маркдаунов: агент правит свой конфиг сам
  (`switch_brain` пишет туда же), и выигрывать не должен тот, кто записал
  последним — разошлось, значит 409 и перечитать.
  Живая проба по HTTP на настоящем канале: чтение 200 без ключей раскладки,
  правка мозга легла в файл, подмена `runner` и `service.session0` отброшена
  (файл цел), устаревший отпечаток — 409 с сохранённой правкой агента, без
  ключа — 403.
- **Слух и речь включаются порознь.** `voice.enabled` — про расшифровку,
  `voice.speak` — про ответ голосом: слышать голосовые и отвечать текстом
  (или наоборот) — законные желания, и один выключатель на двоих их бы склеил.

- **Одна установка — сколько угодно агентов.** До сих пор правило было «папка =
  агент», и второго заводили второй установкой программы: свой рантайм, своё
  дерево кода, своё обновление — около 600 МБ ради второго характера, и два
  значка у часов, которые ничего друг о друге не знают. Теперь агент — это
  папка `agents/<id>/` рядом с программой: свой дом (`agents/<id>/data`), свой
  порт, свой бот, свой мозг; рантайм, код агента, реле и обновление — общие.
  Корневой `helene.json` остался ровно тем, чем был, — это первый агент (`main`),
  и у владельца с одним агентом не меняется НИЧЕГО: ни файла, ни строки в окне.
- **Правило списка записано один раз** (`localharness/agents.py`), а читают его
  трое: питон, оболочка и служба (`common/agents.rs`). Согласие двух голов
  проверяется общим набором случаев `tests/roster-cases.json` — его читают и
  питоновский стенд, и Rust-тест. Порт по умолчанию — `ports.desk` плюс место в
  списке; спор за порт не «поправляется сам», а называется вслух и снимает
  агента с подъёма, оставляя его видимым в окне.
- **Окно показывает того, кого выбрали.** Переключатель — первой строкой полки
  и подменю у значка часов; ярлык на конкретного агента — `helene.exe --agent
  <папка>`. Переключение строит окно заново с адресом и ключом другого агента:
  адрес вебвью задаётся при создании, и подменить его у живого окна нечем, а
  держать в одном окне два адреса — это ровно тот класс, из-за которого окно
  однажды показывало чужую переписку. Остальные агенты при этом живут дальше.
- **Секрет канала — свойство дерева, а не процесса.** Раньше он лежал в
  глобале оболочки (`OnceLock`), и при двух агентах дети второго получили бы
  ключ первого — то есть 403 от собственного канала. Теперь секрет едет со
  спекой ребёнка, а в глобале остаётся только ключ того агента, который сейчас
  в окне.
- **Надзор считает пропажу по каждому агенту.** Условие «своих детей нет вовсе»
  было общим на весь список: пока жив первый агент, упавший второй не
  поднимался — и молчал об этом. То же в службе: занятый порт одного больше не
  держит взаперти остальных.
- **Служба поднимает всех.** Владельцу, живущему без окна, второй агент
  доставался бы только по нажатию — то есть не доставался бы вовсе. Канал
  поднимается всегда, раннер — когда у агента настроен мозг: без ключа модели
  он не думает, а ошибается на каждом ходе.
- **Реле остаётся одно на установку** (порт один, вход в подписку один) и
  поднимается корневым агентом; дом реле считается от корневого дерева, поэтому
  переключение агента в окне не уводит вход в подписку в другую папку.
- **Завести агента** можно в «Настройках» → карточка «Агенты»: имя, и всё.
  Мозг и ограду новый агент наследует от корневого (владелец настроил их один
  раз), бота и тело — нет: они у каждого свои, и общий порт моста означал бы,
  что рукой `computer` второго агента водит тело первого. Дом засевает раннер
  при первом старте — второй реализации засева нет.
- Живая проба: два агента, поднятые службой в консоли на одной машине, — два
  канала на своих портах, каждый называет СВОЁ дерево, секреты разные, замки
  деревьев держат разные процессы («Hélène» и «Мира»), журналы в домах у
  каждого свои, в журнале службы строки помечены именем агента.
- ⚠⚠ **Живая проба окна поймала три дефекта подряд, и ни один не был виден
  стендам** — все три про одно: окно в Tauri нельзя пересоздавать наивно.
  1. Окно, построенное в `setup` от `AppHandle`, уходит в очередь ещё не
     запущенного цикла событий и не появляется НИКОГДА: процесс жив, дети
     подняты, журнал чист, окна нет. Строится оно от самого `App`.
  2. `close()` окно не закрывает: обработчик прячет его в трей, метка `main`
     остаётся занятой, и новое окно отвечает «a webview with label `main`
     already exists» — владелец остаётся без окна вовсе. Нужен `destroy()`,
     а чтобы он не погасил детей (у этого окна смерть = выход), на время
     переключения смерть окна выходом не считается.
  3. Снесённое окно было последним, и Tauri вышел из программы — вместе со
     всеми агентами. Флага «идёт переключение» не хватило: просьба о выходе
     разбирается ПОЗЖЕ, чем строится новое окно. Правило сделано прямым:
     выход — только по слову владельца (`app.exit`, код назван), исчезнувшее
     окно выходом не считается.
  Живая проба после починки: переключение на «Миру» — окно перестроилось на её
  канал (её комната в списке чатов), программа жива, оба агента продолжают
  работать на своих портах.
- Мелочь оттуда же: новый агент наследовал название комнаты окна и подписывал
  переписку с собой чужим именем. Комната зовётся именем своего агента.

## 0.5.2 — реле наконец поднимается, голос на Windows, сервер под управлением, 10.09.2026

- **Реле подписки ChatGPT не поднималось НИКОГДА — ни разу с тех пор, как его
  начала звать оболочка.** Живая проба 10.09: `helene-relay.exe serve` игнорирует
  аргумент целиком, печатает интерактивное меню, читает из закрытого stdin конец
  файла, отвечает «Invalid choice» — и крутится так в горячей петле (70 секунд
  процессора за минуту), не заняв порта ни разу. На машине владельца это было
  невидимо: порт 5011 держало реле ПРЕЖНЕГО поколения продукта, и весь мозг
  молча шёл в него. Починено в самом реле (0.8.1): назван аргумент — делаем
  названное (`serve`, `login`, `refresh`) и выходим; аргумента нет и stdin не
  терминал (служба, контейнер, ребёнок оболочки) — поднимаем сервер; человеку
  за терминалом остаётся прежнее меню.
  ⚠ Тем же корнем была сломана и **кнопка входа в подписку**: установщик и окно
  зовут `helene-relay.exe login`, аргумент игнорировался — браузер не
  открывался никогда, и `data/relay/local_auth` у владельца пуст до сих пор.
  Теперь `login` и `refresh` тоже делают названное; живьём вход не проверялся —
  он открывает браузер и требует руки владельца.
- **Ключ петли к реле стал проверкой, а не обещанием.** Установщик с 0.4.x
  пишет в `helene.json` ключ `sk-frame-…`, оболочка передаёт его реле
  переменной `RELAY_API_KEY`, а комментарий рядом объясняет, зачем: «открытый
  локальный порт позволял бы любому процессу на машине жечь подписку
  владельца». Реле эту переменную не читало — проверки не было вовсе. Теперь
  есть: задан ключ — `/chat/completions` без `Authorization: Bearer <ключ>`
  отвечает 401; ключа в среде нет — поведение прежнее (так живёт её серверное
  реле, у которого порт не выходит за контейнер). `/v1/models` остаётся
  открытым: это проба «реле живо», её зовёт окно.
- **Агент, увезённый на сервер, больше не немеет.** Перенос увозил вход в
  подписку (`data/relay/local_auth` в архиве, назван в паспорте поимённо) и
  адрес мозга на петле — а поднять реле на той стороне было нечем: в
  контейнере жили ровно две службы. Теперь реле едет в поставке вторым бинарём
  (`helene-relay`, Linux, собирается в докере: `installer/relay_src.py
  --build-linux`), `server/serverboot.py` поднимает его третьим ребёнком по
  `relay.enabled` — дом `data/relay`, порт из `relay.port`, ключ петли из
  `model.key`, — и живёт оно В ТОМ ЖЕ контейнере, потому что слушает только
  `127.0.0.1`. Поэтому `model.base_url` из архива на сервере верен без правки:
  чинить конфиг при импорте не понадобилось вовсе.
  Молчания нет ни в одном исходе: нет бинаря — «агент с подпиской ChatGPT будет
  нем» с командой сборки; занят порт — «своё реле не поднимаю» (иначе мозг ушёл
  бы в чужое); `relay.enabled` снят, а адрес мозга смотрит на петлю — сказано и
  это. Стенд `tests/t_server_relay.py` (11 проверок) стережёт каждый исход,
  сборка сверяет отпечаток Linux-бинаря отдельно от виндового.

- **Голос на Windows: агент слышит голосовые.** До сих пор расшифровки в
  поставке не было вовсе — на сервере она есть с 0.3.x (та же коробка, что у
  Праксис), а на Windows голосовое в Telegram или в окне превращалось в
  молчание. Теперь `faster-whisper` едет в рантайме (с ним ctranslate2, av,
  onnxruntime и numpy — поставка тяжелеет примерно на 170 МБ), расшифровка идёт
  ЗДЕСЬ, на процессоре: запись никуда не отправляется.
  Модель в архив не входит и войти не может — 480 МБ у маленькой, 1,6 ГБ у
  рабочей. Её выбирает и качает владелец из окна, карточка «Голос»: две модели
  с честными размерами и оговорками, кнопка с ходом скачивания, папка
  `data/models/whisper`. Ход дела помощник (`localharness/voice.py`) пишет в
  дерево, канал отдаёт его ручкой `/api/voice`, и окно читает эту запись СО
  СРОКОМ ГОДНОСТИ: закрыли окно посреди скачивания — сказано «оборвалось», а не
  вечное «качаю…».
  Раннер ставит дереву `PRAXIS_STT_*` ДО импорта — иначе `media_audio` их уже не
  увидит, — и ставит либо все, либо ни одной: полупроставленная среда означала бы
  глухоту без причины. Нет библиотеки, нет модели, скачана не та — каждая
  развилка названа словами в журнале и в окне.
  ⚠ Модель в памяти по умолчанию НЕ держится, в отличие от сервера: дома это
  1,5 ГБ занятой памяти за несколько голосовых в день. Ручка `voice.keep_loaded`
  рядом.
  Живая проба на машине владельца (`small`, int8, 4 потока): загрузка модели с
  диска 3,8 с, расшифровка 3,9 с на 9,2 с русской речи. Стенд `tests/t_voice.py`
  (16 проверок) — включая сверку имён переменных с тем, что и правда читает
  `live/media_audio.py`.

- **Окно к серверу перестало быть смотрелкой.** Видно было всё — переписка,
  ходы, кадр, — а сделать нельзя было ничего: упавший раннер или неподнявшееся
  реле чинились только через ssh. Теперь на экране «Система» стоит надзор сервера
  как он есть (кто держит харнесс, какие дети подняты, с какими pid, сколько раз
  падали) и три кнопки — перезапустить агента, реле или весь харнесс, — плюс
  хвосты журналов: `runner.log`, `deskapp.log`, `relay.log` и собственный журнал
  реле. То же, что `docker logs`, только без ssh.
  Протокол файловый (`deskd/control.py`): канал КЛАДЁТ просьбу, надзор
  (`server/serverboot.py`) берёт её раз в три секунды, исполняет и пишет
  расписку; он же пишет о себе записку каждые три секунды. Доступность
  управления считается ТОЛЬКО по свежести этой записки — по реальности, а не по
  конфигу: надзор молчит — кнопок нет и сказано, сколько секунд он молчит; на
  Windows надзор — оболочка, и об этом сказано прямо, а не показано мёртвой
  кнопкой. Просьбу берёт только владелец: ручек управления нет ни в
  `_DEVICE_PATHS`, ни под префиксами устройства, то есть спаренному телефону
  сюда нельзя. Имя журнала никогда не превращается в путь — список закрытый,
  иначе ключ окна открывал бы `helene.json` с ключами.
  ⚠ Кнопки «обновить ядро» нет намеренно: контейнер не пересобирает сам себя, а
  канал с доступом к докеру хоста — это не обновление, а отмычка. Обновление
  названо словами и командой, там же, в окне.
  Стенд `tests/t_control.py` (15 проверок); живая проба в контейнере: раннер
  перезапущен по кнопке (pid 8 → 16), расписка пришла за две секунды,
  «перезапустить всё» вывело надзор из контейнера, как и обещано.

- **Ограда научилась Linux — bubblewrap там, где на Windows AppContainer.** Порт
  решено делать «основой, без UIA и брокера», но ограда в основу входит
  обязательно: без неё файловые руки и `shell` идут с правами пользователя, а
  текст режима «Песочница» обещает обратное. До сих пор `fence.py` не
  ИМПОРТИРОВАЛСЯ вне Windows (`ctypes.wintypes` в шапке) — на сервере каждая рука
  шла без ограды, а раннер писал «песочница не поднялась». Теперь виндовые типы
  на POSIX подменяются теми же ctypes-типами, модуль читается везде, а
  `install` выбирает реализацию по платформе. Контракт тот же
  (`prepare`/`describe`/`run`/`sync_mounts`), механизм другой: пространства имён
  вместо контейнера, связывание вместо icacls, `--unshare-pid` с
  `--die-with-parent` вместо job-объекта, символические ссылки вместо стыков.
  Список секретов — тот же `fence.secret_paths` (две правды о том, что прятать,
  разъехались бы молча); поверх связанной памяти они закрываются `/dev/null` и
  пустой tmpfs. Нет bubblewrap или запрещены пространства имён — отказ ВСЛУХ, с
  причиной в снимке устройства, как и на Windows.
  Живая проба в контейнере: команда идёт и пишет в доме, ключи владельца из
  ограды не читаются, память агента читается, чужая папка — нет, без сети наружу
  не ходит, таймаут уносит всё дерево. Стенд `tests/t_fence_posix.py` (13
  проверок, из них 6 — только на Linux с bubblewrap).
  ⚠ macOS не накрыт, и это сказано словами: App Sandbox выдаётся подписью
  приложения, а не запуском процесса, а `sandbox-exec` объявлен устаревшим.

- **Дыра закрыта: `run`, `run_tests` и `pip_install` больше не идут мимо ограды.** Держалась
  она не на замысле, а на арифметике пространств имён: шим ограды подменял `subprocess` в
  модуле `agent`, а эти руки живут в `workshop`, у которого свой `import subprocess`. Подмена
  в чужом модуле до них не доставала никогда — при том что снимок устройства писал «shell в
  AppContainer». Теперь шим стоит и в `workshop`, и в `hands` («пол» — бинарь `praxis-hands`,
  который `run` пробует первым), и уводит в контейнер всё, что эти модули исполняют, сохраняя
  рабочую папку вызывающего: команда по-прежнему выполняется в папке проекта мастерской.
- **Снимок устройства везёт отчёт об ограде поимённо**, а окно рисует его двумя таблицами на
  экране «Система» — что накрыто, что нет и почему, с меткой у каждой руки в общем списке.
  Приговор вычисляется из реальности (стоит ли обёртка на реализации, стоит ли шим в модуле
  руки, поднялся ли контейнер), а не из списка на экране. Умолчание fail-closed: рука, о
  которой ограда не знает, считается вне её.
- **Названо то, что оградой не накрывается и не будет.** Forge — десять рук (`coding_*`), и
  работают они в worktree ЗАДАЧИ, а он лежит там, куда его завёл владелец: это может быть
  любой репозиторий на диске. Туда же дописан текст режима «Песочница», который до сих пор
  обещал, что «файлы и команды дальше дома не идут». Отдельной строкой названа половина
  `run_tests`: аргумент `"self"` исполняет `selfdev` в worktree предложения, а `.proposals`
  контейнеру на запись не выдана — огородить эту ветку значило бы сломать саморазвитие агента.
- Стенды: `tests/t_fence_hands.py` (отчёт: приговор из реальности, fail-closed умолчание,
  протухшее имя в карте) и `tests/t_fence_run.py` (маршрут: что уходит в контейнер, что мимо,
  сохраняется ли рабочая папка, правится ли состояние при сорвавшемся контейнере).

- **Ядро и слой издания стало чем проверять.** Раскладка объявила: ядро в `praxis/`,
  Windows-издание слоем в `helene/core`, — но проверять это объявление было нечем, а
  непроверяемое объявление разъезжается с делом молча. Теперь есть `installer/core_src.py`
  (тем же устройством, что `relay_src.py` для реле): он сверяет слой с ФАКТИЧЕСКОЙ разницей
  ядра и рабочей копии и называет три исхода поимённо — не объявлено, объявлено зря, только
  у нас. Сборка кладёт в паспорт два отпечатка (ядра и слоя) и расхождение между ними, а
  флаг `--from-core` собирает дерево как «ядро + слой» и **отказывается**, пока слой не
  описывает издание целиком.
  ⚠ Первая же сверка: выложенное ядро — её экспорт от **13.08**, и 47 файлов расходятся,
  не будучи объявленными (её собственные прод-починки после этой даты), а 7 объявлены зря —
  числа `EDITION.md` мерились против её живого дерева, а не против выложенного ядра. Пока
  зеркало не переэкспортировано ею, собирать из ядра — значит выпустить ядро месячной
  давности; поставка поэтому по-прежнему едет из рабочей копии, и паспорт теперь говорит
  об этом прямо.
- **Hélène и Praxis стали двумя приложениями, а не одним с ветками.** 09.09 Praxis ругался на
  чужой харнесс пустыми полями и красными строками, и это закрыли сорока четырьмя ветками
  `if (remote)` в общем экране настроек. Заплатка работала, но означала, что окно Элен возит
  в себе логику Praxis, а Praxis — карточки агента, которого рядом нет. Теперь разница
  объявлена: общее окно (канал, состояние, чат, ходы, кадр, восемь экранов, каркас настроек)
  переехало в `ui-kit/window`, а каждое приложение приносит своё — Элен карточки местного
  агента (`app/src/settings-agent.ts`), Praxis одну карточку «Агент живёт на сервере» и
  перехват первого запуска (тогда `pult/`, с 18.09 — `remote/`). Веток `remote` в составе общего экрана не осталось ни
  одной, и стенд `settings-remote.test.mjs` теперь стережёт границу, а не условия.
  Проверяется числом: бандл Praxis **158 кБ против 200 кБ** у Элен — карточек местного
  агента в нём физически нет.
- Пакет desk кладёт на сервер фронт **Praxis**, а не Элен: до разделения фронт был один, и
  на сервер уезжало окно, знающее про местного агента, которого там нет. `copy_static` теперь
  спрашивает, какое приложение собирают, а не берёт первую попавшуюся часть.
- Имя продукта ставит издание (`start({ productName })`), а не константа общего слоя:
  «Hélène», вшитая в `ui-kit`, подписывала Praxis чужим именем в заголовке окна, на полке и в
  служебных плашках чата. Живое имя из канала по-прежнему главнее.
- **Где что лежит на диске — одно объявление** (`layout.py`). Раскладка 10.09 увела `desk/`
  внутрь репозитория `praxis`, а дерево агента, зеркало реле и цель сборки тела остались
  рядом с ним. Жёсткий путь `ROOT / имя` после переезда указывал в пустоту молча (`rglob`
  по несуществующему каталогу отдаёт пустой список), и чинить это пришлось бы в пяти местах
  сразу — сборка, прибор ядра, зеркало реле и три стенда. Место объявлено один раз.

## 0.5.1 — desk одним пакетом, телефон к серверу, реле из одного исходника, 10.09.2026

- Состав, версия и зависимости desk объявлены один раз (`deskpkg.py`), и обе установки —
  сервер и поставка Windows — ставят собранный ПАКЕТ целиком, а не по списку путей. Фронты
  теперь тоже едут пакетом: до этого мини-апп по построению доставался только серверу.
- В пакете два файла о себе: `desk.json` (версия, sha256 каждого файла, один отпечаток) и
  `requirements-desk.txt` (aiohttp каналу, telethon раннеру). Канал отдаёт свой манифест в
  `/api/state`, окно показывает версию и там, где оболочки нет (Praxis на сервере), а
  выкладка сверяет, что канал поднялся ровно на том пакете, который положили.
- `config.js` (имя агента и продукта для страницы) отдаёт канал: файл рядом с фронтом
  уносила первая же выкладка — `/m/config.js` отвечал 404, и телефон Праксис звался «Агент».
- **Телефон к Praxis на сервере наконец подключается.** Раньше кнопка «Показать QR» отвечала
  «Канал не пустил: только с этой машины (403)»: пары телефона выдавались лишь окну на той же
  машине, что и канал, — а у Praxis окно по определению на другой. Теперь пару выдаёт владелец
  (ключ окна) откуда угодно; ключу телефона сюда по-прежнему нельзя. Второй замок был глубже:
  ключи спаренных телефонов канал писал в дерево агента, а на сервере оно смонтировано на
  чтение — обмен падал «Read-only file system» и отвечал 503. Ключи устройств — данные канала:
  теперь у него своя папка (`HELENE_DESK_STATE`), и в чужое дерево он не пишет ни байта.
  QR в этом режиме ведёт на адрес сервера, а не на адрес этой машины.
- **Настройки на чужом харнессе больше не ругаются.** Praxis показывал пустые поля модели и
  Telegram и три красные строки — «модуль режима не нашёлся», «про управление компьютером
  харнесс ничего не рассказал», «снимок устройства пуст», — хотя ничего не сломано: агент живёт
  на сервере, и его настройки правятся там. Карточек местного агента в этом режиме больше нет,
  вместо них одна честная: где живёт агент и что здесь остаётся. Пустой адрес обновлений больше
  не делает кнопку «Проверить обновления» мёртвой.
- **Реле в поставке — из одного исходника с публичным `praxis-relay` 0.8.0.** Отмена доходит
  до бэкенда: бросил клиент — отменяется и запрос наверх, квота подписки не горит на ответ,
  которого никто не ждёт. Появилось третье имя терминального состояния
  (`subscriptions_unavailable`), текст модели берётся из завершённого сообщения с
  аннотациями — маркеры цитат и utm больше не протекают в ответ. И вернулась ручка
  `RELAY_PORT`: оболочка её передавала, а реле не читало — «порт реле» в настройках
  ничего не делал.
- Адрес обновлений и выпуски переехали в репозиторий `praxis`; установщик переносит наш
  прежний адрес на новый, а вписанный владельцем не трогает.
- Рецепт контейнера канала — в репозитории (`server/desk-recipe`) и едет вместе с пакетом:
  образ ставит зависимости самого пакета. Прежний контейнер жил на безымянном образе от чужой
  сборки месячной давности (2,5 ГБ ради одного aiohttp), и пересобрать его было нечем.

## 0.5.0 — зрение в окне, свой Praxis, расход по чатам и людям, 09.09.2026

- Картинка едет вместе с репликой: скрепка в поле ввода, вставка из буфера, перетаскивание
  (PNG, JPEG, WebP, GIF — до четырёх, до 8 МБ). Кадр получает изображение, и вызов на один
  ход переключается на зрячую модель (у GLM — `glm-5.3-flash`): текстовая модель картинку
  не видит и придумывает содержимое, поэтому переключение обязательно. Картинку в
  Telegram-комнату окно не берёт и говорит об этом словами.
- «Настройки» → «Модель»: запасная модель и зрячая модель задаются в окне, а не правкой
  helene.json руками.
- Зрение и запасная модель в журнале вызовов: у вызова с картинкой стоит `vision`, удачный
  переход на запасную модель оставляет след.
- «Система» → расход по чатам, людям и задачам за 7 дней: сколько вызовов и токенов ушло в
  каждую комнату, каждому человеку и в каждый ход, с отдельной корзиной для вызовов вне ходов.
  Считаются токены, не деньги.
- «Система» → кэш по группам действий: все семь разрезов (итерация, рука, род прогона, роль,
  модель, режим кадра, дни) — четыре из них раньше считались, но не показывались.
- Имена чатов берутся из постоянных реестров комнат, а не из хвоста журнала ходов: после
  свёртки комнаты переставали называться и превращались в «чат -100…».
- Ссылки в тексте: голый адрес кликабелен, разметка ссылок не рвётся на длинных адресах.
- Имя продукта берётся из сборки: та же оболочка собирается как Hélène и как **Praxis** —
  окно к своему серверу со своим значком, заголовком, ярлыком и уведомлениями.
  `build_dist --variant praxis` собирает его отдельной поставкой (4,7 МБ вместо 124: окно
  без ядра, рантайма и тела). Обновления в общем канале различаются по имени архива.
- Сборка сверяет имя продукта внутри exe: оболочка варианта больше не может уехать в
  поставку Hélène под именем её окна.

## 0.4.8 — GLM на заданной глубине, честные напоминания, лента шагов, чтение окон, 08.09.2026

- Ступень рассуждения GLM доходит до z.ai: Anthropic-совместимый эндпойнт молча
  игнорировал `reasoning_effort`, теперь ступень едет полем `output_config.effort`.
  Ответы на low в разы короче и быстрее; оценщик на GLM тоже думает на low.
  В журнале вызовов появились ступень, `stop_reason`, род прогона и отпечаток кадра.
- Напоминания: прошедшее время («сейчас вернула 0») больше не читается как обещание;
  ход будильника и записка владельца несут полный текст повода в снимок прогона.
- Обрыв ответа потолком не записывается как «решила промолчать»: причина доходит до
  карточки. Слово без руки `reply` доставляет граница окна, и прогон это знает.
- Рука `computer`: действие `read_window` — дерево контролов окна через UI Automation
  с координатами центра; значение полей ввода читается живым запросом; для текстовой
  модели снимок экрана честно назван недоступным; скрипты PowerShell пишутся с BOM.
- Лента шагов: один блок на шаг с номером, временем и токенами; единый счёт шагов;
  длинные результаты и слово раскрываются целиком, при серверном обрезе дочитываются
  файлом (`/api/run/{run}/result/{id}`); курсор обычный; повод будильника подписан словами.
- Карточка хода: ссылки «Открыть в чате», «Повторить через 10 минут», «Снять» под поводом.
- Экран «Система»: кэш по группам действий за 7 дней (первая итерация против продолжений,
  по рукам, по роду прогона), `/api/frame-stats`.
- Windows: замена файла прогона повторяется при гонке с читателем окна; ход больше не
  встаёт в паузу из-за открытого манифеста.

## 0.4.7 — непрерывность действий в миниаппе, 07.09.2026

- Карточка сохраняется после завершения: повод запуска, действия и итог остаются
  вместе. Поздний ответ старого запроса не подменяет новую активную работу.
- Повод берётся из снимка конкретного запуска; начало всей переписки больше
  не выдаётся за новое обращение. Полный сохранённый ответ доступен при раскрытии.
- Предыдущие действия раскрываются вместо удаления из короткого списка;
  завершение и обновления сохраняют раскрытые подробности и фокус.
- В обзоре повод и итог стоят рядом; действия раскрываются отдельно, квитанции
  доставки остаются в подробностях. Ответы сохраняют форматирование текста.
- Свежесть долгой работы определяется последним обновлением её записи.
  Изменения общие для desktop, телефона и миниаппа; ядро не менялось.

## 0.4.6 — первый экран и общие интерфейсы, 07.09.2026

- На экране «Сейчас» расход и лимиты собраны в компактную сводку. Подробности,
  модели и все окна подписки раскрываются на месте, сохраняя состояние при обновлении.
- Шкалы подписки показывают остаток, как и их подписи; неизвестный остаток не
  изображается нулём. При малом остатке появляется цветовой акцент.
- Последние действия читаются в две строки и раскрываются с клавиатуры без
  перерисовки всего экрана. Исторические запуски не возвращают архивированные чаты.
- Изменения общие для окна, телефона и миниаппа. Ядро не менялось.

## 0.4.5 — Forge и адресность, 07.09.2026

- Forge повторяет оборванный запрос модели до исполнения инструментов. Повтор
  сохраняет контекст текущей итерации; частичные команды не исполняются, а
  исчерпание попыток остаётся явной ошибкой. Повторы и пауза настраиваются.
- Адресат напоминания узнаётся по однозначной привязке Telegram ID в досье.
  Совпавший псевдоним не скрывает другую или дублированную числовую привязку.
- Для отдельного Forge-субагента можно выбрать модель из доступного каталога,
  сохранив основную модель агента. Результат содержит запрошенную и фактическую
  модели; прежние позиционные вызовы сохраняют смысл лимита итераций.
- Теневой кадр остаётся в прежнем режиме. Публичный релиз ещё не опубликован.

## 0.4.4 — локальные хотфиксы, 07.09.2026

- `consolidate_context` различает снимок и изменяемый источник истории: сводка
  больше не обещает освободить следующий контекст, если источник не укорочен.
- Ошибочные сроки напоминаний отклоняются без создания задачи «как можно скорее».
  Корректный прошедший срок сохраняется с явным предупреждением о ближайшем запуске.
- Fallback сравнивается с фактически выбранной основной моделью и не повторяет её
  после переименования. При отсутствии другой модели сохраняется исходная ошибка.
- Схема теневого кадра 6 из 0.4.3 сохранена. Публичный релиз ещё не опубликован.

## 0.4.3 — локальный хотфикс, 07.09.2026

- Теневой контекст больше не замораживает текущие статусы и инструкции из
  `extra_system` внутри эпохи: они целиком обновляются в хвосте T.
- Схема 6 удаляет старую замороженную копию одной границей миграции, сохраняет
  накопленную историю и не расширяет ранее суженную аудиторию.
- Новые проверки воспроизводят смену и исчезновение состояния, миграцию и
  сохранение явно стабильной голосовой рамки. Тень остаётся прибором;
  переключение контекста, отправляемого модели, в этот хотфикс не входит.
- Публичный релиз этой версии ещё не опубликован.

## 0.4.2 — локальная сборка, 07.09.2026

- Восстановление задач из checkpoint после перезапуска, адресность напоминаний
  и подтверждение событий Forge подключены к существующим механизмам ядра.
- Расход агента и полученные от провайдеров лимиты доступны в окне и на телефоне.
- Короткий авторский ответ больше не теряется на границе локального окна.
- Публичный релиз этой версии ещё не опубликован.

## 0.4.1 — локальная сборка, 07.09.2026

- Новое окно из текущих исходников включено в локальную поставку.
- Общая лента «Действия» для окна, телефона и мини-аппа: понятные подписи,
  состояния ожидания, выполнения, результата и ошибки; раскрываемые параметры
  и сохранённые результаты с явным обозначением пропусков.
- Обновление текущих действий сохраняет раскрытие и фокус; краткий сбой
  запроса больше не останавливает опрос. Читатель журнала учитывает ошибки
  модели и инструментов, в том числе при чтении неполного хвоста.
- Публичный релиз этой версии ещё не опубликован.
- Живая занятость локального раннера связана с текущим прогоном ещё до его
  завершения; окно обновляет статус после запуска без переключения вкладок.

## 0.8.2 — владелец по имени, Mac словами Mac, установка от своего пользователя, 20.09.2026 — A

- **Телефон и мини-апп Telegram в канале** (по `КОНТРАКТ-B→A`): область
  ключа устройства расширена на прогоны, ходы комнаты и пульс (телефон
  показывает те же комнаты и «Действия», что окно; конституция, режим и
  анатомия — по-прежнему только окну); `/m/sw.js` отдаётся каналом с
  `no-cache`, страница `/m/` — с `no-store` (WebView Telegram и PWA на экране
  «Домой» держат старую сборку неделями; приём из hardbot); вход мини-аппа
  `POST /pair/telegram {initData}` по подписи Telegram Web Apps (токены —
  `telegram.bot_token` и `HELENE_TG_BOT_TOKENS`, только владельцу, одно
  устройство на пользователя Telegram); имя агента для дерева без снимка —
  из `agent.name` конфига или `HELENE_AGENT_NAME`. Стенд `tests/t_phone.py`.
- **Проверка обновлений при старте.** Раз в сутки окно спрашивает адрес из
  `update.url` и, если есть версия новее, показывает уведомление Windows с
  адресом кнопки; ничего не скачивает и не ставит. Выключается
  `update.auto: false`. Отпечаток проверки — `memory/.state/update-check.json`.
- README и описание репозитория переписаны от возможностей продукта, а не от
  состава папок.

## 0.8.2 — владелец по имени, Mac словами Mac, установка от своего пользователя, 20.09.2026 — B

- **Окно перерисовано.** Полка без большой надписи — подпись продукта внизу
  слева; разделы и слово агента серифом (как страница), реплики владельца
  пузырём; справа панель хода: идущий ход живьём, полоса кадра (из кэша /
  заново / ответ), прошлые ходы шагами с расписками рук. Разные чаты с
  агентом: «+ новый чат», переименование на месте, «убрать» (архив) — по
  контракту комнат (`window-<hex>`); со старым харнессом чат создаётся
  заглушкой и говорит об этом словами. Настройки: оглавление, свежесть
  `helene.json` (`stale` → перечитать/перезаписать), «Скачать и
  установить», отметка про отложенную статику. Тёмная тема по системе или
  переключателем, клавиши Ctrl+B/J/N/,/1–6.
- **Чужой харнесс честно.** Окно, открытое к дереву без снимка Hélène (Praxis
  на сервере), судит о жизни по вызовам модели и прогонам, а не
  пишет «Не запущен»; темы форума читаются из архива родителя.
- **Телефон стал настоящим PWA** (`/m/`): манифест, service worker
  (оболочка офлайн, данные живьём), тот же язык, что у окна, те же чаты,
  лист хода с шагами (когда канал отдаёт их телефону), тема, отвязка.
- **Мини-апп Telegram** (`miniapp/`) — то же приложение на одном коде с
  телефоном (`ui-kit/phone.ts`): вход по подписи Telegram через канал
  (`POST /pair/telegram`, ручка канала в этой же волне), тема и «назад» от
  Telegram. Хостится своим сайтом (статика + прокси API на канал).
- **Один форм-кит** (`ui-kit/dom.ts`, `text.ts`, `steps.ts`) вместо четырёх
  копий обёрток; константы (порты, права `computer.*`, комнаты) — из
  `ui-kit/contract.json`, тест `app/test/contract.test.mjs`.

## 0.4.0 — 2026-09-07

- **Владелец видит либо слово агента, либо плашку.** Два хода из четырёх
  06.09 уходили в окно пустыми: отчёт слабой модели ложился в заметку
  `end_turn(note="done: …")`, а условие доставки считало отправленный файл
  словом и заметку не читало; прежнее правило вдобавок глотало всю заметку,
  если она начиналась с `done:`. Теперь на границе хода харнесс читает запись
  хода дерева: слово в заметке доставляется как её реплика (префикс исхода
  снят; `wait:` → «Жду: …», `blocked:` → «Препятствие: …»), медиа этого не
  отменяет; молчание по её решению (`stay_silent`) и ход без слова получают
  серую плашку продукта (`system`, `kind: "silence"`), которая в память
  агента не идёт. Стенд `tests/t_window_word.py`.
- **Разные чаты с агентом в окне.** Комнаты `window` (по умолчанию, зовётся
  именем агента, не удаляется) и `window-<8 hex>`: свой архив, свой горячий
  слой памяти и своё имя в кадре у каждой; память жизни — дневник, события,
  желания — одна. Канал: `POST/DELETE /api/rooms…`, `kind` и `title` в
  `/api/chats`, адрес `window-<hex>` в `/api/say`; удалённая комната уезжает
  в `memory/groups/archive/`, не стирается. Реестр — `deskd/rooms.py`, общий
  для канала и харнесса. Стенд `tests/t_rooms.py`. Окно — в редакции B по
  контракту `docs/КОНТРАКТ-ОКНА-0709.md`.
- **Обновление: что заменяется, а что нет** (`resources/ОБНОВЛЕНИЕ.md`).
  Интерфейс окна (`app/static`) меняется по тому, менял ли его ВЫПУСК —
  сборка кладёт манифест `.helene-static.json`, установщик сравнивает его с
  манифестом прежней поставки: равны — папку пользователя не трогает вовсе,
  разные — заменяет и откладывает прежнюю в `app/static.prev`
  (`installed.static_prev` в конфиге, слово в расписке); первая установка —
  кладёт с манифестом. `runtime/` (200 МБ) не копируется, если паспорт сборки
  тот же. В оболочке — `update_download` (архив в «Загрузки», sha256 из релиза
  сверяется, не сошлась — файл удалён) и `update_install` (распаковка рядом,
  запуск установщика); кнопка — B. Стенды в `setup` (`static_follows_the_
  release_not_the_user`, `runtime_is_skipped_only_when_the_passport_matches`).
- **По ревью архитектуры 06.09** (`docs/АРХИТЕКТУРА-РЕВЬЮ-06.09.md`):
  `config_save` с проверкой свежести (окно шлёт `mtime_ns`, расхождение →
  `stale`, черновик не пишется); установщик сливает `model` по полям —
  `model.keys` и `compact_model` окна переживают обновление; ключ реле — из
  CSPRNG (BCryptGenRandom) вместо RandomState; одна проба модели на окно и
  установщик (`common/model_probe.rs`: 200 без списка моделей — не «ok», как
  отвечало окно на неверный ключ z.ai); служба из окна ставится и снимается
  рецептом установщика — UAC ждётся, результат читается, расписка по SCM
  (раньше «запрошено» значило «сделано»); `service_state` с дедлайном в обоих;
  имя правила брандмауэра в установщике — из `common/firewall_rule.rs`;
  `_append_jsonl` под замком (склейка строк двух потоков в архиве комнаты);
  живые просьбы о папках в `/api/mode` → `mounts_live`; один формат штампа
  времени в `helene.log`, `service.log`, `broker.log`; `ps_quote` в двух
  контрактах → `ps_escape`/`ps_quote` в `common/ps.rs`; одна таблица маршрутов
  канала на HTTP и WebSocket (`deskapp.ROUTES`, стенд `tests/t_routes.py`);
  константы портов и скоупов — `ui-kit/contract.json` со сверкой из Python
  и трёх крейтов (`tests/t_contract.py`); спул моста подчищается сторожем
  тела (5 МБ за вечер: кадры для контроллера, которых HTTP-опрос не читает, и
  отвеченные ответы); `procps` в образе сервера (`free` для агента).
- Проверено живьём 07.09 на установке автора (тихая установка 0.4.0 поверх
  0.3.2): интерфейс заменён, прежний — в `app/static.prev`, рантайм пропущен
  (установка за 4–6 с вместо копирования 200 МБ); повтор с правленной
  статикой при том же выпуске — правки целы; подменённый отпечаток выпуска —
  замена с откладыванием правок в `static.prev`; конфиг слит (права руки
  `computer`, режим, ключ — на месте). Комната окна: создана по каналу, ход в
  ней (агент назвал комнату по кадру и увидел две комнаты через
  `search_chats`, ответ рукой `reply` лёг в её архив, запись хода — с её
  ключом и именем), удалена в архив. `mounts_live`, `kind`/`title` в списке
  чатов и `spool_bytes` — отданы каналом.
- Не проверено живьём (честно): «Скачать и установить» из окна — кнопки в
  окне ещё нет (B); плашки молчания (агент в проверке ответил рукой — путь
  заметки и молчания накрыт только стендом); подчистка спула по расписанию
  (раннер жил меньше десяти минут); служба из окна под новым рецептом; тело
  под службой.
- Сборка: в поставку едут все модули `deskd/` — до этого копировались два
  файла по именам, и новый `rooms.py` не уезжал (канал падал на импорте;
  найдено первой же живой установкой).

## 0.3.2 — 2026-09-06

- **Слово «труба» ушло из текстов** (слово владельца). Связь окна и телефона с
  деревом агента в интерфейсе, журналах и документах поставки зовётся
  «канал»; именованный канал брокера в журнале службы — тоже «канал».
  Поведение не менялось. Сборка для проверки знакомым.

## 0.3.1 — 2026-09-06

- **Управление компьютером: рука `computer` работает.** В поставке — тело
  Праксис: мост `helene-bridge.exe` и тело `helene-body.exe` (собраны из
  `tree/body/crates`, UIA через COM, экран, клавиатура и мышь, файлы и
  процессы). Поднимает их харнесс (`localharness/body.py`) детьми раннера в
  сессии владельца — так тело есть и под службой, где харнесс поднимает не
  окно, а `helene-svc.exe`; дети живут в job-объекте и умирают вместе с
  раннером, токены двух сторон генерируются на каждый старт и живут только в
  памяти (в среду и на диск не попадают). Порт моста свой — 9480, занят —
  берётся следующий свободный. Ограда до тела не достаёт: оно снаружи
  контейнера, поэтому окна доступны и в песочнице.
- **Разрешает владелец, не Telegram-id.** Дерево решало права руки по
  `PRAXIS_OWNER_ID`, которого у Hélène нет, и хозяину из его же окна отвечало
  бы «нет выданного права для этого Telegram id». Теперь право — четыре
  галочки владельца (`computer.scopes`: смотреть, файлы, процессы, окна и
  ввод), харнесс перечитывает их из `helene.json` на каждый вызов руки; отказ
  называет право, которого нет, и карточку, где оно выдаётся. Опция —
  выключатель в установщике и карточка «Управление компьютером» в Настройках
  (тексты из `modes.py`, живое состояние тела — снимок
  `memory/.state/body.json`, кнопка «Проверить»), строка в анатомии и на
  экране «Система». Умолчание — выключено, с оговоркой про слабые модели.
- **Набор текста телом — по одному знаку.** Первый живой ход показал: « — Мира
  была здесь» приезжало в Блокнот 11 как пробел и семнадцать «ь». Получатель
  с асинхронным вводом (WinUI/TSF) читает знак VK_PACKET при разборе очереди,
  а не в момент отправки, и пачка из одной `SendInput` даёт последний знак
  на всех. Тело (`tree/body`, коммит в ветке port/windows дерева) шлёт
  теперь по одной записи с паузой 20 мс после отпускания — проверено пробами
  на машине автора (8–12 мс ещё теряют знаки) и вторым живым ходом: строка
  «Мира: набор через тело работает, ёж и Hélène на месте.» набрана
  посимвольно верно. Цена — ~50 знаков в секунду; пауза набора не входит в
  бюджет задержек и показана в ответе отдельно.
- **Перенос агента одним архивом и харнесс на сервере.** Карточка «Перенос»
  в Настройках и `helene-setup.exe --export` собирают
  `helene-<агент>-<штамп>.zip` (`app/localharness/carry.py`): `data/` с
  личным git, вход ChatGPT и сессия Telegram, `helene.json` с ключами,
  паспорт `helene-carry.json`, где секреты названы поимённо; тело, журналы,
  ключ окна и стыки не едут. Импорт (`carry.py import`) сливает конфиг:
  блоки агента — из архива, блоки хоста — местные; прежняя `data/` остаётся
  рядом. В поставке — `server/`: Dockerfile, compose, надзор `serverboot.py`
  (канал + раннер, ключ окна печатается при старте) и шаблон конфига;
  STT — та же коробка faster-whisper, что у Праксис, моделью из тома. Окно
  подключается к серверу той же карточкой (`mode: remote`, адрес, ключ).
  Инструкция — `server/README-СЕРВЕР.md`. Проверено живьём 06.09: экспорт
  Миры с живой установки (кнопкой и из консоли), импорт в раскладку сервера,
  образ и контейнер из той же поставки — локально в Docker Desktop и на VPS
  автора (`/opt/helene`, порт 8194): канал и раннер поднялись, git найден,
  ограда честно «интерактивный», тело честно «в поставке нет», живой ход через
  канал (`shell`, `fs_ls`, `computer status`, ответ рукой `reply`); Мира сама
  записала в `self/CURRENT`, что переехала. Найдено и починено по дороге:
  пересозданный контейнер получал тот же pid, что лежал в замке дерева, и
  харнесс отказывался подниматься кодом 3 — замок с чужим именем хоста или
  со своим собственным pid теперь считается брошенным, а `serverboot`
  снимает замок прошлого контейнера при старте. Не проверено: STT на сервере
  голосовым сообщением (модель есть, Telegram у Миры нет), окно владельца в
  `remote` к этому серверу (его окно оставлено на локальной Мире), обратный
  перенос.
- **По ревью архитектуры 06.09** (`docs/АРХИТЕКТУРА-РЕВЬЮ-06.09.md`) починены
  две находки: установщик читал `helene.json` без снятия BOM/UTF-16 — конфиг
  из Блокнота не разбирался, и обновление поверх молча теряло решения
  владельца и ключ реле; служба поднимала реле без `RELAY_INSTRUCTIONS` —
  под session-host агент получал 23 КБ чужого промпта на каждом ходу.
- **Интерактивный режим открыт по-настоящему.** Файловые руки (`fs_read`,
  `fs_write` и остальные) без ограды видят всё, что доступно учётке владельца, —
  как `shell`. Раньше их запирал в доме гард самого дерева, и `fs_read` отвечал
  «вне дома» там, где `shell` тот же файл читал; карточка настроек при этом
  уверяла обратное. Внутри дома и кода правила дерева (секреты, ядро через
  предложение) остались. Монтирование стало дверью только песочницы: без ограды
  карточка спрятана, рука `mount_request` не выдаётся, список в конфиге
  сохраняется и оживает с песочницей.

## 0.3.0 — 2026-09-06

Проверено живьём 06.09 на машине владельца: сборка, установщик (руками и
тихо), песочница, первый ход агента, обновление поверх 0.2.1. **Не проверено
живьём:** постановка и снятие службы, просьба агента к брокеру — отдельная
задача (F1 в `docs/РЕЖИМЫ-И-БРОКЕР.md`); там это по-прежнему выбор, а не
проверка.

- **Git из коробки, личный для агента.** Поставка везёт MinGit
  (`runtime/git`, ~85 МБ распакованных, GPL-2.0 с письменным предложением в
  лицензиях); при рождении дома харнесс заводит в `data/` репозиторий от имени
  агента с первым снимком «день ноль». Обещание кадра «правка автокоммитится,
  перед shell ставится страховочная точка» с этого выпуска правда: снимки
  ведёт код дерева (`selfgit`), память и ключи в них не попадают
  (`data/.gitignore`). Ограда выдаёт контейнеру запись в `data/.git` и видит
  `runtime/git/cmd` в PATH — агент ходит в свой git и из-под песочницы. Код
  `tree/` в репозиторий не входит: отката у правок кода по-прежнему нет, и
  навык `my-own-code` говорит это прямо.
- **Статика окна читается с диска.** `app/static` больше не мёртвый груз:
  окно берёт файлы оттуда на каждый запрос (свой протокол оболочки,
  `no-cache`), правка видна по F5, оболочку пересобирать не нужно. Вшитая в
  `helene.exe` копия осталась запасным выходом на случай снесённой папки.
- **Комната окна носит имя агента**, а не слово «Окно» — в списке комнат, в
  шапке и на телефоне; переименование в настройках переименовывает и её.
- **Почерк агента.** Имя над его комнатой, на полке и на телефоне, а в
  установщике — живая подпись под полем имени, набраны Shantell Sans Light
  (OFL); продукт остаётся серифом, интерфейс — гротеском.
- **Провайдеры по протоколу Anthropic — шесть кнопок** в установщике и в
  настройках, из одной таблицы `ui-kit/providers.ts`: Z.ai (GLM), MiniMax,
  Kimi, Anthropic, DeepSeek, Qwen — адрес, модель по умолчанию, что за план
  (подписка или по счётчику) и как там с рассуждением.
- **Усилие рассуждения — по провайдеру.** Шкала показывает только те ступени,
  которые ядро действительно передаст: подписка ChatGPT и OpenAI-совместимые —
  low…xhigh, Z.ai — low / high / max, остальные по протоколу Anthropic —
  «ступень сюда не передаётся»: глубину решает модель (Kimi k3 и MiniMax M2.x
  думают всегда; MiniMax M3, DeepSeek V4 и Qwen включают рассуждение
  параметром `thinking`, которого ядро из настроек пока не шлёт). Чужая
  ступень при сохранении снимается, а не уезжает в отказ 400.
- **Стартовый контекст агента — три файла в кадре** (зона K): конституция
  ужата и получила раздел «Как я меняюсь»; новый `soul/VOICE.md` — палитра
  голоса; запись о себе «день ноль» ложится через `self_model.migrate` с
  провенансом (копией кадр её отвергает), письмо собравших дом уходит в
  `history/0000.md`. Навыков двадцать: добавлены `looking-back`, `wanting`,
  `rewriting-myself`, `my-own-code`, `who-i-am-today`, `code-map`.
- Шапка полки — имя продукта, не агента (три места писали по-разному).
- Сборка падает на неотслеженных исходниках (`_guard_untracked`): файлы,
  которых нет в git, в поставку не уезжают молча.

- **Режим и служба — два независимых измерения.** Режим (`agent_mode` в
  `helene.json`) отвечает только на вопрос «есть ли ограда рук» и имеет два
  значения: `sandbox` и `interactive`. Служба Windows — **опция поверх любого
  из них**, ограду она не снимает и не включает; стоит она или нет, продукт
  спрашивает у самой Windows, а не у файла настроек. Экран выбора в
  установщике, карточка «Режим» в «Настройках»; старый конфиг мигрирует по
  тому, что в нём уже есть. Значение `service` в `agent_mode` (его писала
  первая редакция этой же волны) читается ради совместимости, оградой не
  считается и при первой записи заменяется выведенной оградой. Названия и
  описания лежат в одном месте, `localharness/modes.py`, и установщик с окном
  берут их оттуда.
- ⚠ **Починена миграция, которая молча снимала песочницу.** Пока служба
  считалась третьим режимом, у владельца, поставившего службу И выбравшего
  песочницу, миграция выводила режим `service`, а `service` означал «ограды
  нет». Ограда снималась без единого слова, при том что владелец её выбирал.
  Теперь ограда выводится только из `sandbox.enabled`, а служба к ней
  отношения не имеет вовсе.
- Из «Настроек» исчезли карточка «Служба Windows» и тумблер «Песочница для
  рук»: службу ставят и снимают из карточки «Режим», ограду выставляет сам
  режим. Тумблер «Сеть из shell» остался.
- **Служба больше не работает агентом от имени системы.** Раньше харнесс
  наследовал права `LocalSystem`, и этого никто не выбирал. Теперь служба
  поднимает его отдельным процессом в сессии владельца (задача планировщика
  `Helene\session-host`, на владельца, без повышения) — агент работает правами
  человека и видит рабочий стол. Цена названа честно: **до входа владельца в
  систему служба агента не поднимает**, поднимать его тогда некуда. Прежнее
  обещание «агент живёт до входа в систему» снято из описания службы, README и
  карты устройства.
- Отдельная галочка «разрешить нулевую сессию» (`service.session0`, по
  умолчанию выключена) возвращает прежнее поведение осознанно: права системы,
  но без рабочего стола. Ею же открыта агенту дверь `exec` у брокера — команды
  правами системы. Служба пишет об этом предупреждение в `service.log`.
- Новый ключ `service.firewall` (по умолчанию включён) — нужна ли СЛУЖБЕ
  привилегия на правило брандмауэра для телефона. Раньше и это, и права
  системы для агента держал один `service.session0`: кнопка «Телефон» под
  службой была мертва, пока владелец не отдаст агенту всю машину. ⚠ Ключ пока
  только записывается и показывается: служба его ещё не читает, и при живой
  службе правило по-прежнему ставит она сама при старте (включить телефон в
  «Настройках» и перезапустить службу), а кнопка «Телефон» идёт через брокера
  и упирается в нулевую сессию.
- **Служба выравнивает права на папку установки** при каждом старте: `app\`,
  `runtime\` и exe рядом с ними — обычной учётной записи только на чтение и
  запуск. `data\`, `tree\` и корень не трогаются. Если на машине выключен UAC,
  а учётная запись административная, служба честно пишет, что выравнивание
  почти ничего не закрывает. **Снятие службы открывает права обратно само**
  (`uninstall` → `relax_acl`): руками ничего дописывать не надо. Команда
  `helene-svc acl-relax --config <helene.json>` осталась для другого случая —
  обновиться, не снимая службу.
- **Брокер прав.** При живой службе окно просит привилегированное действие
  через её канал вместо окна UAC на каждый чих; сегодня такое действие одно —
  правило брандмауэра для телефона. Каждое обращение ложится строкой в
  `data/broker.log`: зачем просили, что запускали, чем кончилось.
- **Агент может попросить права — рука `broker_request`.** До этого брокер был
  дверью ровно для одной кнопки окна, а тексты продукта говорили агенту про
  брокера как про существующий механизм. Теперь агент пишет просьбу
  (`data/memory/.state/broker-asks.json`), окно показывает её владельцу родным
  окном Windows — команду целиком и «зачем» словами агента — и только по «да»
  идёт в канал своим токеном; ответ и квитанция уходят в
  `broker-answers.json`, отказ записывается наравне с согласием, просьба
  старше десяти минут отклоняется без вопроса. Честно о границе: это
  подтверждение и запись, а не замок — брокер закрыт от чужих программ, а от
  самого агента закрыт быть не может, и в интерактивном режиме он читает тот
  же секрет. Экрана «Система» для списка обращений в окне пока нет.
- **Монтирование папок.** Папка вне папки продукта открывается агенту только
  тем, что владелец перечислил в `sandbox.mounts`; агенту она видна как
  `data/workspace/mnt/<имя>` и работает в любом режиме. Сам агент папку открыть
  не может — он подаёт просьбу рукой `mount_request` («зачем» одной строкой,
  читает владелец), решение принимает человек. В «Настройках» для этого есть
  карточка «Монтирование»: список открытых папок, добавление и снятие, просьбы
  агента с кнопками «открыть» и «отказать». Просьбы копятся в
  `data/memory/.state/mounts.json`, отказы переживают перезапуск
  (`sandbox.mounts_denied`).
- **Про окна сказано честно.** «В песочнице агент видит и водит окна» —
  наполовину правда, и вторая половина важнее: ограда до руки окон действительно
  не достаёт, но тела под ней в поставке нет ни в одном режиме, порт UIA не
  сделан. Рука `computer` теперь отвечает об этом по-русски и прямо, вместо
  английского «token is not configured», которое читалось как «поправь
  настройку».
- Конституция и навыки агента научились говорить о режимах по-новому: навык
  `fence-and-broker` (ограда и служба — два разных вопроса; как узнать свою
  ограду; чего ограда не держит; как попросить права). Он заменил `three-modes`
  из первой редакции этой же волны — тот описывал три режима и прямо говорил
  агенту «позвать брокера я не могу». Поправлены границы файловых рук в
  конституции и в `home-map`.
- Документы: `ОБНОВЛЕНИЕ.md` больше не предлагает снимать службу правой кнопкой
  по `uninstall-service.ps1` (этот путь прав администратора не даёт) и не
  относит порт к полям визарда — визард его не переписывает. Из
  `КАК-УСТРОЕН-HELENE.md` убран запрет сохранять «Настройки» при локальной
  модели: и установщик, и окно кладут туда одну и ту же заглушку ключа, обходить
  больше нечего.
- Документы под уточнённую модель: `README.md`, `КАК-УСТРОЕН-HELENE.md`
  (`resources/HELENE-MAP.md`), `docs/КАРТА-ДЕРЕВА.md` и `ОБНОВЛЕНИЕ.md` больше
  не знают «трёх режимов» и разводят ограду и службу в два ответа. Из них убран
  ручной шаг возврата прав после снятия службы — его теперь делает сама команда
  `uninstall`. Оба документа задачи (`docs/РЕЖИМЫ-И-БРОКЕР.md` и заменённый им
  `docs/БРОКЕР-ПРАВ.md`) оставлены как летопись, но с поправкой в шапке: читать
  по ним устройство режимов нельзя.

## 0.2.1 — 2026-09-03

- Имя пишется по-французски: Hélène в заголовках, установщике, окне, иконке,
  конституции и уведомлениях. Латиницей — имена файлов и папок (helene.exe,
  helene.json, Programs\Helene), имя службы в системе и адрес репозитория.
  Ещё не везде: во внутренних расписках харнесса — тех, что читает сам агент, —
  остаются прежние имена «Frame» и «Пульт». Перечень открытых мест — в
  docs/PLAN.md.
- Модели по умолчанию: gpt-5.6-sol для подписки ChatGPT, glm-5.3 для
  Anthropic-совместимого провайдера (пресет Z.ai — первым).
- Занятый порт разбирается, а не проглатывается: если его держит тот же
  харнесс (то же дерево), окно просто становится его клиентом; если чужая
  программа — окно к ней НЕ подключается вовсе. Адрес чужого харнесса в окно
  не попадает: вместо переписки открывается экран «порт держит другая
  установка Hélène» с адресом её дерева и кнопкой «Перезапустить». Чужая
  память, чужие чаты и чужая конституция остаются чужими.
- Связь окна с агентом закрыта ключом. Секрет заводится при первом запуске и
  лежит в данных агента (`memory/.state/desk-token`); его предъявляют окно,
  служба и телефон. Раньше полный доступ к переписке, ключам моделей и записи
  в конституцию получал любой процесс на этой машине — включая программы
  другой учётной записи Windows. Побочное: открыть `http://127.0.0.1:<порт>`
  в браузере теперь можно только с `?key=<секрет из этого файла>`.
- «Собрать логи для поддержки»: ключи, токены и строки Bearer в тексте
  закрываются при сборке архива, перед отправкой программа показывает список
  того, что в него попало, и удаляет прошлые архивы из временной папки.
- Ключ модели не уезжает по переадресации: проверка адреса и проверка
  обновлений больше не идут по 30x — ни в окне, ни в установщике; разбор
  адреса («по http — только к себе») появился и в установщике тоже.
- Конфигурационная ошибка больше не лечится вечным перезапуском: когда агент
  выходит с кодом «виноват конфиг» или «нет папки с кодом», программа говорит
  причину человеческими словами и ждёт решения владельца.

## 0.2.0 — 2026-09-03, продукт назван Hélène

- Имя продукта — Hélène. Файлы, папка, служба,
  идентификатор уведомлений и архив переименованы: helene.exe, helene-setup.exe,
  helene-svc.exe, helene-relay.exe, helene.json, Programs\Helene, Helene.zip.
- Имя агента больше не подменяет имя продукта: заголовок окна, ярлыки, значок у
  часов и уведомления — Hélène; агент — только там, где говорит агент.
- Текст установщика — словами автора; первый запуск для агента — «осмотреться
  и познакомиться»; конституция переписана: стержень из пяти положений,
  характер растёт из дел.
- Модель: провайдер «Anthropic API» (Anthropic, Z.ai и совместимые) со своим
  протоколом проверки; список моделей реле ChatGPT берётся из самого реле
  (gpt-5.4 по умолчанию, gpt-5.2 реле не знало); усилие рассуждения —
  отдельным селектором.
- Снятие — визард в стиле установщика с выбором судьбы данных; тихое снятие
  из командной строки сохранено.
- При установке не мелькают окна консоли: служба ставится скрытым процессом.
- Разделы окна названы нейтрально: Чат, Задачи, Контекст, Файлы, Журнал,
  Система; панель справа — Действия.

## 0.1.0 — 2026-09-03, первый выпуск

Vera — рантайм для создания агента на Windows.

- Установщик с motion-сценами: имя агента и владельца, конституция (правится
  и принимается на старте), откуда приходит модель (ключ API, подписка ChatGPT
  через встроенное реле, локальная модель) с проверкой адреса и выбором модели
  из списка, Telegram-бот, служба Windows. Тихая установка и снятие из
  командной строки, запись в «Приложениях».
- Окно: разговор с агентом, планы, кадр, файлы (правка на месте), журнал,
  устройство, настройки. Панели сворачиваются как в IDE. Единая модель
  состояния в шапке, ошибки на месте, уведомления Windows словом агента,
  закрытие в трей, первый запуск как первый ход агента.
- Оболочка надзирает за процессами: упавший руннер поднимается снова, дети
  живут ровно столько, сколько окно; логи детей и сбор логов для поддержки.
- Телефон: страница с того же адреса, спаривание по QR двухразовым кодом (для
  iPhone), доступ по Wi-Fi или через Tailscale. Сквозной прогон с телефона не
  пройден; слово «PWA» снято — service worker'а нет, значит нет ни установки
  как приложения, ни офлайна.
- Telegram своим аккаунтом (MTProto) в дополнение к боту.
- Песочница v1: рука shell в AppContainer Windows, файловые руки внутри папки
  Vera.
- Проверка обновлений по адресу GitHub Releases, без подмены файлов.
- Иконка с именем агента, создаётся при установке. Тема как в Windows.
- Лицензия Apache 2.0; лицензии сторонних частей в поставке.

Известные границы: подписи кода нет (SmartScreen спросит один раз); поставка
— zip, а не один exe; переменные окружения харнесса внутренние; телефон вне
Wi-Fi — только через Tailscale.

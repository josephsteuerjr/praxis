"""Owner controls and lifecycle hooks for Forge-backed source review."""
from __future__ import annotations

import base64
import json
from functools import lru_cache
import logging
import math
from pathlib import Path
import re
import time
import uuid

from localharness import self_review


log = logging.getLogger("helene.self-review")
SCHEMA = "helene.self-review.status.v1"
ACTIONS = {"request", "cancel", "disposition"}
DECISIONS = {"accepted", "fix", "deferred", "continue-with-reason"}
SUBJECT_SCHEMA = {"type": "object", "additionalProperties": False, "properties": {
    "kind": {"type": "string", "enum": ["plan", "change", "task_result"]},
    "task_id": {"type": "string"}, "question": {"type": "string"},
    "criteria": {"type": "array", "items": {"type": "string"}},
    "text": {"type": "string", "description": "plan: exact authored plan text"},
    "assignment": {"type": "string", "description": "task_result: original assignment"},
    "answer": {"type": "string", "description": "task_result: exact answer, not a summary substituted later"},
    "observed_effects": {"type": "array", "items": {"type": "string"}, "description": "author claims, not host attestations"},
    "checks": {"type": "array", "items": {"type": "string"}, "description": "author claims; attach exact evidence as materials"},
    "materials": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {
        "name": {"type": "string", "description": "logical name, same on both change sides"},
        "side": {"type": "string", "enum": ["base", "candidate", "context"]},
        "root": {"type": "string", "enum": ["workspace", "agent", "app"]},
        "path": {"type": "string", "description": "explicit relative UTF-8 file; no memory/config/credentials or links"},
        "sha256": {"type": "string", "description": "exact bytes; absent material omits SHA"},
        "exists": {"type": "boolean"}}, "required": ["name", "root", "path"]}}},
    "required": ["kind", "question", "criteria"]}
TOOL = {
    "name": "self_review",
    "description": "Voluntary independent Forge review: choose your question, criteria, materials and depth when criticism helps. Ordinary work may finish without review or a skip ritual. Omit subject for legacy source-only review; otherwise freeze typed plan (text), change (matching base/candidate material refs, explicit absences), or task_result (assignment/exact answer/artifacts/effect and check claims). All refs require exact SHA and remain owner-only; no ambient memory or execution. For conflict updates use source_update and its strict full-battery panel, never ordinary disposition. Verdicts and author decisions stay separate; source/material clear is not installed proof. Owner dialogue only.",
    "input_schema": {"type": "object", "properties": {
        "action": {"type": "string", "enum": ["status", "request", "cancel", "disposition"]},
        "id": {"type": "string"}, "depth": {"type": "string", "enum": list(self_review.DEPTHS)},
        "intent": {"type": "string"}, "decision": {"type": "string", "enum": sorted(DECISIONS)},
        "retry": {"type": "boolean"},
        "critics": {"type": "integer", "minimum": 1, "maximum": 8,
                    "description": "ordinary request: choose critic count on existing configured voice models; default follows policy/depth"},
        "subject": SUBJECT_SCHEMA,
        "reason": {"type": "string"}, "subject_sha256": {"type": "string"}},
        "required": ["action"]},
}


def _root(tree):
    return Path(tree) / "memory" / ".self-review"


def _read(path):
    return self_review._read(path) or {}


def command(tree, body):
    if not isinstance(body, dict) or body.get("action") not in ACTIONS:
        raise ValueError("action must be request, cancel or disposition")
    value = {key: body[key] for key in
             ("action", "id", "depth", "intent", "decision", "reason", "subject_sha256", "retry", "subject", "critics") if key in body}
    if 'critics' in value and (value['action'] != 'request' or type(value['critics']) is not int or not 1 <= value['critics'] <= 8):
        raise ValueError('critics must be 1..8 for a review request')
    if 'subject' in value:
        if value['action'] != 'request' or value.get('intent'):
            raise ValueError('typed subject belongs to request and supplies its own question')
        from localharness.self_review_subjects import normalize
        value['subject'] = normalize(value['subject'])
    if "retry" in value and not isinstance(value["retry"], bool):
        raise ValueError("retry must be a boolean")
    if value.get("depth") is not None and value["depth"] not in self_review.DEPTHS:
        raise ValueError("depth must be quick, normal or deep")
    for key in ("id", "intent", "decision", "reason", "subject_sha256"):
        if key in value and (not isinstance(value[key], str) or len(value[key]) > 12000):
            raise ValueError(key + " must be text of at most 12000 characters")
    if value["action"] != "request" and not re.fullmatch(r"review-[0-9a-f]{16}", value.get("id", "")):
        raise ValueError("review id required")
    if value["action"] == "disposition":
        if (value.get("decision") not in DECISIONS or not value.get("reason", "").strip()
                or not re.fullmatch(r"[0-9a-f]{64}", value.get("subject_sha256", ""))):
            raise ValueError("disposition, reason and exact subject_sha256 required")
    command_id = "command-" + uuid.uuid4().hex
    self_review._write(_root(tree) / "commands" / (command_id + ".json"),
                       {**value, "command_id": command_id, "created": time.time(), "state": "queued"})
    return {"ok": True, "command_id": command_id, "state": "queued"}


@lru_cache(maxsize=256)
def _activity_counts(path, modified, size):
    row = _read(Path(path))
    if row.get("cancel_requested") or row.get("execution") not in {"queued", "running"}:
        return 0, 0
    critics = row.get("critics") or []
    return (sum(c.get("execution") in {"starting", "running", "finishing"} for c in critics),
            sum(c.get("execution") == "queued" for c in critics))


def activity(tree,review_cursor='',review_limit=20):
    """Small read-only projection; stale coordinator records cannot light the badge."""
    root = _root(tree)
    running = queued = 0
    from .source_update_activity import activity as update_activity
    try:update=update_activity(tree)
    except (OSError,ValueError,KeyError,TypeError):update=None
    after=None
    if review_cursor:
        try:
            after=json.loads(base64.urlsafe_b64decode(review_cursor.encode('ascii')).decode('utf8'))
            if (not isinstance(after,list) or len(after)!=2 or isinstance(after[0],bool)
                    or not isinstance(after[0],(int,float)) or not math.isfinite(after[0])
                    or not isinstance(after[1],str) or len(after[1])>512):raise ValueError()
            after=tuple(after)
        except (ValueError,TypeError,UnicodeError):raise ValueError('Invalid reviewer cursor') from None
    limit=min(max(int(review_limit),1),100)
    reviewers=[];recent=[]
    terminal={'done','completed','error','failed','cancelled','stopped','unavailable'}
    now = time.time()
    for store in (root, root.with_name(".source-update-reviews")):
        for path in store.glob("review-*/request.json"):
            try:
                stat = path.stat()
                fresh=-5 <= now - stat.st_mtime < 30
                row=_read(path)
                selected=bool(update and row.get('id')==update.get('review_id'))
                active, waiting = _activity_counts(str(path), stat.st_mtime_ns, stat.st_size)
                if fresh:
                    running += active
                    queued += waiting
                for critic in row.get('critics',[]):
                    unit=critic.get('unit_id');execution=critic.get('execution','unknown')
                    if not isinstance(unit,str) or not unit.strip():continue
                    finished=execution in terminal
                    if not finished and not selected and (not fresh or row.get('execution') not in {'queued','running'}):continue
                    focus={'integration':'Ревью интеграции','adversarial':'Критик'}.get(critic.get('focus'),'Ревьюер')
                    record={'id':str(row.get('id',''))+'/'+unit,'unit_id':unit,'task_id':row.get('task_id'),
                        'name':critic.get('name') or focus,'model':critic.get('model_actual') or critic.get('model') or '',
                        'review_id':row.get('id'),'execution':critic.get('execution','unknown'),
                        'live':not finished and not row.get('cancel_requested') and fresh and critic.get('execution') in {'starting','running','finishing'},
                        'cancel_requested':bool(row.get('cancel_requested')),
                        'observed_at':stat.st_mtime,'started_at':critic.get('started_at'),'finished_at':critic.get('finished_at'),
                        'verdict':critic.get('verdict'),'summary':str(critic.get('summary') or critic.get('reason') or '')[:4000],
                        'findings':critic.get('findings',[])[:50]}
                    if finished:
                        at=record['finished_at']
                        if not isinstance(at,(int,float)) or isinstance(at,bool) or not math.isfinite(at):at=stat.st_mtime
                        record['finished_at']=at;recent.append(record)
                    else:reviewers.append(record)
            except (OSError, ValueError, TypeError, AttributeError):
                continue
    key=lambda record:(record['finished_at'],record['id'])
    recent.sort(key=key,reverse=True)
    if after is not None:recent=[record for record in recent if key(record)<after]
    page=recent[:limit]
    cursor=(base64.urlsafe_b64encode(json.dumps(key(page[-1])).encode()).decode('ascii') if len(recent)>limit else None)
    return {"running": running, "queued": queued,'reviewers':reviewers,'update':update,
        'recent_reviewers':page,'recent_reviewers_cursor':cursor}


def status(tree, config=None, review_id=""):
    root = _root(tree)
    runtime = _read(root / "runtime.json")
    reviews = [_read(path) for store in (root, root.with_name('.source-update-reviews'))
               for path in store.glob("review-*/request.json")]
    if review_id:
        reviews = [row for row in reviews if row.get("id") == review_id]
    commands = [_read(path) for path in (root / "commands").glob("command-*.json")]
    fresh = 0 <= time.time() - float(runtime.get("at") or 0) < 15
    capability = {"supported": runtime.get("supported", False),
                  "available": fresh and bool(runtime.get("supported")),
                  "reason": runtime.get("reason") or "Runner has not published self-review capability."}
    return {"schema": SCHEMA, "settings": self_review.settings((config or {}).get("self_review", {})),
            "reviews": sorted(reviews, key=lambda row: row.get("created", 0), reverse=True),
            "commands": sorted(commands, key=lambda row: row.get("created", 0), reverse=True),
            "capability": capability, "runtime": runtime}


class Integration:
    def __init__(self, tree, code_dir, app_root, forge, config_path, agent):
        self.tree, self.code_dir, self.app_root = map(Path, (tree, code_dir, app_root))
        self.config_path, self.agent = Path(config_path), agent
        self.service = self_review.Service(tree, code_dir, app_root, forge,
                                          self._config().get("self_review", {}))
        self.seen_config = None
        self.next_tick = 0.0
        self._settled_commands = {}

    def _config(self):
        from localharness import boot
        value = json.loads(boot.read_config_text(self.config_path))
        if not isinstance(value, dict):
            raise ValueError("helene.json must be an object")
        return value

    def install(self):
        if getattr(self.agent, "SELF_EDIT_REVIEW_API", 0) == 1:
            self.agent.SELF_EDIT_REVIEW_HOOK = self.after_self_edit
        tools, impl = getattr(self.agent, "BASE_TOOLS", None), getattr(self.agent, "TOOL_IMPL", None)
        if isinstance(tools, list) and isinstance(impl, dict):
            def hand(action="status", **body):
                context = getattr(self.agent, "_TURN_CHANNEL", None)
                channel = context.get() if context is not None else None
                if channel is None or not getattr(channel, "owner", False):
                    return "Self-review controls are available only in an owner dialogue."
                try:
                    if action == "status":
                        result = status(self.tree, self._config(), str(body.get("id") or ""))
                    else:
                        result = command(self.tree, {**body, "action": action})
                    return json.dumps(result, ensure_ascii=False)
                except (OSError, ValueError) as exc:
                    return "Self-review request not saved: " + str(exc)
            impl[TOOL["name"]] = hand
            if not any(row.get("name") == TOOL["name"] for row in tools if isinstance(row, dict)):
                tools.append(TOOL)
            purposes = getattr(self.agent, "HAND_PURPOSE", None)
            if isinstance(purposes, dict):
                purposes[TOOL["name"]] = "voluntary independent source/plan/change/task_result criticism with exact frozen evidence"
        self.publish()
        return self

    def publish(self, error=""):
        supported = getattr(self.service.forge, "SELF_REVIEW_API", 0) == 1
        hook = getattr(self.agent, "SELF_EDIT_REVIEW_API", 0) == 1
        reason = ("Voluntary frozen source/plan/change/task_result Forge review; installed/runtime checks remain separate." if supported
                  else "Selected preserved Forge lacks self-review API v1; shipped stock code is not the executing code.")
        self_review._write(_root(self.tree) / "runtime.json", {
            "at": time.time(), "supported": supported, "self_edit_supported": hook,
            "source_update_supported": supported and getattr(self.service.forge, 'SOURCE_UPDATE_API', 0) == 1,
            "app_root": str(self.app_root.resolve()),
            "reason": reason, "code": str(self.code_dir), "error": error,
            "self_edit_note": "hook installed" if hook else "Selected agent lacks self-edit review callback API v1."})

    def after_self_edit(self, sha, message, paths):
        source_paths = [str(path) for path in paths if self_review._code_file(Path(path))
                        and not any(part.lower() in self_review.EXCLUDED for part in Path(path).parts)]
        if not source_paths:
            return None
        sources = {"agent": self.code_dir, "app": self.app_root / "app"}
        if any((self.tree / path).is_file() for path in source_paths):
            sources["home_code"] = self.tree
        return self.service.request(trigger="after_self_edit", operation_id=str(sha or ""),
                                    intent=str(message), criteria=["Inspect self-edited source: " + ", ".join(source_paths)],
                                    sources=sources)

    def _overlay_sources(self, overlay):
        if not overlay.get("conflicts"):
            return {}, overlay
        try:
            raw_folder = str(overlay.get("folder") or "")
            folder = Path(raw_folder)
            if (folder.is_absolute() or not folder.parts or folder.parts[0] != "workspace"
                    or ".." in folder.parts or ":" in raw_folder or "\\" in raw_folder):
                raise ValueError("conflict materials must name a relative workspace folder")
            materials = self.tree / folder
            if not materials.resolve().is_relative_to((self.tree / "workspace").resolve()):
                raise ValueError("conflict materials escaped the selected home")
            if not isinstance(overlay["conflicts"], list):
                raise ValueError("conflicts must be an exact path list")
            sources = {}
            for index, row in enumerate(overlay["conflicts"]):
                name = row.get("path") if isinstance(row, dict) else None
                if not isinstance(name, str):
                    raise ValueError("conflict path missing")
                relative = Path(name)
                if (relative.is_absolute() or len(relative.parts) < 2 or relative.parts[0] not in {"tree", "app"}
                        or ".." in relative.parts or ":" in name or "\\" in name):
                    raise ValueError("conflict path outside selected source roots")
                kind = relative.parts[0]
                logical = Path(*relative.parts[1:]).as_posix()
                # A private conflict is still a required review request, but
                # never a model input. Convert it to an evidence gap here,
                # before explicit source collection can reject the request.
                self_review._relative_code_name(logical)
                for side, suffix in (("base", "base"), ("mine", "mine"), ("release", "theirs")):
                    sources[f"{side}-{index}"] = {"root": materials / kind,
                                                  "files": {logical: logical + "." + suffix}}
                root = self.code_dir if kind == "tree" else self.app_root / "app"
                sources[f"resolved-{index}"] = {"root": root, "files": {logical: logical}}
            return sources, overlay
        except (OSError, ValueError) as exc:
            return {}, {**overlay, "materials_error": str(exc)}

    def observe_update(self, receipt):
        if not isinstance(receipt, dict) or not (receipt.get("kind") == "package" or receipt.get("state") == "done"):
            return None
        operation = "update:" + str(receipt.get("id") or "") + ":" + str(receipt.get("state") or "")
        observed_path = _root(self.tree) / "updates.json"
        observed = _read(observed_path)
        if operation in observed:
            return None
        if any(operation in row.get("operations", []) for row in self.service.status()):
            return None
        overlay = receipt.get("agent_code") or {}
        if not isinstance(overlay, dict):
            overlay = {"materials_error": True}
        if overlay.get("skipped"):
            overlay = {**overlay, "skipped_code": overlay["skipped"]}
        intent = "Inspect update " + str(receipt.get("from_version") or "unknown") + " -> " + str(receipt.get("to_version") or "unknown")
        sources = {"agent": self.code_dir, "app": self.app_root / "app"}
        stock = self.app_root / "tree"
        if stock.is_dir() and stock.resolve() != self.code_dir.resolve():
            sources["release_agent"] = stock
        sides, overlay = self._overlay_sources(overlay)
        sources.update(sides)
        result = self.service.request(trigger="after_update", operation_id=operation,
                                      overlay=overlay, intent=intent, sources=sources,
                                      criteria=["Check integration of the release with retained agent edits; report unverified inputs."])
        observed[operation] = {"state": result.get("state"), "review_id": result.get("id"), "at": time.time()}
        self_review._write(observed_path, observed)
        return result

    def observe_updates(self):
        from deskd import control
        self.observe_update(_read(self.tree / "memory" / ".control" / control.UPDATE_RECEIPT))
        self.observe_update(_read(self.tree / "memory" / ".state" / "package-update.json"))

    def tick(self, paused=False):
        if time.monotonic() < self.next_tick:
            return
        self.next_tick = time.monotonic() + 5
        try:
            stamp = self.config_path.stat().st_mtime_ns
            if stamp != self.seen_config:
                self.service.settings(self._config().get("self_review", {}))
                self.seen_config = stamp
            self.observe_updates()
            for path in sorted((_root(self.tree) / "commands").glob("command-*.json")):
                stamp = path.stat()
                signature = (stamp.st_mtime_ns, stamp.st_size)
                if self._settled_commands.get(path) == signature:
                    continue
                asked = _read(path)
                if asked.get("state") != "queued":
                    if asked.get('state') in {'done','error'}:
                        self._settled_commands[path] = signature
                    continue
                try:
                    action = asked["action"]
                    if action == "request":
                        record = next((row for row in self.service.status()
                                       if asked["command_id"] in row.get("operations", [])), None)
                        if record is None:
                            record = self.service.request(operation_id=asked["command_id"],
                                                          depth=asked.get("depth"), intent=asked.get("intent", ""),
                                                          retry=asked.get("retry", False), subject=asked.get('subject'),
                                                          critics=asked.get('critics'))
                    elif action == "cancel":
                        record = self.service.cancel(asked["id"])
                    else:
                        record = self.service.disposition(asked["id"], asked["decision"], asked["reason"], asked["subject_sha256"])
                    asked.update(state="done", review_id=record.get("id"), at=time.time())
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    asked.update(state="error", error=str(exc), at=time.time())
                self_review._write(path, asked)
                stamp = path.stat()
                self._settled_commands[path] = (stamp.st_mtime_ns, stamp.st_size)
            self.service.tick(paused=paused)
            self.publish()
        except (OSError, ValueError, TypeError) as exc:
            log.exception("self-review maintenance failed; startup and Stop remain independent")
            self.publish(error=str(exc))

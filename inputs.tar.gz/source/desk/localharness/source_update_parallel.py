"""Twelve private battery slots; recipe coverage stays owned by the full gate."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import ast
import hashlib
import logging
import os
import queue
from pathlib import Path
import shutil
import stat
import threading
import time

from .package_notice import read,write


def _publish_progress(path, value):
    """Telemetry can stay stale while a Windows reader holds the old snapshot.

    The atomic writer already retries briefly and preserves the previous file.
    Lane results, source bindings and final receipts still use strict writes.
    A later publication carries current counters; this never creates a result.
    """
    try:
        write(path,value)
    except PermissionError as exc:
        if getattr(exc,'winerror',None) not in (5,32,33):raise
        logging.getLogger(__name__).warning('Battery progress publication deferred: %s',exc)


def live_progress(work,cache,slot,active):
    """Read only the current command's telemetry; it never grants approval."""
    if active.get('phase')!='running' or not active.get('lane'):return {}
    row=read(Path(work)/('slot-'+str(slot))/'test-progress.json')
    identity=hashlib.sha256(active['lane'].encode()).hexdigest()[:20]
    expected=str((Path(cache)/(identity+'.cases.json')).resolve())
    if row.get('format')!='helene-test-progress.v1' or row.get('report')!=expected:return {}
    completed,failed,collected=(row.get(key) for key in ('tests_completed','tests_failed','tests_collected'))
    if any(type(n) is not int or n<0 for n in (completed,failed)):return {}
    if collected is not None and (type(collected) is not int or collected<completed):return {}
    return {'tests_completed':completed,'tests_failed':failed,'tests_collected':collected,
            'current_test':row.get('current_test') if isinstance(row.get('current_test'),str) else '',
            'test_phase':row.get('phase')}


def policy(operation):
    workers=(operation.get('verification_executor') or {}).get('parallel_lanes',12)
    if type(workers) is not int or not 1<=workers<=12:
        raise ValueError('parallel_lanes must be an integer from 1 through 12')
    return {'version':4,'workers':workers,'preparation_workers':min(workers,2),'input_strategy':'windows-protected-attempt-base;otherwise-private','isolation':'private-slot-source-home-dependencies-caches',
            'dispatch':'next-free-private-slot;ordered-build-chains',
            'quiescent':'after-all-parallel-command-groups-settle;fresh-private-copy',
            'core_sharding':'flat-module-before-import;legacy-package-case-id','dependencies':'npm-chain;cargo-chain;declared-shared-native-quiescent',
            'scheduler_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def shared_native_session(binding):
    # The pure hands CLI has per-call base/receipt paths in each private slot.
    # Desktop/body/display inputs share a live session and remain serialized.
    env = binding['executor'].get('native_inputs', {}).get('native_env', {})
    return bool(set(env) - {'PRAXIS_HANDS','HELENE_HOST_BINARY'})


def native_scope(lane,env,native_inputs):
    """Unannotated commands have private CLI hands, never shared desktop inputs."""
    from .source_verification_bundle import SHARED_NATIVE_INPUTS
    requested=lane.get('native_inputs',[])
    if (not isinstance(requested,list) or any(not isinstance(key,str) or key not in SHARED_NATIVE_INPUTS for key in requested)
            or len(requested)!=len(set(requested))):raise ValueError('Invalid lane native capabilities')
    if 'HELENE_BODY_BIN' in requested and 'HELENE_BODY_DIR' not in requested:
        raise ValueError('Native body capability requires its declared directory')
    scoped=dict(env)
    for key in SHARED_NATIVE_INPUTS:scoped.pop(key,None)
    if native_inputs is None:
        if any(key in env for key in requested):raise ValueError('Shared native capability has no bound executor inputs')
        return scoped,None
    allowed={'PRAXIS_HANDS','HELENE_HOST_BINARY',*requested}
    selected={key:value for key,value in native_inputs.get('native_env',{}).items() if key in allowed}
    scoped.update(selected)
    keep={str(Path(selected[key]).resolve()) for key in ('PRAXIS_HANDS','HELENE_HOST_BINARY') if key in selected}
    if 'HELENE_BODY_DIR' in selected:
        base=Path(selected['HELENE_BODY_DIR']);suffix='.exe' if os.name=='nt' else ''
        keep.update(str((base/(prefix+'-'+kind+suffix)).resolve()) for prefix in ('helene','praxis') for kind in ('body','bridge'))
    pins={path:digest for path,digest in native_inputs.get('native_files',{}).items() if path in keep}
    return scoped,{'native_env':selected,'native_files':pins}


def _check(stopped):
    if stopped():raise InterruptedError('Owner stopped update battery')


def _fresh_check(stopped,abort):
    """Latch a fresh Stop or unreadable control before any sibling can admit."""
    _check(abort.is_set)
    try:
        if stopped():abort.set()
    except BaseException:
        abort.set()
        raise
    _check(abort.is_set)


def _cancellation(stopped,abort):
    """Share a20ms durable-control poll interval across the private file slots.

    File/chunk checkpoints stay cheap; each command still admits against a fresh
    owner read. A positive observation is latched for this one battery attempt.
    """
    lock=threading.Lock();last=-float('inf')
    def observe():
        nonlocal last
        if abort.is_set():return True
        if time.monotonic()-last>=.02:
            with lock:
                if not abort.is_set() and time.monotonic()-last>=.02:
                    try:
                        if stopped():abort.set()
                    except BaseException:
                        abort.set()
                        raise
                    last=time.monotonic()
        return abort.is_set()
    return observe


def _copy(source,target,stopped,progress=None):
    """No links/shared writable inodes; cancellation is checked per chunk."""
    source,target=Path(source),Path(target)
    _check(stopped)
    info=source.lstat()
    if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:
        raise ValueError('Linked battery input root: '+str(source))
    for directory,dirs,names in os.walk(source):
        _check(stopped);here=Path(directory)
        for name in [*dirs,*names]:
            entry=here/name;info=entry.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:
                raise ValueError('Linked battery input: '+str(entry))
        destination=target/here.relative_to(source);destination.mkdir(parents=True,exist_ok=True)
        for name in names:
            _check(stopped)
            copied=0
            with (here/name).open('rb') as src,(destination/name).open('xb') as dst:
                while chunk:=src.read(1024*1024):
                    _check(stopped);dst.write(chunk);copied+=len(chunk)
            shutil.copystat(here/name,destination/name)
            if progress:progress(copied,1)


def inventory(battery,root,stopped,expected=None):
    rows={};root=Path(root)
    for directory,dirs,names in os.walk(root):
        _check(stopped);here=Path(directory)
        dirs[:]=sorted(name for name in dirs if name not in battery.bundle.EXCLUDED)
        for name in [*dirs,*sorted(names)]:
            _check(stopped);path=here/name;info=path.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('Linked verification input')
            if not path.is_file():continue
            digest=hashlib.sha256()
            with path.open('rb') as stream:
                while chunk:=stream.read(1024*1024):_check(stopped);digest.update(chunk)
            row={'sha256':digest.hexdigest(),'size':info.st_size,
                'mode':'100755' if info.st_mode&0o111 and os.name!='nt' else '100644'}
            name=path.relative_to(root).as_posix()
            if expected is None:
                if battery.bundle.python_framework(path)=='pytest':row['framework']='pytest'
                native=battery.bundle.python_native_inputs(path)
                if native is not None:row['native_inputs']=native
            else:
                # The full current composition was already classified before
                # spawning slots. Reuse its annotations ONLY after independently
                # hashing every byte, size and mode of this private copy.
                prior=expected.get(name,{})
                if all(prior.get(key)==value for key,value in row.items()):
                    for key in ('framework','native_inputs'):
                        if key in prior:row[key]=prior[key]
            rows[name]=row
    return rows


def groups(lanes,workers,external_native=False):
    if len({row['id'] for row in lanes})!=len(lanes):raise ValueError('Duplicate battery lane identity')
    count=1 if external_native else workers
    result=[[] for _ in range(count)]
    turn=0
    for index,lane in enumerate(lanes):
        if lane.get('isolation')=='quiescent':continue
        # Flat discovery can partition source modules before importing them.
        # Package/load_tests traversal keeps legacy whole-discovery semantics.
        sources=lane.get('sources',[])
        flat=(not lane.get('_legacy_discovery') and sources and all(name.startswith(lane.get('root','live')+'/')
              and name.count('/')==1 for name in sources))
        if lane['kind']=='unittest' and count>1:
            for shard in range(count):
                part={**lane,'id':lane['id']+'/shard-'+str(shard),
                      '_shard_index':shard,'_shard_count':count}
                if flat:
                    part['_module_sources']=sorted(sources)[shard::count]
                    part['_all_module_sources']=sorted(sources)
                result[shard].append((index,part))
        else:
            slot=(0 if lane['kind'] in {'npm-prepare','npm-build','node'} else
                  min(1,count-1) if lane['kind'] in {'cargo','cargo-build'} else turn%count)
            if lane['kind']=='unittest' and flat:lane={**lane,'_module_sources':sorted(sources)}
            result[slot].append((index,lane));turn+=1
    return [group for group in result if group]


def aggregate(lane,parts):
    if len(parts)==1 and '_shard_index' not in parts[0][0]:return parts[0][1]
    parts.sort(key=lambda pair:pair[0]['_shard_index'])
    rows=[row for _,row in parts];observations=[row.get('observation') or {} for row in rows]
    expected=observations[0].get('discovered')
    collected=[case for observed in observations for case in observed.get('collected',[])]
    if '_module_sources' in parts[0][0]:
        modules=[name for part,_ in parts for name in part['_module_sources']]
        required=parts[0][0]['_all_module_sources']
        complete=(Counter(modules)==Counter(required)
            and all(part.get('_all_module_sources')==required
                    and observed.get('module_sources')==part['_module_sources']
                    for (part,_),observed in zip(parts,observations))
            and len(parts)==parts[0][0]['_shard_count']
            and all(observed.get('complete') and observed.get('coverage_complete') for observed in observations))
        expected=collected
    else:
        complete=(expected is not None and all(observed.get('discovered')==expected for observed in observations)
            and len(parts)==parts[0][0]['_shard_count'] and Counter(collected)==Counter(expected)
            and all(observed.get('complete') and observed.get('coverage_complete') for observed in observations))
    observation={'collected':expected or collected,'complete':complete,'coverage_complete':complete,
        'tests_run':sum(row.get('tests_run',0) for row in observations)}
    for name in ('executed','skipped_before_start','outcomes'):
        observation[name]=[case for observed in observations for case in observed.get(name,[])]
    passed=complete and all(row.get('status')=='passed' and row.get('exit')==0 for row in rows)
    failure=next((row for row in rows if row.get('status')!='passed'),{})
    return {'id':lane['id'],'kind':lane['kind'],'status':'passed' if passed else failure.get('status','failed'),
        'reason':failure.get('reason','' if complete else 'Shard discovery/coverage differs'),
        'exit':0 if passed else 1,'observation':observation,'shards':rows,
        'logs':{name:digest for row in rows for name,digest in row.get('logs',{}).items()}}


def package_discovery(files,read_source,root='live'):
    """Only inert package initializers permit per-file discovery replay.

    An executable initializer may define/import load_tests dynamically. Keep the
    original whole traversal for it, not an incident-specific hook-name guess.
    """
    prefix=root+'/'
    for name in files:
        if not name.startswith(prefix) or not name.endswith('/__init__.py') or name==prefix+'__init__.py':continue
        try:body=ast.parse(read_source(name),filename=name).body
        except (SyntaxError,UnicodeError):return True
        if any(not (isinstance(node,ast.Pass) or isinstance(node,ast.Expr)
            and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str)) for node in body):return True
    return False


def execution_lanes(lanes,repository,actual_files):
    """Read scheduling constraints from exact frozen test bytes, without
    changing the logical recipe schema understood by older update preparers.
    """
    result=[]
    for lane in lanes:
        name=lane.get('source','');value=dict(lane)
        from . import source_verification_bundle as bundle
        sources=list(dict.fromkeys([*lane.get('sources',[]),*([name] if name else [])]))
        if lane.get('kind')=='unittest':
            prefix=lane.get('root','live')+'/'
            value['_legacy_discovery']=package_discovery(actual_files,lambda n:(Path(repository)/n).read_bytes(),lane.get('root','live'))
        for source in sources:
            if source not in actual_files:continue
            path=Path(repository)/source
            if path.suffix!='.py':continue
            body=path.read_bytes()
            if hashlib.sha256(body).hexdigest()!=actual_files[source]['sha256']:raise ValueError('Native capability source changed: '+source)
            native=bundle.python_native_inputs(path)
            if (native is not None)!=('native_inputs' in actual_files[source]) or native is not None and actual_files[source]['native_inputs']!=native:
                raise ValueError('Native capability metadata differs from frozen source: '+source)
        native=bundle.native_lane_inputs(actual_files,sources)
        if value.get('native_inputs',native)!=native:raise ValueError('Lane native capabilities differ from frozen source')
        if native:value.update(native_inputs=native,isolation='quiescent')
        if name.startswith('desk/tests/') and name.endswith('.py') and name in actual_files:
            body=(Path(repository)/name).read_bytes()
            if hashlib.sha256(body).hexdigest()!=actual_files[name]['sha256']:raise ValueError('Test isolation source changed: '+name)
            try:module=ast.parse(body.decode('utf-8-sig'))
            except (SyntaxError,UnicodeError):module=ast.Module(body=[],type_ignores=[])
            for node in module.body:
                if not isinstance(node,ast.Assign) or not any(isinstance(t,ast.Name) and t.id=='HELENE_TEST_ISOLATION' for t in node.targets):continue
                try:isolation=ast.literal_eval(node.value)
                except (ValueError,TypeError):raise ValueError('Test isolation must be a literal: '+name)
                if isolation!='quiescent' or value.get('isolation',isolation)!=isolation:raise ValueError('Test isolation differs from frozen source: '+name)
                value['isolation']=isolation
        result.append(value)
    return result


def run(battery,lanes,repository,actual_files,work,runner,tools,operation,cache,stopped,binding,errors,*,runtime=None,shared=None):
    from . import source_verification_python as private_python
    layout=private_python.describe(runtime,tools['python']) if runtime is not None and not errors.get('python') else None
    if layout is not None and battery.merge.signature(layout)!=binding['executor'].get('private_python_layout_sha256'):
        raise ValueError('Private Python layout differs from the exact battery binding')
    execution=execution_lanes(lanes,repository,actual_files)
    quiescent=[(i,lane) for i,lane in enumerate(execution) if lane.get('isolation')=='quiescent']
    scheduled=groups(execution,policy(operation)['workers']) or [[]]
    physical_total=sum(len(group) for group in scheduled)+len(quiescent)
    required_parts=Counter(index for group in scheduled for index,_ in group)
    required_parts.update(index for index,_ in quiescent)
    # Independent files use the next free private slot. Build chains and core
    # shards retain their explicit ordering and isolated native constraints.
    pending=queue.Queue()
    fixed=[]
    for group in scheduled:
        chain=[]
        for index,lane in group:
            if lane['kind'] in {'unittest-file','pytest-file','script','helper'}:
                pending.put((index,lane))
            else:chain.append((index,lane))
        fixed.append(chain)
    scheduled=fixed
    # Copies contain source/tests, not runtimes or models. Refuse insufficient
    # storage before making twelve dependency overlays; never silently share it.
    source_bytes=sum(row.get('size',0) for row in actual_files.values())
    dependency_bytes=sum(row.get('size',0) for row in binding['executor'].get('dependency_files',{}).values())
    executor=operation.get('verification_executor') or {}
    cache_bytes=0
    for group in scheduled:
        kinds={lane['kind'] for _,lane in group}
        needed=({'npm_config_cache'} if kinds&{'npm-prepare','npm-build','node'} else set())|({'CARGO_HOME','RUSTUP_HOME'} if kinds&{'cargo','cargo-build'} else set())
        for key in needed:
            source=Path(executor[key]) if executor.get(key) else None
            if source and source.is_dir():
                for directory,dirs,names in os.walk(source):
                    _check(stopped)
                    for name in names:cache_bytes+=(Path(directory)/name).lstat().st_size
    python_bytes=sum((Path(layout['root'])/name).stat().st_size for name in layout['files']) if layout else 0
    shared_mode=os.name=='nt' and layout is not None
    required=source_bytes*len(scheduled)+(dependency_bytes+python_bytes)*(1 if shared_mode else len(scheduled))+cache_bytes+256*1024*1024
    if shutil.disk_usage(work).free<required:
        raise OSError('Insufficient free space for isolated battery slots: '+str(required)+' bytes required')
    abort=threading.Event()
    cancelled=_cancellation(stopped,abort)
    progress_lock=threading.RLock();finished_parts=Counter();active={};last_write=0.0
    observed_tests=0;observed_failed=0;copied_bytes=0;copied_files=0
    def publish(state='running',*,force=False,error=''):
        nonlocal last_write
        now=time.monotonic()
        if not force and now-last_write<.25:return
        running=[dict(slot=slot,**value,**live_progress(work,cache,slot,value)) for slot,value in sorted(active.items())]
        _publish_progress(cache/'progress.json',{'state':state,'slots':len(scheduled),'updated_at':time.time(),
            'observation':'live scheduler; counters include only completed commands and observed tests',
            'completed':sum(finished_parts.values()),'total':physical_total,
            'completed_lanes':sum(finished_parts[i]==n for i,n in required_parts.items()),'total_lanes':len(lanes),
            'tests_completed':observed_tests+sum(row.get('tests_completed',0) for row in running),
            'tests_failed':observed_failed+sum(row.get('tests_failed',0) for row in running),'tests_total_known':False,
            'copied_bytes':copied_bytes,'copied_files':copied_files,
            'active':running,
            **({'error':error} if error else {})})
        last_write=time.monotonic()
    def copy_progress(size,files):
        nonlocal copied_bytes,copied_files
        with progress_lock:
            copied_bytes+=size;copied_files+=files;publish()
    def jobs(group):
        yield from group
        while not cancelled():
            try:yield pending.get_nowait()
            except queue.Empty:return
    with progress_lock:publish(force=True)
    shared_state=shared
    shared=work/'shared-inputs'
    shared_python=None
    shared_dependencies=None
    dependencies=(operation.get('verification_executor') or {}).get('python_dependencies')
    dependency_expected=binding['executor'].get('dependency_files')
    if shared_mode:
        identity=battery.merge.signature({'layout':layout,'dependencies':dependency_expected})
        if shared_state is not None and shared_state.get('identity'):
            if shared_state['identity']!=identity:raise ValueError('Transition immutable test inputs changed')
            shared_python=str(shared/'interpreter/python.exe')
            shared_dependencies=shared/'dependencies' if dependencies else None
            private_python.verify(layout,shared/'interpreter',cancelled)
            if shared_dependencies and inventory(battery,shared_dependencies,cancelled,expected=dependency_expected)!=dependency_expected:
                raise ValueError('Shared transition dependencies changed')
        else:
            shared.mkdir()
            shared_python=private_python.provision(layout,shared/'interpreter',cancelled,copy_progress)
            if dependencies:
                if dependency_expected is None:raise ValueError('Missing bound Python dependencies')
                shared_dependencies=shared/'dependencies'
                _copy(Path(dependencies),shared_dependencies,cancelled,copy_progress)
                if inventory(battery,shared_dependencies,cancelled,expected=dependency_expected)!=dependency_expected:
                    raise ValueError('Shared Python dependencies differ')
            from .verification_readonly import protect
            _check(cancelled);protect(shared,cache);_check(cancelled)
            if shared_state is not None:shared_state.update(identity=identity,cache=str(cache))
    preparation=threading.BoundedSemaphore(policy(operation)['preparation_workers'])
    def slot(number,group):
        nonlocal observed_tests,observed_failed
        _check(cancelled)
        private=work/('slot-'+str(number));repo=private/'repository'
        with progress_lock:
            active[number]={'phase':'preparing','started_at':time.time()};publish(force=True)
        while not preparation.acquire(timeout=.1):_check(cancelled)
        try:
            _copy(repository,repo,cancelled,copy_progress)
            if inventory(battery,repo,cancelled,expected=actual_files)!=actual_files:raise ValueError('Private source copy differs')
            env=battery._environment(private/'home',repo/'live',repo/'desk',operation)
            selected_tools=dict(tools)
            if shared_mode:
                selected_tools['python']=shared_python
                env['PYTHONHOME']=str(shared/'interpreter')
                env['HELENE_VERIFICATION_PYTHON_SDK']=str(shared/'interpreter/Lib/site-packages')
                env['HELENE_VERIFICATION_SHARED_INPUTS']=str(shared)
            elif layout is not None:
                selected_tools['python']=private_python.provision(layout,private/'interpreter',cancelled,copy_progress)
                env['PYTHONHOME']=str(private/'interpreter')
                env['HELENE_VERIFICATION_PYTHON_SDK']=str(private/'interpreter/Lib/site-packages')
            kinds={lane['kind'] for _,lane in group}
            needed=({'npm_config_cache'} if kinds&{'npm-prepare','npm-build','node'} else set())|({'CARGO_HOME','RUSTUP_HOME'} if kinds&{'cargo','cargo-build'} else set())
            for key in ('CARGO_HOME','RUSTUP_HOME','npm_config_cache'):
                source=Path(env[key]);target=private/'inputs'/key
                if key in needed and source.is_dir():_copy(source,target,cancelled,copy_progress)
                env[key]=str(target)
            dependencies=(operation.get('verification_executor') or {}).get('python_dependencies')
            if dependencies:
                source=Path(dependencies).resolve();target=shared_dependencies if shared_mode else private/'dependencies'
                expected=binding['executor'].get('dependency_files')
                if expected is None:raise ValueError('Missing bound Python dependencies')
                if not shared_mode:
                    _copy(source,target,cancelled,copy_progress)
                    if inventory(battery,target,cancelled,expected=expected)!=expected:raise ValueError('Private Python dependencies differ')
                env['PYTHONPATH']=os.pathsep.join(str(target) if part==str(source) else part for part in env['PYTHONPATH'].split(os.pathsep))
                env['HELENE_VERIFICATION_DEPENDENCIES']=str(target)
        finally:
            preparation.release()
        results=[]
        executed=[]
        for index,lane in jobs(group):
            _fresh_check(stopped,abort)  # No cached poll and no transient Stop gap.
            _check(cancelled)
            with progress_lock:
                active[number]={'phase':'running','lane':lane['id'],'kind':lane['kind'],
                    'file':lane.get('source') or lane.get('root') or lane['id'],'started_at':time.time()}
                publish(force=True)
            reason=lane.get('platform_skip',{}).get(battery.sys.platform)
            if lane['kind']=='helper':row={'id':lane['id'],'status':'support-only','reason':lane['reason']}
            elif reason:row={'id':lane['id'],'status':'platform-skip','reason':reason}
            else:
                missing=errors.get(battery._lane_tool(lane))
                if lane['kind'] in {'npm-prepare','npm-build'}:missing=missing or errors.get('node')
                if not lane['sources']:missing='Full lane sources unavailable: '+lane['id']
                if missing:row={'id':lane['id'],'status':'unavailable','reason':missing}
                else:
                    try:row=battery._run_lane(lane,repo,runner,selected_tools,env,cache,cancelled,binding['executor'].get('native_inputs'))
                    except InterruptedError:raise
                    except OSError as exc:row={'id':lane['id'],'status':'unavailable','reason':str(exc)}
            if dependencies and not shared_mode and inventory(battery,target,cancelled,expected=expected)!=expected:
                raise ValueError('Tests changed private Python dependencies')
            # Each finished lane survives a later lane/cleanup failure.
            write(cache/(hashlib.sha256(lane['id'].encode()).hexdigest()[:20]+'.lane.json'),row)
            results.append((index,lane,row))
            executed.append(lane)
            with progress_lock:
                finished_parts[index]+=1
                observation=row.get('observation') or {}
                count=observation.get('tests_run')
                if type(count) is int and count>=0:observed_tests+=count
                observed_failed+=sum(value.get('status') not in {'passed','skipped'} for value in observation.get('outcomes',[]))
                active.pop(number,None)
                publish(force=True)
        if dependencies and not shared_mode and inventory(battery,target,cancelled,expected=expected)!=expected:
            raise ValueError('Tests changed private Python dependencies')
        if not shared_mode:private_python.verify(layout,private/'interpreter',cancelled)
        changes,outputs=battery._test_copy_changes(repo,actual_files,executed,cancelled)
        with progress_lock:active.pop(number,None);publish(force=True)
        return results,[f'slot-{number}/{name}' for name in changes],[dict(row,slot=number) for row in outputs]
    results=[];changes=[];outputs=[];failures=[]
    with ThreadPoolExecutor(max_workers=policy(operation)['workers'],thread_name_prefix='helene-battery') as pool:
        pending_futures={pool.submit(slot,number,group) for number,group in enumerate(scheduled)}
        while pending_futures:
            completed,pending_futures=wait(pending_futures,timeout=2,return_when=FIRST_COMPLETED)
            with progress_lock:publish(force=True)
            for future in completed:
                try:
                    found,changed,built=future.result();results.extend(found);changes.extend(changed);outputs.extend(built)
                except BaseException as exc:abort.set();failures.append(exc)
    if failures:
        with progress_lock:publish('interrupted',force=True,error=str(failures[0]))
        # Every active child settles before cleanup; uncertain custody wins.
        raise next((exc for exc in failures if isinstance(exc,battery.CustodyUnconfirmed)),failures[0])
    _check(stopped)
    if quiescent:
        try:
            # Every parallel command and descendant has settled. Reclaim its
            # disposable copies before a fresh latency-measurement context, so
            # peak disk use does not grow to thirteen dependency overlays.
            cleanup=battery._cleanup_work(work,cache,retain_repository=True)
            if cleanup.get('state')!='slots-removed':raise OSError('Could not retire parallel test copies before quiescent checks')
            found,changed,built=slot(0,quiescent)
            results.extend(found);changes.extend(changed);outputs.extend(built)
        except BaseException as exc:
            with progress_lock:publish('interrupted',force=True,error=str(exc))
            raise
    if shared_mode:
        private_python.verify(layout,shared/'interpreter',cancelled)
        if shared_dependencies and inventory(battery,shared_dependencies,cancelled,expected=dependency_expected)!=dependency_expected:
            raise ValueError('Tests changed shared Python dependencies')
    rows=[]
    for index,lane in enumerate(lanes):rows.append(aggregate(lane,[(part,row) for i,part,row in results if i==index]))
    with progress_lock:publish('completed',force=True)
    return rows,sorted(changes),outputs

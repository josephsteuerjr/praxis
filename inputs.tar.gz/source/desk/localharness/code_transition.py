"""Prepare source merges before shutdown and apply them to independent code."""
from __future__ import annotations

import hashlib
from pathlib import Path
import tempfile
import uuid
import zipfile

from . import source_merge as merge
from .package_notice import read, write


def seal(program):
    """Keep actual release contents, not just hashes, as the next merge base."""
    program = Path(program)
    files = merge.inventory(program / 'tree')
    archive = program / 'code-upstream.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
        for name in sorted(files):
            output.write(program / 'tree' / name, name)
    write(program / 'code-upstream.json', {
        'format': 'helene-code-upstream.v1', 'files': files,
        'version': read(program / 'python-app.json').get('version', ''),
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()})


def _keep_upstream(program):
    """A verified delivery's B remains immutable across authored-code merges."""
    program=Path(program)
    declaration=read(program/'source-admission.json')
    if not declaration:
        # Portable releases already carry their exact B archive. Repacking it
        # from extracted files changes ZIP timestamps/identity without changing
        # source, invalidating the review choice that was bound before stop.
        if (program/'code-upstream.json').exists() or (program/'code-upstream.zip').exists():
            from .migration_source import verify
            verify(program)
            return
        seal(program)
        return
    from .source_admission import _upstream
    upstream,_=_upstream(program,declaration)
    if merge.inventory(program/'tree')!=upstream['files']:
        raise ValueError('Incoming pristine source changed before migration')


def baseline(program, destination, sources=()):
    program, destination = Path(program), Path(destination)
    archive = program / 'code-upstream.zip'
    if archive.is_file():
        record = read(program / 'code-upstream.json')
        if record.get('sha256') != hashlib.sha256(archive.read_bytes()).hexdigest():
            raise ValueError('Stored upstream source archive changed')
        with zipfile.ZipFile(archive) as reader:
            names = reader.namelist()
            if len(names) != len(set(names)) or set(names) != set(record['files']):
                raise ValueError('Stored upstream source inventory differs')
            for name in names:
                if not merge.allowed(name):
                    raise ValueError('Non-code path in upstream snapshot')
                path = destination / name
                path.parent.mkdir(parents=True, exist_ok=True)
                content = reader.read(name)
                if hashlib.sha256(content).hexdigest() != record['files'][name]['sha256']:
                    raise ValueError('Stored upstream source contents differ')
                path.write_bytes(content)
                if merge.os.name != 'nt':
                    path.chmod(0o755 if record['files'][name]['mode'] == '100755' else 0o644)
        return destination
    # Legacy Python editions retain a separate shipped tree. Old donor hashes
    # in edition-inventory/snapshot_files do not describe these release bytes.
    stock = (program / 'tree').resolve()
    if any(Path(source).resolve() == stock or stock.is_relative_to(Path(source).resolve()) for source in sources):
        raise ValueError('This legacy installation edits its stock tree; an exact original source snapshot is required')
    if not stock.is_dir():
        raise ValueError('Exact previous release source is missing')
    return stock


def preflight(old, new, *, notify=True):
    from .app_migration import discover
    from . import source_update
    old, new = Path(old).resolve(), Path(new).resolve()
    carrier=new/'code-transition-plan.json'
    if carrier.exists():
        import json
        previous=json.loads(carrier.read_text(encoding='utf8'))
        if not isinstance(previous,dict) or previous.get('format')!='helene-code-plan.v1':raise ValueError('Existing update protocol is unreadable or incompatible')
    else:previous={}
    found = discover(old)
    sources = list(dict.fromkeys(str(Path(row['code']).resolve()) for row in found['agents']
                                if row['value'].get('mode') != 'remote'))
    incoming = merge.inventory(new / 'tree')
    from . import update_source
    source_choice=update_source.selected(old,new)
    exe = merge.executable(new, old)
    # Work/evidence belong to persistent selected data, never replaceable app/UI.
    root = Path(found['agents'][0]['tree']).resolve() / 'memory/.source-updates'
    root.mkdir(parents=True, exist_ok=True)
    plans = []
    from . import update_composition
    shared_repair = update_composition.shared(new)['changed']
    from . import app_source_update
    app_source=app_source_update.changed(old,new)
    shared_repair=shared_repair or app_source is not None
    if not sources:
        if app_source is not None:raise ValueError('Сохранение правок оболочки требует локального агента для совмещения и проверки')
        return {'state': 'ready', 'plans': []}
    with tempfile.TemporaryDirectory(prefix='baseline-', dir=root) as temporary:
        base = baseline(old, Path(temporary), sources)
        base_files = merge.inventory(base)
        for source in sources:
            agent = next(row for row in found['agents'] if str(Path(row['code']).resolve()) == source)
            plan_root = Path(agent['tree']).resolve() / 'memory/.source-updates'
            plan_root.mkdir(parents=True, exist_ok=True)
            local_files = merge.inventory(source)
            identity = merge.signature({'base': base_files, 'local': local_files,
                                        'incoming': incoming, 'source': source,
                                        'operation':source_choice['new'] if source_choice else '',
                                        'app_source':app_source,
                                        'version': read(new / 'python-app.json').get('version', '')})
            directory = plan_root / identity
            plan = read(directory / 'plan.json')
            if not plan:
                if directory.exists():
                    directory.rename(plan_root / (identity + '-incomplete-' + uuid.uuid4().hex))
                plan = merge.create(base, source, new / 'tree', directory, exe=exe)
            if (plan['files'] != {'base': base_files, 'local': local_files, 'incoming': incoming}
                    or Path(plan['local_path']).resolve() != Path(source).resolve()):
                raise ValueError('Source merge inputs changed')
            if merge.inventory(source) != local_files:
                raise ValueError('Local code changed during preparation; retry the update')
            state = plan['state']
            detail = {}
            if app_source is not None:
                if plan.get('app_source') not in (None,app_source):raise ValueError('Authored application inputs changed')
                plan['app_source']=app_source
            if shared_repair and not plan.get('shared_app_required'):
                plan['shared_app_required'] = True
            write(directory / 'plan.json', plan)
            plans.append({'source': source, 'tree':str(Path(agent['tree']).resolve()), 'directory': str(directory), 'state': state,
                          'error': str(detail.get('error') or detail.get('reason') or '')})
    from . import direct_update
    protocol=direct_update.protocol(plans,previous)
    direct=protocol==direct_update.FORMAT
    if direct:
        direct_update.bind(new,plans,profiles=[{'tree':str(Path(r['tree']).resolve()),'source':str(Path(r['code']).resolve())}
            for r in found['agents'] if r['value'].get('mode')!='remote'])
    if direct and plans:
        first=plans[0]
        if source_update.requires_gate(merge.validate_inputs(first['directory']),first['directory']):
            _admit(old,new,first,notify)
        for row in plans:row.update(state=first['state'],error=first.get('error',''))
    else:
        for row in plans:
            if source_update.requires_gate(merge.validate_inputs(row['directory']),row['directory']):_admit(old,new,row,notify)
    record={'format':'helene-code-plan.v1','old':str(old),
        'require_review':bool((source_choice or {}).get('require_review')),'choice':source_choice,
        'sources':sources,'incoming':incoming,'plans':plans}
    if direct:record['direct_update']=direct_update.FORMAT
    write(new/'code-transition-plan.json',record)
    if not direct:
        shared=update_composition.shared(new,plans)
        if not shared['consistent']:
            for row in plans:
                row.update(state='needs_attention',error='Final shared application differs; reconcile peer app candidates: '+', '.join(shared['different_paths']))
                operation=read(Path(row['directory'])/'pipeline.json')
                if operation.get('resolution_owner')=='agent' and operation.get('state')=='ready_to_apply':
                    request_path=source_update.path(operation['tree']);request=read(request_path)
                    if request.get('id')==operation['id'] and request.get('state')=='ready':
                        request.update(state='pending',tries=0,retry_at=0);write(request_path,request)
            write(new/'code-transition-plan.json',record)
    pending = [row for row in plans if row['state'] != 'ready']
    blocked = [row for row in pending if row['state'] in {'needs_attention', 'cancelled'}]
    message = ('Панель обновления требует внимания; старая версия сохранена. ' +
               '; '.join(row['error'] or row['state'] for row in blocked) if blocked else
               'Агент разбирает пересечения кода; затем результат независимо проверят. '
               'Старая версия остаётся открытой. После проверки обновление продолжится автоматически.')
    return {'state': 'needs_resolution' if pending else 'ready', 'plans': plans,
            'message': message if pending else ''}


def _admit(old,new,row,notify):
    """Existing gate once per retained legacy row or once for a new leader."""
    from . import source_update,update_source
    directory=Path(row['directory']);choice=update_source.selected(old,new)
    if choice and choice['mode']=='preserve' and choice.get('resolution_owner')!='incoming':
        from .agent_source_update import request,require_patch_tool
        require_patch_tool(choice.get('resolution_runtime') or old)
        request(row['tree'],old,row['source'],directory,read(new/'python-app.json').get('version',''))
    elif notify:source_update.ensure(row['tree'],old,row['source'],directory,read(new/'python-app.json').get('version',''))
    try:source_update.validate_ready(directory);row.update(state='ready',error='')
    except (OSError,ValueError,KeyError,TypeError) as exc:
        detail=read(directory/'pipeline.json');state=detail.get('state','queued')
        if state=='ready_to_apply':state='needs_attention';detail={**detail,'error':str(exc)}
        row.update(state=state,error=str(detail.get('error') or detail.get('reason') or ''))


def validate(new):
    from .validation_read import checkpoint,digest
    checkpoint()
    from .app_migration import discover
    from . import source_update
    record = read(Path(new) / 'code-transition-plan.json')
    if not record:
        return
    if record.get('format')=='helene-clean-code-plan.v1':
        from .update_source import validate_clean
        return validate_clean(new,record)
    found = discover(Path(record['old']))
    if record.get('require_review'):
        from .update_source import selected
        if record.get('choice')!=selected(Path(record['old']),Path(new)):
            raise ValueError('Bound migration review policy changed')
    sources = list(dict.fromkeys(str(Path(row['code']).resolve()) for row in found['agents']
                                if row['value'].get('mode') != 'remote'))
    if sources != record.get('sources'):
        raise ValueError('Selected code paths changed before applying the update; retry')
    selected_upstream=record.get('selected_upstream')
    expected=selected_upstream.get('tree') if selected_upstream else record['incoming']
    if merge.inventory(Path(new) / 'tree') != expected:
        raise ValueError('Incoming upstream code changed before applying the update; retry')
    if selected_upstream:
        base=read(Path(new)/'code-upstream.json');archive=Path(new)/'code-upstream.zip'
        if base.get('files')!=record['incoming']:
            raise ValueError('Pristine upstream merge base changed')
        with archive.open('rb') as stream:measured=digest(stream)
        if measured!=base.get('sha256'):
            raise ValueError('Pristine upstream merge base changed')
        for name,files in selected_upstream.items():
            checkpoint()
            merge.relative(name)
            if merge.inventory(Path(new)/name)!=files:raise ValueError('Selected upstream result changed')
    from . import update_composition
    update_composition.require_shared(new, record.get('plans', []))
    for row in record.get('plans', []):
        checkpoint()
        plan = merge.validate_inputs(row['directory'])
        if merge.inventory(row['source']) != plan['files']['local']:
            raise ValueError('Local code changed before applying the update; retry')
        if source_update.requires_gate(plan, row['directory']):
            source_update.validate_ready(row['directory'])
    if (Path(new).parent / 'compound-overlay.json').exists():
        update_composition.selected_files(new)


def prepare(old, new, note, *, progress=None):
    old, new = Path(old).resolve(), Path(new).resolve()
    if not (new / 'tree').is_dir():
        return
    if not note['source_paths']:
        from . import update_source,app_source_update
        choice=update_source.require(old,new,progress)
        if choice['mode']=='preserve' and app_source_update.changed(old,new):
            raise ValueError('Сохранение правок оболочки требует локального агента для совмещения и проверки')
        _keep_upstream(new)
        return
    from . import update_source
    choice=update_source.require(old,new,progress)
    note['source_policy']=choice['mode'];note['source_choice']=choice
    if choice['mode']=='clean':
        update_source.clean_prepare(old,new,note,choice)
        return
    result = preflight(old, new, notify=False)
    if result['state'] != 'ready':
        from .agent_source_update import AgentResolutionPending
        if any(read(Path(row['directory'])/'pipeline.json').get('state')=='waiting_agent'
               and read(Path(row['directory'])/'plan.json').get('state')!='ready' for row in result['plans']):
            raise AgentResolutionPending('Агент разбирает пересечения в изолированной копии. После его исправлений и независимой проверки обновление продолжится автоматически; память и рабочий код сохранены.')
        from .source_update_host import review
        review(old, new, result['plans'], progress)
        validate(new)
        result = preflight(old, new, notify=False)
    if result['state'] != 'ready':
        raise RuntimeError(result['message'])
    from .app_migration import preserve_source
    from .essential_backup import configs, load
    selected = {}
    receipts = []
    from . import update_composition
    update_composition.overlay(new, result['plans'])
    portable=note.get('portable_folder_switch') is True
    if portable:_keep_upstream(new)
    for row in note['source_paths']:
        original, target = Path(row['old']).resolve(), Path(row['selected']).resolve()
        if original in selected:
            row['selected'] = str(selected[original])
            continue
        if portable:
            target=new/'tree' if not selected else new/'code'/note['id']/str(len(selected))
            row['selected']=str(target)
        elif original == target:
            target = new / 'code' / note['id'] / str(len(selected))
            preserve_source(original, target, source_only=True)
            row['selected'] = str(target)
        plan_row = next(p for p in result['plans'] if Path(p['source']).resolve() == original)
        directory = Path(plan_row['directory'])
        if portable:merge.apply_upstream(directory,target)
        else:merge.apply(directory, target)
        selected[original] = target
        plan = read(directory / 'plan.json')
        from .clean_code_retirement import git_signature
        receipts.append({'source': str(original), 'selected':str(target), 'directory': str(directory),
                         'commits': plan['commits'], 'merged_commit': plan['merged_commit'],
                         'previous_files':plan['files']['local'],'git_signature':git_signature(original/'.git')})
    for config in configs(new):
        if not config.is_file():
            continue
        value = load(config)
        prior = Path(value.get('code', '')).resolve()
        if prior in selected:
            value['code'] = str(selected[prior])
        write(config, value)
    if portable:
        record=read(new/'code-transition-plan.json')
        record['selected_upstream']={path.relative_to(new).as_posix():merge.inventory(path) for path in selected.values()}
        write(new/'code-transition-plan.json',record)
    else:_keep_upstream(new)
    write(new / 'code-transition.json', {'format': 'helene-code-transition.v2', 'merges': receipts})
    note['code_transition'] = str(new / 'code-transition.json')

"""Give the existing agent the incoming update hand without another model."""
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
import hashlib,json,os,subprocess,sys,urllib.request
from urllib.parse import urlsplit
if __package__ in (None,''):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]));__package__='localharness'
from .package_notice import read,write
from .agent_source_update import require_patch_tool,AgentResolutionUnavailable

_CONTROLLER=ContextVar('helene_legacy_update_owner',default=None)


@contextmanager
def controller_scope(owner):
    """A native migration job reloads its own runner, never resurrects an old UI."""
    token=_CONTROLLER.set(owner)
    try:yield
    finally:_CONTROLLER.reset(token)


def _restart_selected(old):
    owner=_CONTROLLER.get()
    if owner is not None and owner.root.resolve()==Path(old).resolve():
        owner.close();owner.start()
    else:restart_engine(old)


def replace_owned(path,expected,data):
    import uuid
    part=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        part.write_bytes(data)
        if path.read_bytes()!=expected:raise RuntimeError('Update hand changed before replacement')
        part.replace(path)
    finally:part.unlink(missing_ok=True)


def live_control(old):
    http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    from .program_state import window_controls
    for path in window_controls(old):
        control=read(path)
        if Path(control.get('root') or '.').resolve()!=Path(old).resolve():continue
        url=urlsplit(control.get('origin',''))
        if url.scheme!='http' or url.hostname!='127.0.0.1' or not url.port or url.username:continue
        probe=urllib.request.Request(control['origin']+'/__python__/invoke',
            data=b'{"command":"agents_list","args":{}}',
            headers={'Content-Type':'application/json','X-Helene-Window':control['token']})
        try:
            with http.open(probe,timeout=2) as response:payload=json.load(response)
            status=payload.get('result',payload)
            if not any(row.get('raised') for row in status.get('agents',[])):continue
        except (OSError,ValueError):continue
        return control
    raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Прежнее окно не предоставляет управление раннером. Запусти прежнюю Hélène для передачи задачи агенту или выбери чистый код с сохранением данных.')


def restart_engine(old):
        control=live_control(old)
        request=urllib.request.Request(control['origin']+'/__python__/invoke',
            data=b'{"command":"engine_restart","args":{}}',
            headers={'Content-Type':'application/json','X-Helene-Window':control['token']})
        http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with http.open(request,timeout=60) as response:
            result=json.load(response)
        if result.get('error'):raise RuntimeError(result['error'])
        if result.get('result',result).get('ok') is not True:raise RuntimeError('Legacy runner restart not acknowledged')
        return


def ensure_agent_window(old,new):
    """A closed legacy Python window can be opened with its existing profile."""
    try:live_control(old);return True
    except AgentResolutionUnavailable:pass
    entry=Path(old)/'app/python_app.py'
    controller=Path(old)/'app/localharness/python_controller.py'
    if (not entry.is_file() or not controller.is_file()
            or 'def publish_control' not in entry.read_text(encoding='utf-8-sig')
            or 'engine_restart' not in controller.read_text(encoding='utf-8-sig')):
        raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Прежняя программа не предоставляет Python-управление агентом. Доступен чистый код с сохранением данных.')
    from .update_process import interpreter_for
    with (Path(new).parent/'legacy-agent-window.log').open('ab') as log:
        child=subprocess.Popen([str(interpreter_for(old)),'-s',str(entry),'--root',str(old)],
            cwd=old,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
            env=dict(os.environ,PYTHONPATH=str(Path(old)/'app'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8'),
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    import time
    deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        if child.poll() is not None:break
        try:live_control(old);return False
        except AgentResolutionUnavailable:time.sleep(.2)
    raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Не удалось открыть прежнего агента для подключения инструмента. Подробности сохранены в legacy-agent-window.log; доступен чистый код с сохранением данных.')


def shim(new,interpreter,tool,bridge_id):
    """Appended to the old module; its other legacy functions stay available."""
    import inspect
    from .source_update_hand import try_request
    from .runtime_identity import capture
    client=inspect.getsource(try_request).replace('def try_request(', 'def _incoming_rpc(',1)
    identity=inspect.getsource(capture).replace('def capture(', 'def _capture_worker_identity(',1)
    return '\n# Incoming update hand, temporary; no model process.\n'+client+'\n'+identity+'\n'+f'''
TOOL = {tool!r}
CONTINUATION_PROTOCOL = 2
_incoming_program = {str(Path(new).resolve())!r}
_incoming_python = {str(interpreter)!r}
_incoming_hand = {str(Path(new)/'app/localharness/legacy_update_tool.py')!r}
_incoming_bridge_id = {bridge_id!r}
def command(tree, action='status', **args):
    import subprocess,os
    handled,value=_incoming_rpc(tree,action,args,_incoming_program)
    if handled:return value
    result=subprocess.run([_incoming_python,'-B','-s',_incoming_hand,'--tree',str(tree)],
        input=json.dumps(dict(args,action=action)).encode('utf-8'),capture_output=True,
        timeout=90,env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8'),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode:raise RuntimeError(result.stderr.decode('utf-8',errors='replace')[-1000:])
    return json.loads(result.stdout)
def pending(tree):
    request=read(path(tree))
    return request if request.get('resolution_owner')=='agent' and request.get('state') in ('pending','waiting_agent','verification_requested','review_requested','reviewing','ready_to_apply','needs_attention') else None
def install(agent,tree):
    def hand(action='status',**args):
        try:return json.dumps(command(tree,action,**args),ensure_ascii=False)
        except Exception as error:return json.dumps({{'error':str(error)}},ensure_ascii=False)
    agent.TOOL_IMPL['source_update']=hand
    agent.BASE_TOOLS[:]=[t for t in agent.BASE_TOOLS if t.get('name')!='source_update']
    agent.BASE_TOOLS.append(TOOL)
    context={{}}
    if globals().get('__file__') and getattr(agent,'__file__',None):
        context=_capture_worker_identity(Path(__file__).resolve().parents[2],Path(agent.__file__).resolve().parent)
    write(path(tree).with_name('source-update-hand-ready.json'),{{'bridge':_incoming_bridge_id,'pid':__import__('os').getpid(),'worker_context':context}})
def notify_due(tree,turn):
    request=pending(tree)
    if not request:return
    from . import owner_stop
    if owner_stop.stopped() or owner_stop.paused():return
    import hashlib
    from pathlib import Path
    identity=str(request.get('id') or '');directory=Path(request.get('directory') or '.').resolve()
    programme=Path(request.get('program') or '.').resolve();base=Path(tree).resolve()
    if len(identity)!=64 or directory not in (programme/'.source-updates'/identity,base/'memory/.source-updates'/identity):return
    operation=read(directory/'pipeline.json');plan=read(directory/'plan.json')
    if (operation.get('state') not in ('waiting_agent','needs_attention') or operation.get('cancel_requested')
            or (directory/'cancel.json').exists() or operation.get('paused')):return
    control=(operation.get('coordinator') or {{}}).get('job_control') or {{}}
    parent=read(control['path']) if control.get('path') else {{}}
    if control and (parent.get('id')!=control.get('id') or parent.get('state') in ('completed','cancelled','superseded','paused')):return
    automatic=operation.get('continuation')=='automatic-v1'
    if automatic and read(directory/'coordinator-hand.json').get('state')!='ready':return
    event=hashlib.sha256(json.dumps(dict(state=operation.get('state'),candidate=operation.get('candidate_sha256'),
        composition=operation.get('composition_sha256'),review=operation.get('review_id'),clear=operation.get('review_clear'),
        error=operation.get('verification_error') or operation.get('finish_error') or operation.get('error'),
        result=plan.get('result'),resolved=plan.get('resolved')),sort_keys=True).encode()).hexdigest()
    notice_path=directory/'legacy-agent-notice.json';notice=read(notice_path);now=time.time()
    if notice.get('event')==event and (notice.get('state')!='failed' or now<notice.get('retry_at',0)):return
    value={{'event':event,'state':'reserved','at':now}};write(notice_path,value)
    if read(path(tree)).get('id')!=identity or read(directory/'pipeline.json')!=operation:return
    flow=('После finish обновлятор сам выполнит полные тесты, независимое ревью и разрешённое переключение. '
          if automatic else 'После finish: verify, затем review после PASS и apply после clear. ')
    try:
        result=turn('source-update-'+identity+'-'+event[:16],speaker='Hélène',origin_text=
            'Событие текущего обновления '+identity[:8]+'. Прочитай source_update status и фактические замечания/ошибку. '
            'Разреши конфликты или исправь findings через read/diff/patch/resolve, затем finish. '+flow+
            'Живой код, замороженные входы и квитанции не меняй. Stop/Pause обязательны; новых подтверждений владельца не требуется.')
    except BaseException:
        write(notice_path,dict(value,state='failed',retry_at=now+60));raise
    write(notice_path,dict(value,state='failed' if result=='failed' else 'delivered',
        **({{'retry_at':now+60}} if result=='failed' else {{}})))
    return result
'''


@contextmanager
def provide(old,new):
    old,new=Path(old).resolve(),Path(new).resolve()
    try:require_patch_tool(old)
    except AgentResolutionUnavailable:pass
    else:
        yield;return
    from . import owner_stop,app_migration,source_update
    if owner_stop.stopped() or owner_stop.paused():
        raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Stop/Pause запрещает перезапуск агента для подключения инструмента.')
    # Never append bootstrap code to an authored source tree.
    target=old/'app/localharness/source_update.py'
    for agent in app_migration.discover(old)['agents']:
        if source_update._owner_blocked(agent['tree']):
            raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Stop/Pause выбранного агента запрещает подключение инструмента.')
        if target.is_relative_to(Path(agent['code']).resolve()):
            raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Старый инструмент находится внутри авторского кода; выбери чистый код или отдельную программу.')
    if not target.is_file():raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Прежний Python-инструмент обновления отсутствует.')
    from .source_update_host import verified_runtime
    verified_runtime(new)
    from .update_process import interpreter_for
    import uuid,time
    bridge_id=uuid.uuid4().hex
    trees=[Path(a['tree']) for a in app_migration.discover(old)['agents'] if a['value'].get('mode')!='remote']
    interpreter=new/'runtime/python.exe' if os.name=='nt' else interpreter_for(new)
    original=target.read_bytes();patched=original+shim(new,interpreter,source_update.TOOL,bridge_id).encode('utf-8')
    backup=new.parent/'legacy-update-tool-backup.py';backup.write_bytes(original)
    try:replace_owned(target,original,patched)
    except OSError as error:
        raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Нет доступа для подключения инструмента к прежней программе. Прежний файл сохранён; можно установить чистый код с текущими данными.') from error
    try:
        controller=_CONTROLLER.get()
        if controller is not None and controller.root.resolve()==old:
            _restart_selected(old)
        elif ensure_agent_window(old,new):restart_engine(old)
        deadline=time.monotonic()+30
        while not all(read(source_update.path(tree).with_name('source-update-hand-ready.json')).get('bridge')==bridge_id for tree in trees):
            if owner_stop.stopped() or owner_stop.paused():raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Подключение инструмента остановлено владельцем.')
            if time.monotonic()>=deadline:raise AgentResolutionUnavailable('SELECTED_AGENT_UPDATE_UNAVAILABLE: Раннер не подтвердил подключение нового инструмента; доступен чистый код с сохранением данных.')
            time.sleep(.2)
        yield
    finally:
        if target.read_bytes()==patched:
            replace_owned(target,patched,original)
            if not owner_stop.stopped() and not owner_stop.paused():_restart_selected(old)
        else:raise RuntimeError('Temporary update hand changed; original retained at '+str(backup))
        for tree in trees:
            receipt=source_update.path(tree).with_name('source-update-hand-ready.json')
            if read(receipt).get('bridge')==bridge_id:receipt.unlink(missing_ok=True)


def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--tree',type=Path,required=True);args=parser.parse_args()
    new=Path(__file__).resolve().parents[2]
    from localharness.source_update_host import verified_runtime
    verified_runtime(new)
    from localharness import source_update
    from localharness import source_merge
    request_state=read(source_update.path(args.tree))
    _,plan=source_update._bound(request_state)
    if (request_state.get('version')!=read(new/'python-app.json').get('version')
            or plan['files']['incoming']!=source_merge.inventory(new/'tree')):
        raise ValueError('Incoming hand does not match this requested update')
    request=json.load(sys.stdin);action=request.pop('action','status')
    result=source_update.command(args.tree,action,**request)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':
    if __package__ in (None,''):sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    main()

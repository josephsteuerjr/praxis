# -*- coding: utf-8 -*-
"""Подача конфига продукта её дереву: раскладка, ручки среды, мозг.

Один принцип владельца — ПОЛНАЯ КОНФИГУРИРУЕМОСТЬ — и один файл настроек рядом с exe
(`helene.json`). Дерево агента конфигурируется 321 env-ручкой и своим `memory/llm.json`;
здесь ровно шов между ними: продукт кладёт значения ТУДА, где дерево их и читает,
вместо второй реализации тех же решений.

⚠⚠ ЛОВУШКА ПОРТА, НАЙДЕННАЯ ЖИВЬЁМ 30.08. `agent.py` на импорте зовёт
`load_dotenv(override=True)`, а `find_dotenv()` ищет `.env` ВВЕРХ ОТ ФАЙЛА ДЕРЕВА —
то есть рядом с кодом. На машине разработчика там лежит боевой `.env` (ключи, сессия
Telegram, поднятые рычаги), и локальный харнесс молча поднимался с ним: рук стало 100
вместо 95, рычаг речи оказался поднят «сам». В продукте такого файла не будет, и
поведение разошлось бы с отлаженным здесь.

Отсюда правило: ручки применяются ДВАЖДЫ — до импорта (их читают на импорте) и ПОСЛЕ
(чтобы случайный `.env` рядом с кодом не победил конфиг продукта). Найденный `.env`
называется в логе вслух: тихая подмена настроек — не мелочь, а класс.
"""
from __future__ import annotations

import atexit
from contextlib import contextmanager
import hashlib
import json
import logging
import math
import os
import sys
import platform
import re
import signal
import threading
import time
from pathlib import Path

log = logging.getLogger("frame.boot")

# Порт как есть: значения рычагов = боевые (live/.env прода на 30.08). Продукт не
# изобретает своего поведения — он повторяет то, на котором она живёт.
#   PRAXIS_CHAT_REPLY_HAND — контракт v3: её реплика уходит РУКОЙ `reply`, а текст
#     хода это заметка. Опущенный рычаг вернул бы «последний текст = сообщение».
#   PRAXIS_WORK_LOOP + CONTINUATIONS — ход не кончается на первом тексте, закрывает
#     его её `end_turn`.
#   PRAXIS_FRAME_SHADOW — захват кадра (экран «Кадр» в окне живёт на этих слепках).
# Веб-поиск по умолчанию опущен: hosted-рука зависит от провайдера, а продукт обязан
# подниматься на любом OAI-совместимом эндпойнте, включая локальную модель.
#   ⚠ 03.09. Отсюда убрана ручка `PRAXIS_EVALUATOR: risky`: её не читает НИ ОДНА
#     строка дерева (grep по live/ даёт только сам .env автора). Она приехала
#     слепком боевого .env и доказывала, что этот набор — не выбор продукта.
#     Остальные значения перепроверены и оставлены сознательно; LAST_N=80 против
#     умолчания дерева 50 — продуктовое решение владельца, не наследство.
PORT_DEFAULTS: dict[str, str] = {
    "PRAXIS_WORK_LOOP": "on",
    "PRAXIS_WORK_CONTINUATIONS": "8",
    "PRAXIS_CHAT_REPLY_HAND": "on",
    # ⚠ 17.09, ПО ЗАМЕРУ. Её прошлые реплики в ленте кадра лежали обычной прозой — это
    # единственный образец ассистентского хода во всём кадре, и модель ему следовала:
    # писала готовый ответ текстом вместо вызова руки `reply`, а текст никуда не уезжал.
    # Замер ядра 16.09 на пяти кадрах: 34/48 = 71 % таких ходов на базе, 0/42 под этим
    # рычагом (Фишер p = 3e-13). По моделям на ОДНОМ кадре: gpt-5.6-terra 0 %, sol 4 %,
    # astra 12 %, glm-5.3 47 %, glm-5.3-flash 67 % — то есть у поставки, указывающей
    # умолчанием на OpenAI, дефекта почти нет, а у того, кто поставит GLM, молчит каждый
    # второй ход. Цена обратная ожидаемой: вызов стоит 559 выходных токенов против 1860
    # у прозы. Умолчание самого дерева остаётся `off` — это гарантия отката.
    "PRAXIS_FRAME_TAPE_HANDS": "on",
    "PRAXIS_FRAME_SHADOW": "on",
    # ⚠ РЕТЕНЦИЯ ПРОГОНОВ, 17.09. Снимки `results/` — то, что уехало в модель и что
    # она ответила, по одному на итерацию: на проде это 28,7 ГБ из 29,5 ГБ всех
    # прогонов и +1 ГБ в сутки. У человека дома этому расти некуда. Манифесты и
    # события не трогаются никогда — история «что было» остаётся целиком.
    # Тик заводит `runner._retention_forever`: в издании звать ретенцию больше
    # неоткуда, `sleep.run_scheduled` здесь не работает.
    "PRAXIS_RUNS_RETENTION": "on",
    "PRAXIS_RUNS_RETENTION_BUDGET": "600",
    # Every available hand is provider-native, with its complete English schema.
    # h.hand remains available inside scripts; describe/call are not a discovery
    # prerequisite. The old September pointer optimization hid useful hands.
    "PRAXIS_TOOLS_POINTERS": "off",
    "PRAXIS_LAST_N": "80",
    "PRAXIS_CONTEXT_BUDGET": "0",
    # ⚠ Два рычага кэша, поднятые 03.09 ПО ЗАМЕРУ на этой поставке. Стабильная
    # «голова» кадра расходилась на 2798-м токене (счётчики uptime/расхода и
    # запись прошлого хода живут внутри неё), и весь хвост системного сообщения
    # плюс лента платились свежими на каждом ходе. Замер двух ходов, снятых
    # живьём с интервалом в минуты:
    #     без рычагов — общий префикс 11617 из 14232 знаков (81,6 %)
    #     с рычагами  — 13934 из 13934 (100 %, байт в байт)
    # Счётчики при этом НЕ исчезают: они переезжают в живой evidence-блок —
    # проверено, uptime_minutes/tokens_today/latest_turn/skips_today на месте.
    # В ядре рычаги опущены по решению ДРУГОГО агента про ЕГО собственный кадр;
    # кадр агента этого продукта собирает продукт, и это его решение.
    "PRAXIS_STATE_COUNTERS_SPLIT": "1",
    "PRAXIS_FRAME_TAIL_SPLIT": "1",
    "PRAXIS_AUTO_RECALL_K": "0",
    "PRAXIS_EMBEDDINGS": "0",
    "PRAXIS_WEB_SEARCH": "0",
    # ⚠ 1.0.0 (26.09), кадр её прода. Стабильная голова КОМНАТЫ: system и набор рук не
    # зависят от того, кто заговорил. Её замер 13.09 (40 пар соседних кадров группы): при
    # смене говорящего system рвался на 17-й тысяче знаков, и каждое чередование стоило
    # ~15 тыс. токенов заново. Под рычагом полномочия хода едут строкой «говорит» в зоне
    # «СЕЙЧАС», STATE и приватное из досье — ярусами живого конверта; из кадра не исчезает
    # ничего, меняется место. `_RUNS` — то же для её собственных ходов без комнаты.
    "PRAXIS_FRAME_HEAD_STABLE": "1",
    "PRAXIS_FRAME_HEAD_STABLE_RUNS": "1",
    # ⚠ 1.0.1: её сон. `sleep.run_scheduled` в ядре заводят часы mtproto_runner, которого
    # харнесс не запускает, — до 1.0.1 ночного цикла (консолидация, формирование, ревизия
    # характера, карта памяти, мётла inbox) в издании не было вовсе. Теперь его зовёт
    # `runner._sleep_due` между ходами по её `sleep.due`; `off` — вернуть прежнее.
    "PRAXIS_SLEEP_CYCLE": "on",
}

# Каноническая конституция продукта — ресурс рядом с кодом (resources/SOUL.md).
# Владелец читает, правит и принимает её при установке; сюда она приходит уже
# принятой. Имена подставляются здесь, чтобы у ресурса был один текст на всех.
_RESOURCES = Path(__file__).resolve().parent.parent / "resources"
_SOUL_CANON = _RESOURCES / "SOUL.md"
_SOUL_FALLBACK = """# Конституция

## Кто я

Меня зовут {{agent}}. Я агент, собранный в Hélène и живущий на компьютере {{owner}}.

## Кому я верен

Мой владелец — {{owner}}. При конфликте указаний решает это слово.
"""


def agent_name(cfg: dict) -> str:
    """Имя агента даёт владелец при установке: `agent.name`.

    Старые конфиги держали его в `telegram.agent_name` — читаем и оттуда, чтобы
    не терять имя при обновлении. Пустое имя — не «Hélène» и не чужое имя, а
    честное «Агент»: продукт не подписывает агента именем, которого ему не давали.
    """
    agent = cfg.get("agent") or {}
    telegram = cfg.get("telegram") or {}
    name = str(agent.get("name") or telegram.get("agent_name") or "").strip()
    return name or "Агент"


def owner_name(cfg: dict) -> str:
    return str((cfg.get("owner") or {}).get("name") or "").strip() or "владелец"


def _names(text: str, cfg: dict) -> str:
    """Подстановка имён — одна на конституцию и на весь стартовый комплект."""
    return text.replace("{{agent}}", agent_name(cfg)).replace("{{owner}}",
                                                              owner_name(cfg))


def initial_soul_seed(config_path: Path, tree: Path) -> str | None:
    """Profile birth choice survives code updates before the first model login.

    Existing secondary-agent seeds keep their legacy location and behaviour.
    An unreadable explicit profile choice must never silently become canonical.
    """
    seed=tree/'memory/.state/soul-seed.md'
    if seed.exists() or seed.is_symlink():
        try:
            text=read_config_text(seed)
            if not text.strip():raise ValueError('пустой текст')
            return text
        except (OSError,ValueError) as error:
            if (tree/'soul/SOUL.md').is_file():
                log.warning('запись рождения не читается (%s); существующая конституция сохранена: %s',seed,error)
                return None
            raise LayoutError(f'Не удалось прочитать выбранную конституцию ({seed}): {error}') from error
    seed=config_path.with_name('soul-seed.md')
    try:return read_config_text(seed) if seed.is_file() else None
    except (OSError,ValueError) as error:
        log.warning('сид души не читается (%s): родится каноническая конституция — %s',seed,error)
        return None


def soul_text(cfg: dict) -> str:
    """Каноническая конституция с подставленными именами."""
    try:
        canon = _SOUL_CANON.read_text(encoding="utf-8")
    except OSError:
        log.warning("ресурса конституции нет (%s) — пишу короткий запасной текст",
                    _SOUL_CANON)
        canon = _SOUL_FALLBACK
    return _names(canon, cfg)


def read_config_text(path: Path) -> str:
    """helene.json с диска — как его сохранил РЕДАКТОР ВЛАДЕЛЬЦА, а не как хочется нам.

    ⚠ ПЕРВЫЙ-ЗАПУСК.md зовёт править этот файл руками, а Блокнот, VS Code и
    `Set-Content` из PowerShell 5.1 по умолчанию пишут UTF-8 с BOM или UTF-16LE.
    Строгий `read_text(encoding="utf-8")` ронял руннер на первом же байте
    («Unexpected UTF-8 BOM», «codec can't decode byte 0xff»), при том что
    оболочка тот же файл уже читает (она BOM снимает и UTF-16 понимает) —
    считала продукт настроенным, поднимала детей и перезапускала умершего
    руннера по кругу, а в окне стояло «Модель не настроена».

    Читаем то же, что и оболочка: BOM UTF-8, UTF-16 с меткой и без неё.
    """
    raw = Path(path).read_bytes()
    if raw[:3] == b"\xef\xbb\xbf":
        return raw[3:].decode("utf-8")
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16")          # метку разберёт сам кодек
    # UTF-16 БЕЗ метки проходит `decode("utf-8")` насквозь (нулевой байт — законный
    # символ UTF-8), и разбор JSON падал уже на второй букве. В JSON нулей не бывает:
    # нашли — значит это широкая кодировка, а не текст.
    if b"\x00" in raw[:4096]:
        for encoding in ("utf-16-le", "utf-16-be"):
            try:
                text = raw.decode(encoding)
            except UnicodeDecodeError:
                continue
            if "{" in text:                  # похоже на JSON, а не на случайность
                return text
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("файл не читается ни как UTF-8, ни как UTF-16 — "
                         f"пересохрани его в UTF-8 ({exc})") from exc


class LayoutError(RuntimeError):
    """Раскладку завести не удалось — причина в тексте, для лога и для оболочки."""


def _seed_kit(tree: Path, cfg: dict, *, birth: bool = True,
              skill_overrides: frozenset[str] = frozenset(),
              proposals: set[str] | None = None) -> int:
    """Birth seeds `resources/**`; later calls only stage soul candidates.

    ⚠ Здесь писался РОВНО ОДИН файл — `soul/SOUL.md`. Поэтому конституция,
    ссылающаяся на соседей (soul/VOICE.md, soul/FRAME.md, soul/skills/INDEX.md),
    на первом же ходе врала про собственный дом: агент шёл читать названное и
    не находил ничего. Любой стартовый комплект лежал в поставке мёртвым грузом.

    Правило «только если нет» — то же, что у конституции, и оно тут главное:
    навык, который агент под себя переписал, обновление продукта молча вернуло
    бы к заводскому. Один упрямый файл (занят, нет прав) не роняет раскладку —
    он называется в логе, остальные едут.
    """
    planted = 0
    for src_root, dst_root in ((_RESOURCES / "soul", tree / "soul"),
                               (_RESOURCES / "memory", tree / "memory")):
        if not src_root.is_dir():
            continue
        for src in sorted(src_root.rglob("*")):
            rel = src.relative_to(src_root)
            if src.is_dir() or any(part.startswith((".", "__")) for part in rel.parts):
                continue
            if src_root.name == "soul" and rel.parts[0] == "skills" and rel.name in skill_overrides:
                continue
            dst = dst_root / rel
            if dst.exists() and birth:
                continue
            try:
                data = src.read_bytes()
                if src_root.name == "soul" and not birth:
                    import kit_proposals
                    text = data.decode("utf-8")
                    selected = kit_proposals.stage(tree, f"soul/{rel.as_posix()}",
                                                   _names(text, cfg).encode("utf-8"), source="kit")
                    if selected and proposals is not None:
                        proposals.add(selected)
                    continue
                if dst.exists():
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    text = data.decode("utf-8")
                except UnicodeDecodeError:
                    dst.write_bytes(data)    # не текст — кладём байтами
                else:
                    dst.write_text(_names(text, cfg), encoding="utf-8", newline="\n")
            except (OSError, UnicodeError) as exc:
                if src_root.name == "soul" and not birth:
                    raise LayoutError(f"кандидат soul/{rel} не сохранён: {exc}") from exc
                log.warning("стартовый файл %s не лёг в дерево: %s", rel, exc)
                continue
            planted += 1
    return planted


#: Прежние редакции стартового комплекта (`installer/kit_history.py`): точка в имени —
#: `_seed_kit` такой файл в дом не кладёт.
_KIT_HISTORY = _RESOURCES / ".shipped-history.json"


def _kit_history() -> dict[str, list[str]]:
    try:
        data = json.loads(_KIT_HISTORY.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    files = data.get("files") if isinstance(data, dict) else None
    return {str(k): [str(t) for t in v if isinstance(t, str)]
            for k, v in (files or {}).items() if isinstance(v, list)}


def refresh_kit(tree: Path, cfg: dict, *, birth: bool = False,
                skill_overrides: frozenset[str] = frozenset(),
                proposals: set[str] | None = None) -> list[str]:
    """Legacy stock is evidence for a candidate, not consent to replace soul.

    1.2.5 (28.09, слово Егора): тексты комплекта переписаны — без рода, без чужих имён,
    путей и контейнеров. `_seed_kit` кладёт только отсутствующее, и у агентов, рождённых
    раньше, лежали бы прежние слова. Правило: файл, совпадающий СЛОВО В СЛОВО с какой-либо
    прежней редакцией поставки (после подстановки имён), не правил никто — его меняем;
    changed or missing soul text stays outside the live persona until she reviews
    it and chooses her own revision. The legacy CURRENT shortcut is proposal-only.
    """
    history = _kit_history()
    done: list[str] = []
    for rel, olds in sorted(history.items()):
        if rel == "self-day-zero.md":
            continue
        if rel.startswith("soul/skills/") and Path(rel).name in skill_overrides:
            continue
        src = _SOUL_CANON if rel == "SOUL.md" else _RESOURCES / rel
        dst = tree / "soul" / "SOUL.md" if rel == "SOUL.md" else tree / rel
        if not src.is_file() or not dst.is_file():
            continue
        try:
            have = dst.read_text(encoding="utf-8")
            new = _names(src.read_text(encoding="utf-8"), cfg)
        except (OSError, UnicodeDecodeError):
            continue
        if have == new:
            continue
        if not birth and dst.relative_to(tree).parts[0] == "soul":
            import kit_proposals
            selected = kit_proposals.stage(tree, dst.relative_to(tree).as_posix(),
                                           new.encode("utf-8"), source="kit")
            if selected and proposals is not None:
                proposals.add(selected)
            continue
        if have not in {_names(old, cfg) for old in olds}:
            continue
        try:
            dst.write_text(new, encoding="utf-8", newline="\n")
        except OSError as exc:
            log.warning("текст поставки %s не обновился: %s", rel, exc)
            continue
        done.append(str(dst.relative_to(tree)).replace("\\", "/"))
    if birth and _refresh_day_zero(tree, cfg, history.get("self-day-zero.md") or []):
        done.append("soul/self/CURRENT.md")
    elif not birth and _SELF_DAY_ZERO.is_file():
        # The old revision-0 shortcut was still an installer-authored identity
        # revision. Keep the proposed body outside CURRENT until the agent acts.
        current = tree / "soul" / "self" / "CURRENT.md"
        if not current.exists() and (tree / "soul" / "self.md").is_file():
            import kit_proposals
            selected = kit_proposals.stage(tree, "soul/self/CURRENT.md",
                                           _names(_SELF_DAY_ZERO.read_text(encoding="utf-8"), cfg).encode("utf-8"),
                                           source="kit:day-zero-body")
            if selected and proposals is not None:
                proposals.add(selected)
        elif current.is_file() and history.get("self-day-zero.md"):
            model = _import_self_model()
            if model is not None:
                try:
                    meta, body = model._store(tree)._split_current(current.read_text(encoding="utf-8"))
                    proposal = _names(_SELF_DAY_ZERO.read_text(encoding="utf-8"), cfg)
                    olds = {_names(old, cfg).strip() for old in history["self-day-zero.md"]}
                    if str(meta.get("revision")) == "0" and body.strip() in olds \
                            and body.strip() != proposal.strip():
                        import kit_proposals
                        selected = kit_proposals.stage(tree, "soul/self/CURRENT.md",
                                                       proposal.encode("utf-8"), source="kit:day-zero-body")
                        if selected and proposals is not None:
                            proposals.add(selected)
                except (OSError, UnicodeError, ValueError) as exc:
                    log.warning("запись дня ноль: кандидат не подготовлен: %s", exc)
    return done


def _refresh_day_zero(tree: Path, cfg: dict, olds: list[str]) -> bool:
    """Запись о себе дня ноль, которую агент ещё не правил, — новой ревизией."""
    if not olds or not _SELF_DAY_ZERO.is_file():
        return False
    current = tree / "soul" / "self" / "CURRENT.md"
    if not current.is_file():
        return False
    self_model = _import_self_model()
    if self_model is None:
        return False
    try:
        store = self_model._store(tree)
        meta, body = store._split_current(current.read_text(encoding="utf-8"))
        if str(meta.get("revision")) != "0":
            return False                      # агент уже переписывал — его слово
        if body.strip() not in {_names(old, cfg).strip() for old in olds}:
            return False
        new = _names(_SELF_DAY_ZERO.read_text(encoding="utf-8"), cfg)
        result = store.revise(
            new, reason="поставка 1.2.5: запись дня ноль теми же словами, только без рода "
                        "и без чужих имён (агент её ещё не правил)",
            evidence_refs=["soul/SOUL.md"], by="helene", confidence="uncertain", trigger="birth")
    except Exception:
        log.warning("запись дня ноль не обновилась", exc_info=True)
        return False
    return bool(result.get("ok"))


_SELF_DAY_ZERO = _RESOURCES / "self-day-zero.md"


def _import_self_model():
    """`self_model` из tree/ — или None словами в журнале. Раскладка без ядра не падает.

    ⚠ Руннер вставляет путь к коду в sys.path ПОСЛЕ раскладки (в `_import_agent`), и на
    первом рождении установленной копии self_model не находился — запись о себе молча не
    ложилась, кадр жил с дырой. Кандидаты: код рядом с папкой программы (поставка:
    `<корень>/tree`), дерево разработки (`../live`), и явный HELENE_CODE.
    """
    try:
        import self_model  # noqa: WPS433 — из tree/
        return self_model
    except ImportError:
        root = _RESOURCES.parent.parent
        for cand in (os.environ.get("HELENE_CODE") or "", root / "tree", root.parent / "live"):
            cand = Path(cand) if cand else None
            if cand and (cand / "self_model.py").is_file():
                sys.path.insert(0, str(cand))
                break
        try:
            import self_model  # noqa: WPS433
            return self_model
        except Exception as exc:
            log.warning("запись о себе: self_model не импортируется (%s)", exc)
            return None
    except Exception as exc:
        log.warning("запись о себе: self_model не импортируется (%s)", exc)
        return None


def seed_self(tree: Path, cfg: dict) -> bool:
    """Запись о себе в день ноль — в кадр, через `self_model` с провенансом.

    Зона K кадра — три файла: конституция, голос и `soul/self/CURRENT.md`.
    Первые два — обычный markdown, их кладёт `_seed_kit`. Третий кадр читает
    только с провенанс-шапкой (`self_model.current_prompt` возвращает пустоту
    на файле без неё), поэтому положить его копией нельзя: он ляжет мёртвым, и
    в кадре на этом месте будет дыра. Единственный законный вход — `migrate`:
    письмо `soul/self.md` уходит в `history/0000.md` как самая первая версия,
    а текст из `resources/self-day-zero.md` становится CURRENT ревизии 0.

    Идемпотентно: при живом CURRENT ничего не делает — правку агента обновление
    продукта не затирает. `self_model` живёт в `tree/`, и путь туда руннер
    вставляет в `sys.path` до раскладки; здесь импорт ленивый, чтобы раскладка
    без ядра (тесты, чужой запуск) не падала на нём.
    """
    legacy = tree / "soul" / "self.md"
    if not legacy.is_file() or not _SELF_DAY_ZERO.is_file():
        return False
    self_model = _import_self_model()
    if self_model is None:
        return False
    try:
        if self_model.current_prompt_info(tree).source == "current":
            return False
        text = _names(_SELF_DAY_ZERO.read_text(encoding="utf-8"), cfg)
        result = self_model.migrate(
            base=tree,
            reason="день ноль: запись о себе положена теми, кто собрал дом; "
                   "агент переписывает её первой",
            evidence_refs=["soul/SOUL.md", "soul/self.md"],
            compact_text=text,
            by="helene",
            confidence="uncertain",
            trigger="birth",
        )
    except Exception:
        log.exception("запись о себе не легла в дерево")
        return False
    if not result.get("ok"):
        log.warning("запись о себе не легла: %s", result.get("error"))
        return False
    return bool(result.get("migrated"))


# --------------------------------------------------------------------------- #
#  Личный git агента
# --------------------------------------------------------------------------- #

# Что НЕ снимок его работы: память и журналы ведёт код дерева на каждом ходе,
# ключи (memory/llm.json, relay/local_auth) в историю не кладут никогда,
# смонтированное (workspace/mnt) — чужие папки владельца, модели голоса
# (models/) — снаряжение машины весом в гигабайты.
_GIT_IGNORE = """\
# Личный репозиторий агента: снимки ЕГО правок — конституции, голоса, записи о
# себе, навыков, рабочих файлов. Память, журналы, ключи и смонтированное —
# не снимки: их ведёт код дерева, а ключам в истории не место.
memory/
relay/
telegram/
body/
.desktop-owner.lock
.python-desktop-status
.python-desktop-status.*.tmp
# Модели голоса: полтора гигабайта снаряжения машины. В снимках правок агента им
# не место — и попади они туда, личный репозиторий распух бы до неподъёмного.
models/
*.log
*.sqlite3
*.sqlite3-*
*.session
*.session-journal
workspace/.fence/
workspace/.tmp/
workspace/mnt/
workspace/media/
__pycache__/
"""


#: Строки, без которых личный git агента набирает то, чему в снимках не место.
#: Проверяются и в СУЩЕСТВУЮЩЕМ файле: он пишется один раз при заведении
#: репозитория, а список с тех пор пополнялся — и у того, кто поставил продукт
#: раньше, в снимки уехали бы гигабайты моделей голоса (снимок делает `add -A`).
_IGNORE_MUST = ("memory/", "relay/", "telegram/", "body/", "models/", ".desktop-owner.lock",
                ".python-desktop-status", ".python-desktop-status.*.tmp",
                "workspace/mnt/", "workspace/.fence/", "workspace/.tmp/")


def _top_up_ignore(path: Path) -> list[str]:
    """Дописать в существующий `.gitignore` то, чего в нём не хватает.

    Файл не переписывается целиком намеренно: агент дописывает в него своё, и
    затирать его правки ради нашей строки нельзя.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    have = {line.strip() for line in text.splitlines()}
    missing = [item for item in _IGNORE_MUST if item not in have]
    if not missing:
        return []
    head = ("\n# Дописано продуктом: этих строк не было, а без них в снимки правок\n"
            "# агента попадает то, что снимком его работы не является.\n")
    try:
        with path.open("a", encoding="utf-8", newline="\n") as fh:
            if not text.endswith("\n"):
                fh.write("\n")
            fh.write(head + "\n".join(missing) + "\n")
    except OSError as exc:
        log.warning("личный git: .gitignore не дополнен (%s): %s", path, exc)
        return []
    log.info("личный git: в .gitignore дописано %s", ", ".join(missing))
    return missing


def git_exe() -> Path | None:
    """git из поставки: Windows — `runtime/git/cmd/git.exe` (MinGit, см.
    build_dist.stage_git), macOS — `runtime/git/bin/git` (git, собранный с
    RUNTIME_PREFIX; кладёт сборка Mac)."""
    runtime = _RESOURCES.parent.parent / "runtime"
    bundled = (runtime / "git" / "cmd" / "git.exe" if os.name == "nt"
               else runtime / "git" / "bin" / "git")
    return bundled if bundled.is_file() else None


def _developer_tools_present() -> bool:
    """macOS: стоят ли Command Line Tools (`xcode-select -p` отвечает нулём)."""
    import subprocess
    try:
        done = subprocess.run(["/usr/bin/xcode-select", "-p"], capture_output=True,
                              text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return False
    return done.returncode == 0


def git_ready() -> Path | None:
    """Каким git пользоваться: поставки, иначе системный — если он настоящий.

    ⚠ macOS без Command Line Tools: `/usr/bin/git` есть всегда, но это заглушка
    Apple — `which` её находит, а ЗАПУСК открывает диалог «установить
    инструменты разработчика» посреди первого запуска и возвращает ошибку.
    Такой git не считается найденным: снимки правок агента выключены, о чём
    говорит журнал, а окно не трогаем. Настоящий git не из поставки (Homebrew)
    остаётся годным — заглушка узнаётся по пути, а не по платформе.
    """
    import shutil
    exe = git_exe()
    if exe is not None:
        return exe
    found = shutil.which("git")
    if not found:
        return None
    if (sys.platform == "darwin" and os.path.realpath(found) == "/usr/bin/git"
            and not _developer_tools_present()):
        log.warning("git: в поставке нет (runtime/git/bin/git), а системный без "
                    "Command Line Tools — заглушка; снимков правок агента не будет")
        return None
    return Path(found)


def arm_git() -> str:
    """Вставить git поставки в PATH этого процесса — ПЕРВЫМ.

    `selfgit` дерева зовёт голое `git`, а `runner._git_state` спрашивает
    `git_ready`; без этой строки поставка с git в runtime/git всё равно
    считала бы, что git нет. Первым — чтобы снимки делал наш git, а не что
    нашлось на машине. -> откуда git: «поставка» | «система» | «».
    """
    exe = git_exe()
    if exe is not None:
        here = str(exe.parent)
        if here not in os.environ.get("PATH", "").split(os.pathsep):
            os.environ["PATH"] = here + os.pathsep + os.environ.get("PATH", "")
        return "поставка"
    return "система" if git_ready() is not None else ""


def _agent_email(cfg: dict) -> str:
    """Адрес автора снимков: латиница из имени или `agent`, домен — helene.local."""
    plain = agent_name(cfg).lower().encode("ascii", "ignore").decode()
    slug = re.sub(r"[^a-z0-9]+", "", plain)
    return f"{slug or 'agent'}@helene.local"


def seed_git(tree: Path, cfg: dict) -> bool:
    """Личный репозиторий агента в дереве данных — один раз, при рождении дома.

    Кадр дерева обещает агенту автокоммит правок (`selfgit.snapshot`) и
    страховочные снимки перед shell (`selfgit.safety_point`); оба молчат без
    репозитория в BASE. Здесь он и заводится: `git init` в дереве данных, игнор
    на память и ключи, автор — сам агент, первый снимок — дом в день ноль.
    Слово владельца 06.09: «git как в Уроборосе, из коробки, личный для агента».

    Живой `.git` не пересоздаём: обновляем игнор и снимаем из индекса только
    производные замок/статус процесса. Без git (ни поставки, ни системы) —
    честное предупреждение в лог, кадру об этом скажет `runner._announce_git`.
    Полурепозиторий (init прошёл, снимок нет) сносится, чтобы следующий старт
    попробовал заново, а не жил с HEAD без коммита, на котором safety_point
    молча возвращает None.
    """
    import shutil
    import subprocess
    existing = (tree / ".git").exists()
    # Тот же ответ, что у `arm_git`: заглушка Apple без Command Line Tools —
    # это не git, и звать её отсюда значило бы открыть диалог посреди раскладки.
    if git_ready() is None:
        log.warning("личный git агента не заведён: git не найден ни в поставке "
                    "(runtime/git), ни в системе")
        return False
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    def git(*args: str) -> subprocess.CompletedProcess:
        return subprocess.run(["git", "-C", str(tree), *args], capture_output=True,
                              text=True, encoding="utf-8", errors="replace",
                              timeout=120, creationflags=flags)

    if existing:
        # Old homes may already track the exclusive runtime lock. Ignore rules
        # do not untrack it. Remove only these derived index entries, never the
        # working files, commits, authored source, or the live lock itself.
        try:
            ignore = tree / ".gitignore"
            if not ignore.exists():
                ignore.write_text(_GIT_IGNORE, encoding="utf-8", newline="\n")
            else:
                _top_up_ignore(ignore)
            done = git("rm", "--cached", "--ignore-unmatch", "-f", "--",
                       ".desktop-owner.lock", ".python-desktop-status")
            if done.returncode:
                log.warning("личный git: служебные файлы остались в индексе: %s",
                            (done.stderr or done.stdout or "").strip()[:300])
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("личный git: проверка служебных файлов не завершена: %s", exc)
        return False

    try:
        ignore = tree / ".gitignore"
        if not ignore.exists():
            ignore.write_text(_GIT_IGNORE, encoding="utf-8", newline="\n")
        else:
            _top_up_ignore(ignore)
        steps = (
            # `init -b main` появился в git 2.28, а на Debian 10 (заявленный порог
            # поставки) системный git 2.20: unborn HEAD переставляется на main
            # `symbolic-ref`'ом — это работает у всех, от 2.20 до новых.
            ("init", "-q"),
            ("symbolic-ref", "HEAD", "refs/heads/main"),
            ("config", "user.name", agent_name(cfg)),
            ("config", "user.email", _agent_email(cfg)),
            ("config", "core.autocrlf", "false"),
            ("config", "core.safecrlf", "false"),
            ("config", "core.quotepath", "false"),
            # фоновая сборка мусора не отцепляется в отдельный процесс: под
            # оградой он пережил бы задание и остался в контейнере навсегда
            ("config", "gc.autoDetach", "false"),
            ("add", "-A"),
            ("commit", "-q", "--no-verify", "-m", "день ноль: дом собран"),
        )
        for step in steps:
            done = git(*step)
            if done.returncode != 0:
                said = (done.stderr or done.stdout or "").strip()[:300]
                raise OSError(f"git {' '.join(step[:2])}: {said}")
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("личный git агента не заведён: %s", exc)
        shutil.rmtree(tree / ".git", ignore_errors=True)
        return False
    return True


def _unfinished_birth_scaffold(tree: Path) -> bool:
    """The gap after a first creator made directories but before O_EXCL marker.

    A legacy tree containing only these empty directories is ambiguous too:
    refusing it is safer than interpreting a second writer as an old home.
    """
    entries = list(tree.iterdir())
    if len(entries) != 1 or entries[0].name != "memory" or not entries[0].is_dir():
        return False
    entries = list(entries[0].iterdir())
    if not entries:
        return True
    return (len(entries) == 1 and entries[0].name == ".state" and
            entries[0].is_dir() and not any(entries[0].iterdir()))


def ensure_layout(tree: Path, cfg: dict | None = None, *, soul_seed: str | None = None,
                  skills_seed: dict[str, str] | None = None,
                  birth_receipt: Path | None = None) -> None:
    """Составляющие кадра — каждая в своей папке (слово владельца 30.08).

    Создаём только то, чего дерево само не заводит по дороге: дом конституции,
    входной ящик окна и стартовый комплект из `resources/**`. Остальное
    (memory/**, runs, .state) код дерева создаёт сам — заводить это здесь
    значило бы держать вторую карту раскладки.

    The production runner presents one tree-bound birth receipt, minted by
    setup or agents.create outside the data tree and consumed exactly once.
    Missing, interrupted or completed receipts never authorize another birth;
    later kit soul text stays as candidates outside soul. Direct test callers
    without a receipt may seed an empty home only through the compatibility path.
    `soul_seed` (1.4.0) — текст рождения из `agents/<id>/soul-seed.md`,
    который раннер читает рядом с конфигом: он ложится вместо канона ТОЖЕ только
    при отсутствии души; живая душа сильнее сида. Подстановка имён — та же,
    `{{agent}}`/`{{owner}}`, и только они: сид — текст, а не макрос.
    `skills_seed` (1.4.1) — знания рождения из `agents/<id>/skills-seed/`:
    ложатся в `soul/skills/` тоже только при отсутствии своего файла — живое
    сильнее рождения, всегда.

    ⚠ Неписуемая папка (диск только для чтения, чужие права, антивирус) роняла
    руннер здесь голым PermissionError — оболочка видела «упал» и перезапускала
    его по кругу, не имея чем назвать причину владельцу. Теперь причина названа
    исключением с текстом, а руннер уходит кодом «конфиг/раскладка», не «упал».
    """
    cfg = cfg or {}
    tree = Path(tree)
    proposals: set[str] = set()
    # Classify BEFORE creating a directory. A missing SOUL or .git is not proof
    # of birth: both can be lost from an agent who has already lived here. This
    # exclusive marker also serializes two competing first starts: only one may
    # seed, the loser refuses an incomplete home rather than opening it.
    try:
        if birth_receipt is not None:
            # A real runner must use install/agent provenance OUTSIDE data. A
            # deleted data tree is not a new agent; a shell/service desk-token
            # prewrite is not proof of birth. Only an installer/create receipt
            # authorizes the first seed, once, bound to this exact tree.
            marker = Path(birth_receipt)
            if marker.is_symlink():
                raise LayoutError(f"маркер рождения — symlink: {marker}")
            if marker.is_file():
                state = json.loads(marker.read_text(encoding="utf-8"))
                if not isinstance(state, dict) or state.get("schema") != 1 or \
                        os.path.normcase(str(Path(state.get("tree", "")).resolve())) != \
                        os.path.normcase(str(tree.resolve())):
                    raise LayoutError(f"маркер рождения не принадлежит дереву {tree}")
                if state.get("state") == "prepared":
                    claim = marker.with_name(marker.name + ".claim")
                    fd = os.open(claim, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    with os.fdopen(fd, "w", encoding="utf-8") as sink:
                        json.dump({"pid": os.getpid(), "tree": state["tree"]}, sink)
                        sink.flush()
                        os.fsync(sink.fileno())
                    state["state"] = "started"
                    tmp = marker.with_name(marker.name + ".tmp")
                    tmp.write_text(json.dumps(state), encoding="utf-8")
                    os.replace(tmp, marker)
                    empty = True
                elif state.get("state") in ("complete", "partial"):
                    empty = False
                else:
                    raise LayoutError(f"первое рождение не завершено ({marker}); проверь дерево")
            else:
                if marker.exists():
                    raise LayoutError(f"маркер рождения не файл: {marker}")
                empty = False
        else:
            # Only isolated direct boot callers use this compatibility route.
            empty = not tree.exists() or not any(tree.iterdir())
            marker = tree / "memory" / ".state" / "kit-birth.json"
            if not empty and not marker.exists() and _unfinished_birth_scaffold(tree):
                raise LayoutError(f"рождение другого процесса ещё не отмечено ({tree}); "
                                  "сохрани дерево и повтори после проверки")
            if empty:
                marker.parent.mkdir(parents=True, exist_ok=True)
                try:
                    fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                except FileExistsError:
                    empty = False
                else:
                    with os.fdopen(fd, "w", encoding="utf-8") as sink:
                        json.dump({"state": "started", "pid": os.getpid()}, sink)
                        sink.flush()
                        os.fsync(sink.fileno())
            if not empty and marker.exists():
                if marker.is_symlink():
                    raise LayoutError(f"маркер рождения — symlink: {marker}")
                started = json.loads(marker.read_text(encoding="utf-8"))
                if not isinstance(started, dict) or started.get("state") != "complete":
                    raise LayoutError(f"первое рождение не завершено ({marker}); "
                                      "сохрани дерево и проверь его до повторного старта")
    except (OSError, ValueError) as exc:
        raise LayoutError(f"состояние рождения не читается ({tree}): {exc}") from exc
    for rel in ("soul", "workspace/inbox", "memory/.control/desk_inbox/processed"):
        try:
            (tree / rel).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise LayoutError(f"не создаётся папка {tree / rel}: {exc}") from exc
    soul = tree / "soul" / "SOUL.md"
    if not soul.exists():
        text = soul_text(cfg)
        if soul_seed and soul_seed.strip():
            # Сид рождения сильнее канона — но слабее живой души: файл существует,
            # значит слово о себе уже сказано, и мы его не переписываем.
            text = _names(soul_seed, cfg)
        try:
            if empty:
                soul.write_text(text, encoding="utf-8", newline="\n")
            else:
                import kit_proposals
                selected = kit_proposals.stage(tree, "soul/SOUL.md", text.encode("utf-8"), source="kit")
                if selected:
                    proposals.add(selected)
        except (OSError, UnicodeError) as exc:
            raise LayoutError(f"конституция не подготовлена ({soul}): {exc}") from exc
    planted = _seed_kit(tree, cfg, birth=empty,
                        skill_overrides=frozenset(skills_seed or ()), proposals=proposals)
    if planted:
        log.info("стартовый комплект: положено файлов в дерево: %d", planted)
    # Знания рождения (1.4.1, доктор): каждый файл — только при отсутствии
    # своего места в soul/skills/; живое сильнее рождения.
    if skills_seed:
        skills_root = tree / "soul" / "skills"
        try:
            skills_root.mkdir(parents=True, exist_ok=True)
            for fname, text in skills_seed.items():
                target = skills_root / fname
                if empty and target.exists():
                    continue
                if empty:
                    target.write_text(text, encoding="utf-8", newline="\n")
                else:
                    import kit_proposals
                    selected = kit_proposals.stage(tree, f"soul/skills/{fname}",
                                                   text.encode("utf-8"), source="kit:agent-seed")
                    if selected:
                        proposals.add(selected)
        except (OSError, ValueError, UnicodeError) as exc:
            raise LayoutError(f"не пишутся знания рождения {skills_root}: {exc}") from exc
    refreshed = refresh_kit(tree, cfg, birth=empty,
                            skill_overrides=frozenset(skills_seed or ()), proposals=proposals)
    if refreshed:
        log.info("стартовый комплект: обновлены нетронутые тексты поставки — %s",
                 ", ".join(refreshed))
    if empty and seed_self(tree, cfg):
        log.info("запись о себе: день ноль, soul/self/CURRENT.md")
    # После записи о себе: первый снимок должен застать дом целиком.
    git_seeded = seed_git(tree, cfg)
    if git_seeded:
        log.info("личный git агента: репозиторий заведён в дереве данных, "
                 "первый снимок «день ноль» сделан")
    if not empty:
        import kit_proposals
        kit_proposals.publish_active(tree, proposals)
    if empty:
        # An interrupted birth stays visibly incomplete. Even a *returned*
        # birth can lack a soul file, a provenance-valid CURRENT or Git (the
        # legacy seed helpers warn and return on failure). Never certify such
        # a home complete or silently retry installing persona on next boot.
        gaps = []
        for source in sorted((_RESOURCES / "soul").rglob("*.md")):
            target = tree / "soul" / source.relative_to(_RESOURCES / "soul")
            if not target.is_file():
                gaps.append(target.relative_to(tree).as_posix())
        if not soul.is_file():
            gaps.append("soul/SOUL.md")
        if _SELF_DAY_ZERO.is_file():
            model = _import_self_model()
            try:
                valid_self = (model is not None and
                              model.current_prompt_info(tree).source == "current")
            except (OSError, ValueError, UnicodeError):
                valid_self = False
            if not valid_self:
                gaps.append("soul/self/CURRENT.md")
        if not (tree / ".git").exists():
            gaps.append("agent_git")
        if gaps and birth_receipt is not None:
            # She gets a precise candidate/repair address on her first turn.
            # No implicit second birth follows this partial result. A fresh
            # failure while retaining candidates leaves STARTED, not complete.
            import kit_proposals
            if "soul/SOUL.md" in gaps:
                selected = kit_proposals.stage(tree, "soul/SOUL.md",
                                               (soul_seed or soul_text(cfg)).encode("utf-8"),
                                               source="kit")
                if selected:
                    proposals.add(selected)
            _seed_kit(tree, cfg, birth=False, proposals=proposals)
            refresh_kit(tree, cfg, birth=False, proposals=proposals)
            kit_proposals.publish_active(tree, proposals)
            log.warning("первое рождение частично: %s; тексты души не досеиваются без решения агента",
                        ", ".join(gaps))
        temporary = marker.with_name(marker.name + ".tmp")
        completed = ({**state, "state": "partial" if gaps else "complete", "gaps": gaps}
                     if birth_receipt is not None
                     else {"state": "complete"})
        temporary.write_text(json.dumps(completed), encoding="utf-8")
        os.replace(temporary, marker)


# --------------------------------------------------------------------------- #
#  Замок на дерево: одна копия харнесса на одну память
# --------------------------------------------------------------------------- #

# Владелец замка обязан подтверждать, что жив (сердцебиение руннера переписывает
# отметку каждые 10 с). Три минуты — это восемнадцать пропущенных подтверждений:
# столько живой руннер не молчит даже на самом долгом ходе, потому что отметку
# пишет отдельный поток.
_LOCK_FRESH_SEC = 180.0
_LOCK: dict = {"path": None, "token": ""}
_BIRTH_CUSTODY = threading.Lock()


def tree_lock_path(tree: Path) -> Path:
    return Path(tree) / "memory" / ".state" / "harness.lock"


def _pid_alive(pid: int) -> bool:
    """Жив ли процесс. На Windows — только запрос, НИКАКОГО os.kill.

    ⚠ `os.kill(pid, 0)` на Windows не «проверяет», а зовёт TerminateProcess:
    проверка живости чужого руннера убила бы его вместе с ходом владельца.
    """
    if pid <= 0:
        return False
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True                      # чужой пользователь — но жив
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = kernel32.OpenProcess(0x1000, False, int(pid))   # QUERY_LIMITED_INFO
    if not handle:
        # 5 = отказано в доступе: процесс ЕСТЬ, просто чужой. 87 = нет такого.
        return ctypes.get_last_error() == 5
    try:
        code = ctypes.c_ulong(0)
        if kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
            return code.value == 259         # STILL_ACTIVE
        return True
    finally:
        kernel32.CloseHandle(handle)


def _read_lock(path: Path) -> dict:
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _torn_lock_is_abandoned(path: Path) -> bool:
    """Reclaim only a stable, old empty/zero-filled record left by a crash.

    Fresh reservations, unreadable files and unknown nonzero contents keep
    ownership protection. An ordinary heartbeat updates at least every10s.
    """
    try:
        before = path.stat()
        if time.time() - before.st_mtime <= _LOCK_FRESH_SEC:
            return False
        with path.open('rb') as source:
            raw = source.read(16385)
        after = path.stat()
    except OSError:
        return False
    if (len(raw) > 16384 or raw.strip(b'\0') or
            (before.st_ino, before.st_size, before.st_mtime_ns) !=
            (after.st_ino, after.st_size, after.st_mtime_ns)):
        return False
    log.warning('замок дерева пуст или заполнен нулями и давно не обновлялся — восстанавливаю запуск')
    return True


def _lock_is_live(holder: dict) -> bool:
    """Владелец замка жив? Сомнение — в пользу ЖИВОГО: два агента хуже, чем один."""
    if not holder:
        return False
    if holder.get('role') in ('explicit first-create','server-transfer'):
        # Component installation can outlast the legacy heartbeat TTL. This
        # short-lived lease is tied to an actual process generation instead;
        # an unknown or remote owner never becomes permission to take it.
        import psutil
        if holder.get('host')!=platform.node():return True
        try:
            pid=holder.get('pid');birth=holder.get('birth')
            if type(pid) is not int or pid<=0 or type(birth) not in (int,float) or not math.isfinite(birth) or birth<=0:return True
            process=psutil.Process(pid)
            return process.create_time()==birth and process.status()!=psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:return False
        except (psutil.Error,OSError,ValueError,OverflowError):return True
    try:
        pid = int(holder.get("pid") or 0)
        at = float(holder.get("at") or 0.0)
    except (TypeError, ValueError):
        return False
    # Замок с другого хоста: номер процесса чужого пространства ничего не значит.
    # Найдено на сервере 06.09: контейнер пересоздан, новый раннер получил тот же
    # pid 8, что и прежний в замке, и харнесс отказывался подниматься кодом 3.
    # Свой собственный номер в чужом замке — тот же случай (тот же контейнер,
    # `docker restart`): держать замок сами на себя мы не можем.
    host = str(holder.get("host") or "")
    if host and host != platform.node():
        log.warning("замок дерева: pid %d на хосте %s, а мы на %s — считаю замок брошенным",
                    pid, host, platform.node())
        return False
    if pid == os.getpid():
        log.warning("замок дерева: в нём наш собственный pid %d — замок брошен прежней копией",
                    pid)
        return False
    if not _pid_alive(pid):
        return False
    if time.time() - at > _LOCK_FRESH_SEC:
        # Pid жив, а отметка старая: скорее всего номер достался чужому процессу
        # (винда их переиспользует). Забираем дерево, но говорим об этом вслух.
        log.warning("замок дерева: pid %d жив, но не подтверждал себя %.0f с — "
                    "считаю замок брошенным", pid, time.time() - at)
        return False
    return True


def claim_tree(tree: Path, *, agent: str = "", role: str = "", reclaim_stale: bool = True) -> dict:
    """Забрать дерево себе. -> {} наш; иначе снимок ЖИВОГО владельца замка.

    ⚠ Замок по ПОРТУ (оболочка, служба) закрывает только случай «порт занят».
    А случаев, где руннер жив, а deskapp на порту нет, хватает: осиротевший
    процесс прошлой копии, убитый антивирусом deskapp, служба, поставленная из
    работающего окна. Живьём это выглядит так: рождение случается ДВАЖДЫ, ходы
    двух копий перемешиваются в ленте владельца, записка съедается одной копией
    и остаётся без ответа у другой — и ни один лог не говорит о второй ни слова.
    Для владельца это не «два агента», а «агент сломался».

    Замок — файл в самом дереве, потому что защищаем мы дерево, а не порт.
    Гонка двух одновременных стартов закрыта O_EXCL; брошенный замок (руннер
    убит) снимается проверкой живости pid.
    """
    # A different selected agent/global Resume must never restart this local
    # copy while a VPS may own its life. This survives controller replacement.
    transfer = Path(tree)/'memory/.state/server-transfer.json'
    try:
        moved = json.loads(transfer.read_text(encoding='utf-8'))
    except FileNotFoundError: moved = None
    except (OSError,ValueError): raise LayoutError('Не прочитана квитанция переноса на VPS; местный запуск заблокирован') from None
    if moved is not None and (not isinstance(moved,dict) or moved.get('phase')!='server-stopped'):
        raise LayoutError('Этот агент перенесён на VPS или перенос ещё не завершён; сначала останови серверную копию через восстановление')
    path = tree_lock_path(tree)
    mine = {"pid": os.getpid(), "at": time.time(), "agent": str(agent or ""),
            "role": str(role or ""), "host": platform.node(),
            "token": hashlib.sha1(f"{os.getpid()}:{time.time()}".encode()).hexdigest()[:12]}
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        log.warning("замок дерева не завести (%s) — иду без него: %s", path, exc)
        return {}
    for attempt in (1, 2):
        try:
            handle = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            holder = _read_lock(path)
            # A creator may have just reserved this name but not written its
            # JSON yet. Unknown is not a dead process. Explicit first birth
            # also never reclaims a pre-existing record, including stale ones.
            if not reclaim_stale or (not holder and not _torn_lock_is_abandoned(path)):
                return holder or {"pid": 0, "state": "identity-unknown"}
            if _lock_is_live(holder):
                return holder
            if attempt == 2:
                return _read_lock(path) or {"pid": 0}
            try:
                os.unlink(path)              # брошенный замок — снимаем и берём
            except OSError:
                return _read_lock(path) or {"pid": 0}
            continue
        except OSError as exc:
            # Своей неудачей замок не имеет права остановить продукт: без него
            # мы возвращаемся ровно к прежнему поведению, и это сказано в логе.
            log.warning("замок дерева не завести (%s) — иду без него: %s", path, exc)
            return {}
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as sink:
            json.dump(mine, sink, ensure_ascii=False)
        _LOCK["path"], _LOCK["token"] = path, mine["token"]
        atexit.register(release_tree)
        log.info("замок дерева взят: %s (pid %d)", path, mine["pid"])
        return {}
    return {}


def refresh_tree_lock() -> None:
    """Подтвердить, что владелец замка жив. Зовёт сердцебиение руннера."""
    path, token = _LOCK["path"], _LOCK["token"]
    if path is None:
        return
    holder = _read_lock(path)
    if holder and holder.get("token") != token:
        # Замок уже не наш (кто-то счёл нас мёртвыми) — переписывать чужое нельзя.
        log.warning("замок дерева больше не наш: им владеет pid %s",
                    holder.get("pid"))
        _LOCK["path"] = None
        return
    holder.update({"pid": os.getpid(), "at": time.time(), "token": token})
    # Never truncate the live ownership record. Persist the complete heartbeat
    # before atomic replacement so a crash leaves the preceding record intact.
    import tempfile
    spare = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='\n',
                prefix=path.name+'.', suffix='.tmp', dir=path.parent, delete=False) as sink:
            spare = Path(sink.name)
            json.dump(holder, sink, ensure_ascii=False)
            sink.flush()
            os.fsync(sink.fileno())
        current = _read_lock(path)
        if current and current.get('token') != token:
            _LOCK['path'] = None
            log.warning('замок дерева сменил владельца во время пульса; чужую запись не меняю')
            return
        os.replace(spare, path)
    except OSError as exc:
        log.warning("замок дерева не подтверждён: %s", exc)
    finally:
        if spare is not None:
            try:spare.unlink(missing_ok=True)
            except OSError:pass


def release_tree() -> None:
    """Снять свой замок. Чужой не трогаем даже на выходе."""
    path, token = _LOCK["path"], _LOCK["token"]
    if path is None:
        return
    _LOCK["path"] = None
    try:
        if _read_lock(path).get("token") == token:
            path.unlink(missing_ok=True)
    except OSError:
        pass


@contextmanager
def birth_custody(tree: Path):
    """First Create must own a real tree lock; legacy fail-open is insufficient."""
    with _BIRTH_CUSTODY:
        if _LOCK['path'] is not None:
            raise LayoutError('Этот процесс уже владеет деревом; новое рождение не начато')
        if os.path.lexists(tree_lock_path(tree)):
            raise LayoutError('Есть прежняя запись владения данными; первое создание не удаляет чужие или неопределённые замки')
        busy=claim_tree(tree,role='explicit first-create',reclaim_stale=False)
        try:
            path=tree_lock_path(tree);holder=_read_lock(path)
            if (busy or _LOCK['path']!=path or not _LOCK['token']
                    or holder.get('token')!=_LOCK['token'] or holder.get('pid')!=os.getpid()):
                raise LayoutError('Не подтверждено исключительное владение данными; первое создание не начато')
            import psutil
            from .vision_policy import _document, _write
            holder['birth']=psutil.Process(os.getpid()).create_time()
            _write(path,_document(holder),private=True)
            yield
        finally:release_tree()


# --------------------------------------------------------------------------- #
#  Сторож родителя: оболочка умерла — уходим сами (POSIX)
# --------------------------------------------------------------------------- #
#
# На Windows детей держит job-объект оболочки: умерла она — умерли движок и
# канал. На macOS и Linux такого механизма нет: осиротевший движок жил бы дальше
# с замком на дереве и открытой сессией Telegram, а следующее окно увидело бы
# «этой памятью уже занят другой». Оболочка (shell/src/main.rs) ставит детям
# HELENE_PARENT_PID на всех платформах; здесь его читают только POSIX-ветки.

PARENT_PID_ENV = "HELENE_PARENT_PID"
_WATCH: dict = {"parent": 0}

#: Колбэки мягкого выхода: отрабатывают при SIGTERM ДО SystemExit и перед жёстким
#: добиванием сторожа (`os._exit`), которого atexit уже не застаёт. Ими, например,
#: ограда macOS снимает детей команд, переживших движок (`fence_macos`).
_SOFT_EXIT_HOOKS: list = []


def on_soft_exit(fn) -> None:
    """Зарегистрировать колбэк мягкого выхода. Идемпотентно (один и тот же — раз).

    На Windows обработчик SIGTERM не ставится (детей держит job-объект оболочки),
    так что зарегистрированные колбэки там просто не сработают — и это верно.
    """
    if callable(fn) and fn not in _SOFT_EXIT_HOOKS:
        _SOFT_EXIT_HOOKS.append(fn)


def _run_soft_exit_hooks(name: str) -> None:
    for fn in list(_SOFT_EXIT_HOOKS):
        try:
            fn()
        except Exception:
            log.warning("%s: колбэк мягкого выхода упал", name, exc_info=True)


def parent_pid() -> int:
    """pid оболочки из HELENE_PARENT_PID; 0 — не задан или не число."""
    raw = (os.environ.get(PARENT_PID_ENV) or "").strip()
    try:
        return max(0, int(raw)) if raw else 0
    except ValueError:
        log.warning("%s = %r — не число, сторож родителя не ставится", PARENT_PID_ENV, raw)
        return 0


def arm_soft_exit(name: str) -> bool:
    """POSIX: SIGTERM → SystemExit в главном потоке, а не мгновенная смерть.

    Умолчание Python на SIGTERM — умереть сразу, без atexit: замок дерева
    остался бы лежать, а квитанции — недописанными. Обработчик поднимает
    SystemExit там, где главный поток сейчас (в ожидании записки, внутри хода),
    и дальше отрабатывают `finally` и atexit (`release_tree`). Тот же путь,
    которым процесс уходит по `kill` от оболочки, — и сторож родителя ниже
    дёргает именно его. На Windows не ставится: там SIGTERM никто не шлёт, а
    останавливает детей job-объект.
    """
    if os.name == "nt":
        return False

    def _on_term(signum, _frame):
        log.info("%s: получен SIGTERM — завершаюсь", name)
        # Колбэки — ЗДЕСЬ, до SystemExit: если ход застрянет в чужом коде и
        # сторож добьёт процесс `os._exit`, atexit не отработает, а эти уже да.
        _run_soft_exit_hooks(name)
        raise SystemExit(128 + int(signum))

    try:
        signal.signal(signal.SIGTERM, _on_term)
    except (ValueError, OSError) as exc:       # не главный поток
        log.warning("%s: обработчик SIGTERM не поставлен: %s", name, exc)
        return False
    return True


def watch_parent(name: str, *, every: float = 2.0, grace: float = 8.0) -> int:
    """Сторож родителя (POSIX): оболочка умерла — уходим вслед. -> pid или 0.

    Поток-демон раз в `every` секунд сверяет `os.getppid()` с HELENE_PARENT_PID.
    Расхождение (родитель умер — ppid стал 1, launchd, или другим) → SIGTERM
    самим себе, то есть мягкий выход (`arm_soft_exit`; у канала SIGTERM
    штатно ловит aiohttp). Не ушли за `grace` секунд (ход застрял в чужом
    коде, кто-то проглотил SystemExit) — `os._exit`: лучше грубо, чем сирота
    навсегда. На Windows и без переменной сторож не ставится (0).
    """
    if os.name == "nt":
        return 0
    parent = parent_pid()
    if parent <= 0:
        return 0
    if os.getppid() != parent:
        # Нас поднял не тот, кто назван, — судить о его жизни по ppid нельзя.
        # Не сторожим и говорим об этом: молчаливый сторож не той цели убил бы
        # живой процесс.
        log.warning("%s: %s = %d, а родитель — pid %d; сторож родителя не ставлю",
                    name, PARENT_PID_ENV, parent, os.getppid())
        return 0

    def _loop() -> None:
        while True:
            time.sleep(every)
            if os.getppid() == parent:
                continue
            log.warning("%s: оболочка (pid %d) умерла — завершаюсь вслед за ней", name, parent)
            try:
                os.kill(os.getpid(), signal.SIGTERM)
            except OSError as exc:
                log.warning("%s: SIGTERM себе не ушёл: %s", name, exc)
            time.sleep(grace)
            log.error("%s: не завершился за %.0f с после SIGTERM — выхожу жёстко", name, grace)
            # Backstop: если главный поток застрял и `_on_term` не отработал,
            # колбэки (снятие детей ограды) не звал никто — зовём отсюда перед
            # жёстким `os._exit`, который atexit уже не застанет. Идемпотентно.
            _run_soft_exit_hooks(name)
            try:
                logging.shutdown()
            finally:
                os._exit(143)

    threading.Thread(target=_loop, name="parent-watch", daemon=True).start()
    _WATCH["parent"] = parent
    log.info("%s: сторож родителя поставлен — оболочка pid %d", name, parent)
    return parent


# Имена ручек, значение которых нельзя показывать: экран «Система», телефон и
# GET /api/anatomy читают один и тот же файл, а ключ в таблице на экране — это
# ключ на скриншоте и при демонстрации экрана.
_SECRET_NAME_PARTS = ("KEY", "TOKEN", "SECRET", "PASSWORD", "PASSWD", "PWD",
                      "PASS", "CREDENTIAL", "COOKIE", "SESSION")
# Имена, которые содержат опасное слово, но секретом не являются: `max_tokens`
# из блока модели пропал бы с экрана «Система» вместе с ключами, а это ровно та
# настройка, ради показа которой экран и заведён.
_SECRET_NAME_SAFE = ("MAX_TOKENS", "MAX_OUTPUT_TOKENS", "TOKENS_TODAY", "TOKEN_CAP",
                     "TOKEN_BUDGET", "TOKEN_LIMIT", "KEYWORD", "PASSTHROUGH", "BYPASS")

# Пароль внутри адреса — форма, которую кред-пол дерева не ловит (он про токены),
# а владелец кладёт её в ручки постоянно: DATABASE_URL, SMTP_URL, AMQP_URL.
_URL_PASSWORD = re.compile(r"://[^/\s:@]{1,64}:[^/\s@]{1,256}@")


def is_secret_knob(name: str) -> bool:
    upper = str(name).upper()
    for safe in _SECRET_NAME_SAFE:          # вычёркиваем безобидные совпадения
        upper = upper.replace(safe, "")
    return any(part in upper for part in _SECRET_NAME_PARTS)


def secret_shape(value) -> str:
    """Секрет ли это ПО ФОРМЕ ЗНАЧЕНИЯ. '' — не похоже; иначе название формы.

    ⚠ Маска по именам ручек угадывает, а не знает: `DATABASE_URL` или `SMTP_URL`
    с паролем внутри адреса под неё не попадают, хотя это тот же пароль владельца.
    Механический кред-пол уже есть в дереве (`core/secrets.credential_floor` —
    sk-…, токен бота, ключ z.ai, JWT, приватный ключ, ключи AWS/GitHub), и звать
    его дешевле, чем угадывать имена. Имена при этом НЕ отменяются: пол знает
    формы токенов и не знает слова `p@ssw0rd` в `SMTP_PASSWORD`. Работают оба.

    Пол живёт в дереве и приезжает поставкой; если его нет (дерево ещё не на
    sys.path, чужая сборка) — молча остаёмся на именах, а не роняем анатомию.
    """
    text = str(value or "")
    if not text.strip():
        return ""
    try:
        from core.secrets import credential_floor
        found = credential_floor(text)
    except Exception:
        found = ""
    if found:
        return found
    if _URL_PASSWORD.search(text):
        return "пароль внутри адреса"
    return ""


def looks_secret(name, value) -> bool:
    """Секрет по ИМЕНИ ручки или по ФОРМЕ значения — достаточно одного."""
    return bool((is_secret_knob(name) and str(value or "").strip())
                or secret_shape(value))


def scrub(value, _depth: int = 0):
    """Значение без секретов — для анатомии, лога и любого показа наружу.

    Рекурсивно: секрет прячется и внутри вложенного объекта. Именно этого не
    хватило блоку `model`, где фильтр перечислял имена («key», «api_api») —
    окно завело рядом НОВОЕ поле `model.keys` с тремя боевыми ключами, и оно
    поехало в анатомию целиком. Перечисление имён проигрывает соседу, который
    заводит поле; форма значения — нет.
    """
    if _depth > 6:
        return "…"
    if isinstance(value, dict):
        return {k: scrub(v, _depth + 1) for k, v in value.items()
                if not is_secret_knob(k)}
    if isinstance(value, (list, tuple)):
        return [scrub(v, _depth + 1) for v in value]
    return "задан" if secret_shape(value) else value


def public_model(cfg: dict) -> dict:
    """Блок `model` из helene.json без ключей — то, что можно показать владельцу."""
    block = cfg.get("model")
    return scrub(block) if isinstance(block, dict) else {}


def _windows_tz_name() -> str:
    """IANA-имя пояса Windows — у системного ICU (`icu.dll`, Windows 10 1903+).

    Реестр хранит имя Windows («Russia Time Zone 3»), а дерево понимает только IANA;
    таблица соответствий у ICU уже есть — она и отвечает за часы самой системы."""
    try:
        import ctypes
        icu = ctypes.WinDLL("icu.dll")
        fn = icu.ucal_getDefaultTimeZone
        fn.argtypes = [ctypes.c_wchar_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_int)]
        fn.restype = ctypes.c_int32
        buf = ctypes.create_unicode_buffer(128)
        status = ctypes.c_int(0)
        size = fn(buf, 128, ctypes.byref(status))
        if status.value > 0 or size <= 0:
            return ""
        return buf.value[:size]
    except Exception:
        return ""


def _posix_tz_name() -> str:
    """IANA-имя пояса macOS/Linux: `TZ`, иначе цель ссылки /etc/localtime."""
    tz = str(os.environ.get("TZ") or "").lstrip(":")
    if tz and "/" in tz and not tz.startswith("/"):
        return tz
    try:
        target = os.path.realpath("/etc/localtime")
    except OSError:
        return ""
    marker = "zoneinfo/"
    at = target.find(marker)
    return target[at + len(marker):] if at >= 0 else ""


def local_tz_name() -> str:
    """Пояс этой машины именем IANA ('' — не узнали, тогда решает умолчание дерева).

    26.09 (ревью W3 S2, W4 S2): издание `PRAXIS_TZ` не ставило, и дерево жило по своим
    умолчаниям: сон «с 4 до 6» и часы кадра — по Москве, календарный день — по Самаре, а
    будильники — по системным часам. У владельца в Новосибирске сон шёл в 8–10 утра, в
    Нью-Йорке — в 21–23, и агент в это время молчал."""
    name = _windows_tz_name() if os.name == "nt" else _posix_tz_name()
    if not name:
        return ""
    try:
        from zoneinfo import ZoneInfo
        ZoneInfo(name)
    except Exception:
        return ""
    return name


def env_knobs(cfg: dict, tree: Path | None = None) -> dict[str, str]:
    """Ручки среды: порт-дефолты, пояс машины, КЕАТ личного потока (если есть дерево и
    владелец в Telegram), поверх — `env` из helene.json (его слово последнее).

    ⚠ `"env": []` (или строка, или число) в конфиге роняло руннер AttributeError
    ещё до импорта дерева. Кривой конфиг — не повод для безымянной смерти.
    """
    knobs = dict(PORT_DEFAULTS)
    zone = local_tz_name()
    if zone:
        knobs["PRAXIS_TZ"] = zone
    if tree is not None:
        try:
            knobs.update(keat_knobs(Path(tree), cfg))
        except Exception:
            # КЕАТ — надстройка над живым путём: без неё ход идёт прежним путём
            # байт-в-байт, и это не повод не подняться.
            log.warning("КЕАТ: политика захвата не собралась — поток идёт прежним путём",
                        exc_info=True)
    extra = cfg.get("env")
    if extra and not isinstance(extra, dict):
        log.warning("helene.json: блок env должен быть объектом, а не %s — "
                    "беру только порт-дефолты", type(extra).__name__)
        extra = None
    for key, value in (extra or {}).items():
        if value is None:
            knobs.pop(str(key), None)          # явное «не задавать» — тоже решение
        else:
            knobs[str(key)] = str(value)
    return knobs


#: Ревизия политики захвата издания. Меняется только вместе со смыслом полей записи.
KEAT_POLICY_REVISION = "2026-09-26.helene-owner.v1"
#: Ротация эпох КЕАТ: сколько последних эпох держать и сколько места они могут занять.
KEAT_EPOCHS_KEEP = 24
KEAT_EPOCHS_MAX_MB = 256
#: Эпоха моложе этого не трогается никогда: её ход может ещё идти или возобновиться.
KEAT_EPOCHS_MIN_AGE_SEC = 3600.0


def keat_owner(cfg: dict) -> str:
    """Telegram-id владельца как поток КЕАТ, или '' — точное положительное число."""
    raw = str((cfg.get("telegram") or {}).get("owner_id") or "").strip()
    try:
        ok = raw.isascii() and raw.isdecimal() and str(int(raw)) == raw and int(raw) > 0
    except ValueError:
        ok = False
    return raw if ok else ""


def keat_paths(tree: Path) -> tuple[Path, Path]:
    """(корень КЕАТ, файл политики) — абсолютные: оба сверяет приёмная `keat_readiness`."""
    state = (Path(tree) / "memory" / ".state").resolve()
    return state / "keat", state / "keat-capture-policy.json"


def keat_knobs(tree: Path, cfg: dict) -> dict[str, str]:
    """КЕАТ личного потока владельца в Telegram (1.0.0, порт её прода 12–25.09).

    Что это даёт. Каждое сообщение личного потока — его слова и её ответы — получает при
    приёме расписку в реестре захвата (`memory/.state/keat/capture/…`, дописываемый,
    сцеплен sha256), а каждый вызов модели проверяется у границы: лента, которая уходит в
    модель, обязана быть точной проекцией захваченных оригиналов, и тогда вызов «служится»
    (`frame_meta.keat.served`) с записанной эпохой. Правка или удаление оригинала отзывает
    его навсегда; всё, что не сходится, идёт прежним путём байт-в-байт — КЕАТ ничего не
    переписывает сам.

    ⚠ История не выпадает. У неё в проде 25.09 обслуженный вызов в личке нёс ОДНУ реплику:
    её ответы не захватывались, и проекция начиналась после последнего из них. Здесь
    захватываются обе стороны (`botapi.Rooms.record`), расписка ленты-вызовов признаётся
    проекцией (`keat_candidate.render_receipt`), а раннер отдаёт проекцию только если
    захвачена ВСЯ горячая лента (`runner._dialogue`), иначе — прежний путь с историей.

    Выключить: `"keat": false` или `"keat": {"enabled": false}` в helene.json (строки
    "false"/"off"/"0" тоже). Ручка в блоке `env` перекрывает только саму себя — например,
    `PRAXIS_KEAT_CAPTURE=off` гасит захват (ревью 26.09: прежде здесь было написано «любая
    ручка PRAXIS_KEAT*», а `PRAXIS_KEAT=off` захват не гасил). Кадр v6 (подмена system свежим E) здесь НЕ
    поднимается: ему нужен `PRAXIS_OWNER_ID`, который в издании меняет и другие пути
    дерева; включается осознанно ручками `PRAXIS_FRAME_V6`/`PRAXIS_FRAME_V6_STREAMS`.
    Политика пишется файлом рядом с состоянием дерева при каждом старте движка.
    """
    raw_block = cfg.get("keat")
    if raw_block is False or str(raw_block).strip().lower() in ("false", "off", "0", "no"):
        return {}
    block = raw_block if isinstance(raw_block, dict) else {}
    enabled = block.get("enabled", True)
    if enabled is False or str(enabled).strip().lower() in ("false", "off", "0", "no"):
        return {}
    owner = keat_owner(cfg)
    if not owner:
        return {}
    root, policy_path = keat_paths(tree)
    policy = {
        "schema": "keat.capture-policy.v1",
        "namespace": f"helene-{owner}-owner-v1",
        "root": str(root),
        "enrollments": [{
            "stream": owner, "mode": "owner",
            "capture": {"issuer": "helene:self", "policy_revision": KEAT_POLICY_REVISION,
                        "audience": ["owner"], "transfer": "closed",
                        "presence_hidden": False},
        }],
    }
    raw = (json.dumps(policy, ensure_ascii=False, indent=1, sort_keys=True) + "\n").encode("utf-8")
    try:
        current = policy_path.read_bytes()
    except OSError:
        current = b""
    if current != raw:
        # Байты политики сверяются на каждом захвате и вызове: переписывать файл без
        # перемены смысла значило бы зря сбрасывать проверку идущего хода.
        policy_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = policy_path.with_name(policy_path.name + ".tmp")
        tmp.write_bytes(raw)
        os.replace(tmp, policy_path)
    root.mkdir(parents=True, exist_ok=True)
    return {
        "PRAXIS_KEAT": "serve",
        "PRAXIS_KEAT_CAPTURE": "on",
        # Канонические байты пар: `keat_runtime.staged` сверяет строку целиком.
        "PRAXIS_KEAT_PAIRS": json.dumps([["owner", owner]], ensure_ascii=True,
                                        allow_nan=False, separators=(",", ":")),
        "PRAXIS_KEAT_ROOT": str(root),
        "PRAXIS_KEAT_CAPTURE_POLICY": str(policy_path),
    }


def prune_keat_epochs(tree: Path, *, keep: int = KEAT_EPOCHS_KEEP,
                      max_mb: int = KEAT_EPOCHS_MAX_MB,
                      min_age_sec: float = KEAT_EPOCHS_MIN_AGE_SEC) -> dict:
    """Ротация эпох КЕАТ: `memory/.state/keat/epochs/<эпоха>/` — снимки вызовов хода.

    Каждый вызов модели в обслуженном ходе пишет неизменяемый снимок проекции (ленту,
    расписки, схемы рук); у неё в проде это 4,25 МБ на снимок и 8,5 ГБ за две недели.
    Дома этому расти некуда. Эпоха снимается ЦЕЛИКОМ (внутри неё снимки сцеплены, и
    обрыв цепи — порча, а не экономия): держим `keep` свежих и не больше `max_mb`;
    моложе `min_age_sec` не трогаем никогда — её ход может ещё идти. Снятая эпоха
    значит одно: возобновление того хода пойдёт прежним путём, а не обслуженным.
    Реестр захвата (`capture/`) не трогается: он канон, и ротация его — порча.
    """
    import shutil
    root, _policy = keat_paths(tree)
    epochs = root / "epochs"
    report = {"kept": 0, "removed": 0, "freed_bytes": 0, "errors": []}
    if not epochs.is_dir():
        return report
    rows = []
    now = time.time()
    for path in epochs.iterdir():
        if not path.is_dir():
            continue
        try:
            head = path / "HEAD"
            mtime = (head if head.exists() else path).stat().st_mtime
            size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
        except OSError as exc:
            report["errors"].append(f"{path.name}: {exc}")
            continue
        rows.append((mtime, path, size))
    rows.sort(key=lambda row: row[0], reverse=True)
    budget = max(0, int(max_mb)) * 1024 * 1024
    total = kept_old = 0
    for mtime, path, size in rows:
        young = now - mtime < float(min_age_sec)
        if young or (kept_old < int(keep) and total + size <= budget):
            total += size
            report["kept"] += 1
            if not young:
                kept_old += 1
            continue
        try:
            shutil.rmtree(path)
            report["removed"] += 1
            report["freed_bytes"] += size
        except OSError as exc:
            report["errors"].append(f"{path.name}: {exc}")
    return report


def safe_knobs(cfg: dict, tree: Path | None = None) -> dict[str, str]:
    """Те же ручки, но значения секретов заменены на «задан».

    Прозрачность продукта — в том, чтобы владелец видел, ЧТО ручка задана, а не её
    значение. Ровно так `public_model` очищает блок `model` в анатомии; здесь та
    же мера для `env`, куда владелец кладёт OPENAI_API_KEY, токен бота и пароль
    SMTP. Анатомия уезжает на телефон и рисуется таблицей на экране.

    Маска идёт по имени ручки И по форме значения (`looks_secret`): имя ловит
    `SMTP_PASSWORD=p@ssw0rd`, форма — `DATABASE_URL=postgres://u:pass@host/db`
    и любой ключ, положенный в ручку с безобидным именем.
    """
    return {k: ("задан" if looks_secret(k, v) else v)
            for k, v in env_knobs(cfg, tree).items()}


def apply_env(knobs: dict[str, str], *, where: str) -> None:
    os.environ.update(knobs)
    log.debug("ручки среды применены (%s): %d", where, len(knobs))


def chosen_dotenv(code_dir: Path) -> Path | None:
    """Match python-dotenv's ordinary upward search from agent.py's directory.

    The runner already resolved `code_dir` as the source it will import. Looking
    only beside that source misses a parent `.env` which bare load_dotenv reads.
    Do not parse or return any credential bytes at this discovery seam.
    """
    code_dir = Path(code_dir)
    for folder in (code_dir, *code_dir.parents):
        path = folder / ".env"
        if path.is_file():
            return path
    return None


def dotenv_gate(code_dir: Path, cfg: dict) -> None:
    """Решить судьбу `.env` рядом с кодом — ДО импорта дерева.

    В продукте такого файла нет: он в .gitignore и наружу не уезжает. А на машине
    разработчика рядом с деревом лежит боевой — с ключами, сессией Telegram и
    поднятыми рычагами. Пока он приезжал молча, локальный продукт вёл себя не так,
    как поведёт себя у пользователя, и отладка врала.

    Дефолт: НЕ читать (`"read_dotenv": false`) — единственный источник настроек это
    helene.json. Кому нужен старый способ — ставит `true`, и дерево читает `.env` как
    читало. Оба случая называются в логе: тихой разницы между ними быть не должно.
    """
    stray = chosen_dotenv(code_dir)
    if bool(cfg.get("read_dotenv")):
        if stray is not None:
            log.warning("читаю %s по просьбе конфига: его значения перекроют helene.json "
                        "на импорте (load_dotenv override=True)", stray)
        return
    try:
        import dotenv
    except ImportError:
        return
    dotenv.load_dotenv = lambda *a, **kw: False
    if stray is not None:
        log.warning("рядом с деревом лежит %s — НЕ читаю его (read_dotenv=false): "
                    "настройки продукта живут в helene.json", stray)


# --------------------------------------------------------------------------- #
#  Мозг: model из helene.json -> её memory/llm.json
# --------------------------------------------------------------------------- #

def _int_or(value, default: int, *, what: str) -> int:
    """Число из конфига владельца — или дефолт с названной причиной.

    ⚠ ПЕРВЫЙ-ЗАПУСК.md прямо зовёт владельца править helene.json руками. `"max_tokens":
    "8k"` роняло руннер ValueError ДО загрузки дерева: оболочка перезапускала его с
    растущей паузой и говорила «падает раз за разом» без причины. Соседняя строка
    (max_tool_iters) была защищена, эта — нет.
    """
    try:
        return int(value)
    except (TypeError, ValueError):
        if value not in (None, ""):
            log.warning("helene.json: %s = %r — не число, беру %d", what, value, default)
        return default


def _brain_config(cfg: dict) -> dict:
    """helene.json -> схема её llm.json (frameworks + roles + limits + pricing).

    Оба фреймворка описаны всегда: фолбэк роли и её собственный `switch_brain` живут
    на этой развилке.

    ⚠ ЧТО ТАКОЕ РОЛЬ `evaluator` НА САМОМ ДЕЛЕ (здесь стояло «привратник
    исходящего» — это неправда, и она стоила денег). Привратник исходящего в
    окне не зовётся НИКОГДА: ход владельца проходит его без вызова модели
    (`live/agent.py:14990`). Зовёт эту роль ДРУГОЕ — свёртка памяти и
    формирование (`live/memory_life.py:847` → `llm.chat("evaluator", …)`), а
    свёртку зовёт наш собственный руннер после каждого хода. Промпт свёртки —
    до 48 000 знаков, и он не из кэша.

    Поэтому модель этой роли — РУЧКА ВЛАДЕЛЬЦА, а не тень голоса:
      * `"evaluator": {"model": "…"}` в helene.json — полный блок роли. ЭТО
        ДОЛГОВЕЧНОЕ МЕСТО: ключа `evaluator` нет в WIZARD_KEYS установщика
        (`setup/src/install.rs:433`), значит переустановка его сохраняет;
      * `"model": {"compact_model": "…"}` — короткая форма рядом с моделью
        голоса. ⚠ Блок `model` визард при обновлении ПЕРЕПИСЫВАЕТ целиком, так
        что эта форма переживает не всё; писателю (окно Настроек, визард) стоит
        класть решение владельца в блок `evaluator`.
    Умолчание осталось прежним — модель голоса: подставить «дешёвую» от себя
    значило бы вписать имя, которого у владельца может не быть ни на одном
    эндпойнте, и свёртка молча падала бы на каждом ходе. Пустая ручка честнее
    выдуманной, а место, где её задать, теперь есть.

    ⚠ 03.09, три правки одного шва:
      * `fallback_framework` выбрасывался, и фолбэк уходил в «противоположный»
        фреймворк, ключа к которому нет: механика фолбэка ядра (429, обрыв сети,
        5xx) была обесточена ровно там, где она нужнее всего — на подписке;
      * оценщик наследовал `max_tokens` и `reasoning_effort` голоса, хотя докстринг
        обещал «только короче потолок». Наследуется теперь только адрес и модель;
      * `pricing` не переносился вовсе, поэтому доллары в продукте не считались
        нигде: `llm.pricing()` всегда пуст -> `estimated_cost_today()` всегда None.
    """
    voice = dict(cfg.get("model") or {})
    judge_raw = cfg.get("evaluator")
    judge = dict(judge_raw) if isinstance(judge_raw, dict) and judge_raw else None
    # Короткая форма: одно поле рядом с моделью голоса. Полный блок `evaluator`
    # сильнее — он ответ на «хочу другой эндпойнт», а это на «хочу другую модель».
    compact = str(voice.get("compact_model") or "").strip()
    if compact:
        judge = dict(judge or {})
        judge.setdefault("model", compact)
    out = {"frameworks": {"anthropic": {"base_url": "", "api_key": ""},
                          "openai": {"base_url": "", "api_key": ""}},
           "roles": {}, "limits": {}}
    def endpoint(block, protocol, *, inherited_from=None):
        from urllib.parse import urlsplit
        source = inherited_from or {}
        base = str(block.get("base_url", source.get("base_url", "")) or "").strip()
        key = str(block.get("key", block.get("api_key", source.get("key", source.get("api_key", "")))) or "").strip()
        host = (urlsplit(base).hostname or "").lower()
        families = {"api.openai.com": "openai", "api.anthropic.com": "anthropic",
                    "api.z.ai": "zai", "api.minimax.io": "minimax", "api.minimaxi.com": "minimax",
                    "api.kimi.com": "kimi", "api.kimi.ai": "kimi", "api.moonshot.ai": "kimi",
                    "api.moonshot.cn": "kimi", "api.deepseek.com": "deepseek"}
        family = str(block.get("provider_id") or families.get(host) or
                     ("qwen" if host.endswith(".aliyuncs.com") else "compatible"))
        if block.get("provider") == "chatgpt":
            family = "relay"
        spec = {"base_url": base, "api_key": key, "protocol": protocol, "provider": family,
                "api_mode": str(block.get("api_mode") or source.get("api_mode") or "")}
        if spec["api_mode"] not in ("responses", "chat_completions"):
            spec["api_mode"] = ""
        return spec

    def register(name, spec):
        out["frameworks"][name] = spec
        legacy = out["frameworks"][spec["protocol"]]
        if not legacy["base_url"] and not legacy["api_key"]:
            legacy.update(base_url=spec["base_url"], api_key=spec["api_key"])

    for role, block, default_tokens in (("voice", voice, 8192),
                                        ("evaluator", judge if judge else voice, 1024)):
        inherited = role == "evaluator" and judge is None
        # Фреймворк роли свёрток по умолчанию — ТОТ ЖЕ, что у голоса: там лежат
        # адрес и ключ. Прежнее умолчание "openai" при anthropic-голосе уводило
        # свёртку в пустой блок без ключа, и она падала на каждом ходе.
        default_fw = str(voice.get("framework") or "openai") if role == "evaluator" \
            else "openai"
        framework = str(block.get("framework") or default_fw).strip().lower()
        if framework not in ("openai", "anthropic"):
            framework = "openai"
        primary = "voice_primary" if inherited else role + "_primary"
        if inherited:
            out["frameworks"]["evaluator_primary"] = dict.fromkeys(("base_url", "api_key", "protocol", "provider", "api_mode"), "")
        if not inherited:
            register(primary, endpoint(block, framework,
                                      inherited_from=voice if role == "evaluator" and framework == default_fw and not block.get("base_url") else None))
        tokens = default_tokens if inherited else _int_or(
            block.get("max_tokens") or default_tokens, default_tokens,
            what=f"model.max_tokens ({role})")
        role_cfg = {"framework": primary,
                    "model": str(block.get("model") or ""),
                    "max_tokens": max(1, tokens),
                    "fallback_model": str(block.get("fallback_model") or "")}
        fallback_fw = str(block.get("fallback_framework") or "").strip().lower()
        if fallback_fw not in ("openai", "anthropic"):
            fallback_fw = framework
        fallback_name = role + "_fallback"
        out["frameworks"][fallback_name] = dict.fromkeys(("base_url", "api_key", "protocol", "provider", "api_mode"), "")
        if role_cfg["fallback_model"]:
            own_endpoint = any(str(block.get(name) or "").strip() for name in
                               ("fallback_base_url", "fallback_key", "fallback_api_mode", "fallback_provider_id"))
            if own_endpoint:
                fallback = {"base_url": block.get("fallback_base_url", ""),
                            "key": block.get("fallback_key", ""),
                            "api_mode": block.get("fallback_api_mode", ""),
                            "provider_id": block.get("fallback_provider_id", "")}
                register(fallback_name, endpoint(fallback, fallback_fw))
                role_cfg["fallback_framework"] = fallback_name
            else:
                role_cfg["fallback_framework"] = primary if fallback_fw == framework else fallback_fw
        # 09.09: зрячая замена текстовой модели на ход с картинкой (`model.vision_model`
        # в helene.json). Пусто — ядро само берёт glm-5.3-flash для glm; оценщик без
        # своего блока наследует ручку голоса вместе с адресом и моделью.
        vision = str(block.get("vision_model") or "").strip()
        if vision:
            role_cfg["vision_model"] = vision
        effort = str(block.get("reasoning_effort") or "").strip().lower()
        codex_none = effort == 'none' and out['frameworks'][primary].get('provider') == 'relay'
        if effort and not inherited and not codex_none:
            role_cfg["reasoning_effort"] = effort
        elif inherited and role_cfg["model"].strip().lower().startswith("glm-"):
            # 08.09: у GLM серверное умолчание глубины — max. Оценщик без ступени
            # (свёртки, судья) думал дольше и дороже голоса, который владелец
            # поставил на low. Ступень оценщика — low, если не задана явно блоком
            # `evaluator`; чужим провайдерам ничего не подставляется.
            role_cfg["reasoning_effort"] = "low"
        from localharness.fast_mode import normalize as tier_value
        override = (cfg.get('roles') or {}).get(role) or {}
        selected_tier = override.get('service_tier', block.get('service_tier') if not inherited else None)
        if out['frameworks'][primary].get('provider') == 'relay':
            tier = tier_value(selected_tier)
            if tier is not None:
                role_cfg['service_tier'] = tier
        out["roles"][role] = role_cfg
    out["limits"]["max_tool_iters"] = _int_or(cfg.get("max_tool_iters") or 20, 20,
                                              what="max_tool_iters")
    pricing = cfg.get("pricing")
    if isinstance(pricing, dict) and pricing:
        out["pricing"] = pricing
    images = cfg.get("images") if isinstance(cfg.get("images"), dict) else {}
    out["images"] = {"enabled": images.get("enabled") is True,
                     "model": str(images.get("model") or "gpt-image-2"),
                     "quality": str(images.get("quality") or "auto"),
                     "size": str(images.get("size") or "auto"),
                     "background": str(images.get("background") or "opaque")}
    relay = cfg.get("relay") if isinstance(cfg.get("relay"), dict) else {}
    app_dir = str(Path(__file__).resolve().parent.parent)
    if app_dir not in sys.path:
        sys.path.insert(1, app_dir)
    from deskd.readers import RELAY_PORT_DEFAULT
    relay_port = _int_or(relay.get("port") or RELAY_PORT_DEFAULT, RELAY_PORT_DEFAULT, what="relay.port")
    relay_key = str(relay.get("key") or (voice.get("key") if relay.get("enabled") else "") or "")
    out["image_channel"] = {"base_url": f"http://127.0.0.1:{relay_port}", "api_key": relay_key}
    return out


def _own_only(target: Path) -> None:
    """Сузить права файла с ключом до владельца — по-настоящему, а не 0o600.

    ⚠ Здесь стоял `os.chmod(target, 0o600)` с комментарием «конфиг с ключом не для
    чужих глаз». На Windows (а продукт — Windows-only) chmod умеет ровно один бит,
    «только чтение», и 0o600 его даже не ставит: права оставались наследованными,
    а в коде стояло обещание защиты. Ложная запись в защите хуже её отсутствия:
    следующий читатель не станет закрывать то, что уже «закрыто». Настоящий
    механизм рядом — `fence._grant` зовёт icacls; зовём его же.
    """
    if os.name != "nt":
        try:
            os.chmod(target, 0o600)
        except OSError as exc:
            log.debug("права на %s не сузились: %s", target, exc)
        return
    import subprocess
    user = os.environ.get("USERNAME") or ""
    if not user:
        log.warning("права на %s не сужены: USERNAME пуст", target)
        return
    # SYSTEM и админы остаются намеренно: службу продукта ставит сама поставка и
    # она поднимает руннер от LocalSystem — отобрать у SYSTEM чтение значило бы
    # сломать режим службы ради видимости защиты. Уходит ровно лишнее: ручки,
    # унаследованные от папки, включая RX песочницы.
    try:
        proc = subprocess.run(
            ["icacls", str(target), "/inheritance:r",
             "/grant:r", f"{user}:F", "/grant:r", "*S-1-5-18:F",
             "/grant:r", "*S-1-5-32-544:F", "/Q"],
            capture_output=True, text=True, encoding="cp866", errors="replace",
            creationflags=0x08000000, timeout=60)
        if proc.returncode != 0:
            log.warning("права на %s не сузились: %s", target,
                        (proc.stdout or proc.stderr or "").strip()[:200])
    except Exception as exc:
        log.warning("права на %s не сузились: %s", target, exc)


#: Ключи роли, которыми владеет проекция: их отсутствие в helene.json значит «снять»,
#: а не «оставить прежнее» (иначе убранный в окне фолбэк жил бы в llm.json вечно).
_OWNED_ROLE_KEYS = ("framework", "model", "max_tokens", "fallback_model",
                    "fallback_framework", "vision_model", "reasoning_effort")


def _projected_fields(built: dict) -> dict[str, object]:
    """Какие поля фреймворков проекция записала непустыми — расписке, чтобы уметь их снять."""
    out: dict[str, object] = {}
    for name, sub in (built.get("frameworks") or {}).items():
        if isinstance(sub, dict):
            fields = sorted(k for k, v in sub.items() if v not in (None, ""))
            if fields:
                out[str(name)] = fields
    channel = built.get("image_channel")
    if isinstance(channel, dict):
        out["_image_channel"] = sorted(k for k, v in channel.items() if v not in (None, ""))
    tiers = {name: value['service_tier'] for name, value in (built.get('roles') or {}).items()
             if isinstance(value, dict) and value.get('service_tier') is not None}
    if tiers:
        out['_service_tiers'] = tiers
    return out


def _merge_brain(current: dict, built: dict, previously_projected: dict | None = None) -> dict:
    """Проекция ПОДМЕШИВАЕТСЯ по вложенным блокам, а не заменяет их целиком (25.09, C.2).

    `merged.update(built)` затирал `frameworks` и `roles` целиком: ручная правка
    вложенного блока (адрес и ключ второго фреймворка, `vision_models` роли) не
    переживала ни одной проекции, а второй фреймворк из проекции приходил пустым — и
    стирал живой. Теперь:
      * `frameworks.<fw>`: непустое значение проекции побеждает, пустое не трогает
        записанное руками;
      * `roles.<role>`: ключи, которыми владеет проекция, заменяются набором (нет в
        helene.json — снято), остальные (её `vision_models`, ручные ручки) остаются;
      * всё прочее (`limits`, `pricing`) — как раньше, целиком из проекции.

    Ревью 25.09 (A6 F10): «пустое не трогает записанное руками» не различало ручное и
    своё — убранный в окне ключ запасного или очищенный адрес жили в llm.json навсегда.
    `previously_projected` (расписка прошлой проекции: какие поля каких фреймворков
    записала она сама) снимает ровно их, если теперь они пусты; ручное остаётся.
    """
    merged = dict(current)
    prev = previously_projected if isinstance(previously_projected, dict) else {}
    for key, value in built.items():
        cur = merged.get(key)
        if key == "frameworks" and isinstance(cur, dict) and isinstance(value, dict):
            block = {name: dict(sub) if isinstance(sub, dict) else sub for name, sub in cur.items()}
            for name, sub in value.items():
                if isinstance(sub, dict):
                    slot = block.get(name) if isinstance(block.get(name), dict) else {}
                    mine = set(prev.get(str(name)) or ())
                    for field, val in sub.items():
                        if val not in (None, "") or field not in slot:
                            slot[field] = val
                        elif field in mine:
                            slot.pop(field, None)   # своё прежнее — снято владельцем в окне
                    block[name] = slot
                else:
                    block[name] = sub
            merged[key] = block
        elif key == "image_channel" and isinstance(cur, dict) and isinstance(value, dict):
            slot = dict(cur)
            mine = set(prev.get("_image_channel") or ())
            for field, val in value.items():
                if val not in (None, "") or field not in slot:
                    slot[field] = val
                elif field in mine:
                    slot.pop(field, None)
            merged[key] = slot
        elif key == "roles" and isinstance(cur, dict) and isinstance(value, dict):
            block = dict(cur)
            for name, sub in value.items():
                if isinstance(sub, dict) and isinstance(block.get(name), dict):
                    kept = {k: v for k, v in block[name].items() if k not in _OWNED_ROLE_KEYS}
                    prior_tier = (prev.get('_service_tiers') or {}).get(name)
                    if ('service_tier' not in sub and prior_tier is not None
                            and kept.get('service_tier') == prior_tier):
                        kept.pop('service_tier', None)
                    block[name] = {**kept, **sub}
                else:
                    block[name] = sub
            merged[key] = block
        else:
            merged[key] = value
    return merged


def _consumer_brain_config(built, code_dir):
    """Preserved pre-alias code keeps its two-protocol role contract."""
    if code_dir is None:
        return built  # callers without a selected runtime request the new schema
    import ast
    source = Path(code_dir) / 'llm.py'
    try:
        module = ast.parse(source.read_text(encoding='utf-8-sig'))
    except (OSError, SyntaxError) as exc:
        raise RuntimeError('Selected model consumer is unreadable; config was not projected') from exc
    if any(isinstance(node, ast.Assign)
           and any(isinstance(t, ast.Name) and t.id == 'LLM_ENDPOINTS_API' for t in node.targets)
           and isinstance(node.value, ast.Constant) and node.value.value == 1
           for node in module.body):
        return built
    import copy
    legacy = copy.deepcopy(built)
    specs = built['frameworks']
    selected = {}
    def resolve(alias):
        spec = specs.get(alias) or {}
        protocol = spec.get('protocol') or alias
        if protocol not in ('openai', 'anthropic'):
            raise ValueError('Selected preserved code does not support this endpoint protocol')
        if spec.get('api_mode') == 'responses':
            raise ValueError('Selected preserved code does not support explicit Responses mode; update its code before selecting this route')
        identity = (spec.get('base_url') or '', spec.get('api_key') or '', spec.get('api_mode') or '')
        if protocol in selected and selected[protocol][0] != identity:
            raise ValueError('Selected preserved code cannot represent independent same-protocol accounts; update its code or use one account')
        selected[protocol] = (identity, spec)
        return protocol
    for role in legacy['roles'].values():
        role['framework'] = resolve(role['framework'])
        if role.get('fallback_model'):
            role['fallback_framework'] = resolve(role.get('fallback_framework') or
                ('openai' if role['framework'] == 'anthropic' else 'anthropic'))
        else:
            role.pop('fallback_framework', None)
    legacy['frameworks'] = {key: {'base_url': '', 'api_key': ''} for key in ('openai', 'anthropic')}
    for protocol, (_, spec) in selected.items():
        legacy['frameworks'][protocol] = {key: spec.get(key, '') for key in ('base_url', 'api_key', 'protocol', 'provider', 'api_mode')}
    return legacy


def project_brain(tree: Path, cfg: dict, *, code_dir: Path | None = None) -> str:
    """Положить мозг из helene.json в её `memory/llm.json` — но не затирать ЕЁ выбор.

    У неё есть своя рука `switch_brain`: она правит этот же файл. Переписывать его на
    каждом старте значило бы молча отменять её решение при каждом запуске окна. Поэтому
    проекция идёт ровно тогда, когда изменился САМ helene.json (сверяем отпечаток блока
    модели с распиской прошлой проекции) — или когда конфига мозга ещё нет.

    -> строка для лога: что сделано и почему.
    """
    target = tree / "memory" / "llm.json"
    receipt = tree / "memory" / ".state" / "brain_projection.json"
    # Расписка звалась `pult_brain.json` до 18.09.2026. Переносим её один раз:
    # без этого пропавшая расписка читается как «конфига мозга ещё нет», и
    # первый же запуск МОЛЧА отменит её собственный выбор рукой switch_brain.
    legacy_receipt = receipt.with_name("pult_brain.json")
    if not receipt.exists() and legacy_receipt.exists():
        try:
            receipt.parent.mkdir(parents=True, exist_ok=True)
            os.replace(legacy_receipt, receipt)
        except OSError as exc:  # дальше просто спроецируем заново
            log.warning("расписка мозга не перенеслась: %s", exc)
    built = _consumer_brain_config(_brain_config(cfg), code_dir)
    # Свёртки памяти — вторая по расходу статья продукта после самих ходов, и до
    # 04.09 о ней не говорила ни одна строка: роль молча брала модель голоса.
    judge, voice_role = built["roles"]["evaluator"], built["roles"]["voice"]
    log.info("свёртки памяти: модель %s%s", judge["model"] or "(не задана)",
             "" if judge["model"] != voice_role["model"] else
             " — та же, что у голоса; дешевле задаётся блоком \"evaluator\": "
             "{\"model\": \"…\"} в helene.json")
    fingerprint = hashlib.sha256(
        json.dumps(built, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    previously_projected: dict | None = None
    if target.exists():
        try:
            loaded = json.loads(receipt.read_text(encoding="utf-8"))
            seen = loaded.get("fingerprint") if isinstance(loaded, dict) else None
            if isinstance(loaded, dict) and isinstance(loaded.get("projected"), dict):
                previously_projected = loaded["projected"]
        except (OSError, ValueError):
            seen = None
        if seen == fingerprint:
            if previously_projected is None:
                # 25.09 (ревью V3 F3): расписка от 0.8.5–0.8.7 без `projected` — при неизменном
                # helene.json она никогда бы не дописалась, и убранный позже ключ запасного
                # жил бы в llm.json вечно. В этот момент `built` — ровно то, что проецировала
                # прежняя версия: дописываем поля, сам llm.json не трогаем.
                try:
                    receipt.write_text(json.dumps({"fingerprint": fingerprint,
                                                   "projected": _projected_fields(built)},
                                                  ensure_ascii=False),
                                       encoding="utf-8", newline="\n")
                except OSError:
                    log.debug("расписка мозга без projected не дописалась", exc_info=True)
            return "мозг: llm.json на месте, helene.json не менялся — не трогаю"
    # ⚠ Файл ПОДМЕШИВАЕТСЯ, а не подменяется: ядро уже чинило этот класс у себя
    # (llm.py: «пропускаем как есть, чтобы запись конфига панелью не стирала блок»),
    # а продукт писал файл сам и стирал всё, чего не знает — в первую очередь
    # дописанный руками `pricing`, единственный источник долларов в отчётах.
    merged: dict = {}
    if target.exists():
        try:
            current = json.loads(target.read_text(encoding="utf-8"))
            if isinstance(current, dict):
                merged = current
        except (OSError, ValueError):
            merged = {}
    merged = _merge_brain(merged, built, previously_projected)
    target.parent.mkdir(parents=True, exist_ok=True)
    # The projection can contain provider keys. A named temp inherited a broad
    # Windows directory ACL until AFTER its bytes had been written. Use the same
    # empty-file-first, verified private writer as the vision-policy migration;
    # its restricted ACL follows the file through the atomic replacement.
    if __package__:
        from .vision_policy import _write as _write_private_config
    else:
        from vision_policy import _write as _write_private_config
    _write_private_config(
        target, json.dumps(merged, ensure_ascii=False, indent=1).encode("utf-8"),
        private=True)
    # Already protected and verified through replacement. The historical
    # USERNAME/icacls helper must not grant another account access afterwards.
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(json.dumps({"fingerprint": fingerprint,
                                   "projected": _projected_fields(built)}, ensure_ascii=False),
                       encoding="utf-8", newline="\n")
    role = built["roles"]["voice"]
    return (f"мозг: llm.json записан из helene.json — {role['model']} @ "
            f"{built['frameworks'][role['framework']]['base_url']} ({role['framework']})")

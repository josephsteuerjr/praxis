// Карточка «Голос»: слышит ли агент голосовые на этом ПК.
//
// Что здесь особенного и почему это отдельный файл. Голос — единственная часть
// продукта, которой НЕ ХВАТАЕТ ГИГАБАЙТА, чтобы работать: библиотека едет в
// рантайме, а модель — нет (самая маленькая 480 МБ, рабочая 1,6 ГБ). Значит
// карточка обязана уметь то, чего не умеет ни одна другая: показать, чего не
// хватает, скачать это и рассказывать о ходе дела, не притворяясь готовой.
//
// Состояние спрашивается у КАНАЛА (`/api/voice`, тот же `localharness/voice.py`,
// которым голос поднимает раннер), а не считается здесь: вторая правда о том,
// скачана ли модель, разъехалась бы с первой молча.
import { voicePreferencesFields } from "../../ui-kit/window/voice-preferences";
import { api, shell, channelURL } from "../../ui-kit/window/api";
import { el, humanError } from "../../ui-kit/window/lib";
import { button, card, choice, toggle } from "../../ui-kit/dom";
import type { Config } from "../../ui-kit/window/views/settings-frame";

interface VoiceModel {
  id: string;
  title: string;
  note: string;
  size_mb: number;
  installed: boolean;
}

interface VoiceState {
  enabled: boolean;
  model: string;
  ready: boolean;
  why: string;
  dir: string;
  library: EngineState;
  installed: { model?: string; path?: string; bytes?: number };
  catalog: VoiceModel[];
  speech?: SpeechState;
  download: {
    state: string;
    model: string;
    note: string;
    got_bytes: number;
    total_bytes: number;
    updated_utc: string;
  } | null;
}

/** Чем слушать и говорить. С 1.2.1 на Windows движок голоса не едет в установщике: его
 *  можно докачать (`downloadable`) — одной кнопкой вместе с моделью или голосом. */
interface EngineState {
  present: boolean;
  why: string;
  downloadable?: boolean;
  size_mb?: number;
  cuda_supported?: boolean | null;
}

/** Голос агента наружу — вторая половина того же ответа канала. */
interface SpeechState {
  speaker?: string;
  speakers?: string[];
  languages?: string[];
  worker_ready?: boolean | null;
  enabled: boolean;
  voice: string;
  ready: boolean;
  why: string;
  dir: string;
  model: string;
  library: EngineState;
  catalog: Array<{ id: string; title: string; note: string; size_mb: number; installed: boolean }>;
  download: { state: string; voice: string; done_mb?: number; size_mb?: number; at?: string; error?: string } | null;
}

export interface VoiceCard {
  el: HTMLElement;
  enabled(): boolean;
  model(): string;
  keepLoaded(): boolean;
  speak(): boolean;
  speakVoice(): string;
}

const MB = 1024 * 1024;

function mb(bytes: number | undefined): string {
  return bytes ? `${Math.round(bytes / MB)} МБ` : "0 МБ";
}

/** Карточка голоса. Черновик правится на месте, как у соседей. */
export function voiceCard(draft: Config): VoiceCard {
  const voice = (draft.voice = draft.voice || {});
  // Умолчание — ВЫКЛЮЧЕНО: без скачанной модели включённый голос был бы
  // обещанием, которое нечем исполнить.
  let enabled = !!voice.enabled;
  let model = String(voice.model || "turbo");
  let keep = !!voice.keep_loaded;
  // Речь — отдельный выключатель, а не часть слуха: слышать голосовые и
  // отвечать голосом — разные желания, и одно без другого законно.
  let speak = !!voice.speak;
  let speakVoice = "xtts";
  voice.voice = speakVoice;

  const box = el("div");
  const status = el("p", "field-hint", "спрашиваю канал…");
  const pickBox = el("div");
  const actions = el("div", "actions");
  const note = el("span", "receipt");
  const fetchBtn = button("Скачать модель", "quiet", () => void start());
  actions.append(fetchBtn, note);

  const onOff = toggle("Расшифровывать голосовые на этом ПК", enabled, (v) => {
    enabled = v;
    voice.enabled = v;
    void refresh();
  });
  const keepOff = toggle("Держать модель в памяти между голосовыми", keep, (v) => {
    keep = v;
    voice.keep_loaded = v;
  });

  let picker = choice<string>([], model, () => {});
  let timer: ReturnType<typeof setTimeout> | null = null;
  let refreshing = false;
  let refreshAgain = false;

  const drawPicker = (state: VoiceState) => {
    const items = state.catalog.map((m) => ({
      value: m.id,
      title: m.title + (m.installed ? " · скачана" : ` · ${m.size_mb} МБ`),
      text: m.note,
    }));
    picker = choice<string>(items, model, (v) => {
      model = v;
      voice.model = v;
      void refresh();
    }, { stack: true });
    pickBox.replaceChildren(picker.el);
  };

  const say = (state: VoiceState) => {
    const down = state.download;
    const busy = !!down && down.state === "running" && fresh(down.updated_utc);
    fetchBtn.disabled = busy;
    if (busy) {
      const total = down!.total_bytes || 1;
      note.className = "receipt";
      note.textContent = `качаю ${down!.model}: ${mb(down!.got_bytes)} из ~${mb(total)}`;
    } else if (down && down.state === "failed") {
      note.className = "receipt err";
      note.textContent = down.note;
    } else if (down && down.state === "running") {
      // Помощник качал и пропал: окно закрыли, машину усыпили, процесс убит.
      // Вечное «качаю…» здесь было бы враньём, поэтому запись читается со
      // сроком годности.
      note.className = "receipt err";
      note.textContent = "скачивание оборвалось — нажми ещё раз";
    } else if (down && down.state === "done" && state.installed.path) {
      note.className = "receipt ok";
      note.textContent = `модель на месте, ${mb(state.installed.bytes)}`;
    }
    if (!state.library.present) {
      if (state.library.downloadable) {
        // 1.2.1: движок не в установщике — он приедет той же кнопкой, первым.
        status.textContent =
          `Агент не слышит: движок голоса ещё не скачан. «Скачать модель» сначала скачает его ` +
          `(~${state.library.size_mb ?? "?"} МБ, один раз на обе половины голоса), потом модель.`;
        return;
      }
      status.textContent = state.library.why + ". Голос в этой сборке не поднимется.";
      fetchBtn.disabled = true;
      return;
    }
    const where = `Модели лежат в ${state.dir}.`;
    if (state.ready) {
      status.textContent =
        `Агент слышит: модель ${state.installed.model || "?"} (${mb(state.installed.bytes)}) на диске. ` +
        (state.why ? state.why + ". " : "") +
        `Расшифровка идёт на процессоре, примерно за половину длительности записи. ${where}`;
    } else {
      status.textContent = `Агент не слышит: ${state.why}. ${where}`;
    }
  };

  const fresh = (stamp: string): boolean => {
    const at = Date.parse(stamp || "");
    const age = Date.now() - at;
    return Number.isFinite(at) && age >= 0 && age < 60_000;
  };

  const refresh = async () => {
    if (timer) { clearTimeout(timer); timer = null; }
    if (refreshing) { refreshAgain = true; return; }
    refreshing = true;
    try {
      const state = await api<VoiceState>("/api/voice");
      if (!box.isConnected) return;
      // Выбор владельца в черновике главнее того, что лежит в файле: он мог
      // переключить модель и ещё не нажать «Сохранить».
      const shown = { ...state, model, enabled };
      if (!picker.el.childElementCount) drawPicker(shown);
      say(shown);
      // Речь приезжает тем же ответом канала — второй запрос разъезжался бы с
      // первым ровно тогда, когда владелец нажимает обе кнопки подряд.
      const speech = state.speech;
      if (speech) {
        const mine = { ...speech, voice: speakVoice, enabled: speak };
        if (!speechPicker.el.childElementCount) drawVoices(mine);
        sayVoice(mine);
        const names = speech.speakers || [];
        cudaOption.disabled=speech.library.cuda_supported===false;
        deviceNote.textContent=speech.library.cuda_supported===false?'Этот runtime собран для CPU. Для CUDA нужен совместимый runtime и видеокарта; веса модели остаются теми же.':'CUDA требует совместимого runtime и видеокарты. На машине без GPU используй CPU; менять модель не нужно.';
        if (names.join('\n') !== speakerSelect.dataset.catalog) {
          speakerSelect.replaceChildren(...names.map(name => new Option(name, name)));
          const selected = String(voice.tts_speaker || speech.speaker || 'Ana Florence');
          if (!names.includes(selected)) speakerSelect.append(new Option(selected+' · недоступен в каталоге', selected));
          speakerSelect.value = selected;
          speakerSelect.dataset.catalog = names.join('\n');
          speakerSelect.disabled = !names.length;
          speakerCount.textContent = names.length ? `${names.length} голосов установленной модели` : 'Каталог появится после установки XTTS';
        }
        previewBtn.disabled = previewing || speech.worker_ready !== true;
        if (!previewing && speech.worker_ready !== true) previewNote.textContent = speech.worker_ready === null ? 'Не удалось проверить процесс XTTS; смотри журнал.' : 'Процесс XTTS ещё не готов. Включи голос, сохрани настройки и проверь журнал, если ожидание затянулось.';
      } else {
        speechStatus.textContent = "этот канал про голос агента ничего не знает";
        speechBtn.disabled = true;
      }
      const down = state.download;
      const dv = speech?.download;
      if ((down && down.state === "running" && fresh(down.updated_utc))
          || (dv && dv.state === "running" && fresh(dv.at || ""))
          || (speak && speech?.library.present && speech.speakers?.length && speech.worker_ready !== true)) {
        timer = setTimeout(() => void refresh(), 2000);
      }
    } catch (e) {
      if (box.isConnected) status.textContent = "канал не ответил про голос: " + humanError(e).text;
    } finally {
      refreshing = false;
      const again = refreshAgain;
      refreshAgain = false;
      if (again && box.isConnected) {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => void refresh(), 0);
      }
    }
  };

  const start = async () => {
    note.className = "receipt";
    note.textContent = "запускаю помощника…";
    fetchBtn.disabled = true;
    try {
      const said = await shell<string>("voice_fetch", { model });
      note.textContent = said;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => void refresh(), 1500);
    } catch (e) {
      note.className = "receipt err";
      note.textContent = humanError(e).text;
      fetchBtn.disabled = false;
    }
  };

  // ---- вторая половина: агент говорит сам -----------------------------------
  const speechStatus = el("p", "field-hint", "спрашиваю канал…");
  const speechPickBox = el("div");
  const speechActions = el("div", "actions");
  const speechNote = el("span", "receipt");
  const speechBtn = button("Установить XTTS из комплекта", "quiet", () => void startVoice());
  speechActions.append(speechBtn, speechNote);
  const speechFields = el("div");
  const deviceLabel=el('label','field-label','Вычисления XTTS');
  const deviceSelect=document.createElement('select');deviceSelect.className='field-input';
  const cudaOption=new Option('CUDA · совместимая NVIDIA GPU','cuda');
  deviceSelect.append(new Option('CPU · работает без видеокарты','cpu'),cudaOption);
  deviceSelect.value=String(voice.tts_device||'cpu');deviceSelect.onchange=()=>{voice.tts_device=deviceSelect.value};
  const deviceNote=el('small','field-hint','CPU — базовый путь; поддержку CUDA определяет runtime.');
  deviceLabel.append(deviceSelect,deviceNote);speechFields.append(deviceLabel);
  const speakerLabel = el('label','field-label','Голос XTTS');
  const speakerSelect = document.createElement('select');speakerSelect.className='field-input';
  speakerSelect.onchange=()=>{voice.tts_speaker=speakerSelect.value};
  const speakerCount=el('small','field-hint','Читаю каталог установленной модели…');
  speakerLabel.append(speakerSelect,speakerCount);speechFields.append(speakerLabel);
  const sample=el('input','field-input') as HTMLInputElement;
  sample.value='Привет. Это мой голос. Его можно изменить.';sample.maxLength=300;
  sample.setAttribute('aria-label','Текст для прослушивания голоса');
  const audio=document.createElement('audio');audio.controls=true;audio.preload='none';audio.hidden=true;
  audio.setAttribute('aria-label','Образец выбранного голоса');
  let previewing = false;
  const previewNote=el('span','receipt');
  const previewBtn=button('Прослушать голос','quiet',async()=>{
    if (previewing) return;
    previewing=true;previewBtn.disabled=true;previewNote.textContent='Готовлю образец локально…';
    try {
      // Synthesis can exceed the event tunnel's 25s. Use the same authenticated
      // HTTP channel, not a second service or the model/Telegram transport.
      const response=await fetch(channelURL('/api/voice/preview'),{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({speaker:speakerSelect.value,language:voice.tts_language||'ru',text:sample.value})});
      if(!response.ok)throw new Error(await response.text());
      const result=await response.json();
      if(result.mime!=='audio/wav'||typeof result.base64!=='string')throw new Error('Нет аудио в ответе XTTS');
      audio.src='data:audio/wav;base64,'+result.base64;audio.hidden=false;
      await audio.play();previewNote.textContent='Образец готов. Выбор сохранится вместе с настройками.';
    }catch(e){previewNote.textContent=humanError(e).text}finally{previewing=false;previewBtn.disabled=false}
  });
  previewBtn.disabled=true;
  speechActions.append(previewBtn,previewNote);
  speechFields.append(sample,audio);
  for (const [key, title, fallback] of [
    ["tts_language", "Язык синтеза", "ru"],
    ["tts_reference", "Свой образец голоса (локальный WAV, необязательно)", ""],
  ]) {
    const label = el("label", "field-label", title);
    const input = el("input", "field-input") as HTMLInputElement;
    input.value = String(voice[key] || fallback);
    input.oninput = () => { voice[key] = input.value; };
    label.append(input); speechFields.append(label);
  }
  const speakOff = toggle("Отвечать голосом, когда сочтёт нужным", speak, (v) => {
    speak = v;
    voice.speak = v;
    void refresh();
  });
  let speechPicker = choice<string>([], speakVoice, () => {});

  const drawVoices = (state: SpeechState) => {
    const items = state.catalog.map((one) => ({
      value: one.id,
      title: one.title + (one.installed ? " · скачан" : ` · ${one.size_mb} МБ`),
      text: one.note,
    }));
    speechPicker = choice<string>(items, speakVoice, (v) => {
      speakVoice = v;
      voice.voice = v;
      void refresh();
    }, { stack: true });
    speechPickBox.replaceChildren(speechPicker.el);
  };

  const sayVoice = (state: SpeechState) => {
    const down = state.download;
    const busy = !!down && down.state === "running" && fresh(down.at || "");
    speechBtn.disabled = busy;
    if (busy) {
      speechNote.className = "receipt";
      speechNote.textContent = `качаю ${down!.voice}: ${down!.done_mb ?? 0} из ~${down!.size_mb ?? "?"} МБ`;
    } else if (down && down.state === "failed") {
      speechNote.className = "receipt err";
      speechNote.textContent = String(down.error || "не скачалось");
    } else if (down && down.state === "running") {
      speechNote.className = "receipt err";
      speechNote.textContent = "скачивание оборвалось — нажми ещё раз";
    } else if (down && down.state === "done") {
      speechNote.className = "receipt ok";
      speechNote.textContent = "голос на месте";
    }
    if (!state.library.present) {
      if (state.library.downloadable) {
        speechStatus.textContent =
          `XTTS ещё не установлен. Кнопка устанавливает отдельный runtime и модель из комплекта; Whisper остаётся независимым.`;
        return;
      }
      speechStatus.textContent = state.library.why + ". Говорить в этой сборке нечем.";
      speechBtn.disabled = true;
      return;
    }
    speechStatus.textContent = state.ready
      ? `XTTS установлен. Время синтеза зависит от устройства; модель держит отдельный процесс под общим Stop. Модель: ${state.dir}.`
      : `Агент отвечает текстом: ${state.why}. Голоса лежат в ${state.dir}.`;
  };

  const startVoice = async () => {
    speechNote.className = "receipt";
    speechNote.textContent = "запускаю помощника…";
    speechBtn.disabled = true;
    try {
      const said = await shell<string>("voice_fetch", { model: speakVoice, kind: "speak" });
      speechNote.textContent = said;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => void refresh(), 1500);
    } catch (e) {
      speechNote.className = "receipt err";
      speechNote.textContent = humanError(e).text;
      speechBtn.disabled = false;
    }
  };

  box.append(voicePreferencesFields(), onOff, status, pickBox, actions, keepOff,
    el("p", "field-hint",
      "Модель держится в памяти около 1,5 ГБ. Дома это дорого за несколько голосовых в день, поэтому по умолчанию " +
      "она загружается на время расшифровки и отпускается; на сервере наоборот. Применяется перезапуском."),
    el("hr", "card-split"),
    speakOff, speechStatus, speechPickBox, speechFields, speechActions,
    el("p", "field-hint",
      "XTTS местный, без Piper и сетевого fallback. Модель XTTS-v2 и её аудио — только для некоммерческого использования (Coqui Public Model License). Whisper распознаёт твои голосовые, XTTS озвучивает ответы. Настройки применяются перезапуском."));

  const onSection = (event: Event) => {
    if (!box.closest(".page")) {
      removeEventListener("frame-section", onSection);
      if (timer) { clearTimeout(timer); timer = null; }
      return;
    }
    if ((event as CustomEvent).detail === "settings" && box.isConnected) void refresh();
    else {audio.pause();if (timer) { clearTimeout(timer); timer = null; }}
  };
  addEventListener("frame-section", onSection);
  void refresh();

  return {
    el: card("Голос", box,
      "Распознавание и синтез речи работают локально. Распознанный текст получает выбранная модель агента. Голосовые компоненты можно подготовить, когда они понадобятся."),
    enabled: () => enabled,
    model: () => model,
    keepLoaded: () => keep,
    speak: () => speak,
    speakVoice: () => speakVoice,
  };
}

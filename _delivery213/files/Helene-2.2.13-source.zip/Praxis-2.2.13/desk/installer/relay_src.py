#!/usr/bin/env python3
"""Исходник реле для поставки: сверить с живым и обновить зеркало.

Реле в поставке (`helene-relay.exe`) собирается из `_relay_prod_src/` рядом с
репозиториями — это КОПИЯ живого исходника с сервера (`/opt/relay/current`), и до
10.09 она обновлялась руками и без следа. Класс ошибки уже стрелял: 09.09 в
поставке лежал бинарь от 03.09, а починка ссылок была от 09.09 — узнали об этом
случайно, потому что сверять было нечем.

Здесь два действия и один отпечаток:

    python installer/relay_src.py --check --host <адрес>   # зеркало = живой?
    python installer/relay_src.py --pull  --host <адрес>   # обновить зеркало
    python installer/relay_src.py --digest                 # отпечаток зеркала
    python installer/relay_src.py --build                  # собрать exe для Windows
    python installer/relay_src.py --build-linux            # собрать бинарь для сервера

Отпечаток считается по содержимому с одной нормой переводов строк (LF): копия
на Windows иначе расходилась бы с сервером на каждом файле. Его же пишет в
паспорт сборка (`helene-build.json` -> `relay`), а рядом с зеркалом лежит
`RELAY-SOURCE.json`: откуда, какой коммит, когда снято.

Пароль — в `PRAXIS_DEPLOY_PASSWORD` (или ключом ssh-agent). Нужен `paramiko`.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

DESK = Path(__file__).resolve().parent.parent
ROOT = DESK.parent
sys.path.insert(0, str(DESK))
import layout  # noqa: E402 — где на диске лежат соседи раскладки
import relay_rebuild_kit  # noqa: E402 — byte-exact build input inventory

MIRROR = layout.relay_mirror()
STAMP = "RELAY-SOURCE.json"
BUILT = "RELAY-BUILD.json"
#: Linux-бинарь реле: тот же исходник, другая цель. Нужен серверу — на той
#: стороне агент с подпиской ChatGPT без него нем (`server/serverboot.py`).
LINUX_BUILT = "RELAY-BUILD-LINUX.json"
LINUX_REL = ("target", "linux", "helene-relay")
LINUX_IMAGE = "helene-relay-build:local"
LINUX_IN_IMAGE = "/usr/src/codex/target/release/codex-proxy-server"
# Stable source pointer to the immutable release used by the live relay.
# /opt/relay/Code is a preserved legacy checkout and no longer the build source.
REMOTE_DEFAULT = "/opt/relay/current"

# Что считается исходником реле: то, из чего собирается бинарь. Каталог target/
# и логи не в счёт — это следы сборки, а не она сама.
PATTERNS = ("src/**/*", "Cargo.toml", "Cargo.lock")


def _files(root: Path) -> list[Path]:
    seen: list[Path] = []
    for pat in PATTERNS:
        seen += [p for p in root.glob(pat) if p.is_file()]
    return sorted(set(seen))


def digest(root: Path) -> tuple[str, dict[str, str]]:
    """Отпечаток исходника -> (общий sha256, файл -> sha256).

    Содержимое приводится к LF: зеркало на Windows и оригинал на сервере
    отличались бы каждым файлом, и сверка не значила бы ничего.
    """
    files = {}
    for path in _files(root):
        rel = path.relative_to(root).as_posix()
        files[rel] = hashlib.sha256(
            path.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    total = hashlib.sha256(
        "\n".join(f"{rel} {sha}" for rel, sha in sorted(files.items())).encode("utf-8")
    ).hexdigest()
    return total, files


INPUT_DIGEST_KIND = "byte_exact_relay_build_inputs_v1"
WINDOWS_BUILD_METHOD = "cargo_explicit_target_v1"
LINUX_BUILD_METHOD = "docker_immutable_image_v1"


def build_inputs(root: Path) -> tuple[str, int]:
    """All selected Rust/Docker source files, distinct from the legacy LF locator.

    Includes Dockerfile, build.rs, .cargo and resources; excludes Git, target
    and private receipts. External toolchain/network inputs remain unqualified.
    """
    files = relay_rebuild_kit.inventory(root, source=True, private_mirror=True)
    return relay_rebuild_kit._digest(files), len(files)


def _build_input_receipt(root: Path, before: tuple[str, int]) -> dict:
    if build_inputs(root) != before:
        raise SystemExit("relay source changed during build; no build receipt written")
    return {"input_digest_kind": INPUT_DIGEST_KIND,
            "input_sha256": before[0], "input_files": before[1]}


def newest_mtime(root: Path = MIRROR) -> float:
    """Когда исходник трогали в последний раз — чтобы сборка увидела, что
    бинарь старше своих же исходников (09.09 в поставку уехало реле от 03.09)."""
    return max((p.stat().st_mtime for p in _files(root)), default=0.0)


def stamp(root: Path = MIRROR) -> dict:
    """Что записано о происхождении зеркала; пусто — не записано ничего."""
    return _read(root / STAMP)


def built(root: Path = MIRROR) -> dict:
    """Чем собран лежащий рядом бинарь; пусто — сборка ничего о себе не сказала."""
    return _read(root / BUILT)


def _read(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def build(root: Path = MIRROR) -> dict:
    """Собрать реле и записать, ИЗ ЧЕГО оно собрано.

    Отпечаток исходника в момент сборки — единственный честный ответ на вопрос
    «этот ли бинарь у меня в поставке». По времени файлов судить нельзя: любое
    обновление зеркала переписывает mtime, ничего не меняя по существу.
    """
    root = Path(root).resolve()
    total, files = digest(root)
    inputs = build_inputs(root)
    print(f"cargo build --release в {root} ({len(files)} файлов исходника)…")
    target = "x86_64-pc-windows-msvc"
    r = subprocess.run(["cargo", "build", "--release", "--locked", "--target", target,
                        "--target-dir", str(root / "target")], cwd=root,
                       text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise SystemExit("реле не собралось")
    produced = root / "target" / target / "release" / "codex-proxy-server.exe"
    if not produced.is_file():
        raise SystemExit(f"после сборки не нашёлся бинарь в {produced}")
    exe = root / "target" / "release" / produced.name
    exe.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(produced, exe)
    if hashlib.sha256(exe.read_bytes()).digest() != hashlib.sha256(produced.read_bytes()).digest():
        raise SystemExit("relay build output copy differs")
    note = {
        "digest": total,
        **_build_input_receipt(root, inputs),
        "build_method": WINDOWS_BUILD_METHOD,
        "target": target,
        "exe": exe.name,
        "exe_sha256": hashlib.sha256(exe.read_bytes()).hexdigest(),
        "built_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    (root / BUILT).write_text(json.dumps(note, ensure_ascii=False, indent=1) + "\n",
                              encoding="utf-8", newline="\n")
    print(f"собрано: {exe} ({exe.stat().st_size / 1e6:.1f} МБ)")
    print(f"записано: {root / BUILT}")
    return note


def linux_binary(root: Path = MIRROR) -> Path:
    """Где лежит собранный Linux-бинарь реле (внутри `target/` — не исходник)."""
    return root.joinpath(*LINUX_REL)


def built_linux(root: Path = MIRROR) -> dict:
    """Чем собран Linux-бинарь; пусто — сборка о себе ничего не сказала."""
    return _read(root / LINUX_BUILT)


def build_linux(root: Path = MIRROR, image: str = LINUX_IMAGE,
                memory_limit: str = "") -> dict:
    """Собрать реле под Linux в докере и записать, ИЗ ЧЕГО оно собрано.

    Windows-бинарь собирается `cargo` на месте, Linux-бинарь — в контейнере по
    `Dockerfile` самого реле (стадия `builder`). Кросс-компиляции здесь нет
    намеренно: у реле `reqwest` с нативным TLS, и подбор линкера под музл
    занял бы больше, чем один слой докера.

    Бинарь достаётся из образа (`docker create` + `docker cp`), а не пишется
    в бинд-маунт: маунт с диска Windows в контейнер медленнее раз в сорок, и
    сборка в нём идёт минутами вместо секунд.
    """
    root = Path(root).resolve()
    total, files = digest(root)
    inputs = build_inputs(root)
    print(f"docker build (реле под Linux) в {root} ({len(files)} файлов исходника)…")
    # The tag can be replaced by another concurrent build. Create only from
    # this invocation's immutable image ID recorded in a private temporary file.
    with tempfile.TemporaryDirectory(prefix="relay-image-") as tmp:
        iid = Path(tmp) / "image-id"
        r = subprocess.run(["docker", "build", *(["--memory", memory_limit] if memory_limit else []),
                            "--target", "builder", "--iidfile", str(iid),
                            "-t", image, "."], cwd=root,
                           text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            raise SystemExit("реле под Linux не собралось (docker build)")
        image_id = iid.read_text(encoding="ascii").strip()
    if re.fullmatch(r"sha256:[0-9a-f]{64}", image_id) is None:
        raise SystemExit("docker did not attest an immutable image id")
    made = subprocess.run(["docker", "create", image_id], cwd=root, capture_output=True,
                          text=True, encoding="utf-8", errors="replace")
    cid = made.stdout.strip()
    if made.returncode != 0 or not cid:
        raise SystemExit("не создался контейнер для выемки бинаря: " + made.stderr[-300:])
    out = linux_binary(root)
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        got = subprocess.run(["docker", "cp", f"{cid}:{LINUX_IN_IMAGE}", str(out)],
                             capture_output=True, text=True, encoding="utf-8", errors="replace")
        if got.returncode != 0 or not out.is_file():
            raise SystemExit("бинарь не достался из образа: " + got.stderr[-300:])
    finally:
        subprocess.run(["docker", "rm", "-f", cid], capture_output=True, text=True)
    note = {
        "digest": total,
        **_build_input_receipt(root, inputs),
        "build_method": LINUX_BUILD_METHOD,
        "image_id": image_id,
        "memory_limit": memory_limit or None,
        "target": "x86_64-unknown-linux-gnu",
        "exe": out.name,
        "exe_sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
        "built_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    (root / LINUX_BUILT).write_text(json.dumps(note, ensure_ascii=False, indent=1) + "\n",
                                    encoding="utf-8", newline="\n")
    print(f"собрано: {out} ({out.stat().st_size / 1e6:.1f} МБ)")
    print(f"записано: {root / LINUX_BUILT}")
    return note


# --- сервер -------------------------------------------------------------------

_PROBE = r"""
import hashlib, json, pathlib, subprocess
root = pathlib.Path(%r)
pats = %r
files = {}
seen = []
for pat in pats:
    seen += [p for p in root.glob(pat) if p.is_file()]
for path in sorted(set(seen)):
    files[path.relative_to(root).as_posix()] = hashlib.sha256(
        path.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
head = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'],
                      capture_output=True, text=True).stdout.strip()
dirty = bool(subprocess.run(['git', '-C', str(root), 'status', '--porcelain'],
                            capture_output=True, text=True).stdout.strip())
print(json.dumps({'files': files, 'head': head, 'dirty': dirty}))
"""


def _connect(host: str, user: str):
    try:
        import paramiko  # noqa: PLC0415 — зависимость только этой утилиты
    except ImportError:
        raise SystemExit("нужен paramiko: python -m pip install paramiko")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user,
                   password=os.environ.get("PRAXIS_DEPLOY_PASSWORD") or None, timeout=30)
    return client


def remote_state(client, remote: str) -> dict:
    # Через base64: код многострочный, и любая попытка передать его кавычками
    # ломается о разбор оболочки — переводы строк доезжают до python3 уже
    # обратной косой с буквой, и он падает на первой же строке.
    code = base64.b64encode((_PROBE % (remote, PATTERNS)).encode("utf-8")).decode("ascii")
    cmd = f"python3 -c \"import base64;exec(base64.b64decode('{code}'))\""
    _in, out, err = client.exec_command(cmd, timeout=120)
    body = out.read().decode("utf-8", "replace").strip()
    if out.channel.recv_exit_status() != 0 or not body:
        raise SystemExit("не прочитался исходник на сервере: "
                         + err.read().decode("utf-8", "replace")[-500:])
    return json.loads(body)


def compare(mine: dict[str, str], theirs: dict[str, str]) -> list[str]:
    lines = []
    for rel in sorted(set(mine) | set(theirs)):
        a, b = theirs.get(rel), mine.get(rel)
        if a == b:
            continue
        lines.append(f"  {'нет в зеркале' if b is None else 'нет на сервере' if a is None else 'различается'}: {rel}")
    return lines


def main() -> int:
    ap = argparse.ArgumentParser(description="исходник реле: сверка и обновление зеркала")
    ap.add_argument("--host", default=os.environ.get("PRAXIS_DEPLOY_HOST", ""))
    ap.add_argument("--user", default=os.environ.get("PRAXIS_DEPLOY_USER", "root"))
    ap.add_argument("--remote", default=REMOTE_DEFAULT, help="исходник реле на сервере")
    ap.add_argument("--mirror", default=str(MIRROR), help="зеркало рядом с репозиториями")
    ap.add_argument("--check", action="store_true", help="сверить зеркало с живым")
    ap.add_argument("--pull", action="store_true", help="обновить зеркало живым")
    ap.add_argument("--digest", action="store_true", help="напечатать отпечаток зеркала")
    ap.add_argument("--build", action="store_true",
                    help="собрать реле и записать, из какого исходника")
    ap.add_argument("--build-linux", action="store_true",
                    help="собрать Linux реле в Docker на сервере (не на локальном Windows)")
    ap.add_argument("--docker-memory", default="",
                    help="limit server Docker builder memory, e.g. 1536m")
    args = ap.parse_args()

    mirror = Path(args.mirror)
    if args.build:
        build(mirror)
        if not (args.check or args.pull or args.build_linux):
            return 0
    if args.build_linux:
        build_linux(mirror, memory_limit=args.docker_memory)
        if not (args.check or args.pull):
            return 0
    if args.digest or not (args.check or args.pull):
        total, files = digest(mirror)
        note = stamp(mirror)
        made = built(mirror)
        print(f"зеркало: {mirror}")
        print(f"файлов: {len(files)}, отпечаток {total[:16]}")
        print("происхождение: " + (json.dumps(note, ensure_ascii=False)
                                   if note else f"НЕ ЗАПИСАНО (нет {STAMP})"))
        if not made:
            print(f"бинарь: о себе ничего не сказано (нет {BUILT}) — собери "
                  "installer/relay_src.py --build")
        elif made.get("digest") == total:
            print(f"бинарь: собран из этого же исходника ({made.get('built_utc')})")
        else:
            print(f"бинарь: собран ИЗ ДРУГОГО исходника ({made.get('digest', '')[:16]}) — пересобрать")
        linux = built_linux(mirror)
        if not linux_binary(mirror).is_file():
            print("Linux-бинарь: НЕТ — собери installer/relay_src.py --build-linux "
                  "(без него агент, увезённый на сервер, нем)")
        elif linux.get("digest") == total:
            print(f"Linux-бинарь: собран из этого же исходника ({linux.get('built_utc')})")
        else:
            print(f"Linux-бинарь: собран ИЗ ДРУГОГО исходника ({linux.get('digest', '')[:16]}) — пересобрать")
        return 0

    if not args.host:
        raise SystemExit("нужен --host (или PRAXIS_DEPLOY_HOST)")
    client = _connect(args.host, args.user)
    try:
        state = remote_state(client, args.remote)
        _total, mine = digest(mirror)
        diff = compare(mine, state["files"])
        head = state["head"][:7] + ("-dirty" if state["dirty"] else "")
        print(f"живой исходник: {args.remote} @ {head}, файлов {len(state['files'])}")
        if args.check:
            if not diff:
                print("зеркало сходится с живым исходником — поставка соберётся из него")
                return 0
            print("зеркало РАСХОДИТСЯ с живым:")
            print("\n".join(diff))
            print("обновить: installer/relay_src.py --pull --host " + args.host)
            return 1

        # --pull: тянем ровно то, что считается исходником, и ничего больше.
        sftp = client.open_sftp()
        pulled = 0
        for rel in sorted(state["files"]):
            target = mirror / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with sftp.open(f"{args.remote.rstrip('/')}/{rel}", "rb") as src:
                data = src.read()
            target.write_bytes(data)
            pulled += 1
        sftp.close()
        for rel in sorted(set(mine) - set(state["files"])):
            print(f"  лишний файл в зеркале (не трогаю): {rel}")
        total, _files = digest(mirror)
        note = {
            "from": f"{args.user}@{args.host}:{args.remote}",
            "commit": state["head"],
            "dirty": state["dirty"],
            "pulled_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "digest": total,
            "files": pulled,
        }
        (mirror / STAMP).write_text(json.dumps(note, ensure_ascii=False, indent=1) + "\n",
                                    encoding="utf-8", newline="\n")
        print(f"взято файлов: {pulled}, отпечаток {total[:16]}")
        print(f"записано: {mirror / STAMP}")
        print("пересобрать реле: cargo build --release в " + str(mirror))
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())

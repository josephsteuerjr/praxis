# -*- coding: utf-8 -*-
"""Рука брокера: агент ПРОСИТ команду с правами, подписывает владелец (R7).

До этой руки брокер был дверью ровно для одной кнопки окна («Телефон»), а в
`localharness/` слова broker не встречалось ни разу. Тексты продукта при этом
говорили агенту про брокера как про существующий механизм — то есть обещали то,
чего у него не было. Здесь эта рука заводится.

## Как это работает

Своей двери к брокеру у агента нет: труба службы пускает по токену, а токен
лежит в `memory/.state/broker-token` с правами «СИСТЕМА, администраторы,
владелец». Поэтому агент не зовёт брокера, а пишет ПРОСЬБУ; оболочка её читает,
показывает владельцу родным окном Windows и только по «да» идёт в трубу своим
токеном. Обратно приходит квитанция — код возврата, оба потока, длительность.

Обмен — два файла в `memory/.state`, у каждого РОВНО ОДИН писатель, поэтому
замка не нужно (тот же приём, что у `mounts.json`):

    broker-asks.json      пишем мы, читает оболочка — чего просит агент;
    broker-answers.json   пишет оболочка, читаем мы — что решил владелец.

Контракт полей записан в шапке `common/broker.rs` рядом с `broker_asks_path` —
он один на обе стороны, и здесь повторяется только то, что нужно руке.

## Чего эта рука НЕ даёт, и врать об этом нельзя

* **Это не замок на агента.** В песочнице агент токена брокера не прочитает, а
  в интерактивном режиме — прочитает и может пойти в трубу сам, минуя окно
  подтверждения. Так написано и в `common/broker.rs`: брокер закрыт от ЧУЖИХ
  программ, а от собственного агента закрыт быть не может. Подтверждение
  владельца — честный и записываемый путь, а не преграда.
* **Ответ может не прийти вовсе.** Просьбу читает оболочка; нет окна — нет и
  читателя. Мы это проверяем ДО записи (блок `desk` в файле ответов плюс живой
  pid) и говорим агенту прямо, вместо того чтобы молчать до таймаута.
* **`exec` (права СИСТЕМЫ) заперт галочкой нулевой сессии** — её проверяет сама
  служба (`svc::broker_exec_allowed`). Владелец может сказать «да» в окне, а
  служба всё равно откажет: это два разных замка, и второй нам не подчиняется.
* **Просьба живёт десять минут.** Оболочка отклоняет всё, что старше
  (`BROKER_WISH_STALE_SEC`): подписывать вслепую просьбу, от которой агент уже
  ушёл дальше, опаснее, чем отказать. Значит рука ждёт минуты, а не часы, и
  «владелец не ответил» говорит именно этими словами — не «отказал».

Проверки просьбы здесь — копия проверок `BrokerAsk::parse` из
`common/broker.rs`. Не ради вежливости: что отвергает служба, владельцу даже не
показывают, и без местной проверки агент получал бы отказ через минуту ожидания
вместо ответа сразу.

## macOS (порт 19.09)

Службы и трубы нет: брокер — САМА ОБОЛОЧКА. Она читает те же `broker-asks.json`,
спрашивает владельца родным диалогом и исполняет сама: `spawn_interactive` —
правами владельца в его сессии, `exec` — правами администратора через
`osascript … with administrator privileges` (пароль спрашивает система своим
диалогом, и этот диалог — подпись владельца; отмена — отказ). `ping` отвечает
без вопроса. Двери `firewall` на Mac нет: брандмауэр там спрашивает сам. Проверка
команды — POSIX: абсолютный путь, без `..`, программа на месте (`check_cmd`).
Файлы обмена, квитанция и слова «владелец не ответил» — те же.

## Linux

При service.session0=true агент обращается к root-службе по Unix-сокету;
SO_PEERCRED определяет владельца, служба проверяет его сохранённое согласие.
Окно, polkit и пароль для поручений не нужны. При выключенной нулевой сессии
просьбу читает окно, которое запускает отдельный broker-root через pkexec:
каждая exec требует пароль администратора. Обе двери возвращают квитанцию
и пишут поручение в журнал. spawn_interactive на Linux не предлагается.

Модуль без зависимостей, кроме стандартной библиотеки и соседей по харнессу.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import sys
import time
import unicodedata
from pathlib import Path

log = logging.getLogger("helene.broker")

#: Версия протокола обмена — `BROKER_V` в common/broker.rs.
V = 1

#: Сколько просьба живёт у оболочки (`BROKER_WISH_STALE_SEC`). Старше — отказ
#: без вопроса владельцу, поэтому и мы такие из своего файла убираем.
ASK_STALE_SEC = 10 * 60

#: Сколько рука ждёт ответа по умолчанию и сколько согласна ждать вообще.
#: Верх — меньше, чем живёт просьба: ждать дольше, чем она действительна, значит
#: обещать агенту ответ, которого уже не будет.
WAIT_DEFAULT = 120
WAIT_MAX = 300

#: Потолок ожидания САМОЙ КОМАНДЫ (`BROKER_TIMEOUT_MAX`).
TIMEOUT_MAX = 600
TIMEOUT_DEFAULT = 60

#: Сколько просьб держим в файле. У оболочки потолок разбора 64 строки; больше
#: тридцати ждущих просьб — это не работа, а очередь модальных окон владельцу.
KEEP_ASKS = 32

#: Двери брокера. `ping` ничего не выполняет.
OPS = ("ping", "spawn_interactive", "exec")

#: Что видно в анатомии. Заполняется на установке руки и на каждом её вызове.
STATE: dict = {"hand": False, "desk": "", "asks": 0, "answers": 0, "note": ""}

#: Брокер есть на Windows (просьбы исполняет служба `svc`) и на macOS (исполняет
#: сама оболочка, пароль администратора спрашивает система), а на Linux —
#: Unix-сокет или pkexec. Стенды подменяют флаг на любой машине.
HAS_BROKER = os.name == "nt" or sys.platform == "darwin" or sys.platform.startswith("linux")
LINUX = sys.platform.startswith("linux")
LINUX_SOCKET = "/run/helene/broker.sock"
#: Форма пути к программе — POSIX (`/usr/bin/…`) или Windows (`C:\…`, UNC).
#: Стенды передают её явно, чтобы разобрать обе на любой машине.
POSIX_PATHS = os.name != "nt"


def executor() -> str:
    """Кто исполняет подписанную просьбу — для слов агенту: на Windows служба,
    на macOS сама оболочка."""
    return "служба" if os.name == "nt" else "оболочка"


def call_linux(payload: dict, wait_sec: float, *, socket_path: str | None = None) -> dict:
    """One bounded JSON-line exchange with the root service; no polkit fallback."""
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as peer:
        peer.settimeout(wait_sec)
        peer.connect(socket_path or LINUX_SOCKET)
        peer.sendall(json.dumps(payload, ensure_ascii=False).encode("utf-8") + b"\n")
        with peer.makefile("rb") as response:
            line = response.readline(1024 * 1024)
        if not line.endswith(b"\n"):
            raise OSError("брокер закрыл связь или прислал слишком большой ответ")
        reply = json.loads(line)
        if not isinstance(reply, dict):
            raise OSError("ответ брокера — не объект")
        return reply


# --------------------------------------------------------------------------- #
#  Windows: поручение идёт СЛУЖБЕ напрямую (28.09, слово Егора)
# --------------------------------------------------------------------------- #
#
# «С включённым тумблером не надо запрашивать у владельца: говорит службе — та
# делает». Согласие владельца — сам тумблер нулевой сессии: включая его, он читает
# оговорку (modes.SESSION0_WARNING). Окно подтверждения на каждое поручение было
# вторым вопросом о том же и держало агента за окном: закрыто окно — поручать
# некому. Теперь харнесс ходит в трубу службы сам: труба пускает процессы из сессии
# владельца по токену (`common/broker.rs`), а харнесс живёт именно там.
#
# Замки службы остаются её замками и не подчиняются нам: `exec` без тумблера она
# отклонит своими словами (`svc::broker_exec_allowed`), чужую сессию — тоже.
# Каждое поручение служба пишет в свой журнал `broker.log`.

#: Поручения по трубе — только Windows: на macOS исполнитель — сама оболочка, и
#: подписью там служит системный диалог пароля (его не обойти и не нужно).
DIRECT = os.name == "nt"

#: Сколько ждём свободную трубу (ERROR_PIPE_BUSY) — как `broker_call` в Rust.
PIPE_BUSY_WAIT = 5.0
#: Сверх срока самой команды: служба отвечает квитанцией и по таймауту, но убитая
#: посреди работы служба оставила бы нас висеть на чтении.
PIPE_SLACK = 20.0
#: Последние квитанции — для action=list.
RECENT: list[dict] = []
RECENT_KEEP = 8


def install_root() -> Path:
    """Корень установки (папка `helene-svc.exe`): `app/localharness/broker.py` → вверх на два."""
    env = os.environ.get("HELENE_ROOT")
    return Path(env) if env else Path(__file__).resolve().parents[2]


def _norm_root(root) -> str:
    """Как `broker_norm_path`: без `\\\\?\\`, без хвостового слэша, нижний регистр."""
    raw = str(root).replace("/", "\\")
    if raw.startswith("\\\\?\\UNC\\"):
        raw = "\\\\" + raw[8:]
    elif raw.startswith("\\\\?\\"):
        raw = raw[4:]
    return raw.rstrip("\\").lower()


def pipe_name(root) -> str:
    """`\\\\.\\pipe\\helene-broker-<FNV-1a 64 пути установки>` — как `broker_pipe_name`."""
    h = 0xCBF29CE484222325
    for byte in _norm_root(root).encode("utf-8"):
        h ^= byte
        h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
    return f"\\\\.\\pipe\\helene-broker-{h:016x}"


def read_token(tree: Path) -> str | None:
    """Токен брокера — `memory/.state/broker-token`, те же правила, что `broker_token_read`."""
    try:
        raw = (Path(tree) / "memory" / ".state" / "broker-token").read_text(encoding="utf-8")
    except OSError:
        return None
    tok = raw.strip()
    return tok if 16 <= len(tok) <= 128 and tok.isascii() and tok.isalnum() else None


def _frame(payload: bytes) -> bytes:
    return len(payload).to_bytes(4, "little") + payload


def _read_exact(pipe, n: int) -> bytes:
    out = b""
    while len(out) < n:
        chunk = pipe.read(n - len(out))
        if not chunk:
            raise OSError("служба закрыла трубу посреди ответа")
        out += chunk
    return out


def call_service(pipe: str, payload: dict, wait_sec: float) -> dict:
    """Один запрос в трубу службы -> квитанция словарём. Отказ — исключение с
    человеческими словами (труба не открылась, оборвалась, не ответила)."""
    if os.environ.get('HELENE_BROKER_DISABLED') == '1':
        raise RuntimeError('Брокер исключён из Python-поставки; запрос недоступен.')
    import threading
    deadline = time.monotonic() + PIPE_BUSY_WAIT
    handle = None
    while handle is None:
        try:
            handle = open(pipe, "r+b", buffering=0)
        except OSError as exc:
            if getattr(exc, "winerror", None) == 231 and time.monotonic() < deadline:
                time.sleep(0.12)
                continue
            raise OSError(f"служба не отвечает на трубе {pipe}: {exc}. Брокер живёт, "
                          "только пока стоит служба Hélène") from exc
    box: dict = {}

    def talk():
        try:
            handle.write(_frame(json.dumps(payload, ensure_ascii=False).encode("utf-8")))
            size = int.from_bytes(_read_exact(handle, 4), "little")
            if size <= 0 or size > 4 * 1024 * 1024:
                raise OSError(f"квитанция странного размера: {size} байт")
            box["receipt"] = json.loads(_read_exact(handle, size).decode("utf-8"))
        except Exception as exc:                      # отдаём наружу словами
            box["error"] = exc

    worker = threading.Thread(target=talk, name="broker-pipe", daemon=True)
    worker.start()
    worker.join(wait_sec)
    try:
        handle.close()
    except OSError:
        pass
    if worker.is_alive():
        raise OSError(f"служба не ответила за {int(wait_sec)} с — квитанции нет")
    if "error" in box:
        raise OSError(str(box["error"]))
    receipt = box.get("receipt")
    if not isinstance(receipt, dict):
        raise OSError("квитанция не разобралась")
    return receipt


def _remember(row: dict) -> None:
    RECENT.append(row)
    del RECENT[:-RECENT_KEEP]


# --------------------------------------------------------------------------- #
#  Файлы обмена
# --------------------------------------------------------------------------- #

def asks_path(tree: Path) -> Path:
    return Path(tree) / "memory" / ".state" / "broker-asks.json"


def answers_path(tree: Path) -> Path:
    return Path(tree) / "memory" / ".state" / "broker-answers.json"


def _load(path: Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _stamp() -> str:
    # Тот же формат, что у helene.log, service.log и broker.log службы
    # (`common/stamp.rs`): местное время С СЕКУНДАМИ. Раньше здесь их не было,
    # и просьбы агента нельзя было сопоставить с журналом службы по времени.
    return time.strftime("%d.%m.%Y %H:%M:%S")


def _rows(data: dict, key: str) -> list[dict]:
    return [r for r in (data.get(key) or ()) if isinstance(r, dict)]


# --------------------------------------------------------------------------- #
#  Проверки просьбы — копия границы из common/broker.rs
# --------------------------------------------------------------------------- #

#: Слова отказа — те же, что на другой стороне границы
#: (`common/broker.rs::BROKER_INVISIBLE_SAID`).
INVISIBLE_SAID = ("в команде есть невидимые знаки переноса/формата (U+2028, U+200E, "
                  "мягкий перенос и такие же): окно подтверждения показало бы владельцу "
                  "не то, что исполнится. Напиши команду обычными знаками")


def has_invisible(text: str) -> bool:
    """Есть ли в строке знак, которого владелец в окне подтверждения не увидит.

    Категории Cc (управляющие, включая ``\t`` и U+0085), Cf (знаки формата:
    мягкий перенос, ноль-ширины, переключатели направления письма), Zl (U+2028)
    и Zp (U+2029).

    ⚠ ЗАЧЕМ ШИРЕ, ЧЕМ ``ord(c) < 32``. Решение владельца принимается по тому,
    ЧТО ОН УВИДЕЛ: U+2028 переносит строку у всего, что рисует текст, а U+202E
    разворачивает кусок задом наперёд прямо на экране. Просьба могла нарисовать
    в окне одну команду, а уехать в исполнение другой.

    U+00A0 сюда НЕ входит: это обычный пробел (Zs), он видим.

    Зеркало `common/broker.rs::broker_invisible` — одна граница, две копии, как
    и весь остальной разбор просьбы.
    """
    return any(unicodedata.category(c) in ("Cc", "Cf", "Zl", "Zp") for c in text)


def check_why(why: str) -> str:
    """Отказ словами или "" — если «зачем» годится. Это читает ВЛАДЕЛЕЦ."""
    if not why:
        return ("скажи ЗАЧЕМ тебе эта команда — эту строку читает владелец, и по "
                "ней он решает, подписывать или нет")
    if len(why) < 3 or not any(c.isalpha() for c in why):
        return "«зачем» должно быть словами, а не знаком-заглушкой"
    if len(why) > 500:
        return "«зачем» длиннее 500 знаков — это уже не объяснение"
    if has_invisible(why):
        # Журнал владельца читается построчно: перевод строки внутри «зачем»
        # нарисовал бы в нём десяток чужих записей с любым текстом — и тем же
        # приёмом работают невидимые переводы (U+2028, U+0085) и знаки формата.
        return ("«зачем» — одной строкой обычными знаками: перевод строки (в том числе "
                "невидимый — U+2028, U+0085) подделывает журнал, а знаки формата "
                "переставляют текст прямо на экране владельца")
    return ""


def check_cmd(cmd: str, *, posix: bool | None = None) -> str:
    """Отказ словами или "" — если программа названа так, как примет исполнитель.

    Только полный путь: `CreateProcess` ищет голое имя СНАЧАЛА в папке своего
    процесса, а это папка установки. Подложенный туда `netsh.exe` исполнился бы
    правами СИСТЕМЫ. На POSIX голое имя искалось бы по PATH владельца, а
    правами администратора (`exec` на Mac) подменённый в PATH файл ничем не
    лучше — поэтому и там только абсолютный путь, без `..`, и программа обязана
    быть на месте: просьбу о несуществующей команде владельцу показывать незачем.
    """
    if posix is None:
        posix = POSIX_PATHS
    if not cmd:
        return "нет команды: назови программу полным путём в поле cmd"
    if "\0" in cmd:
        return "в имени программы нулевой байт — команда оборвётся на нём"
    if has_invisible(cmd):
        return INVISIBLE_SAID
    if posix:
        if not cmd.startswith("/"):
            return (f"команду надо называть абсолютным путём, а не «{cmd}»: голое "
                    f"имя ищется по PATH, и подменённый там файл исполнился бы "
                    f"чужими правами. Пример: /usr/bin/id")
        if ".." in cmd:
            return "в пути есть «..» — назови программу прямо"
        if not os.path.isfile(cmd):
            return f"программы «{cmd}» нет по этому пути — проверь путь, прежде чем просить"
        return ""
    drive = len(cmd) > 2 and cmd[0].isascii() and cmd[0].isalpha() \
        and cmd[1] == ":" and cmd[2] in "\\/"
    if not drive and not cmd.startswith("\\\\"):
        return (f"команду надо называть полным путём, а не «{cmd}»: голое имя "
                f"Windows ищет сначала в папке программы, и подменённый там файл "
                f"исполнился бы правами СИСТЕМЫ. Пример: "
                f"C:\\Windows\\System32\\netsh.exe")
    if ".." in cmd:
        return "в пути есть «..» — назови программу прямо"
    return ""


def check_args(args) -> str:
    """Отказ словами или "" — если аргументы массивом строк, как их ждёт служба."""
    if args is None:
        return ""
    if isinstance(args, str) or not isinstance(args, (list, tuple)):
        return ("args — МАССИВ строк, и никогда одна строка: склейка командной "
                "строки это класс дыр, а не удобство. "
                "[\"advfirewall\", \"firewall\", \"show\", \"rule\"]")
    if len(args) > 256:
        return "больше 256 аргументов — это не команда"
    for item in args:
        if not isinstance(item, str):
            return "в args есть не-строка — аргументы бывают только строками"
        if "\0" in item:
            return "в args есть нулевой байт — Windows обрежет команду на нём"
        # ⚠ Граница сдвинута 19.09 (судьи): раньше аргументу разрешался перевод
        # строки, а подделку показа снимала оболочка. Но владелец решает по тому,
        # что увидел в окне, и знака, которого на экране нет, там быть не должно
        # вовсе — многострочное отдают файлом, а не аргументом.
        if has_invisible(item):
            return INVISIBLE_SAID
    return ""


def exec_words(*, mac: bool | None = None) -> str:
    """Чем является дверь `exec` на этой платформе — одними словами везде, где
    она называется агенту (граница, схема тула)."""
    if (sys.platform == "darwin") if mac is None else mac:
        return "правами администратора: система сама спросит у владельца пароль"
    return "правами СИСТЕМЫ; работает, только если владелец включил галочку нулевой сессии"


def check(op: str, cmd: str, args, why: str, timeout_sec: int) -> str:
    """Вся граница разом. "" — просьбу можно записывать."""
    if op not in OPS:
        return (f"не знаю такой двери: «{op}». Бывают ping (проверка связи), "
                f"spawn_interactive (правами владельца, в его сессии) и "
                f"exec ({exec_words()})")
    said = check_why(why)
    if said:
        return said
    said = check_args(args)
    if said:
        return said
    if op != "ping":
        said = check_cmd(cmd)
        if said:
            return said
    if not isinstance(timeout_sec, int) or isinstance(timeout_sec, bool):
        return "timeout_sec — это число секунд"
    if timeout_sec < 1 or timeout_sec > TIMEOUT_MAX:
        return f"timeout_sec бывает от 1 до {TIMEOUT_MAX} с"
    return ""


# --------------------------------------------------------------------------- #
#  Рука
# --------------------------------------------------------------------------- #

class Broker:
    """Просьбы агента к брокеру и ответы владельца. Один экземпляр на харнесс."""

    def __init__(self, tree: Path, cfg: dict | None = None):
        self.tree = Path(tree)
        self.cfg = dict(cfg or {})

    # --- чтение ------------------------------------------------------------- #

    def answers(self) -> list[dict]:
        return _rows(_load(answers_path(self.tree)), "answers")

    def asks(self) -> list[dict]:
        return _rows(_load(asks_path(self.tree)), "requests")

    def desk(self) -> tuple[bool, str]:
        """Есть ли кому показать просьбу. -> (слушают ли, слова для агента).

        Блока `desk` нет или файла нет вовсе — окна нет, и просьба не дождётся
        никого. Pid проверяем отдельно: файл ответов переписывается не по
        сердцебиению, и вчерашняя запись про закрытое окно выглядит как живая.
        """
        data = _load(answers_path(self.tree))
        block = data.get("desk")
        if not isinstance(block, dict):
            return False, ("окна Hélène нет: просьбу к брокеру некому показать "
                           "владельцу. Скажи ему словами — брокера открывает "
                           "окно, а не я")
        pid = block.get("pid")
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            pid = 0
        if pid > 0:
            try:
                import boot
                if not boot._pid_alive(pid):
                    return False, ("окно Hélène закрыто (последним его слушал "
                                   f"процесс {pid}) — просьбу к брокеру некому "
                                   "показать владельцу. Скажи ему словами")
            except Exception:
                log.debug("живость окна не спросилась", exc_info=True)
        since = str(block.get("watching_since") or "").strip()
        return True, (f"окно слушает просьбы с {since}" if since else "окно слушает просьбы")

    def service(self) -> bool | None:
        """Стоит ли служба. None — спросить не у кого. Только для честных слов."""
        try:
            import modes
            return modes.service_installed(self.cfg)
        except Exception:
            log.debug("служба не спросилась", exc_info=True)
            return None

    # --- запись ------------------------------------------------------------- #

    def save(self, rows: list[dict]) -> None:
        path = asks_path(self.tree)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(".tmp-" + path.name)
            tmp.write_text(json.dumps({"v": V, "updated_at": _stamp(),
                                       "requests": rows},
                                      ensure_ascii=False, indent=2) + "\n",
                           encoding="utf-8", newline="\n")
            os.replace(tmp, path)
        except OSError as exc:
            log.warning("брокер: просьба не записана (%s): %s", path, exc)
            return
        self._shut_out(path)

    def _shut_out(self, path: Path) -> None:
        """Закрыть файл обмена от контейнера, если ограда поднята.

        Файлы лежат в `memory`, а она выдана контейнеру на изменение. Без этого
        шага агент своей же командой `shell` переписал бы себе ответ владельца —
        прав это ему не даст (настоящую дверь держит оболочка), но обманет его
        самого, а «прибор врёт» здесь дороже всего. Права ставим ПОСЛЕ записи:
        запись идёт через os.replace, и новый файл приходит с правами папки.
        """
        try:
            import fence
            if fence.state().get("container"):
                fence.shut_out_container(Path(path), share_read=True)
        except Exception:
            log.debug("файл брокера не закрыт от песочницы", exc_info=True)

    def forget_answered(self) -> list[dict]:
        """Убрать просьбы, на которые уже ответили, и протухшие. -> что осталось."""
        rows = self.asks()
        answered = {str(r.get("id") or "") for r in self.answers()}
        now = time.time()
        left = []
        for row in rows:
            if str(row.get("id") or "") in answered:
                continue
            try:
                at = float(row.get("at_unix") or 0)
            except (TypeError, ValueError):
                at = 0.0
            if at and now - at > ASK_STALE_SEC:
                continue
            left.append(row)
        if len(left) != len(rows):
            self.save(left)
        return left

    # --- просьба ------------------------------------------------------------ #

    def ask(self, op: str, cmd: str, args, why: str, timeout_sec: int,
            wait_sec: int) -> str:
        if os.environ.get('HELENE_BROKER_DISABLED') == '1':
            return 'Брокер исключён из Python-поставки; запрос недоступен.'
        why = " ".join(str(why or "").split())
        cmd = str(cmd or "").strip()
        if isinstance(args, str):
            # Отдельная строка про строку вместо массива: это самая частая
            # ошибка вызова, и общий отказ читался бы как «мне нельзя».
            return "брокер: " + check_args(args)
        args = list(args or [])
        said = check(op, cmd, args, why, timeout_sec)
        if said:
            return f"брокер: {said}. Просьбу не записал — {executor()} отвергла бы её же"
        if LINUX and POSIX_PATHS:
            if op == "spawn_interactive":
                return "брокер Linux: доступны exec и ping; обычные процессы запускай тулом shell"
            import modes
            if modes.session0(self.cfg):
                return self.tell_linux(op, cmd, args, why, timeout_sec)
            if os.environ.get("HELENE_SUPERVISOR") == "serverboot":
                return ("брокер сервера: доступ root к хосту VPS не включён в настройках этого агента. "
                        "Разрешение выдаёт владелец на сервере; режим «Интерактивный» меняет обычные руки.")
        if DIRECT:
            return self.tell_service(op, cmd, args, why, timeout_sec)
        listening, words = self.desk()
        if not listening:
            return (f"брокер: {words}. Просьбу не записал: она протухнет через "
                    f"{ASK_STALE_SEC // 60} минут, так и не показавшись никому")
        rows = self.forget_answered()
        if len(rows) >= KEEP_ASKS:
            return (f"брокер: у владельца уже {len(rows)} неотвеченных просьб — "
                    f"новые не записываю. Дождись ответа или скажи ему словами")
        ask_id = _new_id()
        rows.append({"id": ask_id, "op": op, "cmd": cmd, "args": args, "why": why,
                     "timeout_sec": int(timeout_sec), "at_unix": int(time.time()),
                     "at": _stamp()})
        self.save(rows)
        STATE["asks"] = len(rows)
        log.info("брокер: просьба агента %s (%s): %s · %s", ask_id, op, why,
                 " ".join([cmd] + [str(a) for a in args])[:300])
        answer = self.wait(ask_id, wait_sec)
        if answer is None:
            return (f"брокер: владелец не ответил за {wait_sec} с. Это НЕ отказ: "
                    f"просьба {ask_id} ещё висит и протухнет через "
                    f"{ASK_STALE_SEC // 60} минут с записи. Посмотреть ответ "
                    f"позже — broker_request(action=\"list\"). Торопит — скажи "
                    f"владельцу словами, окно ждать не умеет")
        return "брокер: " + describe_answer(answer)

    def tell_linux(self, op: str, cmd: str, args: list, why: str, timeout_sec: int) -> str:
        ask_id = _new_id()
        try:
            host_socket = (os.environ.get("HELENE_HOST_BROKER_SOCKET") or "").strip() \
                if os.environ.get("HELENE_SUPERVISOR") == "serverboot" else ""
            payload = {"op": op, "argv": [cmd, *args] if op != "ping" else [],
                       "why": why, "timeout_sec": timeout_sec}
            reply = (call_linux(payload, timeout_sec + PIPE_SLACK, socket_path=host_socket)
                     if host_socket else call_linux(payload, timeout_sec + PIPE_SLACK))
            row = {"id": ask_id, "decision": "done" if reply.get("ok") else "refused",
                   "note": reply.get("error") or reply.get("note") or "",
                   "out": reply.get("out") or "", "err": reply.get("err") or "",
                   "ms": reply.get("ms")}
            if op != "ping" and reply.get("ok"):
                row["code"] = reply.get("code")
        except (OSError, ValueError) as exc:
            note = ("Владелец сервера должен подготовить host-access и подключить его сокет; "
                    "смена режима сама не создаёт root-брокер"
                    if os.environ.get("HELENE_SUPERVISOR") == "serverboot"
                    else "Включи брокер через выбор нулевой сессии в настройках")
            row = {"id": ask_id, "decision": "failed", "note": f"{exc}. {note}"}
        _remember(row)
        return "брокер: " + describe_answer(row)

    def tell_service(self, op: str, cmd: str, args: list, why: str, timeout_sec: int) -> str:
        """Windows: поручение службе по трубе, без окна и без «да» (см. `DIRECT`)."""
        token = read_token(self.tree)
        if not token:
            installed = self.service()
            return ("брокер: службы Hélène нет — поручать некому" if installed is False else
                    "брокер: токена службы нет (memory/.state/broker-token) — служба не "
                    "поставлена или ещё не стартовала")
        ask_id = _new_id()
        payload = {"v": V, "id": ask_id, "token": token, "op": op, "cmd": cmd,
                   "args": [str(a) for a in args], "why": why, "timeout_sec": int(timeout_sec)}
        log.info("брокер: поручение службе %s (%s): %s · %s", ask_id, op, why,
                 " ".join([cmd] + [str(a) for a in args])[:300])
        try:
            receipt = call_service(pipe_name(install_root()), payload,
                                   float(timeout_sec) + PIPE_SLACK)
        except OSError as exc:
            row = {"id": ask_id, "decision": "failed", "note": str(exc)}
            _remember(row)
            return "брокер: " + describe_answer(row)
        row = {"id": receipt.get("id") or ask_id,
               "decision": "done" if receipt.get("ok") else "refused",
               "note": str(receipt.get("note") or "").strip(),
               "out": receipt.get("out") or "", "err": receipt.get("err") or "",
               "ms": receipt.get("ms")}
        if receipt.get("ok") and op != "ping":
            row["code"] = receipt.get("code")
        _remember(row)
        log.info("брокер: квитанция %s: %s", row["id"], row["decision"])
        return "брокер: " + describe_answer(row)

    def wait(self, ask_id: str, wait_sec: int) -> dict | None:
        """Дождаться ответа на свою просьбу. None — не дождались."""
        deadline = time.time() + max(0, int(wait_sec))
        while True:
            for row in self.answers():
                if str(row.get("id") or "") == ask_id:
                    # Оболочка только что переписала файл ответов через rename,
                    # то есть принесла новый файл с правами папки: сужение,
                    # поставленное на установке, на нём не живёт. Ставим снова
                    # ровно в тот момент, когда оно потерялось.
                    self._shut_out(answers_path(self.tree))
                    self.forget_answered()
                    return row
            if time.time() >= deadline:
                return None
            time.sleep(0.7)

    # --- список ------------------------------------------------------------- #

    def listing(self) -> str:
        if LINUX and POSIX_PATHS:
            if os.environ.get("HELENE_SUPERVISOR") == "serverboot":
                import modes
                return "\n".join(["Root на хосте VPS: " + ("запрошен в конфиге; разрешение и связь проверяет ping"
                    if modes.session0(self.cfg) else "не запрошен в конфиге"),
                    *[describe_answer(r) for r in RECENT]])
            import modes
            if modes.session0(self.cfg):
                return "\n".join(["Нулевая сессия: root-брокер выполняет exec без polkit и пароля. "
                                  "Журнал: /var/lib/helene/broker.log.",
                                  *[describe_answer(r) for r in RECENT]])
        if DIRECT:
            installed = self.service()
            out = ["Поручения идут службе напрямую: с включённым тумблером нулевой сессии "
                   "она выполняет exec сразу, без вопроса владельцу. Журнал — broker.log.",
                   {True: "служба установлена — брокер есть",
                    False: "службы нет — поручать некому",
                    None: "стоит ли служба, спросить не у кого"}[installed]]
            if RECENT:
                out.append("Последние квитанции:")
                out += ["  " + describe_answer(r) for r in RECENT]
            else:
                out.append("Квитанций в этом запуске ещё не было.")
            return "\n".join(out)
        rows = self.forget_answered()
        answers = self.answers()[-8:]
        listening, words = self.desk()
        out = [words if listening else f"⚠ {words}"]
        if sys.platform == "darwin":
            # Службы нет как механизма: брокер — само окно, а пароль
            # администратора спрашивает система. Спрашивать SCM не о чем.
            out.append("брокер здесь — само окно: просьбу подписывает владелец, "
                       "пароль администратора для exec спрашивает система")
        else:
            installed = self.service()
            out.append({True: "служба установлена — брокер есть",
                        False: "службы нет — повышать права некому, любая просьба "
                               "получит отказ",
                        None: "стоит ли служба, спросить не у кого"}[installed])
        if rows:
            out.append("Ждут владельца: " + "; ".join(
                f"{r.get('id')} — {r.get('why')}" for r in rows))
        else:
            out.append("Ждущих просьб нет.")
        if answers:
            out.append("Последние ответы:")
            out += ["  " + describe_answer(r) for r in answers]
        else:
            out.append("Ответов ещё не было.")
        return "\n".join(out)


def _new_id() -> str:
    """Свой на просьбу, из знаков, которые примет оболочка ([A-Za-z0-9_-])."""
    return time.strftime("%H%M%S") + "-" + os.urandom(3).hex()


def describe_answer(row: dict) -> str:
    """Квитанция человеческими словами. Не «успех», а что именно вышло."""
    decision = str(row.get("decision") or "")
    head = {"allowed": "владелец разрешил", "refused": "ОТКАЗ",
            "done": "служба выполнила",
            "failed": "не вышло"}.get(decision, decision or "ответ")
    parts = [f"{row.get('id')}: {head}"]
    note = str(row.get("note") or "").strip()
    if note:
        parts.append(note)
    if "code" in row:
        code = row.get("code")
        parts.append("код возврата не пришёл — команда не завершилась"
                     if code is None else f"код возврата {code}")
    for key, title in (("out", "вывод"), ("err", "ошибки")):
        text = str(row.get(key) or "").strip()
        if text:
            parts.append(f"{title}: {text[:2000]}")
    if row.get("ms") is not None:
        parts.append(f"{row.get('ms')} мс")
    return " · ".join(parts)


# --------------------------------------------------------------------------- #
#  Схема руки и выдача её агенту
# --------------------------------------------------------------------------- #

def tool_schema(*, mac: bool | None = None, linux: bool | None = None) -> dict:
    """Схема тула по платформе. На Windows просьбу исполняет служба, на macOS —
    само окно, а права администратора выдаёт системный диалог пароля; слова
    «служба Windows» и «нулевая сессия» на Mac были бы обещанием того, чего нет.
    """
    linux = (LINUX and mac is None) if linux is None else linux
    mac = (sys.platform == "darwin") if mac is None else mac
    if linux:
        description = (
            "Выполнить команду с правами root через broker_request. action=ask: "
            "op=exec (команда) или ping (проверка связи), cmd — абсолютный путь "
            "(/usr/bin/id), args — массив строк, why — зачем, одной строкой. "
            "При service.session0=true поручение идёт root-службе напрямую, "
            "без polkit, пароля и открытого окна; журнал /var/lib/helene/broker.log. "
            "При выключенной нулевой сессии просьбу исполняет открытое окно Hélène: "
            "для каждого exec система спрашивает пароль администратора через polkit; "
            "отмена — отказ. action=list — квитанции или ждущие просьбы. "
            "Квитанция содержит код возврата, stdout, stderr и длительность.")
        if os.environ.get("HELENE_SUPERVISOR") == "serverboot":
            description = (
                "Root на хосте VPS через отдельный брокер, если владелец выдал разрешение и "
                "service.session0=true. Режим interactive сам root не выдаёт. action=ask, op=ping "
                "проверяет связь; op=exec, cmd — абсолютный путь, args — массив строк, why — зачем. "
                "Квитанция называет область host; /usr/bin/id -u отдельно проверяет фактический UID. "
                "Окно/polkit на сервере не используются. action=list — квитанции. "
                "Panic и отзыв разрешения прекращают команды. При потере квитанции сверяй эффект "
                "и журнал владельца: произвольный exec нельзя автоматически повторять.")
        cmd_words = "программа абсолютным путём"
    elif mac:
        description = (
            "Попросить владельца выполнить одну команду с правами, которых у тебя "
            "нет. Ты не «становишься администратором»: просьбу читает владелец в "
            "системном диалоге, видит саму команду и твоё «зачем», и только по его "
            "«да» её выполняет окно Hélène. Отказ тоже записывается.\n"
            "action=ask — попросить: op = spawn_interactive (правами владельца, в "
            "его сессии) | exec (правами администратора: система сама спросит у "
            "владельца пароль) | ping (проверка связи, ничего не выполняет); cmd — "
            "программа АБСОЛЮТНЫМ путём (/usr/bin/id, /usr/sbin/…); args — массив "
            "строк, никогда одна строка; why — зачем, одной строкой, это читает "
            "владелец.\n"
            "action=list — что ждёт ответа и что уже ответили.\n"
            "Брокер здесь — само окно Hélène: окно закрыто — просьбу некому "
            "показать, и я скажу об этом сразу. Ответ приходит минуты; «владелец "
            "не ответил» — это не «отказал».\n"
            "У exec подпись владельца — это и есть диалог пароля: постоянного "
            "разрешения, которое сняло бы его насовсем, здесь нет и не будет. "
            "Каждый exec — отдельный пароль, и отмена диалога это отказ. "
            "Владелец может выключить брокера целиком (Настройки → Система); "
            "тогда просьбы получают отказ сразу, без окна.")
        cmd_words = "программа абсолютным путём"
    else:
        description = (
            "Поручить службе Hélène одну команду, которой нужны другие права или "
            "другой хозяин процесса. Служба выполняет поручение сразу и отдаёт "
            "квитанцию: код возврата, вывод, ошибки, длительность. Каждое "
            "поручение — в журнале службы (broker.log).\n"
            "action=ask — поручить: op = exec (правами СИСТЕМЫ; служба выполняет, "
            "только если владелец включил в Настройках тумблер нулевой сессии, "
            "иначе отказ её словами) | spawn_interactive (процесс правами "
            "владельца в его сессии, отдельно от тебя: он переживает твой "
            "перезапуск — так запускают установщик Hélène) | ping (проверка связи); "
            "cmd — программа ПОЛНЫМ путём (C:\\Windows\\System32\\netsh.exe); "
            "args — массив строк, никогда одна строка; why — зачем, одной строкой, "
            "это пишется в журнал.\n"
            "action=list — последние квитанции.\n"
            "Службы нет — придёт отказ сразу.")
        cmd_words = "программа полным путём"
    props = {
        "action": {"type": "string", "enum": ["ask", "list"],
                   "description": ("ask — попросить, list — ждущие просьбы и ответы" if mac
                                   else "ask — поручить, list — последние квитанции")},
        "op": {"type": "string", "enum": ["ping", "exec"] if linux else list(OPS),
               "description": ("ping | " if linux else "ping | spawn_interactive (правами владельца) | ")
                              + ("exec (правами root)" if linux else "exec (правами администратора)" if mac
                                 else "exec (правами СИСТЕМЫ)")},
        "cmd": {"type": "string", "description": cmd_words},
        "args": {"type": "array", "items": {"type": "string"},
                 "description": "аргументы массивом строк"},
        "why": {"type": "string", "description": ("зачем, одной строкой — это читает владелец"
                                                  if mac else "зачем, одной строкой — в журнал службы")},
        "timeout_sec": {"type": "integer",
                        "description": f"сколько ждать саму команду, 1..{TIMEOUT_MAX} с"},
    }
    if mac or linux:
        # На Windows ждать некого: служба отвечает квитанцией сама (`DIRECT`).
        props["wait_sec"] = {"type": "integer",
                             "description": f"сколько ждать ответа владельца, 0..{WAIT_MAX} с"}
    return {
        "name": "broker_request",
        "description": description,
        "input_schema": {"type": "object", "properties": props},
    }


#: Схема для ЭТОЙ платформы — её и выдаёт `install`.
TOOL = tool_schema()


def _hand(broker: "Broker"):
    def broker_request(action: str = "ask", op: str = "spawn_interactive",
                       cmd: str = "", args=None, why: str = "",
                       timeout_sec: int = TIMEOUT_DEFAULT,
                       wait_sec: int = WAIT_DEFAULT) -> str:
        try:
            action = str(action or "ask").strip().lower()
            if action == "list":
                return broker.listing()
            if action != "ask":
                return "broker_request: action бывает ask или list"
            try:
                timeout_sec = int(timeout_sec)
            except (TypeError, ValueError):
                return "broker_request: timeout_sec — это число секунд"
            try:
                wait_sec = max(0, min(WAIT_MAX, int(wait_sec)))
            except (TypeError, ValueError):
                wait_sec = WAIT_DEFAULT
            return broker.ask(str(op or "").strip().lower(), cmd, args, why,
                              timeout_sec, wait_sec)
        except Exception as exc:                      # рука не роняет ход
            log.exception("broker_request упал")
            return f"broker_request: не вышло — {exc}"

    return broker_request


def install(agent_mod, tree: Path, cfg: dict | None = None) -> None:
    """Выдать агенту руку брокера. Ничего не роняет: не вышло — записано почему.

    Приём тот же, что у `fence._offer_mount_hand`: дерево — код владельца, его
    править нельзя, поэтому схема дописывается в `BASE_TOOLS`, а исполнение — в
    `TOOL_IMPL`. Без записи в `BASE_TOOLS` модель об этой руке просто не узнает.
    """
    if os.environ.get('HELENE_BROKER_DISABLED') == '1':
        impl = getattr(agent_mod, 'TOOL_IMPL', {})
        if isinstance(impl, dict):
            impl.pop('broker_request', None)
        tools = getattr(agent_mod, 'BASE_TOOLS', None)
        if isinstance(tools, list):
            tools[:] = [t for t in tools if not isinstance(t, dict) or t.get('name') != 'broker_request']
        STATE.update({'hand': False, 'desk': '', 'asks': 0, 'answers': 0,
                      'note': 'Брокер исключён из Python-поставки; повышение прав недоступно.'})
        return
    if not HAS_BROKER:
        # Брокера на этой платформе нет (прочие POSIX): просьбы о правах
        # исполняет служба Windows или оболочка на macOS, здесь их подписывать
        # некому. Тул не выдаём: обещать модели тул, который откажет всегда,
        # хуже, чем не иметь его. Секции в снимке нет — только строка в журнал.
        STATE.update({"hand": False, "desk": "", "asks": 0, "answers": 0,
                      "note": "брокера в этой сборке нет — просьбы о правах подавать некому"})
        log.info("брокер: %s", STATE["note"])
        return
    broker = Broker(Path(tree), cfg)
    impl = getattr(agent_mod, "TOOL_IMPL", None)
    if not isinstance(impl, dict):
        log.warning("брокер: рука не выдана — у дерева нет TOOL_IMPL")
        return
    if impl.get(TOOL["name"]) is None:
        impl[TOOL["name"]] = _hand(broker)
        tools = getattr(agent_mod, "BASE_TOOLS", None)
        if isinstance(tools, list) and not any(
                isinstance(t, dict) and t.get("name") == TOOL["name"] for t in tools):
            tools.append(dict(TOOL))
    # Owner requested the complete schema in the model frame, also with tool pointers on.
    native = getattr(agent_mod, "NATIVE_HAND_NAMES", None)
    if isinstance(native, (set, frozenset)):
        agent_mod.NATIVE_HAND_NAMES = frozenset(native) | {TOOL["name"]}
    if LINUX and POSIX_PATHS:
        STATE.update({"hand": True, "desk": "", "asks": 0, "answers": 0,
                      "note": "Linux: нулевая сессия — root-сокет без пароля; интерактивный exec — пароль через окно"})
        if os.environ.get("HELENE_SUPERVISOR") == "serverboot":
            STATE['note'] = "Root хоста VPS — отдельное разрешение владельца и подключённый host-брокер; доступ проверяет ping/exec"
        log.info("брокер: схема broker_request добавлена; Linux root-сокет и интерактивный polkit")
        return
    if DIRECT:
        STATE.update({"hand": True, "desk": "", "asks": 0, "answers": 0,
                      "note": "поручения идут службе напрямую, квитанцией; exec — "
                              "при включённом тумблере нулевой сессии"})
        log.info("брокер: рука broker_request выдана агенту · поручения — службе по трубе %s",
                 pipe_name(install_root()))
        return
    listening, words = broker.desk()
    left = broker.forget_answered()
    # Файл ответов пишет оболочка, и каждый её `rename` приносит новый файл с
    # правами папки: сужение живёт до следующего ответа, поэтому ставим его и
    # здесь, и после каждой своей записи.
    broker._shut_out(answers_path(Path(tree)))
    STATE.update({"hand": True, "desk": words, "asks": len(left),
                  "answers": len(broker.answers()),
                  "note": ((f"просьбы показывает окно; {executor()} выполняет их "
                            "квитанцией") if listening else
                           "просить сейчас некого — окна нет")})
    log.info("брокер: рука broker_request выдана агенту · %s · ждущих просьб %d",
             words, len(left))


def state() -> dict:
    return dict(STATE)
